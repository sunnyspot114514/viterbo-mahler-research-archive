# v49：径向折点的统一接触下界、联合逼近障碍与文献接口审计

日期：2026-09-25。

## 状态

本轮从 v48 继续，补查 11 项外部文献，写出两个解析证明候选并完成独立有理几何核验。主结果不是完整四维中心对称 Mahler 的证明：它处理下述指定接触方向上的一类三维底体。一般 CE、全部 lambda=1 粘合、lambda=2、无低阶分离核心仍未关闭。没有重跑或重新认证 v1–v48 的历史穷尽性。

计算证书只检查列明的符号恒等式、有限线性代数和有理多胞体，未形式化一般解析证明及外部定理；本报告未经过外部同行审阅，不主张文献优先权。

## 1. 目标与文献纠偏

项目目标为：对任意满维 K=-K⊂R^4，M_4(K)=|K||K°|≥32/3。

一般 Viterbo 容量—体积猜想已有反例，Haim-Kislev–Ostrover 的论文于 2026-03-01 在 Annals of Mathematics 正式在线发表 [9]。这不否定中心对称 Mahler。AAKO [8] 证明对 K=-K⊂R^n，c_HZ(K×K°)=4；在凸域上这里是相应的 EHZ 容量。因此为证明四维 Mahler，相关特殊乘积在 R^8，而不是 R^4。把已有平面 billiard／四维辛域结果直接称为四维 Mahler 的证明，是维数混淆。

本轮实际依赖的外部解析输入只有：三维中心对称 Mahler [1]、等分充分条件 [2]，以及支撑函数、平面混合面积和 Brunn–Minkowski 的标准事实。2026 年 shadow-flow 预印本 [5] 不作为本轮主定理的必要输入。

## 2. 接触量与主定理

令 D=-D⊂R^2 为任意满维紧凸体，g=g_D 为其 Minkowski 泛函。令 φ:[0,1]→[0,∞) 连续、凹、非增，φ(0)=1。令 m:D→R 连续、奇，满足

    f(z)=φ(g(z)),    f+m 与 f−m 都凹。

定义

    C={(t,z): z∈D, |t−m(z)|≤f(z)},    e=(1,0,0),
    Q(C,ae)=conv({0}×C, [-1,1]×[-ae,ae]),   0≤a≤1。

C 是满维中心对称凸体，e 是其中心径向端点。记 V=|C|、W=|C°|、J=∫_{C°}|y_t|dy、A_D=|D|。直接切片及取极体给出

\[
 |Q(C,ae)|=V/2+aA_D/3,
 \qquad |Q(C,ae)^\circ|=2(W-aJ),
\]
\[
 E_C(ae)=M_4(Q(C,ae))=(V+\tfrac23aA_D)(W-aJ). \tag{2.1}
\]

### 定理 A：任意凹径向轮廓＋齐次中点

在上述假设下，再假设 m(rz)=r m(z)（0≤r≤1）。则

\[
 \boxed{E_C(ae)\ge32/3\qquad(0\le a\le1).} \tag{A}
\]

φ 可以有任意多个折点，也可以不是分片仿射。D 不要求为多边形，m 不要求线性。齐次中点的假设在定理 A 中不可自行删去。

### 定理 B：有限径向折点强迫齐次中点

若 φ 是有限分片仿射函数，则在上述凸性及奇性假设下，任意合法 m 自动沿径向一次齐次。因此对这一整个类别，(A) 不需要另外假设中点齐次。

这严格扩展 v48 的 φ(r)=1−τr。它没有覆盖任意一般分片仿射 f(z)：这里仍要求 f 的水平集同心同似，即 f=φ∘g_D。这个条件只约束半弦长，不是说 C 的水平截面全部同似。

## 3. 定理 A 的支撑函数表示

令 τ=−φ'_+(0)。凹性、非增性和 φ(1)≥0 保证 0≤τ≤1，且

\[
 \phi(r)\le1-\tau r,\qquad \phi(r)\ge1-r. \tag{3.1}
\]

先设 τ>0。因为 m 齐次，对每个固定 z，

\[
 \frac{1-f(\varepsilon z)\mp m(\varepsilon z)}\varepsilon
 \longrightarrow \tau g(z)\mp m(z).
\]

左侧为凸函数，极限仍凸。故

\[
 h_A(z)=g(z)-m(z)/\tau
\]

是有限、凸、正齐次函数，即某个满维平面凸体 A 的支撑函数。记 B=D°，由奇性得

\[
 \boxed{(A-A)/2=B.} \tag{3.2}
\]

A 不必包含原点；平移 A 对应沿 e 方向的线性剪切。令

\[
 \mu=|D||B|,\quad \rho=|A|/|B|,\quad\delta=1-\rho.
\]

Brunn–Minkowski 给出 0<ρ≤1，故 0≤δ<1。平面混合面积满足

\[
 V_2(B,A)=|B|. \tag{3.3}
\]

证明：2B=A+(−A)，所以 4|B|=2|A|+2V_2(A,−A)，再用双线性。

若 τ=0，则 m 与 −m 都凸，m 必须线性。剪切后取 m=0，直接使用第 5 节的对称基准与二维 Mahler 下界即可。

## 4. 极体切片与精确积分

定义

\[
 \beta(s)=\inf_{0<r\le1}\frac{1-s\phi(r)}r,\qquad0\le s\le1. \tag{4.1}
\]

由 (3.1)，

\[
 1-s+\tau s\le\beta(s)\le1-s\phi(1)\le1. \tag{4.2}
\]

令 K=C°。在 s≥0 的高度上，极性条件为

    <y,z>+s m(z)+s f(z)≤1 对所有 z∈D。

写 z=ru、g(u)=1，并利用 m 齐次，得到

    <y,u>≤β(s)−s m(u)。

右侧是支撑函数 (β(s)−τs)h_B(u)+τs h_A(u)，两项系数均非负，所以

\[
 \boxed{K_s=(\beta(s)-\tau s)B+\tau sA.} \tag{4.3}
\]

负高度由中心对称覆盖。混合面积给出

\[
 \boxed{|K_s|=|B|\left(\beta(s)^2-\delta\tau^2s^2\right).} \tag{4.4}
\]

记

\[
 I=\int_0^1r\phi(r)\,dr,
 \quad H=\int_0^1\beta(s)^2ds,
 \quad L=\int_0^1(1-s)\beta(s)^2ds.
\]

则

\[
 V=4|D|I,
 \qquad W=2|B|(H-\delta\tau^2/3),
\]
\[
 W-J=2|B|(L-\delta\tau^2/12).
\]

因此

\[
 \boxed{E_C(e)=8\mu(I+\tfrac16)(L-\delta\tau^2/12).} \tag{4.5}
\]

另外 (4.2) 及 (3.1) 给出

\[
 I\ge1/6,\qquad
 L\ge1/4+\tau/6+\tau^2/12,
\]
\[
 \boxed{L-\tau^2/4\ge1/4+\tau(1-\tau)/6\ge1/4.} \tag{4.6}
\]

## 5. 一维标量不等式的已知几何证明

需要

\[
 \boxed{(I+\tfrac16)L\ge1/6.} \tag{5.1}
\]

这一步不假设一般四维 Mahler。取 D0=[−1,1]^2，m0=0，半弦长 φ(||z||∞)，构造 C0 和 Q0。Q0 分别关于四个坐标反射不变，因此坐标超平面将其分成 16 个等体积块，同时将每个中心三维坐标截面分成 8 个等体积块。所有这些三维截面均满足 [1] 的下界。FHMRZ [2, Proposition 2] 的全部假设满足，所以 M_4(Q0)≥32/3。

对这个基准 μ0=8、δ0=0，(4.5) 变成 M_4(Q0)=64(I+1/6)L，立即得到 (5.1)。这只是对一个坐标反射类使用已知充分条件，不声称任意四维凸体都存在相同等分。

## 6. 三维差体余量补偿非对称中点损失

由同一个 A 构造辅助三维凸体

\[
 C_*^\circ=\operatorname{conv}(\{1\}\times A,\{-1\}\times(-A)).
\]

它的零高度截面为 B，极体 C_* 的半弦长为 1−g_D，中点为 g_D−h_A。直接混合面积积分（也等于 v48 τ=1 公式）给出

\[
 M_3(C_*)=\frac{4\mu}{9}(2+\rho)=\frac{4\mu}{9}(3-\delta).
\]

由已发表的三维中心对称 Mahler 定理 [1]，

\[
 \boxed{\mu(3-\delta)\ge24.} \tag{6.1}
\]

令 A0=I+1/6。下面是精确恒等式：

\[
\begin{aligned}
 E_C(e)-64A_0L={}&
 8A_0\left(\mu-\frac{24}{3-\delta}\right)
       \left(L-\frac{\delta\tau^2}{12}\right)\\
 &+\frac{64A_0\delta}{3-\delta}\left(L-\frac{\tau^2}{4}\right).
\end{aligned} \tag{6.2}
\]

(4.6) 和 (6.1) 使两项均非负，再由 (5.1)，得到 E_C(e)≥32/3。这完成定理 A 在 a=1 的证明。

若 m 不是线性函数，则 A 不是 B 的平移，Brunn–Minkowski 等号条件给出 δ>0。因此本轮还有一个非锐显式余量：

\[
 E_C(e)\ge\frac{32}{3}+\frac{16\delta}{3(3-\delta)}.
\]

这个较粗余量只在 τ>0 的表示下使用，不替代 v48 的逐 τ 锐余量。

最后，(2.1) 对 a 是凹二次式。a=0 是 M_3(C)≥32/3，a=1 已证明，所以全部 0≤a≤1 都满足下界。

## 7. 定理 B：多个径向折点为何不产生新的中点自由度

写 0=r0<r1<...<rN=1，在每个开区间 (r_{i−1},r_i) 上 φ(r)=c_i−k_i r。

### 7.1 每条射线上的仿射性

在同一个径向环带内，f 沿射线仿射。f+m 与 f−m 的两个 Jensen 非负余量之和为零，故 m 也沿该射线仿射：

    m(ru)=r a_i(u)+b_i(u)。

剩下要证明截距 b_i(u) 不能随方向变化。这一步不能仅凭射线上的仿射性省略。

### 7.2 截距在整个环带内为常数

f±m 为有限凹函数，所以在 int(D) 局部 Lipschitz，m 也局部 Lipschitz。固定环带内一点及足够小的邻域 U，选择固定 0<λ1<λ2，使 λ1 z、λ2 z 及其连接线段对所有 z∈U 都留在该环带。

在几乎处处可微的 z 上，凹函数 f+m 在 [λ1 z,λ2 z] 上仿射，因此两端的梯度相同：一端的支撑平面同时支撑另一端，而可微时支撑梯度唯一。由于 f=c_i−k_i g 的梯度沿射线也相同，得到

    ∇m(λ1 z)=∇m(λ2 z)  a.e.。

定义射线截距函数

\[
 b_i(z)=\frac{\lambda_2m(\lambda_1z)-\lambda_1m(\lambda_2z)}{\lambda_2-\lambda_1}.
\]

局部的定义相互兼容，因为 m 在射线上仿射。它局部 Lipschitz，且上式梯度为零 a.e.，故局部常数。二维径向环带连通，故它是全局常数。奇性给出 b_i(−z)=−b_i(z)，所以 b_i=0。

这里横向维数至少为二、环带连通是论证的一部分；不能把这一论证无条件移植到一维的两个不连通区间。

### 7.3 跨折点拼接

于是每个环带内 m(ru)=r a_i(u)。在 r_i>0 处连续，强迫 a_i(u)=a_{i+1}(u)。有限多个环带全部拼接后，m 在整个 D 上一次齐次。原点和边界由连续性补上。

这完成定理 B。随后应用定理 A 即覆盖任意有限数量的同心同似径向折点。

## 8. 为什么不能再用一个“逼近”句子推出一般径向情形

在 D=B_2^2 上取

\[
 f(x,y)=1-x^2-y^2,\qquad m(x,y)=x^3/4.
\]

m 连续、奇，且

\[
 \nabla^2(f\pm m)=\operatorname{diag}(-2\pm3x/2,-2)
\]

在整个单位圆盘上负定，所以 f±m 都凹。这是合法的非齐次中点。

对 u=(1,0)、r=1/2，有

\[
 m(ru)-r m(u)=-3/32\ne0.
\]

如果 h 一次齐次且 ||m−h||∞≤ε，那么

    3/32≤(1+r)ε=3ε/2，

故

\[
 \boxed{\inf_{h\text{ 齐次}}\|m-h\|_\infty\ge1/16.} \tag{8.1}
\]

因此，把 φ(r)=1−r² 用有限分片仿射 φ_j 逼近，同时要求 m_j 对 φ_j∘g_D 合法，不能使 m_j 一致逼近这个 m：定理 B 会迫使所有 m_j 齐次，(8.1) 阻止联合逼近。

这是对“这种联合逼近足以覆盖一般 CE”论证的反例，不是 Mahler 或 CE 本身的反例。本轮没有计算这个光滑例子的 CE 是否达到某个极值。

## 9. 对一般 CE 的一次整体尝试：三维截断余量积分

对任意三维中心对称 C 和其径向端点 e，不再假设径向轮廓或中点齐次。令 K=C°，并在 0<s≤1 定义

\[
 C_s=\operatorname{conv}(C,\pm e/s),\qquad
 C_s^\circ=K\cap\{|y_t|\le s\}.
\]

Fubini 给出

\[
 W-J=\int_0^1|C_s^\circ|\,ds.
\]

令 d=2|D|/3、M0=32/3，则有精确余量恒等式

\[
\begin{aligned}
 E_C(e)-M_0={}&(V+d)\int_0^1
 \frac{M_3(C_s)-M_0}{|C_s|}\,ds\\
 &+M_0\left((V+d)\int_0^1\frac{ds}{|C_s|}-1\right). \tag{9.1}
\end{aligned}
\]

第一项非负，但第二项不保证非负，因此不能只把三维 Mahler 的常数逐项代入。

例如由可见面锥体分解，对 h≥1 有

\[
 |\operatorname{conv}(C,\pm he)|\le V+d(h-1).
\]

对多胞体，这来自新增两侧锥体体积的导数不超过 2|D|/3；一般凸体由逼近得到。记 α=V/d∈[1,3]。只使用该上界和 M_3(C_s)≥M0，得到

\[
 E_C(e)\ge M_0\frac{(\alpha+1)(\alpha-1-\log\alpha)}{(\alpha-1)^2},
\]

α=1 取连续极限。α=3 时右侧为 M0(2−log3)≈9.614802，低于目标 10.666667。

所以这条整体尝试没有完成一般 CE，但明确了需要的信息：必须把三维族 C_s 的真实 Mahler 余量保留下来，证明其加权积分补偿第二项。FHMRZ [2] 包含三维稳定性结果，是相关的文献入口；本轮没有从中提取到能够证明所有 C 都满足 (9.1)≥0 的有效统一估计。不能把这条新的等价补偿目标写成已证明的引理。

## 10. 精确计算结果

所有数值为 Fraction 精确数。给定有理分片仿射 φ，通过正半径节点得到 β 的有限条直线下包络；积分是有理多项式积分。3D 原像/极体和 4D 原像/极体独立从全部满秩半空间子集重建，体积由统一顺序的 pulling triangulation 计算，检验边界脊关联次数为 2。

本轮核验：

- 7 组三维完整原像/极体/绝对矩重构；
- 其中 3 组独立四维原像/极体重构；
- 35 个平面极体切片独立重构并逐顶点比对 Minkowski 公式；
- 正方形与六边形上分别采用 1、2、4 个径向区间，6 个完整线性系统，均验证中点截距全部为零、跨环带梯度相同；
- 符号验证余量恒等式、β 积分下界、光滑反例的 Hessian 与 1/16 非逼近界。

一个两折点非线性中点样本：A=conv{(1,0),(0,1),(−1,−1)}，B=(A−A)/2，D=B°，τ=1/4，轮廓节点为

    (0,1), (1/3,11/12), (2/3,2/3), (1,1/6)。

得到 C:38V/36F，Q:40V/66F，且

\[
 M_4(Q)=791562649/55566000>32/3.
\]

它不属于 v48 的单段径向仿射类别；ρ=2/3<1，指定方向的中点也不能通过线性剪切归零。

详细全部坐标、切片和体积数据保存在 radial_profile_certificate.json。replay.py --rebuild 在干净临时目录重新生成并逐字节比对该证书。原始 v48 ZIP 的哈希保存在 provenance.json；本轮只复用其 exact_geometry.py，不把旧 PASS 当作新一般定理的证书。

## 11. 文献接口：11 项来源及不能越过的边界

[1] H. Iriyeh, M. Shibata, *Symmetric Mahler's conjecture for the volume product in the three dimensional case*. Duke Math. J. 169 (2020), 1077–1134. arXiv:1706.01749. https://arxiv.org/abs/1706.01749
用途：已发表的三维下界，是 (6.1) 与 a=0 的输入。

[2] M. Fradelizi, A. Hubard, M. Meyer, E. Roldán-Pensado, A. Zvavitch, *Equipartitions and Mahler volumes of symmetric convex bodies*. arXiv:1904.10765v3. https://arxiv.org/html/1904.10765v3
核对：Proposition 2 要求总体等分且每个中心截面也等分，不只要求总量等分；本轮只对 Q0 坐标反射类应用。论文也给出三维稳定性结果。

[3] M. Meyer, S. Reisner, *Shadow systems and volumes of polar convex bodies*. arXiv:math/0606305v2. https://arxiv.org/html/math/0606305v2
用途：固定半弦长中点线段上的极体体积倒数凸性；不是任意多方向 deformation 的凸性。

[4] M. Fradelizi, E. Nakhle, *On Mahler's conjecture for even s-concave functions in dimensions 1 and 2*. arXiv:2412.12372v2 (2025-06-25). https://arxiv.org/html/2412.12372v2
核对：Theorem 1.3 的 s>0、1/s 为整数和偶性；Section 2.1 的 K_{L,m}(f) 使用固定同似纤维 L，不能直接覆盖任意 set-valued fibers。负 s 的结果还有额外渐近条件。

[5] S. Chen, Y. Li, D. Xi, Z.-F. Xu, *The Mahler Conjecture in Three Dimensions*. arXiv:2605.09334v3 (2026-06-15). https://arxiv.org/abs/2605.09334 ; https://arxiv.org/html/2605.09334v3
更新：v3 合并原非对称与对称两稿，不应把 2605.13795 另算为独立证明。Section 5 的计数明确使用三维 Euler 关系及二维 facet，不能直接移到四维。本轮把它作为候选方法来源，而非必需前提。

[6] A. Guberman, *A connection between the Mahler conjecture and floating bodies*. arXiv:2608.10994v1 (2026-08-11). https://arxiv.org/html/2608.10994v1
核对：对至多 l 个顶点的中心对称多胞体类内的局部极小者给出面／顶点度数必要条件；不是所有一般凸体极小者都是多胞体的定理。是预印本。

[7] M.-C. Brandenburg, M. Grillo, C. Hertrich, *Decomposition Polyhedra of Piecewise Linear Functions*. arXiv:2410.04907v1. https://arxiv.org/html/2410.04907v1
用途：固定多面体剖分下的平衡折痕权重与凸性、有限维分解多面体。固定剖分的有限性不等于不限制组合复杂度的有限归约。

[8] S. Artstein-Avidan, R. Karasev, Y. Ostrover, *From Symplectic Measurements to the Mahler Conjecture*. arXiv:1303.4197. https://arxiv.org/abs/1303.4197
核对 PDF 第 4 页 Theorem 1.7 与第 5 页推论：K⊂R^4 对应 K×K°⊂R^8；已知容量等于 4，所缺的是特殊乘积的锐体积下界。

[9] P. Haim-Kislev, Y. Ostrover, *A counterexample to Viterbo's conjecture*. Ann. Math. 203 (2026), 603–622, online 2026-03-01. https://annals.math.princeton.edu/2026/203-2/p05 ; https://arxiv.org/html/2405.16513v3
作用：排除证明一般 Viterbo 的路线；正文 Question 1 单独保留中心对称类问题。不能把反例说成否定本项目的对称 Mahler。

[10] A. Balitskiy, I. Mitrofanov, A. Polyanskii, *Triangle covering problems and the Viterbo inequality in the plane*. arXiv:2603.12495v1 (2026-03-12). https://arxiv.org/html/2603.12495v1
核对：主结果 K,Q⊂R^2，Q 为任意四边形（亦处理仿射正六边形）；辛乘积在 R^4。对 Minkowski billiard 有启发，但不是 K⊂R^4 的 Mahler 下界。

[11] M. Fradelizi, A. Hubard, A. Manui, C. S. Ndiaye, S. Wang, A. Zvavitch, *Volume and Projection Inequalities I: Zonoids and Courtade's Conjecture*. arXiv:2608.12681 (2026-08-13). https://arxiv.org/abs/2608.12681
读取层级：核对 arXiv 摘要和元数据，未完成全文证明复核。摘要报告：degree/codegree≤3 的 Rayleigh 性，以及二者≥4 时的反例；并报告 Courtade 猜想在 zonoids 中也有反例。它提醒我们，不能无证据把三维的投影或拟阵正性估计延伸到 rank 4；不据此否定任何一个尚未逐项对齐的具体项目引理。

## 12. 下一道真正的关口

本轮统一处理了同心同似的有限径向折点，不必继续逐个增加此类样本。一般对象仍可能具有：不保持同心同似的半弦长水平集，或光滑径向轮廓下合法的非齐次中点。

进一步的整体路线是 (9.1) 的三维截断余量补偿：它对一般 C 成立，不依赖组合型。需要的是能与分母 |C_s| 及投影系数匹配的有效稳定性估计，而不是只知道每个三维乘积≥32/3。即使一般 CE 被证明，仍需把任意四维凸体与接触／分离类别连接起来；这条全局桥不能略去。
