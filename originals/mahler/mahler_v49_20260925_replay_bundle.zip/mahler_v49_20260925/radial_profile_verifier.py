#!/usr/bin/env python3
"""Exact arithmetic checks for the radial-profile contact theorem candidate.

The external 3D Mahler/equipartition theorems and the general analytic
homogeneity lemma are NOT formalized by this program. Geometry uses exhaustive
rational halfspace enumeration, not floating-point hulls or sampling proofs.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations, product
import sympy as sp
from exact_geometry import central_pair,hpoly,hull2,area2,volume_moment,jsonable


def integrate_poly(coefs, left, right):
    return sum(c*(right**(i+1)-left**(i+1))/F(i+1) for i,c in enumerate(coefs))


def profile_data(knots):
    knots=[(F(x),F(y)) for x,y in knots]
    assert knots[0]==(F(0),F(1)) and knots[-1][0]==1
    assert all(0<=y<=1 for _,y in knots)
    pieces=[];I=F(0)
    for (x,y),(xx,yy) in zip(knots,knots[1:]):
        assert x<xx and y>=yy
        k=(y-yy)/(xx-x);c=y+k*x
        assert not pieces or k>=pieces[-1][3]
        pieces.append((x,xx,c,k))
        I+=integrate_poly([0,c,-k],x,xx)
    tau=pieces[0][3];assert 0<=tau<=1
    # On each affine phi interval the expression defining beta is monotone
    # in r, or constant, so the minimum is attained at a positive knot.
    lines=sorted(set((1/x,-y/x) for x,y in knots if x))
    breaks={F(0),F(1)}
    for (a,b),(c,d) in combinations(lines,2):
        if b!=d:
            s=(c-a)/(b-d)
            if 0<s<1:breaks.add(s)
    intervals=[]
    for l,r in zip(sorted(breaks),sorted(breaks)[1:]):
        s=(l+r)/2
        line=min(lines,key=lambda ab:ab[0]+ab[1]*s)
        if intervals and intervals[-1][2:]==line:
            intervals[-1]=(intervals[-1][0],r,*line)
        else:intervals.append((l,r,*line))
    H=L=S=F(0)
    for l,r,a,b in intervals:
        for s in [l,r]:
            assert a+b*s>=1-s+tau*s
            assert a+b*s<=1
        sq=[a*a,2*a*b,b*b]
        H+=integrate_poly(sq,l,r)
        S+=integrate_poly([0,*sq],l,r)
        L+=integrate_poly([a*a,2*a*b-a*a,b*b-2*a*b,-b*b],l,r)
    assert H-S==L
    assert I>=F(1,6) and L>=F(1,4)+tau/F(6)+tau*tau/F(12)
    assert (I+F(1,6))*L>=F(1,6)
    return {'knots':knots,'phi_pieces':pieces,'tau':tau,'beta_pieces':intervals,
            'I':I,'H':H,'S':S,'L':L,'scalar_margin':(I+F(1,6))*L-F(1,6)}


def minkowski(P,Q,a=F(1),b=F(1)):
    cloud=[(a*p[0]+b*q[0],a*p[1]+b*q[1]) for p in P for q in Q]
    # The zero coefficient endpoints can be a point; callers below only
    # request full-dimensional polygons.
    return hull2(cloud)


def symbolic_checks():
    mu,d,t,I,L=sp.symbols('mu delta tau I L',real=True)
    A=I+sp.Rational(1,6)
    E=8*mu*A*(L-d*t*t/12)
    first=8*A*(mu-24/(3-d))*(L-d*t*t/12)
    second=64*A*d/(3-d)*(L-t*t/4)
    assert sp.factor(E-64*A*L-first-second)==0
    s=sp.symbols('s',real=True)
    lower=sp.integrate((1-s)*(1-s+t*s)**2,(s,0,1))
    assert sp.expand(lower-(sp.Rational(1,4)+t/6+t*t/12))==0
    assert sp.expand(lower-t*t/4-sp.Rational(1,4)-t*(1-t)/6)==0
    # The nonlinear smooth admissible midpoint is NOT a conjecture counterexample.
    x,y,lam=sp.symbols('x y lam',real=True)
    f=1-x*x-y*y;m=x**3/4
    Hp=sp.hessian(f+m,(x,y));Hm=sp.hessian(f-m,(x,y))
    assert Hp==sp.diag(-2+sp.Rational(3,2)*x,-2)
    assert Hm==sp.diag(-2-sp.Rational(3,2)*x,-2)
    defect=sp.expand(m.subs(x,lam*x)-lam*m)
    assert sp.expand(defect-x**3*(lam**3-lam)/4)==0
    # Uniform distance from any homogeneous midpoint, using u=(1,0), r=1/2.
    # |m(r*u)-r*m(u)|=3/32, hence sup error >= (3/32)/(1+r)=1/16.
    assert abs(F(1,4)*(F(1,2)**3-F(1,2)))/(1+F(1,2))==F(1,16)
    return {'decomposition_identity':str(E-64*A*L),'first_nonnegative_term':str(first),
            'second_nonnegative_term':str(second),'beta_integral_lower_bound':str(lower),
            'smooth_example_Hessian_plus':str(Hp),'smooth_example_Hessian_minus':str(Hm),
            'smooth_example_homogeneity_defect':str(defect),
            'uniform_distance_from_homogeneous_midpoints_lower_bound':'1/16',
            'symbolic_arithmetic_status':'PASS'}


def example(name,A_input,profile_name,knots,check4):
    pr=profile_data(knots);tau=pr['tau'];I,H,S,L=(pr[k] for k in ['I','H','S','L'])
    A=hull2(A_input)
    B=hull2([tuple((x-y)/2 for x,y in zip(p,q)) for p in A for q in A])
    D=hull2(hpoly([(b,F(1)) for b in B],2)['vertices'])
    sa,sb,sd=area2(A),area2(B),area2(D);rho=sa/sb;delta=1-rho;mu=sd*sb
    assert 0<rho<=1 and mu*(2+rho)>=24
    assert (area2(minkowski(B,A))-sb-sa)/2==sb
    points=[(F(0),)+p for p in B]
    for _,_,c,k in pr['phi_pieces']:
        T=minkowski(B,A,k-tau,tau)
        for p in T:
            q=(1/c,p[0]/c,p[1]/c);points.extend([q,tuple(-x for x in q)])
    K,C=central_pair(points)
    W,_,kw=volume_moment(K);V,_,cv=volume_moment(C)
    half=hpoly([(p,F(1)) for p in C['vertices']]+[((-1,0,0),F(0))],3)
    hv,hj,hs=volume_moment(half,0);J=2*hj
    assert 2*hv==W
    assert V==4*sd*I and W==2*sb*(H-delta*tau*tau/3)
    assert J==2*sb*(S-delta*tau*tau/4)
    E=(V+F(2,3)*sd)*(W-J)
    assert E==8*mu*(I+F(1,6))*(L-delta*tau*tau/12)
    base=64*(I+F(1,6))*L
    first=8*(I+F(1,6))*(mu-24/(3-delta))*(L-delta*tau*tau/12)
    second=64*(I+F(1,6))*delta/(3-delta)*(L-tau*tau/4)
    assert E-base==first+second and min(first,second)>=0 and base>=F(32,3)
    slices=[]
    for s in [F(0),F(1,4),F(1,2),F(3,4),F(1)]:
        beta=min(a+b*s for _,_,a,b in pr['beta_pieces'])
        actual=hull2(hpoly([(p[1:],1-p[0]*s) for p in C['vertices']],2)['vertices'])
        expected=minkowski(B,A,beta-tau*s,tau*s)
        assert set(actual)==set(expected)
        assert area2(actual)==sb*(beta*beta-delta*tau*tau*s*s)
        slices.append({'s':s,'beta':beta,'vertices':actual,'area':area2(actual)})
    out={'shape':name,'profile':profile_name,'profile_data':pr,'A':A,'B':B,'D':D,
         'A_area':sa,'B_area':sb,'D_area':sd,'mu':mu,'rho':rho,'delta':delta,
         'auxiliary_3D_Mahler':F(4,9)*mu*(2+rho),'C_volume':V,'polar_volume':W,
         'absolute_first_moment':J,'C_vertex_count':len(C['vertices']),
         'C_facet_count':len(K['vertices']),'contact_product':E,'contact_margin':E-F(32,3),
         'unconditional_scalar_baseline':base,'first_remainder':first,'second_remainder':second,
         'C':C,'C_polar':K,'positive_half_polar':half,
         'triangulations':{'C':cv,'polar':kw,'half':hs},'exact_slices':slices,
         'independent_4D_reconstruction':check4}
    if check4:
        Qpoints=[(F(0),)+p for p in C['vertices']]
        Qpoints.extend([(F(x),F(t),F(0),F(0)) for x,t in product([-1,1],repeat=2)])
        Q,Qp=central_pair(Qpoints)
        v4,_,qv=volume_moment(Q);w4,_,qw=volume_moment(Qp)
        assert v4==V/2+sd/3 and w4==2*(W-J) and v4*w4==E
        out.update({'Q':Q,'Q_polar':Qp,'Q_volume':v4,'Q_polar_volume':w4,
                    'Q_vertex_count':len(Q['vertices']),'Q_facet_count':len(Qp['vertices']),
                    'Q_triangulation':qv,'Q_polar_triangulation':qw})
    return out


def radial_cell_checks():
    """Finite exact checks of radial-intercept rigidity, not a formal general proof."""
    records=[]
    polygons={'square':[(-1,-1),(1,-1),(1,1),(-1,1)],
              'hexagon':[(1,0),(1,1),(0,1),(-1,0),(-1,-1),(0,-1)]}
    for name,D0 in polygons.items():
        D=hull2(D0);N=len(D);half=N//2
        assert all(tuple(-x for x in D[j])==D[(j+half)%N] for j in range(N))
        for bands in [1,2,4]:
            radii=[F(j,bands) for j in range(bands+1)]
            cells=[]
            for b in range(bands):
                for j in range(N):
                    p,q=D[j],D[(j+1)%N];r,R=radii[b],radii[b+1]
                    cells.append(set([(r*p[0],r*p[1]),(R*p[0],R*p[1]),
                                      (r*q[0],r*q[1]),(R*q[0],R*q[1])]))
            dim=3*len(cells);rows=[]
            for i,j in combinations(range(len(cells)),2):
                common=sorted(cells[i]&cells[j])
                if len(common)>=2:
                    for p in common[:2]:
                        row=[F(0)]*dim
                        for k,v in enumerate((*p,F(1))):row[3*i+k]=v;row[3*j+k]=-v
                        rows.append(row)
            for b in range(bands):
                for j in range(half):
                    i=b*N+j;o=b*N+j+half
                    for k in range(3):
                        row=[F(0)]*dim;row[3*i+k]=1;row[3*o+k]=1 if k==2 else -1
                        rows.append(row)
            mat=sp.Matrix(rows);ns=mat.nullspace()
            assert len(ns)==half
            for h in ns:
                assert all(h[3*i+2]==0 for i in range(len(cells)))
                for b in range(1,bands):
                    for j in range(N):
                        assert list(h[3*(b*N+j):3*(b*N+j)+3])==list(h[3*j:3*j+3])
            records.append({'polygon':name,'bands':bands,'unknowns':dim,
                            'linear_rank':dim-len(ns),'odd_midpoint_dimension':len(ns),
                            'quotient_dimension_after_shears':len(ns)-2,
                            'all_intercepts_zero':True,'all_radial_band_gradients_agree':True})
    return records


def main(output):
    sy=symbolic_checks();ranks=radial_cell_checks()
    profiles={
      'affine_control':[(0,1),(1,F(1,2))],
      'one_fold':[(0,1),(F(1,2),F(7,8)),(1,F(1,2))],
      'two_folds':[(0,1),(F(1,3),F(11,12)),(F(2,3),F(2,3)),(1,F(1,6))],
      'zero_boundary_fold':[(0,1),(F(1,2),F(7,8)),(1,0)]}
    shapes={'square':[(-1,-1),(1,-1),(1,1),(-1,1)],
            'triangle':[(1,0),(0,1),(-1,-1)],
            'asymmetric_quadrilateral':[(-2,-1),(2,-1),(1,2),(-1,1)]}
    plan=[('square','one_fold',True),('triangle','affine_control',False),
          ('triangle','one_fold',True),('triangle','two_folds',True),
          ('triangle','zero_boundary_fold',False),
          ('asymmetric_quadrilateral','one_fold',False),
          ('asymmetric_quadrilateral','two_folds',False)]
    cases=[]
    for shape,p,check4 in plan:
        print('START',shape,p,'4D',check4,flush=True)
        c=example(shape,shapes[shape],p,profiles[p],check4);cases.append(c)
        print('PASS',shape,p,'C',c['C_vertex_count'],c['C_facet_count'],'E',c['contact_product'],
              ('Q '+str(c['Q_vertex_count'])+'/'+str(c['Q_facet_count'])) if check4 else '',flush=True)
    result={'version':'v49','date':'2026-09-25','status':'PASS','symbolic':sy,'radial_cell_checks':ranks,
            'exact_3D_reconstructions':len(cases),'independent_4D_reconstructions':sum(c['independent_4D_reconstruction'] for c in cases),
            'independent_planar_slice_checks':5*len(cases),'samples':cases,
            'scope':'rational arithmetic checks and written analytic theorem candidate; no formal proof of external analytic results',
            'general_CE_proved':False,'full_4D_symmetric_Mahler_proved':False,
            'v1_through_v48_rebuilt':False}
    output.write_text(json.dumps(jsonable(result),indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('ALL PASS',output,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,
       default=Path(__file__).resolve().parent/'radial_profile_certificate.json')
    main(parser.parse_args().output)
