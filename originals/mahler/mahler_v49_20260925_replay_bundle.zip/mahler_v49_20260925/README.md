# Mahler contact project v49 — 2026-09-25

## Run

Python 3.11+ and SymPy are required. No NumPy/SciPy or floating-point hull is used.

```bash
python -m pip install -r requirements.txt
python replay.py --rebuild
```

`--rebuild` executes the finite exact verifier in a clean temporary directory,
compares the generated JSON byte-for-byte with the archived certificate, and
checks file hashes. `python replay.py` checks only integrity and stored semantics.

## Files

- `report_zh.md`: full Chinese analytic argument, 11-source literature audit,
  non-approximation counterexample, and remaining gaps.
- `radial_profile_verifier.py`: symbolic identities, six exact radial-cell rank
  checks, seven 3D reconstructions, three independent 4D reconstructions, and
  35 independently reconstructed planar polar slices.
- `exact_geometry.py`: unchanged rational geometry helper copied from v48.
- `radial_profile_certificate.json`: all exact reconstructed data.
- `provenance.json`: original v48 archive/helper hashes and scope of reuse.

## Scope

The written theorem candidate covers arbitrary concave radial profiles with
homogeneous admissible odd midpoints. A separate analytic rigidity lemma covers
all admissible odd midpoints when the radial profile has finitely many affine
pieces. It does not cover all centrally symmetric 3D contact bases, and is not
a proof of the unrestricted 4D symmetric Mahler conjecture.

The external 3D Mahler and equipartition theorems and the general analytic
rigidity argument are not formalized by Python. No historical v1–v48 replay is
claimed. The rank and finite geometric checks do not replace the written proof.
No literature-priority claim or independent peer-review claim is made.
