#!/usr/bin/env python3
"""Integrity check and isolated exact regeneration for v49 only."""
from __future__ import annotations
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def integrity():
    m=json.loads((ROOT/'manifest.json').read_text())
    assert m['version']=='v49'
    for name,record in m['files'].items():
        p=ROOT/name
        assert p.is_file() and p.stat().st_size==record['bytes'] and digest(p)==record['sha256'],name
    return m

def main(rebuild):
    m=integrity();expected=(ROOT/'radial_profile_certificate.json').read_bytes()
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v49_') as td:
            fresh=Path(td)
            for name in ['exact_geometry.py','radial_profile_verifier.py']:
                shutil.copy2(ROOT/name,fresh/name)
            result=subprocess.run([sys.executable,str(fresh/'radial_profile_verifier.py')],
                                  cwd=fresh,capture_output=True,text=True,timeout=1200)
            if result.returncode:raise RuntimeError(result.stdout+'\n'+result.stderr)
            assert (fresh/'radial_profile_certificate.json').read_bytes()==expected
            print(result.stdout,end='')
    c=json.loads(expected)
    assert c['status']=='PASS' and c['exact_3D_reconstructions']==7
    assert c['independent_4D_reconstructions']==3 and c['independent_planar_slice_checks']==35
    assert len(c['radial_cell_checks'])==6
    assert c['general_CE_proved'] is False and c['full_4D_symmetric_Mahler_proved'] is False
    integrity()
    print(json.dumps({'status':'PASS','version':'v49','rebuild':rebuild,
       'manifest_files_checked':len(m['files']),'certificate_regenerated_and_byte_compared':rebuild,
       'general_analytic_theorems_formalized':False,'v1_through_v48_rebuilt':False,
       'general_CE_proved':False,'full_4D_symmetric_Mahler_proved':False},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rebuild',action='store_true')
    main(p.parse_args().rebuild)
