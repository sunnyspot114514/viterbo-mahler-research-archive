#!/usr/bin/env python3
"""Integrity plus clean independent regeneration of the two v51 certificates.

This checks only the finite computations explicitly listed in the report.
It is not a formal proof of its analytic statements or of general Mahler.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integrity() -> tuple[dict, int]:
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('version') != 'v51':
        raise ValueError('Wrong manifest version')
    total = 0
    for rel, rec in manifest['files'].items():
        path = ROOT / rel
        if not path.is_file() or path.stat().st_size != rec['bytes']:
            raise AssertionError(f'File length mismatch: {rel}')
        if sha256(path) != rec['sha256']:
            raise AssertionError(f'File hash mismatch: {rel}')
        total += rec['bytes']
    return manifest, total


def main(rebuild: bool) -> dict:
    manifest, total = integrity()
    targets = [('band_verifier.py', 'band_certificate.json'),
               ('geometry_verifier.py', 'geometry_certificate.json')]
    expected = {cert: (ROOT / cert).read_bytes() for _, cert in targets}
    logs = []
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v51_clean_') as td:
            fresh = Path(td)
            for rel in manifest['files']:
                dest = fresh / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / rel, dest)
            for script, cert in targets:
                (fresh / cert).unlink()
                command = [sys.executable, script, '--output', cert]
                proc = subprocess.run(command, cwd=fresh, capture_output=True,
                                      text=True, timeout=240)
                logs.append('$ ' + ' '.join(command) + '\n' + proc.stdout + proc.stderr)
                if proc.returncode:
                    raise RuntimeError(f'{script} failed:\n{logs[-1]}')
                if not (fresh / cert).is_file():
                    raise AssertionError(f'{script} did not generate {cert}')
                if (fresh / cert).read_bytes() != expected[cert]:
                    raise AssertionError(f'Regenerated certificate differs: {cert}')
            integrity()
    band = json.loads(expected['band_certificate.json'])
    geometry = json.loads(expected['geometry_certificate.json'])
    for rec in (band, geometry):
        assert rec['version'] == 'v51' and rec['status'] == 'PASS'
        assert rec['general_CE_proved'] is False
        assert rec['full_4D_Mahler_proved'] is False
    assert band['general_analytic_results_formalized'] is False
    assert band['v1_through_v50_rebuilt'] is False
    assert len(band['trace_calibrations']) == 4
    assert len(band['harmonic_Hessian_checks']) == 4
    assert geometry['exact_3D_pairs'] == geometry['exact_4D_pairs'] == 4
    assert geometry['exact_slices'] == 28
    ranks = geometry['piecewise_polynomial_ranks']
    assert [(r['coefficient_variables'], r['rank']) for r in ranks] == [(40,38),(90,88),(168,166)]
    assert all(r['kernel_dimension'] == 2 and r['kernel_is_common_linear_shear'] for r in ranks)
    result = {
        'version': 'v51', 'status': 'PASS', 'rebuild': rebuild,
        'manifest_files_checked': len(manifest['files']),
        'manifest_bytes_checked': total,
        'certificates_regenerated_and_byte_compared': 2 if rebuild else 0,
        'exact_3D_pairs': geometry['exact_3D_pairs'],
        'exact_4D_pairs': geometry['exact_4D_pairs'],
        'exact_slices': geometry['exact_slices'],
        'trace_calibrations': len(band['trace_calibrations']),
        'piecewise_rigidity_rank_systems': len(ranks),
        'candidate_elliptic_endpoint_bound': band['elliptic_endpoint_lower'],
        'general_analytic_results_formalized': False,
        'general_CE_proved': False, 'full_4D_Mahler_proved': False,
        'v1_through_v50_rebuilt': False,
        'scope_warning': 'PASS certifies the listed finite checks, not the unformalized analytic theorems.'
    }
    (ROOT / 'replay_output.json').write_text(json.dumps(result, ensure_ascii=False,
        indent=2, sort_keys=True) + '\n', encoding='utf-8')
    (ROOT / 'replay_log.txt').write_text('\n'.join(logs) + '\n' + json.dumps(result,
        ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--rebuild', action='store_true',
                        help='regenerate certificates in a clean temporary directory')
    main(parser.parse_args().rebuild)
