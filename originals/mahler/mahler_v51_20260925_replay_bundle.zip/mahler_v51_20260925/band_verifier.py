#!/usr/bin/env python3
"""Finite exact checks for v51; not a formalization of its analytic theorem.

Checks symbolic integrals, radial perspective identities, rational enclosures
for the constants, and explicit smooth / C1,1 calibration functions.
"""
from __future__ import annotations
import argparse
import json
from fractions import Fraction as F
from pathlib import Path
import sympy as S


def atan_bounds(x: F, terms: int = 24) -> tuple[F, F]:
    if not 0 < x < 1:
        raise ValueError('Alternating-series bound requires 0 < x < 1')
    total = sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    nxt = (-1)**terms*x**(2*terms+1)/F(2*terms+1)
    return min(total, total+nxt), max(total, total+nxt)


def rational_pi_bounds() -> tuple[F, F]:
    # tan(4 atan(1/5)-atan(1/239))=1; the angle lies in (0, pi/2).
    x = F(1,5)
    t2 = 2*x/(1-x*x)
    t4 = 2*t2/(1-t2*t2)
    assert (t4-F(1,239))/(1+t4*F(1,239)) == 1
    l1,u1=atan_bounds(x); l2,u2=atan_bounds(F(1,239))
    return 16*l1-4*u2, 16*u1-4*l2


def main(output: Path) -> dict:
    s,r,t = S.symbols('s r t', positive=True)
    b,a,d,lam = S.symbols('b a d lam', real=True)
    eta = S.symbols('eta', real=True)
    f = S.Function('m')
    radial=(1-s)/r+s*r-s*f(r)/r
    radial_der=S.diff(radial,r)
    expected=(-(1-s)+s*r*r-s*(r*S.diff(f(r),r)-f(r)))/(r*r)
    assert S.simplify(radial_der-expected)==0
    # B(r)=eta*r^2, -1<=eta<=1. The displayed decomposition is nonnegative.
    perspective_der=1-s-s*r*r+s*eta*r*r
    decomposition=(1-3*s)+2*s*(1-r*r)+s*r*r*(eta+1)
    assert S.expand(perspective_der-decomposition)==0

    low = b + 9*s*s*(a-b)
    tail = S.Rational(9,4)*(1-s)**2*a
    H = S.factor(S.integrate(low,(s,0,S.Rational(1,3)))+
                 S.integrate(tail,(s,S.Rational(1,3),1)))
    L = S.factor(S.integrate((1-s)*low,(s,0,S.Rational(1,3)))+
                 S.integrate((1-s)*tail,(s,S.Rational(1,3),1)))
    assert S.simplify(H-(2*b+3*a)/9)==0
    assert S.simplify(L-7*(b+a)/36)==0
    assert S.simplify(low.subs(s,S.Rational(1,3))-tail.subs(s,S.Rational(1,3)))==0
    lower_all = S.factor(2*d*(1+2*lam/3)*(H-lam*(H-L)))
    assert S.simplify(lower_all.subs(lam,1)-35*d*(b+a)/54)==0
    assert S.simplify(S.diff(lower_all,lam,2)+2*d*(b+5*a)/27)==0

    piL,piU = rational_pi_bounds()
    sqL=F(1732050807568877,10**15)
    sqU=F(1732050807568878,10**15)
    assert sqL*sqL < 3 < sqU*sqU
    assert 3*piL-2*sqU>0
    BL_lower=F(35,54)*piL*(3*piL-2*sqU)
    fourier_lower=F(175,144)*piL*piL
    target=F(32,3)
    assert BL_lower>target and fourier_lower>target
    # The weaker general difference-body bound misses even the circular case.
    RS_upper=F(175,162)*piU*piU
    assert RS_upper<target

    theta=S.symbols('theta',real=True)
    calibration=[]
    traces = [
      ('zero',S.Integer(0),S.Integer(0)),
      ('cubic_harmonic',S.cos(3*theta)/3,S.Rational(4,9)),
      ('mixed_cubic_quintic',S.cos(3*theta)/6+S.sin(5*theta)/20,S.Rational(127,900)),
    ]
    for name,w,expected_Tpi in traces:
        T=S.simplify(S.integrate(S.expand_trig((S.diff(w,theta)**2-w*w)/2),(theta,0,2*S.pi)))
        assert S.simplify(T/S.pi-expected_Tpi)==0, (name,T)
        areaA=S.factor(S.pi-T/9)
        endpoint=S.factor(35*S.pi*(S.pi+areaA)/54)
        calibration.append({'name':name,'T_over_pi':str(expected_Tpi),
                            'area_A_over_pi':str(S.factor(areaA/S.pi)),
                            'endpoint_lower_over_pi_squared':str(S.factor(endpoint/S.pi**2))})
    # m=x|x|: integrate the two half-circles separately; the integrand is equal.
    w=S.cos(theta)**2
    Ts=S.simplify(S.integrate(S.diff(w,theta)**2-w*w,(theta,-S.pi/2,S.pi/2)))
    assert S.simplify(Ts-S.pi/8)==0
    calibration.append({'name':'x_abs_x','T_over_pi':'1/8','area_A_over_pi':'71/72',
                        'endpoint_lower_over_pi_squared':'5005/3888',
                        'v50_quadratic_budget_needed':'kappa >= 1'})
    assert S.simplify(35*(S.Rational(1)+S.Rational(71,72))/54-S.Rational(5005,3888))==0
    x,y=S.symbols('x y',real=True)
    fxy=1-x*x-y*y
    for side in [-1,1]:
        mxy=side*x*x
        for sign in [-1,1]:
            Hess=S.hessian(fxy+sign*mxy,(x,y))
            assert Hess.is_negative_semidefinite
    # Common first derivative at x=0 makes the piecewise concavity global.
    assert S.diff(x*x,x).subs(x,0)==S.diff(-x*x,x).subs(x,0)==0
    # The band cannot be silently extended: at s=1/2 the negative x ray
    # yields the strictly stronger constraint sqrt(2) < 3/2.
    r0=1/S.sqrt(2)
    bad_radial=(1-S.Rational(1,2))/r0+2*S.Rational(1,2)*r0
    assert S.simplify(bad_radial-S.sqrt(2))==0
    assert F(2)<F(9,4)

    # Smooth calibration legality on the entire parameter box.
    # Re(z^k), Im(z^k) have Hessian norm k(k-1) r^(k-2).
    harmonic_checks=[]
    for k in (3,5):
        for part in ('real','imag'):
            h=S.re((x+S.I*y)**k).expand() if part=='real' else S.im((x+S.I*y)**k).expand()
            HH=S.hessian(h,(x,y))
            assert S.simplify(HH.trace())==0
            ident=HH*HH-k*k*(k-1)*(k-1)*(x*x+y*y)**(k-2)*S.eye(2)
            assert all(S.expand(z)==0 for z in ident)
            harmonic_checks.append({'degree':k,'part':part,'Hessian_square_identity':'PASS'})

    # Independent elementary Fourier bound: odd trace has only odd modes;
    # after removing translations k=1, k>=3 and k^2-1>=8.
    k=S.symbols('k',integer=True,positive=True)
    assert S.expand((k*k-1)-8-(k-3)*(k+3))==0
    spectral_area=S.Rational(7,8)*S.pi
    assert S.simplify(35*S.pi*(S.pi+spectral_area)/54-S.Rational(175,144)*S.pi**2)==0

    # Reflexive parabola exact integral, for the polygon-rigidity consequence.
    beta_lo=S.Integer(1); beta_hi_sq=4*s*(1-s)
    H0=S.integrate(beta_lo,(s,0,S.Rational(1,2)))+S.integrate(beta_hi_sq,(s,S.Rational(1,2),1))
    L0=S.integrate((1-s)*beta_lo,(s,0,S.Rational(1,2)))+S.integrate((1-s)*beta_hi_sq,(s,S.Rational(1,2),1))
    assert H0==S.Rational(5,6) and L0==S.Rational(23,48)
    exact_reflexive=S.factor(2*(1+2*lam/3)*(H0-lam*(H0-L0)))
    assert S.simplify(exact_reflexive-(3+2*lam)*(40-17*lam)/72)==0

    result={'status':'PASS','version':'v51',
       'scope':'symbolic, finite algebraic and rational enclosure checks only',
       'band':'0 <= s <= 1/3','H_lower':str(H),'L_lower':str(L),
       'all_contact_parameter_bound':str(lower_all),
       'elliptic_endpoint_lower':'35*pi*(3*pi-2*sqrt(3))/54',
       'elliptic_endpoint_decimal':str(S.N(35*S.pi*(3*S.pi-2*S.sqrt(3))/54,18)),
       'weaker_independent_Fourier_lower':'175*pi^2/144',
       'BL_rational_margin_lower':str(BL_lower-target),
       'Fourier_rational_margin_lower':str(fourier_lower-target),
       'generic_difference_body_bound_fails_at_disk':True,
       'pi_bounds':[str(piL),str(piU)],'sqrt3_bounds':[str(sqL),str(sqU)],
       'trace_calibrations':calibration,'harmonic_Hessian_checks':harmonic_checks,
       'nonextension_at_height_one_half':'sqrt(2) < 3/2',
       'reflection_parabola_product_over_mu':str(exact_reflexive),
       'general_analytic_results_formalized':False,
       'general_CE_proved':False,'full_4D_Mahler_proved':False,
       'v1_through_v50_rebuilt':False}
    output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_name('band_certificate.json'))
    args=p.parse_args();res=main(args.output)
    print(json.dumps({'status':res['status'],'trace_calibrations':len(res['trace_calibrations']),
                      'endpoint_lower':res['elliptic_endpoint_lower']},ensure_ascii=False))
