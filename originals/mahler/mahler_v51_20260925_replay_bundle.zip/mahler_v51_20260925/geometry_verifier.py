#!/usr/bin/env python3
"""Independent finite rational checks of the band/cone integration interface.

The four calibration bodies are polyhedral models of the slice diagram, NOT
samples of an elliptic paraboloid. Also checks piecewise-polynomial instances
of the polygon-base rigidity argument. No floating point hulls are used.
"""
from __future__ import annotations
import argparse
import json
from fractions import Fraction as F
from pathlib import Path
import sympy as S
from sympy.polys.matrices import DomainMatrix
from exact_geometry import (hull2,area2,central_pair,hpoly,volume_moment,dot,jsonable)


def minus(p): return tuple(-v for v in p)
def minkowski(A,B,x=F(1),y=F(1)):
    return hull2([(x*a[0]+y*b[0],x*a[1]+y*b[1]) for a in A for b in B])

def inside(poly,p):
    for x,y in zip(poly,poly[1:]+poly[:1]):
        if (y[0]-x[0])*(p[1]-x[1])-(y[1]-x[1])*(p[0]-x[0])<0:
            return False
    return True


def calibration(name,A):
    A=hull2(A)
    B=minkowski(A,[minus(a) for a in A],F(1,2),F(1,2))
    assert all(inside(A,tuple(F(2,3)*v for v in p)) for p in B)
    aa,bb=area2(A),area2(B)
    Bpoly,Dpoly=central_pair(B)
    dd,_,_=volume_moment(Dpoly)
    points=[(F(1,3),)+a for a in A]
    points+= [minus(p) for p in points]
    points += [(F(1),F(0),F(0)),(F(-1),F(0),F(0))]
    K,C=central_pair(points)
    W,_,wk=volume_moment(K)
    V,_,wc=volume_moment(C)
    plus=hpoly([(n,F(1)) for n in C['vertices']]+[((F(-1),F(0),F(0)),F(0))],3)
    Wplus,moment,wm=volume_moment(plus,0)
    J=2*moment
    assert 2*Wplus==W
    assert W==2*(2*bb+3*aa)/9
    assert J==(bb+5*aa)/18
    slices=[]
    for s in (F(0),F(1,12),F(1,6),F(1,4),F(1,3),F(1,2),F(3,4)):
        actual=hpoly([(n[1:],1-n[0]*s) for n in C['vertices']],2)
        area,_,stats=volume_moment(actual)
        if s<=F(1,3):
            predicted=minkowski(B,A,1-3*s,3*s)
            formula=bb+9*s*s*(aa-bb)
        else:
            alpha=F(3,2)*(1-s)
            predicted=hull2([tuple(alpha*v for v in a) for a in A])
            formula=F(9,4)*(1-s)**2*aa
        assert set(actual['vertices'])==set(predicted)
        assert area==formula
        slices.append({'s':s,'vertices':len(actual['vertices']),'area':area,
                       'all_vertices_match':True,'bases':actual['bases_enumerated']})
    projected=hull2([p[1:] for p in C['vertices']])
    assert set(projected)==set(Dpoly['vertices'])
    Qcloud=[(F(0),)+p for p in C['vertices']]
    Qcloud += [(F(eps),F(sign),F(0),F(0)) for eps in (-1,1) for sign in (-1,1)]
    Q,Qpolar=central_pair(Qcloud)
    vq,_,sq=volume_moment(Q);vp,_,sp=volume_moment(Qpolar)
    assert vq==V/2+dd/3
    assert vp==2*(W-J)
    assert vq*vp==(V+2*dd/3)*(W-J)
    return {'name':name,'model_not_parabolic':True,'A_vertices':len(A),'B_vertices':len(B),
            'area_A':aa,'area_B':bb,'area_D':dd,
            'K_vertices':len(K['vertices']),'C_vertices':len(C['vertices']),
            'C_facets':len(C['facets']),'volume_C':V,'volume_K':W,'absolute_first_moment_K':J,
            'slices':slices,'Q_vertices':len(Q['vertices']),'Q_facets':len(Q['facets']),
            'volume_Q':vq,'volume_Q_polar':vp,'M_Q':vq*vp,
            'boundary_tetrahedra_Q':sq['boundary_simplices'],
            'boundary_tetrahedra_Q_polar':sp['boundary_simplices']}


def piecewise_rank(D,degree):
    """Every cone gets an independent polynomial, including even degrees.

    Impose the weak-Hessian tangential equalities, a common first-order jet at
    0, continuity on each cone boundary, and antipodal oddness. These are only
    necessary conditions, so full rank modulo the two linear shears certifies
    the stated finite polynomial ansatz without assuming more convexity.
    """
    D=hull2(D);N=len(D)
    assert N%2==0 and all(minus(D[i])==D[(i+N//2)%N] for i in range(N))
    x,y,r=S.symbols('x y r')
    monom=[x**i*y**j for k in range(degree+1) for i in range(k+1) for j in [k-i]]
    coeff=S.symbols(f'c0:{N*len(monom)}')
    polys=[sum(coeff[i*len(monom)+j]*monom[j] for j in range(len(monom))) for i in range(N)]
    eq=[]
    grad0=[S.diff(polys[0],v).subs({x:0,y:0}) for v in (x,y)]
    for i,p in enumerate(polys):
        # Tangent to this edge (hence to its level lines).
        u,v=D[i],D[(i+1)%N]
        tangent=S.Matrix([S.Rational(v[j]-u[j]) for j in range(2)])
        Hv=S.hessian(p,(x,y))*tangent
        for e in Hv:
            eq.extend(S.Poly(S.expand(e),x,y).coeffs())
        eq.append(p.subs({x:0,y:0}))
        eq.extend(S.diff(p,z).subs({x:0,y:0})-grad0[j] for j,z in enumerate((x,y)))
        # Adjacent cones meet on the ray through vertex D[i].
        edge=S.expand((p-polys[(i-1)%N]).subs({x:r*S.Rational(u[0]),y:r*S.Rational(u[1])}))
        eq.extend(S.Poly(edge,r).coeffs())
        if i<N//2:
            odd=S.expand(p+polys[i+N//2].subs({x:-x,y:-y},simultaneous=True))
            eq.extend(S.Poly(odd,x,y).coeffs())
    eq=[e for e in eq if e!=0]
    mat,rhs=S.linear_eq_to_matrix(eq,coeff)
    assert not any(rhs)
    rr=DomainMatrix.from_Matrix(mat).convert_to(S.QQ).rank()
    assert rr==len(coeff)-2,(N,degree,rr,len(coeff))
    # Independently verify the two common-linear null vectors.
    for mon in (x,y):
        vec=S.Matrix([int(mm==mon) for _ in range(N) for mm in monom])
        assert not any(mat*vec)
    return {'polygon_vertices':N,'per_cone_polynomial_degree':degree,
            'coefficient_variables':len(coeff),'equations':mat.rows,'rank':rr,
            'kernel_dimension':2,'kernel_is_common_linear_shear':True}


def main(output):
    T=[(F(2),F(0)),(F(-1),F(1)),(F(-1),F(-1))]
    square=hull2([(F(x),F(y)) for x in (-1,1) for y in (-1,1)])
    seg=[(F(-1,2),F(0)),(F(1,2),F(0))]
    models=[('triangle',T),('triangle_plus_square',minkowski(T,square,F(1),F(1,3))),
            ('triangle_plus_segment',minkowski(T,seg)),('square',square)]
    geo=[]
    for name,A in models:
        row=calibration(name,A);geo.append(row)
        print(f'{name}: Q={row["Q_vertices"]}V/{row["Q_facets"]}F PASS',flush=True)
    hexagon=[(1,0),(1,1),(0,1),(-1,0),(-1,-1),(0,-1)]
    octagon=[(1,0),(F(3,4),F(3,4)),(0,1),(F(-3,4),F(3,4)),(-1,0),
             (F(-3,4),F(-3,4)),(0,-1),(F(3,4),F(-3,4))]
    ranks=[]
    for D,deg in [(square,3),(hexagon,4),(octagon,5)]:
        row=piecewise_rank(D,deg);ranks.append(row)
        print(f'piecewise rigidity: {row} PASS',flush=True)
    res={'version':'v51','status':'PASS','polyhedral_models':geo,
         'exact_3D_pairs':len(geo),'exact_4D_pairs':len(geo),
         'exact_slices':sum(len(g['slices']) for g in geo),
         'piecewise_polynomial_ranks':ranks,
         'scope':'finite model and symbolic checks, not analytic formalization',
         'general_CE_proved':False,'full_4D_Mahler_proved':False}
    output.write_text(json.dumps(jsonable(res),ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    return res

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('geometry_certificate.json'))
    main(ap.parse_args().output)
