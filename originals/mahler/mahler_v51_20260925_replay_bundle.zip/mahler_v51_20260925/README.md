# Mahler contact progress v51 — 2026-09-25

本轮包括两个**书面解析证明候选**：椭圆底面抛物半弦长的全合法中点接触下界，以及多边形底面下所有合法连续中点的线性刚性。

完整假设和证明见 `report_zh.md`。一般 CE、完整四维中心对称 Mahler、历史 bounded-12 穷尽性并没有由本包证明或重新认证。

## 运行

使用 Python 3.11 或更新版本。实际测试环境写在 `provenance.json`。

```bash
python -m pip install -r requirements.txt
python replay.py --rebuild
```

`--rebuild` 先检查全部 manifest 文件的长度和 SHA-256，再复制到干净临时目录，删除两个已有证书，重新执行两个 verifier，并逐字节比较重建证书。未带 `--rebuild` 时仅进行完整性和已存结果的语义检查，不能描述为重新计算。

输出为 `replay_output.json` 和 `replay_log.txt`。它们不列入 manifest，避免循环依赖。

## 文件

- `band_verifier.py`：符号积分、径向及透视函数导数、严格有理常数包围、四类边界迹、非光滑例子和赤道带越界检查。
- `geometry_verifier.py`：4 个有理 3D/4D 原像—极体模型、28 个完整截面，以及3套独立分锥多项式刚性秩系统。
- `exact_geometry.py`：来自 v50 的有理几何助手。继承哈希及旧包完整性检查边界见 `provenance.json`。
- 两个 `*_certificate.json`：实际重新生成的有限计算结果。
- `manifest.json`：所有源代码、报告、依赖说明和证书的固定哈希。

## PASS 的准确含义

PASS 覆盖列明的有限代数、积分恒等式、模型、秩和证书完整性。一般连续函数上的解析论证、Blaschke–Lebesgue、半凸正则性、Fourier/Parseval 及低维 Mahler 输入没有在证明助理中形式化，也尚未经过独立同行评审。

多面体模型检查的是切片与极性计算接口；它们不是光滑椭圆抛物体的采样。核对 v50 的 manifest 不等于重跑 v50，更不等于重认证 v1–v49。
