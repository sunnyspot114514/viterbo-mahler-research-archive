#!/usr/bin/env python3
"""Finite exact checks of auxiliary bodies and the tail moment interface.
The tail models are NOT claimed to be power-profile bodies.
Only the auxiliary polar bodies are genuine q=1 profile instances.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import sympy as sp
from exact_geometry import hull2, area2, central_pair, hpoly, volume_moment, jsonable

def neg(x): return tuple(-v for v in x)
def mink(A,B,a=F(1),b=F(1)):
    return hull2([(a*x[0]+b*y[0],a*x[1]+b*y[1]) for x in A for y in B])
def polar2(A):
    A=hull2(A);out=[]
    for x,y in zip(A,A[1:]+A[:1]):
        d=x[0]*y[1]-x[1]*y[0]
        if d<=0:raise AssertionError('Origin must be strictly inside polygon')
        out.append(((y[1]-x[1])/d,(x[0]-y[0])/d))
    out=hull2(out)
    assert all(x[0]*y[0]+x[1]*y[1]<=1 for x in A for y in out)
    return out

def contact(C,K):
    V,_,_=volume_moment(C);W,_,_=volume_moment(K)
    B=hpoly([(n[1:],F(1)) for n in C['vertices']],2)
    D=polar2(B['vertices']);d=area2(D)
    assert set(hull2([x[1:] for x in C['vertices']]))==set(D)
    half=hpoly([(n,F(1)) for n in C['vertices']]+[((F(-1),F(0),F(0)),F(0))],3)
    vh,mh,_=volume_moment(half,0)
    assert 2*vh==W
    J=2*mh
    points=[(F(0),)+x for x in C['vertices']]
    points += [(F(a),F(b),F(0),F(0)) for a in [-1,1] for b in [-1,1]]
    Q,Qp=central_pair(points)
    vq,_,nq=volume_moment(Q);wq,_,nqp=volume_moment(Qp)
    assert vq==V/2+d/3 and wq==2*(W-J)
    assert vq*wq==(V+2*d/3)*(W-J)
    return {'V':V,'W':W,'J':J,'d':d,'Q_vertices':len(Q['vertices']),
            'Q_facets':len(Q['facets']),'Q_volume':vq,'Q_polar_volume':wq,
            'Q_product':vq*wq,'primal_boundary_simplices':nq['boundary_simplices'],
            'polar_boundary_simplices':nqp['boundary_simplices']}

def auxiliary(A,name):
    B=mink(A,[neg(x) for x in A],F(1,2),F(1,2));D=polar2(B)
    a,b,d=area2(A),area2(B),area2(D)
    points=[(F(1),)+x for x in A];points += [neg(x) for x in points]
    Z,T=central_pair(points)
    vz,_,_=volume_moment(Z);vt,_,_=volume_moment(T)
    assert vz==2*(2*b+a)/3 and vt==2*d/3
    assert vz*vt==4*d*(2*b+a)/9>=F(32,3)
    assert F(2,3)<=a/b<=1
    slices=[]
    for s in [F(0),F(1,4),F(1,2),F(3,4),F(1)]:
        sl=hpoly([(n[1:],1-s*n[0]) for n in T['vertices']],2)
        pred=mink(B,A,1-s,s)
        assert set(sl['vertices'])==set(pred)
        assert area2(pred)==b+(a-b)*s*s
        slices.append({'s':s,'area':area2(pred),'vertices':len(pred)})
    con=contact(T,Z)
    assert con['Q_product']==2*d*(5*b+a)/9
    return {'name':name,'a':a,'b':b,'d':d,'rho':a/b,'mu':b*d,
            'Z_vertices':len(Z['vertices']),'Z_facets':len(Z['facets']),
            'Z_volume':vz,'T_volume':vt,'M3':vz*vt,'slices':slices,
            'contact':con,'is_genuine_q1_profile_instance':True}

def spfrac(x):return sp.Rational(x.numerator,x.denominator)
def tailmodel(knots,name):
    # All knots are nonnegative; h=1 up to t and then concave polygonal.
    t=knots[1][0]
    slopes=[(v2-v1)/(s2-s1) for (s1,v1),(s2,v2) in zip(knots,knots[1:])]
    assert all(slopes[i]>=slopes[i+1] for i in range(len(slopes)-1))
    assert knots[0]==(F(0),F(1)) and knots[-1]==(F(1),F(0))
    B=[(F(-1),F(-1)),(F(1),F(-1)),(F(1),F(1)),(F(-1),F(1))]
    points=[]
    for s,v in knots:points +=[(s,v*x,v*y) for x,y in B]
    points += [neg(x) for x in points]
    K,C=central_pair(points)
    con=contact(C,K)
    x=sp.Symbol('s');H=sp.Rational(0);L=sp.Rational(0)
    for (s1,v1),(s2,v2) in zip(knots,knots[1:]):
        line=spfrac(v1)+(spfrac(v2-v1)/spfrac(s2-s1))*(x-spfrac(s1))
        H+=sp.integrate(line**2,(x,spfrac(s1),spfrac(s2)))
        L+=sp.integrate((1-x)*line**2,(x,spfrac(s1),spfrac(s2)))
    H=sp.factor(H);L=sp.factor(L);ts=spfrac(t)
    assert H==spfrac(con['W'])/8
    assert L==spfrac(con['W']-con['J'])/8
    z=(-1+sp.sqrt(1+4*(3*H-2*ts-1)/(1-ts)))/2
    Hlin=(2*ts+1+(1-ts)*(z+z*z))/3
    Llin=(ts*(8-3*ts)+3-2*ts+(1-ts)**2*(2*z+z*z))/12
    assert sp.simplify(H-Hlin)==0
    gap=sp.simplify(L-Llin)
    assert gap.is_positive is True
    # Rational bracketing avoids basing a positive conclusion on rounded z.
    assert (z>=0)==True and (z<=1)==True
    return {'name':name,'knots':knots,'sigma':t,'H_normalized':str(H),
            'L_normalized':str(L),'moment_matched_line_endpoint':str(z),
            'L_comparison':str(sp.simplify(Llin)),'positive_L_gap':str(gap),
            'contact':con,'is_genuine_power_profile_instance':False,
            'warning':'These are finite tests of the one-crossing moment interface, not samples proving the power-profile theorem.'}

def main(output):
    tri=hull2([(F(2),F(0)),(F(-1),F(1)),(F(-1),F(-1))])
    square=hull2([(F(-1),F(-1)),(F(1),F(-1)),(F(1),F(1)),(F(-1),F(1))])
    quad=hull2([(F(2),F(0)),(F(0),F(2)),(F(-1),F(0)),(F(0),F(-1))])
    choices=[('triangle',tri),('square',square),('triangle_plus_square',mink(tri,square)),('asymmetric_quadrilateral',quad)]
    aux=[]
    for name,A in choices:
        row=auxiliary(A,name);aux.append(row)
        print(f'auxiliary {name}: M3={row["M3"]}, Q={row["contact"]["Q_product"]} PASS',flush=True)
    profiles=[
      ('two_slope_tail',[(F(0),F(1)),(F(1,3),F(1)),(F(2,3),F(3,4)),(F(1),F(0))]),
      ('short_band',[(F(0),F(1)),(F(1,5),F(1)),(F(3,5),F(2,3)),(F(1),F(0))]),
      ('three_slope_tail',[(F(0),F(1)),(F(1,4),F(1)),(F(1,2),F(9,10)),(F(3,4),F(3,5)),(F(1),F(0))])]
    tails=[]
    for name,knots in profiles:
        row=tailmodel(knots,name);tails.append(row)
        print(f'tail {name}: H={row["H_normalized"]}, L={row["L_normalized"]} PASS',flush=True)
    result={'version':'v53','date':'2026-09-26','status':'PASS','auxiliary_models':aux,
            'tail_moment_models':tails,'independent_3D_pairs':len(aux)+len(tails),
            'independent_4D_pairs':len(aux)+len(tails),'exact_auxiliary_slices':sum(len(a['slices']) for a in aux),
            'one_crossing_geometric_lemma_formalized':False,
            'full_4D_Mahler_proved':False,'general_CE_proved':False,
            'scope':'Finite rational geometry and moment identities only; main continuous theorem is the written analytic proof.'}
    output.write_text(json.dumps(jsonable(result),ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('v53 finite geometry and tail moment checks: PASS',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('geometry_certificate.json'))
    main(p.parse_args().output)
