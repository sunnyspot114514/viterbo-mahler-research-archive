# Mahler v53 research checkpoint

Date: 2026-09-26.

Written analytic proof candidate: for every origin-symmetric planar convex
body D, every finite real q >= 1, and every continuous odd m such that
(g_D)^q +/- m are convex, the specified four-dimensional contact body has
volume product >= 32/3. No near-ellipse restriction is imposed.

The paper contains the proof, including the exact parameter domain and all
external inputs. It is NOT a proof of general CE or unrestricted 4D Mahler.
No claim of literature priority, independent peer review, or formalization.

## Reproduce

Python 3.11+ and SymPy.

```bash
python -m pip install -r requirements.txt
python replay.py --rebuild
```

`python replay.py` checks the manifest and certificate semantics.
`--rebuild` additionally regenerates both new certificates in a clean temporary
directory, byte-compares them, and leaves the archived sources untouched.

## What the programs certify

- Exact polynomial identities and positive Bernstein coefficients on entire
  real parameter intervals, not a finite exponent grid.
- The separate q=1 calculation and the short q=2 positive-gap certificate.
- Four rational auxiliary 3D bodies and their 4D contact bodies; these are
  genuine q=1 profile instances.
- Three rational tail-moment interface models with independent 3D and 4D
  polarity checks; these are explicitly NOT asserted to be power-profile
  examples.
- Twenty exact auxiliary-body slices.

The programs do not formalize Brunn--Minkowski, Rogers--Shephard, the published
3D Mahler theorem, weak derivatives, or the continuous one-crossing argument.
The final conclusion still depends on the written analytic proof.

`provenance.json` records source hashes and the v52 archive integrity check.
Earlier mathematical verifiers are not replayed or re-certified here.
