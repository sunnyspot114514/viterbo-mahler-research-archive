#!/usr/bin/env python3
"""Integrity check and clean regeneration of v53's two finite certificates."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def integrity():
    man=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    assert man['version']=='v53'
    for rel,rec in man['files'].items():
        p=ROOT/rel
        assert p.is_file(),('missing',rel)
        assert p.stat().st_size==rec['bytes'],('size',rel)
        assert sha(p)==rec['sha256'],('hash',rel)
    return man

def main(rebuild):
    man=integrity()
    names=['analytic_certificate.json','geometry_certificate.json']
    expected={n:(ROOT/n).read_bytes() for n in names}
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v53_clean_') as td:
            fresh=Path(td)
            for rel in man['files']:
                dst=fresh/rel;dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/rel,dst)
            for script,out in [('analytic_verifier.py',names[0]),('geometry_verifier.py',names[1])]:
                (fresh/out).unlink()
                result=subprocess.run([sys.executable,str(fresh/script),'--output',str(fresh/out)],
                    cwd=fresh,capture_output=True,text=True,timeout=1800)
                print(result.stdout,end='',flush=True)
                if result.returncode:
                    raise RuntimeError(result.stderr)
                assert (fresh/out).read_bytes()==expected[out],('certificate changed',out)
            integrity()
    a=json.loads(expected[names[0]]);g=json.loads(expected[names[1]])
    assert a['status']==g['status']=='PASS'
    assert a['parabolic_uniform_gap']=='34/10125'
    assert g['independent_3D_pairs']==g['independent_4D_pairs']==7
    assert g['exact_auxiliary_slices']==20
    for x in [a,g]:
        assert x['general_CE_proved'] is False
        assert x['full_4D_Mahler_proved'] is False
    out={'version':'v53','date':'2026-09-26','status':'PASS','rebuild':rebuild,
         'manifest_files_checked':len(man['files']),
         'new_certificates_regenerated_and_byte_compared':2 if rebuild else 0,
         'independent_3D_pairs':7,'independent_4D_pairs':7,'auxiliary_slices':20,
         'all_finite_real_q_ge_1':'written analytic proof candidate, scalar signs certified on complete intervals',
         'all_symmetric_planar_bases':'no near-ellipse restriction in written theorem',
         'old_mathematical_history_rebuilt':False,'external_theorems_formalized':False,
         'general_CE_proved':False,'full_4D_Mahler_proved':False}
    (ROOT/'replay_output.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,indent=2,sort_keys=True),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rebuild',action='store_true')
    main(p.parse_args().rebuild)
