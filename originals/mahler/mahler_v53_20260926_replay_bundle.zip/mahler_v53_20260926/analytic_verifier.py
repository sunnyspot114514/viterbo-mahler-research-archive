#!/usr/bin/env python3
"""Exact algebra certificate for v53. Not a formalization of geometric theorems.

Reconstructs all integral formulas and the scalar dichotomy on the full
continuous parameter domain. Uses rational arithmetic and polynomial
identities/Bernstein coefficients, not floating point sampling.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy as sp

def eq(a, b=0):
    diff = sp.factor(a-b)
    if diff != 0:
        raise AssertionError(str(diff))

def bernstein(poly, x, left, right):
    y=sp.Symbol('_bernstein_parameter')
    p=sp.Poly(sp.expand(poly.subs(x,left+(right-left)*y)),y)
    n=p.degree()
    coeff=[sp.factor(sum(p.nth(j)*sp.binomial(i,j)/sp.binomial(n,j)
                         for j in range(i+1))) for i in range(n+1)]
    if not all(c>0 for c in coeff):
        raise AssertionError(('nonpositive Bernstein coefficient',coeff))
    eq(sum(coeff[i]*sp.binomial(n,i)*y**i*(1-y)**(n-i) for i in range(n+1)),p.as_expr())
    return {'interval':[str(left),str(right)],'degree':n,
            'coefficients':[str(c) for c in coeff],
            'minimum':str(min(coeff)),'negative':0,'zero':0}

def main(output: Path):
    t,r,z,s=sp.symbols('t rho z s', real=True)
    mu=sp.Symbol('mu',positive=True)
    u=2*(1+t)/(1+5*t)
    band=1+(r-1)*s*s/(t*t)
    tail=r*(1+(z-1)*(s-t)/(1-t))**2
    H=sp.factor(sp.integrate(band,(s,0,t))+sp.integrate(tail,(s,t,1)))
    L=sp.factor(sp.integrate((1-s)*band,(s,0,t))+sp.integrate((1-s)*tail,(s,t,1)))
    eq(H,(2*t+r*(1+(1-t)*(z+z*z)))/3)
    eq(L,(t*(8-3*t)+r*(3-2*t+(1-t)**2*(2*z+z*z)))/12)
    eq(sp.diff(H,z),r*(1-t)*(1+2*z)/3)
    zmax=(r+t-1)/(t*r)
    tangent_sq=(1-(1-r)*s/t)**2/r
    eq(sp.integrate(tail,(s,t,1)).subs(z,zmax),sp.integrate(tangent_sq,(s,t,1)))
    eq(r-(1-t)/(1-t*z), (t*r*(zmax-z))/(1-t*z))

    # Comparison with original 3D Mahler and auxiliary 3D Mahler.
    R=sp.factor(4*(1+2*t)*L-3*(1+t)*H)
    S=sp.factor(12*(1+2*t)*L-(1+5*t)*(2+r))
    eq(2*mu*(u+sp.Rational(2,3))*L-2*mu*u*H,
       4*mu*R/(3*(1+5*t)))
    eq(2*mu*(u+sp.Rational(2,3))*L-4*mu*(2+r)/9,
       4*mu*S/(9*(1+5*t)))
    eq(sp.diff(R,z),r*(t-1)*(4*(t*t+t+1)*z+4*t*t+t+1)/3)
    eq(sp.diff(S,z),2*r*(t-1)**2*(2*t+1)*(z+1))
    eq(R.subs(r,0),t*(2+t+6*t*(1-t))/3)
    eq(sp.diff(S,r),(t-1)**2*(2*t+1)*(z*z+2*z)+2-t-4*t*t)
    P=2*(t*t+t+1)*z*z+(4*t*t+t+1)*z-3*t*(2*t+1)
    eq(R.subs(r,1),(t-1)*P/3)
    eq(P.subs(z,1),3)

    # Small t: genuine tail-slope constraint is indispensable here.
    D6=12*t**6-20*t**5-t**4-12*t**3-4*t*t+4*t+3
    A5=12*t**5-20*t**4-13*t**3+9*t*t-13*t+7
    Q9=120*t**9-416*t**8+458*t**7-230*t**6+16*t**5+89*t**4-152*t**3+58*t*t+2*t+1
    Sn=sp.cancel((1-t*z)*S.subs(r,(1-t)/(1-t*z)))
    rem1=sp.rem(sp.Poly(Sn,z),sp.Poly(P,z)).as_expr()
    eq(rem1,(D6*z-t*A5)/(2*(t*t+t+1)))
    a=t*A5/D6
    eq(P.subs(z,a),-6*t*(t*t+t+1)*Q9/D6**2)
    bD=bernstein(D6,t,sp.Rational(0),sp.Rational(1,3))
    bQ=bernstein(Q9,t,sp.Rational(0),sp.Rational(1,3))

    # Middle t: Rogers--Shephard rho >= 2/3.
    N5=6*t**5-t**4+4*t**3-27*t*t+7*t+2
    T10=72*t**10+120*t**9-322*t**8-376*t**7+503*t**6-904*t**5+1922*t**4-664*t**3-259*t*t+56*t+14
    rem2=sp.rem(sp.Poly(S.subs(r,sp.Rational(2,3)),z),sp.Poly(P,z)).as_expr()
    eq(rem2,((1-t)**2*(1+t)*(2*t+1)*z-N5/3)/(t*t+t+1))
    a2=N5/(3*(1-t)**2*(1+t)*(2*t+1))
    eq(P.subs(z,a2),(t*t+t+1)*T10/(9*(1-t)**4*(1+t)**2*(2*t+1)**2))
    bT=bernstein(-T10,t,sp.Rational(1,3),sp.Rational(3,5))
    eq(S.subs({r:1,z:0}),3*t*(1-t)*(2*t-1))
    # Large t: coefficient at z=0 is nonpositive for t >= 3/5.
    x=sp.Symbol('x',nonnegative=True)
    eq((2-t-4*t*t).subs(t,x+sp.Rational(3,5)),
       -4*x*x-sp.Rational(29,5)*x-sp.Rational(1,25))

    # Independent short parabolic dichotomy and explicit positive gap.
    R2=sp.factor(R.subs(t,sp.Rational(1,3)))
    S2=sp.factor(S.subs(t,sp.Rational(1,3)))
    eq(R2,(33-r*(52*z*z+32*z+3))/81)
    eq(S2,(r*(20*z*z+40*z+33)-39)/27)
    cutoff=sp.Rational(51,100)
    rmargin=sp.factor(R2.subs({r:1,z:cutoff}))
    smargin=sp.factor(S2.subs({r:sp.Rational(2,3),z:cutoff}))
    eq(rmargin,sp.Rational(43,22500));eq(smargin,sp.Rational(17,6750))
    gap=min(4*rmargin,sp.Rational(4,3)*smargin)
    eq(gap,sp.Rational(34,10125))

    # q=1 and the independent auxiliary body's volumes.
    q1=2*mu*(5+r)/9
    eq(q1-4*mu*(2+r)/9,2*mu*(1-r)/9)
    b,aa,d=sp.symbols('b a d')
    za=b+(aa-b)*s*s
    vZ=sp.integrate(za,(s,-1,1))
    eq(vZ,2*(2*b+aa)/3)
    eq(vZ*(2*d/3),4*d*(2*b+aa)/9)

    # A deliberately invalid scalar shortcut: removing tail-mass information.
    naive=sp.Rational(35,54)*(9+6)
    assert naive<sp.Rational(32,3)

    result={
      'version':'v53','date':'2026-09-26','status':'PASS',
      'H':str(H),'L_comparison':str(L),'R':str(R),'S':str(S),
      'continuous_scalar_domain':{'t':'0 < t < 1','rho':'2/3 <= rho <= 1',
          'z':'0 <= z <= 1','tail_slope':'rho >= (1-t)/(1-t*z)'},
      'dichotomy_polynomial':str(P),
      'full_interval_positive_certificates':{'D6':bD,'Q9':bQ,'minus_T10':bT},
      'parabolic_cutoff':str(cutoff),'parabolic_R_margin':str(rmargin),
      'parabolic_S_margin':str(smargin),'parabolic_uniform_gap':str(gap),
      'q1_separately_checked':True,'auxiliary_3D_volume_identity_checked':True,
      'old_cone_relaxation_value':str(naive),
      'statement_scope':'All origin-symmetric planar D, finite real q>=1, legal continuous odd midpoint, specified contact direction; written analytic proof candidate.',
      'general_CE_proved':False,'full_4D_Mahler_proved':False,
      'geometric_analytic_theorems_formalized':False,
      'notes':'Exact identities and polynomial certificates only. Brunn--Minkowski, Rogers--Shephard, 3D Mahler, the band lemma and one-crossing argument require their written proofs.'
    }
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('v53 analytic identities and full-parameter sign certificates: PASS')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('analytic_certificate.json'))
    main(p.parse_args().output)
