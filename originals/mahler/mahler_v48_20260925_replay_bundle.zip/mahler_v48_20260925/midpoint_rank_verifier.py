#!/usr/bin/env python3
"""Exhaustive fixed-difference-body midpoint polytopes in the planar fan case.

For a centrally symmetric 2k-gon B with first k edge vectors e_i, all planar
A modulo translations with (A-A)/2=B correspond to
    -1 <= b_i <= 1,   sum_i b_i e_i=0.
A vertex has linearly independent unsaturated columns, hence at most two.
Enumeration extends those columns to a two-column basis and fixes all other
coordinates to signs; it is complete, including degenerate vertices.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations,product
from pathlib import Path
import argparse,json
from exact_geometry import hull2,area2,hpoly,rank,jsonable


def midpoint_vertices(edges):
    k=len(edges)
    if rank(edges)!=2:raise ValueError('The edge vectors must span the plane')
    result=set();bases=0
    for i,j in combinations(range(k),2):
        (a,c),(b,d)=edges[i],edges[j]
        det=a*d-b*c
        if not det:continue
        remaining=[q for q in range(k) if q not in (i,j)]
        for signs in product([-1,1],repeat=k-2):
            bases+=1;z=[F(0)]*k
            for q,s in zip(remaining,signs):z[q]=F(s)
            x=-sum(z[q]*edges[q][0] for q in remaining)
            y=-sum(z[q]*edges[q][1] for q in remaining)
            z[i]=(d*x-b*y)/det;z[j]=(-c*x+a*y)/det
            if all(abs(t)<=1 for t in z):result.add(tuple(z))
    for z in result:
        free=[edges[i] for i,t in enumerate(z) if abs(t)<1]
        assert rank(free)==len(free)<=2
        assert all(sum(z[i]*edges[i][j] for i in range(k))==0 for j in (0,1))
    return sorted(result),bases


def summand_from_allocation(edges,b):
    all_edges=[tuple((1+t)*x for x in e) for e,t in zip(edges,b)]
    all_edges += [tuple(-(1-t)*x for x in e) for e,t in zip(edges,b)]
    points=[];p=(F(0),F(0))
    for e in all_edges:
        points.append(p);p=tuple(x+y for x,y in zip(p,e))
    assert p==(0,0)
    A=hull2(points)
    mean=tuple(sum(p[j] for p in A)/len(A) for j in (0,1))
    return hull2([tuple(x-y for x,y in zip(p,mean)) for p in A])


def inspect(name,B_input):
    B=hull2(B_input);n=len(B)
    assert n%2==0 and all(tuple(-x for x in p) in B for p in B)
    edges=[tuple(y-x for x,y in zip(p,q)) for p,q in zip(B,B[1:]+B[:1])]
    k=n//2
    assert all(edges[i+k]==tuple(-x for x in edges[i]) for i in range(k))
    first=edges[:k]
    vertices,bases=midpoint_vertices(first)
    D=hull2(hpoly([(p,F(1)) for p in B],2)['vertices'])
    mu=area2(B)*area2(D)
    examples=[];free_counts={};A_counts={}
    for b in vertices:
        A=summand_from_allocation(first,b)
        recovered=hull2([tuple((x-y)/2 for x,y in zip(p,q)) for p in A for q in A])
        assert set(recovered)==set(B)
        rho=area2(A)/area2(B)
        assert 0<rho<=1 and F(4,9)*mu*(2+rho)>=F(32,3)
        count=sum(abs(t)<1 for t in b)
        free_counts[count]=free_counts.get(count,0)+1
        A_counts[len(A)]=A_counts.get(len(A),0)+1
        examples.append({'allocation':b,'unsaturated_coordinates':count,'A_vertices':A,'rho':rho,
                         'endpoint_contact_product':F(2,9)*mu*(5+rho)})
    return {'name':name,'B_vertices':B,'first_half_edge_vectors':first,
            'parameter_dimension_mod_translation':k-2,'vertices_count':len(vertices),
            'active_bases_enumerated':bases,'free_coordinate_distribution':free_counts,
            'summand_vertex_count_distribution':A_counts,'planar_Mahler':mu,'vertices':examples}


def main(output):
    triangle=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(-1))]
    hept=[(F(i),F(i*i-4)) for i in range(-3,4)]
    difference=lambda A:[tuple((x-y)/2 for x,y in zip(p,q)) for p in A for q in A]
    u=[(F(1),F(0)),(F(2),F(2)),(F(0),F(3))]
    p=tuple(-sum(e[j] for e in u)/2 for j in (0,1));B=[]
    for e in u+[tuple(-x for x in e) for e in u]:
        B.append(p);p=tuple(x+y for x,y in zip(p,e))
    records=[inspect('square',[(1,1),(-1,1),(-1,-1),(1,-1)]),
             inspect('triangle_difference',difference(triangle)),
             inspect('weighted_hexagon',B),inspect('heptagon_difference',difference(hept))]
    weighted=records[2]
    assert weighted['parameter_dimension_mod_translation']==1
    assert weighted['vertices_count']==2
    assert weighted['free_coordinate_distribution']=={2:2}
    result={'version':'v48','status':'PASS','general_PL_midpoint_theorem_formalized':False,
            'fixed_polygon_endpoint_censuses_complete':True,
            'naive_all_folds_saturated_claim':'FALSE: weighted_hexagon has two unsaturated pairs at each vertex',
            'general_CE_proved':False,'full_4D_Mahler_proved':False,'examples':records}
    output.write_text(json.dumps(jsonable(result),indent=2,sort_keys=True)+'\n',encoding='utf-8')
    for r in records:print(r['name'],'dimension',r['parameter_dimension_mod_translation'],
                           'vertices',r['vertices_count'],'free',r['free_coordinate_distribution'])
    print('PASS:',output)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,
        default=Path(__file__).resolve().parent/'midpoint_rank_certificate.json')
    main(p.parse_args().output)
