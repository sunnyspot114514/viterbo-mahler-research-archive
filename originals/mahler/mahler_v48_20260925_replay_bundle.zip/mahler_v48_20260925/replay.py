#!/usr/bin/env python3
"""Integrity/semantic checks; optional clean byte-identical rebuild of v48 only."""
from __future__ import annotations
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def check():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for rel,rec in manifest['files'].items():
        p=ROOT/rel
        assert p.is_file() and p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'],rel
    a=json.loads((ROOT/'radial_affine_certificate.json').read_text())
    b=json.loads((ROOT/'midpoint_rank_certificate.json').read_text())
    assert a['status']==b['status']=='PASS'
    assert a['exact_3D_examples']==16 and a['independent_full_4D_reconstructions']==5
    assert a['general_CE_proved'] is False and a['full_4D_Mahler_proved'] is False
    assert a['old_v1_through_v47_replayed'] is False
    assert sum(r['vertices_count'] for r in b['examples'])==45
    assert b['examples'][-1]['vertices_count']==40
    assert b['examples'][2]['free_coordinate_distribution']=={'2':2}
    return manifest

def main(rebuild):
    manifest=check()
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v48_clean_') as temp:
            root=Path(temp)
            for rel in manifest['files']:
                target=root/rel;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/rel,target)
            for script,out in [('radial_affine_verifier.py','radial_affine_certificate.json'),
                               ('midpoint_rank_verifier.py','midpoint_rank_certificate.json')]:
                (root/out).unlink()
                proc=subprocess.run([sys.executable,str(root/script),'--output',str(root/out)],
                                    cwd=root,capture_output=True,text=True,timeout=240)
                if proc.returncode:raise RuntimeError(proc.stdout+'\n'+proc.stderr)
                assert (root/out).read_bytes()==(ROOT/out).read_bytes(),out
                print(script+': clean rebuild and byte comparison PASS')
        check()
    result={'version':'v48','status':'PASS','rebuild':rebuild,
            'files_hash_checked':len(manifest['files']),
            'exact_3D_examples':16,'independent_full_4D_reconstructions':5,
            'fixed_polygon_endpoint_censuses':4,'endpoints_enumerated':45,
            'general_CE_proved':False,'full_4D_Mahler_proved':False,
            'old_v1_through_v47_replayed':False,
            'analytic_proofs_formalized':False}
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rebuild',action='store_true')
    main(p.parse_args().rebuild)
