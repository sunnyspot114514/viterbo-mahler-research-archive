# Mahler v48 — 2026-09-25

A research increment following the v47 contact-endpoint work.

## Contents

- `report_zh.md`: assumptions, complete written derivations, sharp radial-affine contact inequality, finite PL midpoint reduction, and limitations.
- `radial_affine_verifier.py`: symbolic checks and 16 complete exact 3D reconstructions, including 5 independently integrated 4D contact/polar pairs.
- `midpoint_rank_verifier.py`: complete endpoint enumerations for four fixed planar difference bodies (45 endpoints in total).
- `exact_geometry.py`: exhaustive rational halfspace enumeration and coherent pulling triangulations.
- `*_certificate.json`: exact outputs, including geometry and endpoint data.
- `manifest.json` and `replay.py`: integrity checks and clean deterministic rebuilding.

## Run

Python 3.11 or later, with SymPy 1.14.0 (the version used for this snapshot):

```bash
python replay.py
python replay.py --rebuild
```

The first command checks hashes and recorded semantic assertions. The second copies the snapshot to a clean temporary directory, reruns both new verifiers, and byte-compares their JSON outputs.

## Main analytic result

Let `D` be any origin-symmetric planar convex body, `g_D` its gauge, and `0 <= tau <= 1`. A centrally symmetric 3D body with half-chord length `1-tau*g_D` may have any continuous odd midpoint compatible with convexity. Its contact construction `Q` satisfies

`M_4(Q) >= 32/3 + (16/9)*tau*(1-tau^2)`.

The bound is sharp for every tau. The theorem has no combinatorial-size restriction. The proof uses the established three-dimensional symmetric Mahler theorem and planar mixed-area/Brunn--Minkowski facts.

## Scope

The written analytic proofs have not had external independent review and are not formalized in a proof assistant. Finite verifier PASS is not a claim of formal verification of the analytic theorems. General CE, all lambda=1 gluings, and unrestricted 4D symmetric Mahler remain unresolved by this increment. Earlier v1–v47 artifacts, including bounded-12 exhaustiveness, were not replayed.
