#!/usr/bin/env python3
"""Exact symbolic and exhaustive finite checks for the v48 radial-affine theorem.
This does not formalize mixed-area theory, Brunn--Minkowski, or 2D/3D Mahler.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sympy as sp
from exact_geometry import central_pair,hpoly,hull2,area2,volume_moment,jsonable


def symbolic():
    c,rho,s,mu=sp.symbols('c rho s mu',real=True)
    cross=(1-s)**2+2*c*s*(1-s)+rho*c*c*s*s
    W=sp.factor(2*sp.integrate(cross,(s,0,1)))
    J=sp.factor(2*sp.integrate(s*cross,(s,0,1)))
    E=sp.factor((sp.Rational(2,3)*(3-2*c)+sp.Rational(2,3))*(W-J)*mu)
    target=sp.Rational(2,9)*mu*(2-c)*(3+2*c+rho*c*c)
    assert sp.expand(E-target)==0
    Vp=sp.Rational(4,9)*mu*(3-2*c)*(1+c+rho*c*c)
    endpoint_excess=sp.factor(E.subs(c,1)-Vp.subs(c,1))
    assert sp.expand(endpoint_excess-sp.Rational(2,9)*mu*(1-rho))==0
    second=sp.diff(E,c,2)
    assert sp.expand(second-sp.Rational(2,9)*mu*(4*(rho-1)-6*rho*c))==0
    chord_gap=sp.factor(E-((1-c)*E.subs(c,0)+c*E.subs(c,1)))
    assert sp.expand(chord_gap-sp.Rational(2,9)*mu*c*(1-c)*(2-rho+rho*c))==0
    sharp=sp.Rational(32,3)+sp.Rational(16,9)*c*(1-c*c)
    coefficient=(2-c)*(3+2*c+c*c)/6
    remainder=sp.Rational(2,27)*mu*(2-c)*(1-rho)*(3+2*c-2*c*c)
    assert sp.expand(E-sharp-coefficient*(Vp.subs(c,1)-sp.Rational(32,3))-remainder)==0
    a,V,W0,J0,A=sp.symbols('a V W0 J0 A', nonnegative=True)
    contact=(V+sp.Rational(2,3)*a*A)*(W0-a*J0)
    assert sp.diff(contact,a,2)==-sp.Rational(4,3)*A*J0
    return {'cross_section_area_div_B':str(cross),'polar_volume_div_B':str(W),
            'absolute_moment_div_B':str(J),'contact_product':str(E),
            'second_derivative':str(sp.factor(second)),
            'endpoint_excess_over_3D_Mahler':str(endpoint_excess),
            'chord_gap':str(chord_gap),'sharp_lower_bound':str(sharp),
            'sharp_remainder':str(remainder),'endpoint_Mahler_coefficient':str(coefficient),
            'noncontact_second_derivative':str(sp.diff(contact,a,2)),
            'all_symbolic_identities':'PASS'}


def example(name,A_input,c,check4):
    A=hull2(A_input)
    B=hull2([tuple((x-y)/2 for x,y in zip(p,q)) for p in A for q in A])
    D=hull2(hpoly([(b,F(1)) for b in B],2)['vertices'])
    SA,SB,SD=area2(A),area2(B),area2(D);rho=SA/SB;mu=SB*SD
    BA=hull2([tuple(x+y for x,y in zip(p,q)) for p in B for q in A])
    mixed=(area2(BA)-SB-SA)/2
    assert mixed==SB and 0<rho<=1 and mu>=8
    points=[(F(0),)+p for p in B]
    for p in A:
        q=(F(1),c*p[0],c*p[1]);points.extend([q,tuple(-x for x in q)])
    K,C=central_pair(points)
    W,_,kw=volume_moment(K);V,_,cv=volume_moment(C)
    half=hpoly([(p,F(1)) for p in C['vertices']]+[((F(-1),F(0),F(0)),F(0))],3)
    halfvol,halfJ,hj=volume_moment(half,0);J=2*halfJ
    assert 2*halfvol==W
    assert V==F(2,3)*SD*(3-2*c)
    assert W==F(2,3)*SB*(1+c+rho*c*c)
    assert J==SB/F(6)*(1+2*c+3*rho*c*c)
    E=(V+F(2,3)*SD)*(W-J)
    assert E==F(2,9)*mu*(2-c)*(3+2*c+rho*c*c)
    sharp=F(32,3)+F(16,9)*c*(1-c*c)
    assert V*W>=F(32,3) and E>=sharp
    rec={'name':name,'c':c,'A_vertices':A,'B_vertices':B,'D_vertices':D,
         'A_area':SA,'B_area':SB,'D_area':SD,'rho':rho,'planar_Mahler':mu,
         'mixed_area_B_A':mixed,'C_vertices':len(C['vertices']),'C_facets':len(K['vertices']),
         'C_volume':V,'C_polar_volume':W,'absolute_moment':J,'C_Mahler':V*W,
         'contact_product':E,'contact_margin':E-F(32,3),'sharp_lower_bound':sharp,
         'margin_over_sharp_bound':E-sharp,
         'C_polar_full_data':K,'C_full_data':C,'half_polar_full_data':half,
         'triangulations':{'C':cv,'polar':kw,'positive_half':hj},
         'full_4D_reconstruction':check4}
    if check4:
        Qpoints=[(F(0),)+p for p in C['vertices']]
        Qpoints.extend([(F(x),F(t),F(0),F(0)) for x,t in product([-1,1],repeat=2)])
        Q,Qpolar=central_pair(Qpoints)
        V4,_,qv=volume_moment(Q);W4,_,qw=volume_moment(Qpolar)
        assert V4==V/F(2)+SD/F(3)
        assert W4==2*(W-J)
        assert V4*W4==E
        rec.update({'Q_vertices':len(Q['vertices']),'Q_facets':len(Qpolar['vertices']),
                    'Q_volume':V4,'Q_polar_volume':W4,'Q_full_data':Q,'Q_polar_full_data':Qpolar,
                    'Q_triangulation':qv,'Q_polar_triangulation':qw})
    rec['nonlinear_midpoint_certified_by_rho_lt_1']=bool(c>0 and rho<1)
    return rec


def main(output):
    sym=symbolic()
    families={
        'square_control':[(-1,-1),(1,-1),(1,1),(-1,1)],
        'triangle':[(1,0),(0,1),(-1,-1)],
        'asymmetric_quadrilateral':[(-2,-1),(2,-1),(1,2),(-1,1)],
        'parabolic_heptagon':[(i,i*i-4) for i in range(-3,4)]}
    samples=[]
    for name,A in families.items():
        for c in [F(0),F(1,3),F(1,2),F(1)]:
            check4=(c==F(1,2)) or (name=='triangle' and c==1)
            rec=example(name,A,c,check4);samples.append(rec)
            print(name,str(c),'3D',rec['C_vertices'],rec['C_facets'],'E',rec['contact_product'],
                  ('4D '+str(rec['Q_vertices'])+'/'+str(rec['Q_facets'])) if check4 else '',flush=True)
    result={'version':'v48','date':'2026-09-25','status':'PASS',
            'symbolic':sym,'exact_3D_examples':len(samples),
            'independent_full_4D_reconstructions':sum(x['full_4D_reconstruction'] for x in samples),
            'arithmetic':'Fraction geometry and SymPy symbolic identities; no floating hulls',
            'analytic_theorem_status':'written proof using external 2D/3D Mahler and planar mixed-area/BM',
            'general_CE_proved':False,'all_lambda1_gluings_proved':False,'full_4D_Mahler_proved':False,
            'old_v1_through_v47_replayed':False,'samples':samples}
    output.write_text(json.dumps(jsonable(result),indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('PASS:',output,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,
        default=Path(__file__).resolve().parent/'radial_affine_certificate.json')
    main(parser.parse_args().output)
