#!/usr/bin/env python3
"""Exact finite algebra for the v46 joint contact-endpoint sufficient condition.
Analytic inputs: v45 single-crossing section lemma and 2D/3D Mahler.
No general contact-endpoint theorem is claimed.
"""
from pathlib import Path
import json
from math import comb
import sympy as sp
ROOT=Path(__file__).resolve().parent
k=sp.symbols('k', real=True)

def bernstein(p,x,a,b):
    t=sp.Dummy('t')
    poly=sp.Poly(sp.expand(p.subs(x,a+(b-a)*t)),t,domain=sp.QQ)
    n=poly.degree()
    cs=[sum(poly.nth(j)*sp.Rational(comb(i,j),comb(n,j)) for j in range(i+1)) for i in range(n+1)]
    assert sp.expand(sum(cs[i]*sp.binomial(n,i)*t**i*(1-t)**(n-i) for i in range(n+1))-poly.as_expr())==0
    return cs

def table(p, intervals):
    records=[]
    for a,b in intervals:
        a,b=map(sp.Rational,(a,b));cs=bernstein(p,k,a,b)
        assert all(c>0 for c in cs),(a,b,cs)
        records.append({'interval':[str(a),str(b)],'coefficients':list(map(str,cs)),'minimum':str(min(cs))})
    assert intervals[0][0]==0 and intervals[-1][1]==1
    return records

def main():
    w=1-k+k*k/3;j=sp.Rational(1,2)-2*k/3+k*k/4;d=w-j
    shape=sp.factor((1+sp.Rational(10,9)*w)*d/w-1)
    shape_num=10*k**4-70*k**3+129*k**2-84*k+18
    assert sp.factor(shape-shape_num/(108*(k*k-3*k+3)))==0
    shape_table=table(shape_num,[(0,sp.Rational(1,4)),(sp.Rational(1,4),sp.Rational(1,2)),(sp.Rational(1,2),sp.Rational(5,8)),(sp.Rational(5,8),1)])
    high=sp.factor((sp.Rational(273,256)+w)*d/w-1)
    high_num=256*k**4-1792*k**3+3123*k**2-1740*k+306
    assert sp.factor(high-high_num/(3072*(k*k-3*k+3)))==0
    high_table=table(high_num,[(0,sp.Rational(1,4)),(sp.Rational(1,4),sp.Rational(3,8)),(sp.Rational(3,8),sp.Rational(1,2)),(sp.Rational(1,2),1)])
    # Convex interpolation between two certified points in (mu,zeta) space.
    mu,zeta,theta,M,P=sp.symbols('mu zeta theta M P', real=True)
    f=lambda m,z:sp.factor((m+z*w)*d/w-1)
    mix_mu=1+sp.Rational(17,256)*theta
    mix_zeta=1+sp.Rational(1,9)*(1-theta)
    assert sp.factor(f(mix_mu,mix_zeta)-theta*high-(1-theta)*shape)==0
    assert sp.factor(256*mix_mu+153*mix_zeta-426)==0
    assert sp.expand(8*(256*(3*M/32)+153*(P/8)-426)-3*(64*M+51*P-1136))==0
    # Exact obstruction of the relaxed data: geometry is not fabricated.
    kval=sp.Rational(1,2)
    relaxed=sp.factor(f(1,1).subs(k,kval)+1)
    assert relaxed==sp.Rational(323,336)
    # A real affine-profile body has the compensating mu=(1+2k)w instead.
    affine_mu=(1+2*k)*w
    affine_E=sp.factor(f(affine_mu,1)+1)
    assert sp.factor(affine_E-(1+k*(1-k)*(2-k)/6))==0
    out={'status':'PASS','analytic_interfaces_not_formalized':['v45 section-root concavity and single-crossing comparison','2D Mahler P=A*B>=8','3D Mahler M(C)>=32/3'],
        'shape_threshold':{'condition':'P(C,e)>=80/9','conclusion':'E(C,e)>32/3','polynomial':str(shape_num),'tables':shape_table},
        'inherited_high_threshold_rederived':{'condition':'M(C)>=91/8','polynomial':str(high_num),'tables':high_table},
        'joint_condition':{'normalized':'mu>=1, zeta>=1, 256*mu+153*zeta>=426','geometric':'64*M(C)+51*P(C,e)>=1136','conclusion':'E(C,e)>32/3','boundary_interpolation':{'mu':'1+17*theta/256','zeta':'1+(1-theta)/9','theta':'0<=theta<=1'}},
        'general_scalar_polynomial':{'variables':{'M':'M(C)','P':'area(proj C)*area(Cpolar central section)'},'polynomial':'(9*M+4*P*(k^2-3*k+3))*(k^2-4*k+6)-384*(k^2-3*k+3)','positive_denominator':'36*(k^2-3*k+3)','interval':'0<=k<=1'},
        'remaining_possible_counterexample':{'M':'32/3 < M(C) < 91/8 (v45 supplies an additional unquantified epsilon0 gap)','P':'8 <= P(C,e) < 80/9','coupled':'64*M(C)+51*P(C,e)<1136'},
        'relaxation_caveat':{'formal_triple':'mu=1,zeta=1,k=1/2','relaxed_E_divided_by_32_3':str(relaxed),'not_claimed_realizable':True,'real_affine_profile_compensation':'mu=(1+2k)w, E/(32/3)=1+k(1-k)(2-k)/6 when planar product=8'},
        'general_CE_proved':False,'full_4D_conjecture_proved':False}
    (ROOT/'joint_bound_certificate.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':'PASS','joint_condition':out['joint_condition']['geometric'],'general_CE_proved':False},indent=2))
if __name__=='__main__':main()
