# v46：接触端点的有限方向归约、联合充分条件与斜截立方体全参数族

日期：2026-09-07。

**证明状态。** 本文给出可逐项核查的解析推导和精确有理数计算证书，尚未经过独立实现复核或外部同行审阅。没有证明任意三维凸体的接触端点不等式，没有证明全部 λ=1 粘合，也没有证明完整四维中心对称 Mahler 猜想。本轮没有重新认证早期 bounded-12 分类的穷尽性。

## 1. 结果概览

本轮得到三个结果。

1. 对任意固定中心对称三维多胞体 C，其全部接触方向的最坏情形可以归约到有限个由 facet-normal 平面产生的交点。若 C 有 m 对 facets，候选方向按反向等价计至多有 13·binomial(m,3) 个。该界依赖 m，不是复杂度无关的有限核心。
2. 令 Σ(C,e)=area(proj_{e⊥} C)·area(C°∩e⊥)。联合充分条件为
   \[
   \boxed{64M(C)+51\Sigma(C,e)\ge1136
   \quad\Longrightarrow\quad\mathcal E(C,e)>32/3.}
   \]
   其中使用了已证明的二维、三维中心对称 Mahler 定理及 v45 的截面矩比较。
3. 对完整连续族
   \[
   C_s=[-1,1]^3\cap\{|x_1+x_2+x_3|\le s\},\qquad1\le s\le3,
   \]
   对所有 v∈C_s 都有 E_{C_s}(v)≥32/3；若 1<s<3，则严格大于。因而该族的所有接触方向及所有包含于 C_s 内的重叠线段均已覆盖，不限于坐标方向或有限样本。

本文“本轮得到”仅说明本轮完成的推导；没有进行足以支持首创声明的全面文献优先权调查。

## 2. 接触向量形式

令 C=-C⊂R³ 满维，K=C°，V=|C|，W=|K|。对 v∈C 定义
\[
 a_C(v)=\|v\|\,|\operatorname{proj}_{v^\perp}C|,\qquad
 J_K(v)=\int_K|\langle v,y\rangle|\,dy,
\]
并令 a_C(0)=0。定义
\[
 E_C(v)=\left(V+\frac23a_C(v)\right)(W-J_K(v)).
\]
当 v=r e∈∂C 时，这就是 v44/v45 的接触端点表达式。对一般 v∈C，四维体
\[
 Q(C,v)=\operatorname{conv}\bigl(\{0\}\times C,[-1,1]\times[-v,v]\bigr)
\]
满足
\[
 |Q|=V/2+a_C(v)/3,\qquad |Q^\circ|=2(W-J_K(v)),
\]
因此 M(Q)=E_C(v)。这些恒等式的解析推导及原始 exact convex-hull 程序保留在 baseline_v45 的 v44 子目录中。

对 v∈C，|v·y|≤1 在 K 上成立；在 K 的内部几乎处处严格小于1。因此 W−J_K(v)>0，包括 v∈∂C 的情形。

## 3. 有限方向归约定理

设 C 是多胞体，完整不可约表示为
\[
 C=\{v:|n_i\cdot v|\le1,\ i=1,\ldots,m\}.
\]
这里 n_i 是 normalized facet-normal representatives，包含每对 antipodal facets 的一个代表。

### 3.1 投影体积在每个符号区域上是线性的

Cauchy 投影公式在三维多胞体上为
\[
 a_C(v)=\frac12\sum_{F\text{ 全部 facets}}|F|\,|\nu_F\cdot v|,
\]
其中 ν_F 是单位外法向。该公式也可以直接由可见 facets 沿 v 的投影分解得到。

用所有平面 n_i·v=0 将 C 划分成闭凸多面体
\[
 D_\varepsilon=C\cap\{\varepsilon_i n_i\cdot v\ge0\text{ 对全部 }i\},
 \qquad\varepsilon_i\in\{-1,1\}.
\]
在每个 D_ε 上，a_C 是线性函数。另一方面，J_K 是凸函数，所以 W−J_K 是严格正的凹函数。于是
\[
 \log E_C(v)
 =\log\left(V+\frac23a_C(v)\right)+\log(W-J_K(v))
\]
在 D_ε 上是凹函数。这里使用 log 在正数上凹且单调递增。

若 v 是 D_ε 顶点的凸组合，由凹性
\[
 E_C(v)\ge\prod_jE_C(v_j)^{\alpha_j}\ge\min_jE_C(v_j).
\]
因此每个区域的最小值都可以在该区域某个顶点取得。

### 3.2 候选交点及计数

所有区域顶点是平面
\[
 n_i\cdot v\in\{-1,0,1\}
\]
的三重独立交点。三个右端均为0时只得到原点。其余满足 v∈C 的交点均在 ∂C 上。

所以
\[
 \boxed{
 \min_{v\in C}E_C(v)
 =\min\left(M(C),\ \min_{v\in\mathcal V_C}E_C(v)\right),
 }
\]
其中 \(\mathcal V_C\) 是所有可行三重交点的集合，去掉0。

每个 independent normal triple 有26个非零右端，按 v~−v 去重至多13个。因此
\[
 \boxed{|\mathcal V_C/\{\pm1\}|\le13\binom m3.}
\]
奇异 normal triples 直接跳过；不同 triples 得到的相同点再次去重。

几何上，候选来自 C 的顶点、边与一个 central normal plane 的交点、以及 facet 与两个 central normal planes 的交点。定理没有声称所有 C 只需检查固定数量的方向。

### 3.3 两个独立校准

程序从完整 normal list 生成候选并重新积分，得到：

| C | 反向等价候选数 | E 值的完整分布 |
|---|---:|---|
| 标准 cube |13|3个32/3，6个100/9，4个34/3|
| 标准 octahedron |9|9个全部32/3|

结合 E_C(0)=M(C)=32/3，这独立恢复了两类等号体的全部方向下界。候选点以外也可能存在等号线段；本节只用于下界，不从候选值分布未经证明地推导完整等号集合。

## 4. 不再只按 M(C) 筛选：联合充分条件

沿用 v45 的记号：m₀=32/3，μ=M(C)/m₀，ζ=Σ/8。二维、三维 Mahler 给出 μ≥1、ζ≥1。

极体归一化截面面积平方根 f 是偶凹函数，f(0)=1。令
\[
 w=\int_0^1 f(t)^2dt=1-k+k^2/3,\qquad0\le k\le1,
\]
\[
 j(k)=\frac12-\frac{2k}{3}+\frac{k^2}{4}.
\]
v45 的单交叉引理保证真实一阶矩不大于 j(k)，从而
\[
 \frac{\mathcal E}{m_0}\ge(\mu+\zeta w)\frac{w-j(k)}w.
\tag{4.1}
\]
本轮重放了该引理所使用的全部 v45 有限代数证书；解析凹性和积分比较不是 Python 形式化内容。

### 4.1 一个新的投影—截面阈值

在 μ=1、ζ=10/9 处，式(4.1)减1等于
\[
 \frac{10k^4-70k^3+129k^2-84k+18}{108(k^2-3k+3)}.
\]
分母为正。分子在四个闭区间上的 degree-4 Bernstein 表全部严格为正：

| 区间 | 最小系数 |
|---|---:|
|[0,1/4]|513/128|
|[1/4,1/2]|1/8|
|[1/2,5/8]|3/64|
|[5/8,1]|669/2048|

因此
\[
 \boxed{\Sigma(C,e)\ge80/9\Longrightarrow\mathcal E(C,e)>32/3.}
\]

### 4.2 与旧高 Mahler 区域作凸插值

v45 已验证 (μ,ζ)=(273/256,1) 对全部 k 严格充分，本轮也重新算了它的四张 Bernstein 表。

式(4.1)对 μ、ζ 是线性的并单调递增，因此整个线段
\[
 \mu_\theta=1+\frac{17}{256}\theta,\qquad
 \zeta_\theta=1+\frac19(1-\theta),\qquad0\le\theta\le1
\]
及其右上方都充分。在线段上
\[
 256\mu_\theta+153\zeta_\theta=426.
\]
结合 μ≥1、ζ≥1，得到
\[
 \boxed{64M(C)+51\Sigma(C,e)\ge1136
 \quad\Longrightarrow\quad\mathcal E(C,e)>32/3.}
\tag{4.2}
\]

这不是一个已经证明的“真实几何自动满足该直线约束”的定理。它只是新的可检查充分条件。它超出 v45 仅用 M(C)≥91/8 的高值区间，也没有量化 v45 的 ε₀。

若一般接触不等式存在反例，它必须同时满足
\[
 M(C)<91/8,\quad8\le\Sigma<80/9,\quad64M(C)+51\Sigma<1136.
\]
另可保留 v45 经外部 Hanner 局部极小性推出的定性条件 M(C)>32/3+ε₀。ε₀仍无有效数值。

## 5. 全方向、全参数斜截立方体族

定义
\[
 C_s=[-1,1]^3\cap\{|x_1+x_2+x_3|\le s\},\quad1\le s\le3.
\]
其极体是
\[
 K_s=\operatorname{conv}\{\pm e_1,\pm e_2,\pm e_3,\pm(1,1,1)/s\}.
\]
1<s<3 时，C_s 有12个顶点、8个 facets。端点 C_1 是 octahedron 的线性像，C_3 是 cube。

直接切掉 cube 的两个 simplex corners 得
\[
 V(s)=8-\frac{(3-s)^3}{3}.
\]
在 octahedron B₁³ 的两个相反三角面上各加一个 tetrahedral pyramid 得
\[
 W(s)=1+\frac1s.
\]
三维 Mahler 余量为
\[
 V(s)W(s)-\frac{32}{3}
 =\frac{(s-3)(s-1)(s^2-4s-1)}{3s},
\]
在 1<s<3 严格为正。

### 5.1 只有六种候选接触路径

normal pairs 是 e₁,e₂,e₃,(1,1,1)/s。对全部4个 normal triples 和各26个非零右端作符号求解，完整得到42条在非退化参数区间内可行的有向 affine paths。按坐标置换及整体取负，只剩六种：

| 代表 v(s) | 有效参数区间 |
|---|---|
|(1,0,0)|[1,3]|
|(1,−1,0)|[1,3]|
|(1,1,0)|[2,3]|
|(1,1,−1)|[1,3]|
|(1,s−1,0)|[1,2]|
|(1,1,s−2)|[1,3]|

最后一种的一阶绝对矩在 s=2 处分段。只在 s=1,2,3 单点可行的额外交点也被记录：它们由极限覆盖；s=1、3 两个体另有等号体校准。

真实反向等价候选数在 s=1,3/2,2,5/2,3 依次为9,18,12,15,13。

### 5.2 投影及绝对一阶矩

令 h=(3−s)²/2。六个 coordinate facets 的面积各为4−h；两个 diagonal facets 的面积各为√3 h。因此
\[
 a_{C_s}(v)=(4-h)(|v_1|+|v_2|+|v_3|)+h|v_1+v_2+v_3|.
\]
K_s 分成8个 octahedral orthant tetrahedra 和2个 attached tetrahedra。每个 simplex 上的绝对 affine moment 由 t₊⁴ 的 confluent divided difference 精确积分。程序在选取符号前，先用精确多项式根计数核验各区间内的符号以及节点差不穿零；重复节点用导数公式处理，不以浮点近似扰动。

记 J=∫_{K_s}|v·y|dy，六种路径的七个区间给出：

| 路径/区间 | J |
|---|---|
|axis| (3s²+2s+3)/(12s²) |
|opposite pair| (5s+3)/(12s) |
|same pair| (2s²+2s+3)/(6s²) |
|cube vertex| (6s³+10s²+5s+3)/(12s²(s+1)) |
|cap midpoint| (3s²−2s+7)/(12s) |
|cap vertex, 1<s<2| −(3s⁴−24s³+62s²−30s−59)/(12s(s−3)²) |
|cap vertex, 2<s<3| (3s⁴−12s³+26s²−22s+3)/(12s(s−1)²) |

所有公式、符号区间、余量分子分母及其 Bernstein 系数都保存在 directional_reduction_certificate.json。

### 5.3 全区间正性

对每个区间形成
\[
 E(s)=\left(V(s)+\frac23a_{C_s}(v(s))\right)(W(s)-J(s)).
\]
将 E(s)−32/3 通分，剥离可能在端点为零的正因子 s−1、3−s，剩余 numerator 在七个完整区间上的 Bernstein 系数均严格为正。最小 numerator coefficients 依次为
\[
 \boxed{48,\ 24,\ 51,\ 256,\ 51,\ 51,\ 51}.
\]
所有 denominator coefficients 同样严格为正。没有从离散参数抽样推断全区间符号。

例如 axis 路径的余量为
\[
 E(s)-\frac{32}{3}
 =\frac{(3-s)(s-1)(-9s^3+35s^2+17s+5)}{36s^2}.
\]
剩余 cubic 在[1,3]上的 Bernstein 系数最小值是48。

由第3节有限方向定理，七张一变量证书同时推出
\[
 \boxed{E_{C_s}(v)\ge32/3\quad\forall s\in[1,3],\ \forall v\in C_s.}
\]
若 1<s<3，候选值和 v=0 的值都严格超过32/3，因此所有 v∈C_s 严格超过32/3。结论自然包括对 C_s 与 v 同时施加可逆线性变换的情形。

这一证明不假设横截面同似。比如 s=2 时，x₁=0 截面是一个正方形，x₁=1 截面是切去一角的五边形，二者不能同似；x₁=1/2 也已是五边形。

## 6. 一个确实超出旧高值阈值的接触

取 s=5/2，v=(5/6,5/6,5/6)。有
\[
 M(C)=1337/120<91/8,\qquad\Sigma=9.
\]
Σ 的计算使用投影商坐标 (x₁−x₃,x₂−x₃) 与其自然对偶 section 坐标 (y₁,y₂,−y₁−y₂)：二者面积为12和3/4，乘积为9。欧氏投影与截面变换的互逆 Jacobians 抵消。

此时
\[
 64M(C)+51\Sigma=17581/15>1136.
\]
新的联合判据适用，旧的 M(C)≥91/8 判据本身不适用。

独立四维凸包重构得到 Q:16V/26F，以及
\[
 |Q|=117/16,\quad|Q^\circ|=197/120,\quad M(Q)=7683/640.
\]
不声称它位于 v45 定性近等号邻域之外，因为该邻域半径仍未知。

## 7. 本轮真实计算范围

- 完整重跑 v45 replay.py --rebuild，其中包括原 v44 两脚本及 v45 三脚本；证书逐字节一致。
- 新的联合阈值 verifier 精确重建8张一变量 Bernstein 表及凸插值恒等式。
- 候选 normal-plane catalogue 完整符号枚举，不使用随机搜索。
- cube 的13个和 octahedron 的9个反向方向候选，分别进行精确三维积分校准。
- 新增8次四维原像/极体完整重构：七个候选 moment interval 各一个有理内部点，加上第6节的对角接触。
- 八次重构都重新枚举所有支撑、完整极体顶点和 face lattice，再经 pulling triangulation 精确求体积；没有使用浮点 Qhull 或数值积分。
- 所有参数区间结论来自符号正性与有限方向定理，八个样本仅用于交叉验证。
- 干净目录重跑并逐字节比较两个新增证书。继承 v1–v43 不在本轮重放范围。

## 8. 仍未证明的部分与下一目标

本轮既没有证明真实几何总满足 64M+51Σ≥1136，也没有证明所有一般 C 都可以下降到 C_s。有限方向定理的候选数量依赖 facets 数；它不等于复杂度无关的归约。

剩余一般 CE 反例必须落在 v45 的中间 M 带以及本轮的联合不足区域，而且对多胞体必须能在某个 normal-arrangement 候选接触处实现。下一步可分别研究三个 support-contact 类型的几何耦合，而不再进行无限方向扫描。

整个 λ=1 的 rank-two 多边形一侧归约，以及 λ=2 和无低阶分离的核心仍未完成。完整四维猜想没有在本轮解决。

## 9. 外部接口与来源

[1] H. Iriyeh, M. Shibata, *Symmetric Mahler's conjecture for the volume product in the three dimensional case*, Duke Math. J. 169 (2020), 1077–1134; arXiv:1706.01749v3。使用三维下界与已知等号体，不在 Python 重新证明。

[2] 平面中心对称 Mahler 定理、Brunn–Minkowski 截面凹性、Cauchy 投影公式。背景见 M. Fradelizi, M. Meyer, A. Zvavitch, *Volume Product*, arXiv:2301.06131。第3节给出 Cauchy 公式进入本证明的具体方式。

[3] v45, *接触端点的截面矩估计、近极小区间归约与等号体全方向验证*, 2026-09-06。本包保留其完整源码/证书并实际重放。其原始归档 SHA-256 为 4eef51bf65a049f090c64488737adcf2738752a5b7608dedfed47c9b5874fe1b。

[4] J. Kim, *Minimal volume product near Hanner polytopes*, arXiv:1212.2544。仅经 v45 继承近最小值存在某个定性安全邻域的论证；本轮没有给该邻域半径赋值。
