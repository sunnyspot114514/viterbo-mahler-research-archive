#!/usr/bin/env python3
"""Integrity and clean exact rebuild of the v46 contact-endpoint work.

Analytic theorem interfaces are stated in report_zh.md. PASS covers finite
algebra, complete stated enumerations, and reconstruction consistency only.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest() -> dict:
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for relative, record in manifest['files'].items():
        path = ROOT / relative
        if not path.is_file() or path.stat().st_size != record['bytes'] or digest(path) != record['sha256']:
            raise RuntimeError(f'Payload integrity mismatch: {relative}')
    return manifest


def run_exact(script: Path, extra: tuple[str, ...] = ()) -> dict | None:
    result = subprocess.run([sys.executable, str(script), *extra], cwd=script.parent,
                            capture_output=True, text=True, timeout=600)
    if result.returncode:
        raise RuntimeError(f'{script.name} failed:\n{result.stdout[-5000:]}\n{result.stderr[-5000:]}')
    print(f'completed {script.name}', flush=True)
    return None


def semantic_check() -> dict:
    joint = json.loads((ROOT / 'joint_bound_certificate.json').read_text())
    directions = json.loads((ROOT / 'directional_reduction_certificate.json').read_text())
    if joint['status'] != 'PASS' or directions['status'] != 'PASS':
        raise RuntimeError('A component is not PASS')
    assert joint['joint_condition']['geometric'] == '64*M(C)+51*P(C,e)>=1136'
    assert joint['shape_threshold']['condition'] == 'P(C,e)>=80/9'
    assert directions['symbolic_catalog_exhaustion']['nondegenerate_feasible_affine_paths'] == 42
    assert len(directions['all_direction_family']['catalog_moment_intervals']) == 7
    assert directions['new_4D_reconstruction_count'] == 8
    assert [x['unoriented_candidate_count'] for x in directions['Hanner_directional_calibrations']] == [13, 9]
    assert directions['reconstructions'][-1]['E'] == '7683/640'
    assert not joint['general_CE_proved'] and not directions['limitations']['general_CE_proved']
    return {
        'joint_sufficient_condition': '64*M(C)+51*Sigma(C,e)>=1136 => E(C,e)>32/3',
        'shape_sufficient_condition': 'Sigma(C,e)>=80/9',
        'finite_contact_direction_reduction': 'proved analytically for every fixed centrally symmetric 3D polytope',
        'unoriented_direction_bound': '13*binomial(m,3), depending on the number m of facet pairs',
        'all_direction_continuous_family': 'C_s=[-1,1]^3 intersect {|x1+x2+x3|<=s}, 1<=s<=3',
        'all_contained_overlap_segments_in_family': True,
        'strict_for_interior_family_parameters': True,
        'symbolic_affine_candidate_paths': 42,
        'candidate_path_orbits': 6,
        'certified_moment_intervals': 7,
        'cube_octahedron_candidate_counts': [13, 9],
        'new_independent_exact_4D_reconstructions': 8,
        'below_old_high_threshold_example': {
            'M_C': '1337/120', 'Sigma': '9', 'contact_E': '7683/640',
            'four_dimensional_combinatorics': '16V/26F'},
        'epsilon0_quantified': False,
        'general_contact_endpoint_inequality_proved': False,
        'all_lambda1_gluings_proved': False,
        'full_4D_conjecture_proved': False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--rebuild', action='store_true')
    args = parser.parse_args()
    manifest = verify_manifest()
    components = []
    if args.rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v46_clean_') as temp:
            stage = Path(temp)
            for relative in manifest['files']:
                destination = stage / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / relative, destination)
            baseline = stage / 'baseline_v45' / 'mahler_ce_v45'
            run_exact(baseline / 'replay.py', ('--rebuild',))
            if digest(baseline / 'replay_output.json') != digest(ROOT / 'baseline_v45' / 'mahler_ce_v45' / 'replay_output.json'):
                raise RuntimeError('Fresh inherited v45 replay output differs')
            components.append('complete inherited v45 rebuild, including v44')
            for script, certificate in [('joint_bound_verifier.py', 'joint_bound_certificate.json'),
                                        ('directional_reduction_verifier.py', 'directional_reduction_certificate.json')]:
                run_exact(stage / script)
                if digest(stage / certificate) != digest(ROOT / certificate):
                    raise RuntimeError(f'Fresh output differs: {certificate}')
                components.append(script)
    result = {
        'status': 'PASS', 'rebuild': args.rebuild,
        'files_integrity_checked': len(manifest['files']),
        'bytes_integrity_checked': sum(row['bytes'] for row in manifest['files'].values()),
        'fresh_components_rebuilt': components,
        'v44_v45_baseline_rebuilt': args.rebuild,
        'v1_through_v43_history_rebuilt': False,
        **semantic_check(),
        'proof_scope': 'Exact finite algebra and enumeration plus written analytic arguments; no independent implementation or formal proof assistant audit.',
    }
    (ROOT / 'replay_output.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
