# v46 replay

Python 3.11+ and SymPy 1.14.0. Arithmetic is integer/rational/symbolic. No network calls, random sampling, floating convex-hull enumeration, or floating quadrature are used by the verifiers.

From this directory:

```bash
python replay.py
python replay.py --rebuild
```

Default mode verifies the manifest and certificate semantics only. `--rebuild` additionally copies the immutable payload into a fresh temporary directory, runs the complete inherited v45 `replay.py --rebuild` (including v44), runs both new v46 verifiers, and compares the newly generated v46 certificates byte for byte. The temporary directory is removed after completion. No v1–v43 reconstruction is claimed.

`report_zh.md` contains the analytic finite-direction and interpolation proofs. Python verifies finite algebra, enumerations, signs, and reconstruction outputs. It does not formalize the external 2D/3D Mahler theorems, Brunn–Minkowski, Cauchy's projection theorem, or analytic log-concavity argument.

Results: a joint sufficient inequality, finite contact directions for each fixed polytope, and the entire all-direction family C_s=[-1,1]^3∩{|sum x_i|≤s}, 1≤s≤3. General contact endpoint, all lambda-one gluings, and the full 4D conjecture remain unproved.
