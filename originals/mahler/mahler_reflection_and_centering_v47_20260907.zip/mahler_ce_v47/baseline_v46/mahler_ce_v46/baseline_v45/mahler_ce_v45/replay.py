#!/usr/bin/env python3
"""Hash integrity and independent exact rebuild for contact endpoint v45.

The printed status covers these finite checks and the explicit scope metadata.
It does not mean the external analytic theorems or the general CE are proved by
Python. See the complete mathematical derivations in report_zh.md.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(script: Path) -> None:
    args=[sys.executable,str(script)]
    if script.name=='replay.py':
        args.append('--rebuild')
    p=subprocess.run(args,cwd=script.parent,capture_output=True,text=True,timeout=300)
    if p.returncode:
        raise RuntimeError(f'{script.name} failed (code {p.returncode}):\n'
                           f'{p.stdout[-5000:]}\n{p.stderr[-5000:]}')
    print(f'completed {script.parent.name}/{script.name}',flush=True)


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument('--rebuild',action='store_true')
    args=parser.parse_args()
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for name,record in manifest['files'].items():
        p=ROOT/name
        if not p.is_file() or p.stat().st_size!=record['bytes'] or sha(p)!=record['sha256']:
            raise RuntimeError(f'Payload integrity failure: {name}')
    rebuilt=[]
    if args.rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v45_clean_') as directory:
            stage=Path(directory)
            for name in manifest['files']:
                dest=stage/name
                dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/name,dest)
            invoke(stage/'baseline'/'replay.py')
            if sha(stage/'baseline'/'replay_output.json')!=sha(ROOT/'baseline'/'replay_output.json'):
                raise RuntimeError('v44 baseline replay output differs')
            rebuilt.append('v44 exact audit and segment reconstruction (both scripts)')
            for script,cert in [('scalar_verifier.py','scalar_certificate.json'),
                                ('extremizer_verifier.py','extremizer_certificate.json'),
                                ('stability_interface_verifier.py','stability_interface_certificate.json')]:
                invoke(stage/script)
                if sha(stage/cert)!=sha(ROOT/cert):
                    raise RuntimeError(f'Fresh certificate differs: {cert}')
                rebuilt.append(script)
    scalar=json.loads((ROOT/'scalar_certificate.json').read_text())
    ext=json.loads((ROOT/'extremizer_certificate.json').read_text())
    stab=json.loads((ROOT/'stability_interface_certificate.json').read_text())
    base=json.loads((ROOT/'baseline'/'replay_output.json').read_text())
    assert scalar['status']==ext['status']==stab['status']==base['status']=='PASS'
    assert scalar['general_bound']['universal_rational_bound']=='41/4'
    assert scalar['sufficient_contact_endpoint_condition']['M_C_at_least']=='91/8'
    assert ext['independent_exact_4D_reconstruction_count']==6
    assert len(stab['finite_Hanner_identifications'])==3
    assert base['independent_exact_4D_reconstructions']==12
    assert not scalar['general_contact_endpoint_inequality_proved']
    assert not stab['analytic_corollary']['epsilon0_computed']
    assert not stab['analytic_corollary']['overlap_with_high_threshold_established']
    output={
      'status':'PASS','rebuild':args.rebuild,
      'files_integrity_checked':len(manifest['files']),
      'bytes_integrity_checked':sum(r['bytes'] for r in manifest['files'].values()),
      'fresh_components_rebuilt':rebuilt,
      'v44_baseline_rebuilt':args.rebuild,
      'v1_through_v43_history_rebuilt':False,
      'uniform_contact_lower_bound':'strictly greater than 41/4',
      'sufficient_condition_for_CE':'M(C)>=91/8 => contact endpoint >32/3 in every direction',
      'cube_and_octahedron_linear_images_all_directions':True,
      'qualitative_near_minimum_exclusion':{
          'statement':'exists epsilon0>0: M(C)<=32/3+epsilon0 => CE for all directions',
          'status':'written analytic corollary using external theorems; not formalized',
          'epsilon0_computed':False,
          'high_threshold_overlap_proved':False},
      'possible_counterexample_interval':'32/3+epsilon0 < M(C) < 91/8 (epsilon0 not quantified)',
      'new_exact_4D_direction_reconstructions':6,
      'additional_exact_4D_Hanner_identifications':3,
      'v44_exact_4D_reconstruction_runs':12,
      'general_contact_endpoint_inequality_proved':False,
      'all_lambda1_gluings_proved':False,
      'full_4D_conjecture_proved':False,
      'analytic_interfaces':'2D/3D Mahler, Brunn-Minkowski, written single-crossing comparison, John compactness, and Kim Hanner local minimality are not Python-formalized.'}
    (ROOT/'replay_output.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(output,indent=2,ensure_ascii=False))

if __name__=='__main__':
    main()
