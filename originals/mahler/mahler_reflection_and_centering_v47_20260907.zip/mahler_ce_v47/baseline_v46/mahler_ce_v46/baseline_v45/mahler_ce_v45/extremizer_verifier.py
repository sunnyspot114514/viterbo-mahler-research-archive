#!/usr/bin/env python3
"""Exact contact-endpoint proofs for every direction of a 3D cube or octahedron.
Symbolic identities prove parameter domains. Finite rational hull reconstructions
are independent checks only. All hull work is exhaustive rational arithmetic.
"""
from __future__ import annotations
import itertools
import json
import math
from fractions import Fraction as F
from pathlib import Path
import sys
import sympy as sp

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'baseline'))
from segment_moment_reduction import hull,integrals,abs_moment,srat
from exact_audit import dot

def tensor_bernstein(poly,vs):
    p=sp.Poly(sp.expand(poly),*vs,domain=sp.QQ)
    deg=p.degree_list(); out=[]; check=sp.Integer(0)
    for index in itertools.product(*(range(d+1) for d in deg)):
        value=sum(coef*sp.prod(sp.Rational(math.comb(i,e),math.comb(d,e))
                    for i,e,d in zip(index,ex,deg))
                  for ex,coef in p.terms() if all(e<=i for e,i in zip(ex,index)))
        basis=sp.prod(sp.binomial(d,i)*v**i*(1-v)**(d-i)
                      for v,d,i in zip(vs,deg,index))
        check+=value*basis
        out.append({'index':list(index),'coefficient':str(value)})
    assert sp.expand(check-poly)==0
    return list(deg),out

def exact_direction_check(name,body,v,expected_M,expected_I,expected_projection):
    v=tuple(F(x) for x in v)
    assert v[0]>0
    # T(v)=e_1. Its determinant is 1/v[0].
    def transform(p):
        return (F(p[0])/v[0],F(p[1])-v[1]*F(p[0])/v[0],
                F(p[2])-v[2]*F(p[0])/v[0])
    C,N,fac=hull([transform(p) for p in body])
    dual_fac=[frozenset(i for i,n in enumerate(N) if dot(n,p)==1) for p in C]
    V=integrals(C,fac)[0]; W=integrals(N,dual_fac)[0]
    I,W2=abs_moment(N,dual_fac,C); assert W2==W
    proj,pn,pf=hull([p[1:] for p in C]); A=integrals(proj,pf)[0]
    assert 1/max(n[0] for n in N)==1
    assert I==F(expected_I)*v[0],(name,'moment',I,expected_I)
    assert A==F(expected_projection)/v[0],(name,'projection',A,expected_projection)
    Q=[(F(0),)+p for p in C]+[(x,t,F(0),F(0))
                                       for x in [F(-1),F(1)] for t in [F(-1),F(1)]]
    qp,qn,qf=hull(Q)
    qdf=[frozenset(i for i,n in enumerate(qn) if dot(n,p)==1) for p in qp]
    qv=integrals(qp,qf)[0]; qw=integrals(qn,qdf)[0]
    M=qv*qw
    assert qv==V/2+A/3 and qw==2*(W-I)
    assert M==F(expected_M) and M>=F(32,3)
    return {'name':name,'original_contact_vector':list(map(str,v)),
         'C_volume':str(V),'C_polar_volume':str(W),'transformed_projection_area':str(A),
         'transformed_polar_absolute_moment':str(I),'contact_radius':'1',
         'four_dimensional_vertices':len(qp),'four_dimensional_facets':len(qn),
         'four_dimensional_volume':str(qv),'four_dimensional_polar_volume':str(qw),
         'contact_product':str(M),'margin':str(M-F(32,3))}

def main():
    b,c=sp.symbols('b c', nonnegative=True)
    # Generic distinct positive coefficients; cancellation extends by continuity.
    raw=sp.Rational(1,3)*(1/((1-b*b)*(1-c*c))+
          b**5/((b*b-1)*(b*b-c*c))+c**5/((c*c-1)*(c*c-b*b)))
    Icube=sp.factor(sp.cancel(raw))
    expected=(b**3*c+b**3+b*b*c*c+2*b*b*c+b*b+b*c**3+
              2*b*c*c+2*b*c+b+c**3+c*c+c)/(3*(1+b)*(1+c)*(b+c))
    assert sp.cancel(Icube-expected)==0
    Mcube=sp.factor((8+sp.Rational(8,3)*(1+b+c))*(sp.Rational(4,3)-Icube))
    gap=sp.factor(Mcube-sp.Rational(32,3))
    num,den=sp.fraction(gap)
    assert sp.expand(den-9*(1+b)*(1+c)*(b+c))==0
    degree,table=tensor_bernstein(num,(b,c))
    values=[sp.Rational(item['coefficient']) for item in table]
    assert degree==[4,4] and all(x>=0 for x in values)
    assert sum(bool(x>0) for x in values)==22
    assert sum(bool(x==0) for x in values)==3
    assert sp.limit(sp.limit(Icube,c,0),b,0)==sp.Rational(1,3)
    # On the axes away from the origin, gap is strictly positive as well.
    edge=sp.factor(gap.subs(c,0))
    assert sp.cancel(edge-8*b*(3-b-b*b)/(9*(1+b)))==0
    assert (3-b-b*b).subs(b,1)==1
    a,bb,cc=sp.symbols('a b c',nonnegative=True)
    Id=4*a+4*(bb*bb+cc*cc)/(3*a)
    Md=(sp.Rational(4,3)+sp.Rational(4,3)*a)*(8-Id)
    dominant_gap=sp.Rational(16,9)/a*((1-a)*(2*a-1)*(2*a+1)+2*(1+a)*bb*cc)
    assert sp.factor((Md-sp.Rational(32,3)-dominant_gap).subs(cc,1-a-bb))==0
    Ib=(1-(1-2*a)**4-(1-2*bb)**4-(1-2*cc)**4)/(12*a*bb*cc)
    balanced_gap=(1-2*(a*a+bb*bb+cc*cc))**2/(3*a*bb*cc)
    assert sp.factor((2*(8-Ib)-sp.Rational(32,3)-balanced_gap).subs(cc,1-a-bb))==0
    # Verify dominant expression also from the box truncated-power integral.
    Id_power=(1-(1-2*bb)**4-(1-2*cc)**4+(2*a-1)**4)/(12*a*bb*cc)
    assert sp.factor((Id_power-Id).subs(cc,1-a-bb))==0
    # Dominant chamber equality: a=1 or a=1/2 and bb*cc=0.
    assert dominant_gap.subs({a:1,bb:0,cc:0})==0
    assert dominant_gap.subs({a:sp.Rational(1,2),bb:sp.Rational(1,2),cc:0})==0
    cube=list(itertools.product([-1,1],repeat=3))
    cross=[tuple(side if i==j else 0 for i in range(3))
                          for j in range(3) for side in [-1,1]]
    samples=[]
    for p,q in [(sp.Rational(1,2),sp.Rational(1,4)),(sp.Integer(1),sp.Integer(1)),
                (sp.Integer(0),sp.Integer(0))]:
        ii=sp.Rational(1,3) if p==q==0 else Icube.subs({b:p,c:q})
        mm=(8+sp.Rational(8,3)*(1+p+q))*(sp.Rational(4,3)-ii)
        samples.append(exact_direction_check('cube_'+str(p)+'_'+str(q),cube,(1,p,q),mm,ii,4*(1+p+q)))
        print('exact hull PASS',samples[-1]['name'],flush=True)
    triples=[(sp.Rational(3,4),sp.Rational(1,6),sp.Rational(1,12)),
             (sp.Rational(1,3),)*3,
             (sp.Rational(1,2),sp.Rational(1,2),sp.Integer(0))]
    for av,bv,cv in triples:
        sub={a:av,bb:bv,cc:cv}
        if av>=sp.Rational(1,2):
            ii=sp.factor(Id.subs(sub)); pp=2*av
        else:
            ii=sp.factor(Ib.subs(sub)); pp=sp.Integer(1)
        mm=sp.factor((sp.Rational(4,3)+sp.Rational(2,3)*pp)*(8-ii))
        samples.append(exact_direction_check('octahedron_'+str(av)+'_'+str(bv)+'_'+str(cv),
                                            cross,(av,bv,cv),mm,ii,pp))
        print('exact hull PASS',samples[-1]['name'],flush=True)
    record={'status':'PASS','scope':'All directions for linear images of a 3D cube or octahedron',
      'cube':{'domain':'v=(1,b,c), 0<=b,c<=1, by sign/permutation invariance',
       'moment':str(Icube),'contact_product':str(Mcube),'margin_numerator':str(num),
       'margin_denominator':str(den),'Bernstein_degree':degree,'Bernstein_table':table,
       'positive_coefficients':22,'zero_coefficients':3,'negative_coefficients':0,
       'minimum_positive_coefficient':str(min(x for x in values if x>0)),
       'singular_corner':{'b':'0','c':'0','moment':'1/3','contact_product':'32/3'},
       'equality_directions':'coordinate axes after normalizing C to the standard cube'},
      'octahedron':{'domain':'a,b,c>=0, a+b+c=1, a=max(a,b,c)',
       'dominant_domain':'a>=1/2','dominant_polar_moment':str(Id),
       'dominant_margin':str(dominant_gap),'dominant_projection_quantity':'2*a',
       'balanced_domain':'a,b,c<=1/2, all positive','balanced_polar_moment':str(Ib),
       'balanced_margin':str(balanced_gap),'balanced_projection_quantity':'1',
       'equality_contact_vectors':'sign/permutation images of (1,0,0) and (1/2,1/2,0)'},
      'independent_exact_4D_reconstruction_count':len(samples),
      'independent_exact_reconstructions':samples,
      'all_extremal_3D_bodies': 'covered using the external Iriyeh-Shibata equality classification',
      'general_contact_endpoint_inequality_proved':False,'full_4D_conjecture_proved':False}
    (ROOT/'extremizer_certificate.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':'PASS','all_cube_and_octahedron_directions':True,
                      'exact_reconstructions':len(samples)}))

if __name__=='__main__':main()
