#!/usr/bin/env python3
"""Check finite equality-body identities used in the qualitative compactness lemma.

This script does NOT prove compactness, John normalization, the 3D equality
classification, or Kim's local-minimality theorem, and computes no epsilon0.
Those analytic inputs and the full contradiction proof are in report_zh.md.
"""
from __future__ import annotations
import itertools
import json
from fractions import Fraction as F
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'baseline'))
from exact_audit import dot
from segment_moment_reduction import hull, integrals


def contact(body, v):
    pts=[(F(0),)+tuple(map(F,p)) for p in body]
    pts += [(F(x),)+tuple(F(s)*F(a) for a in v)
            for x in [-1,1] for s in [-1,1]]
    V,N,fac=hull(pts)
    polar_fac=[frozenset(i for i,n in enumerate(N) if dot(n,p)==1) for p in V]
    vp=integrals(V,fac)[0]
    vn=integrals(N,polar_fac)[0]
    assert vp*vn==F(32,3)
    return V,N,{'vertices':len(V),'facets':len(N),'volume':str(vp),
                'polar_volume':str(vn),'Mahler_product':str(vp*vn)}


def main():
    cube=list(itertools.product([-1,1],repeat=3))
    cross=[tuple(s if i==j else 0 for i in range(3))
           for j in range(3) for s in [-1,1]]
    rec=[]
    V,N,count=contact(cube,(1,0,0))
    # coordinates (x,t,z1,z2): polar is I_t +_1 (I_x x B_1^2).
    expected=[(F(0),F(s),F(0),F(0)) for s in [-1,1]]
    expected += [(F(x),F(0),F(s) if j==0 else F(0),F(s) if j==1 else F(0))
                 for x in [-1,1] for j in range(2) for s in [-1,1]]
    assert set(N)==set(expected)
    rec.append({'case':'cube, contact e1','identified_side':'polar',
                'Hanner_expression':'I_t +_1 (I_x x B_1^2)',**count})
    V,N,count=contact(cross,(1,0,0))
    expected=[(F(x),F(t),F(0),F(0)) for x in [-1,1] for t in [-1,1]]
    expected += [(F(0),F(0),F(s) if j==0 else F(0),F(s) if j==1 else F(0))
                 for j in range(2) for s in [-1,1]]
    assert set(V)==set(expected)
    rec.append({'case':'octahedron, contact e1','identified_side':'primal',
                'Hanner_expression':'B_infty^2(x,t) +_1 B_1^2(z1,z2)',**count})
    V,N,count=contact(cross,(F(1,2),F(1,2),0))
    # Polar variables originally (x,y1,y2,y3); t=(y1+y2)/2,s=(y1-y2)/2.
    transformed=[(p[0],(p[1]+p[2])/2,(p[1]-p[2])/2,p[3]) for p in N]
    core=[(F(0),F(t),F(0)) for t in [-1,1]]
    core += [(F(x),F(0),F(s)) for x in [-1,1] for s in [-1,1]]
    expected=[p+(F(z),) for p in core for z in [-1,1]]
    assert set(transformed)==set(expected)
    rec.append({'case':'octahedron, contact (1/2,1/2,0)','identified_side':'polar',
                'Hanner_expression':'(I_t +_1 B_infty^2(x,s)) x I_z',
                'coordinate_change':'t=(y1+y2)/2, s=(y1-y2)/2',**count})
    out={'status':'PASS','finite_Hanner_identifications':rec,
         'all_equality_contacts_exhausted_by':'extremizer_verifier.py plus the 3D equality theorem',
         'analytic_corollary':{
             'claim':'There exists epsilon0>0 such that M(C)<=32/3+epsilon0 implies contact CE in every direction.',
             'proof_location':'report_zh.md, Section 10',
             'status':'written analytic corollary using external theorems, NOT formalized',
             'external_inputs':['Iriyeh-Shibata equality classification in dimension three',
                                'Jaegil Kim, Minimal volume product near Hanner polytopes, arXiv:1212.2544',
                                'John normalization, Blaschke compactness, polarity and volume continuity'],
             'epsilon0_computed':False,
             'overlap_with_high_threshold_established':False},
         'general_contact_endpoint_inequality_proved':False,
         'full_4D_conjecture_proved':False}
    (ROOT/'stability_interface_certificate.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':'PASS','finite_Hanner_identifications':3,
                      'epsilon0_computed':False,'general_contact_proved':False}))

if __name__=='__main__':main()
