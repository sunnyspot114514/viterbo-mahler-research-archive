#!/usr/bin/env python3
"""Exact algebra for a conditional 3D-section bound for the contact endpoint.

The analytic inputs (Brunn concavity, the single-crossing lemma, and the
2D/3D Mahler theorems) are written in report_zh.md, not proved by this program.
No claim of a proof of the unrestricted contact inequality is made.
"""
from __future__ import annotations
import itertools
import json
import math
from pathlib import Path
import sympy as sp

ROOT = Path(__file__).resolve().parent

def bernstein(poly: sp.Expr, variable: sp.Symbol) -> list[sp.Rational]:
    p = sp.Poly(sp.expand(poly), variable, domain=sp.QQ)
    degree = max(0, p.degree())
    values = [sum(p.nth(j) * sp.Rational(math.comb(i,j), math.comb(degree,j))
                  for j in range(i+1)) for i in range(degree+1)]
    reconstructed = sum(value*sp.binomial(degree,i)*variable**i*(1-variable)**(degree-i)
                        for i,value in enumerate(values))
    assert sp.expand(poly-reconstructed)==0
    return values

def certify_intervals(poly: sp.Expr, variable: sp.Symbol,
                      endpoints: list[sp.Rational]) -> list[dict]:
    t=sp.Symbol('t')
    assert endpoints[0]==0 and endpoints[-1]==1
    assert all(x<y for x,y in zip(endpoints,endpoints[1:]))
    records=[]
    for lo,hi in zip(endpoints,endpoints[1:]):
        pulled=sp.expand(poly.subs(variable,lo+(hi-lo)*t))
        values=bernstein(pulled,t)
        assert all(x>0 for x in values)
        records.append({'interval':[str(lo),str(hi)],'coefficients':list(map(str,values)),
                        'minimum_coefficient':str(min(values))})
    return records

def main() -> None:
    k,t=sp.symbols('k t', real=True)
    w=sp.integrate((1-k*t)**2,(t,0,1))
    j=sp.integrate(t*(1-k*t)**2,(t,0,1))
    assert sp.expand(w-(1-k+k*k/3))==0
    assert sp.expand(j-(sp.Rational(1,2)-2*k/3+k*k/4))==0
    D=k*k-3*k+3
    assert sp.expand(D-(1+(1-k)+(1-k)**2))==0
    assert sp.expand(w-j-(k*k-4*k+6)/12)==0
    R=sp.factor((1+w)*(w-j)/w)
    Rexpected=(k*k-4*k+6)*(k*k-3*k+6)/(12*D)
    assert sp.cancel(R-Rexpected)==0
    universal_poly=32*k**4-224*k**3+399*k*k-237*k+45
    assert sp.cancel(sp.Rational(32,3)*R-sp.Rational(41,4)-universal_poly/(36*D))==0
    universal=certify_intervals(universal_poly,k,[sp.Rational(x) for x in
         [0,sp.Rational(1,4),sp.Rational(3,8),sp.Rational(7,16),sp.Rational(1,2),1]])
    mu0=sp.Rational(273,256)
    assert mu0*sp.Rational(32,3)==sp.Rational(91,8)
    threshold_poly=256*k**4-1792*k**3+3123*k*k-1740*k+306
    threshold_expression=sp.factor((mu0+w)*(w-j)/w-1)
    assert sp.cancel(threshold_expression-threshold_poly/(3072*D))==0
    threshold=certify_intervals(threshold_poly,k,[sp.Rational(x) for x in
          [0,sp.Rational(1,4),sp.Rational(3,8),sp.Rational(1,2),1]])
    mu,zeta,q=sp.symbols('mu zeta q')
    delta=sp.factor(1-R)
    ledger=(-delta+(mu-1)*(1-q)+(zeta-1)*w*(1-q)+(1+w)*(j/w-q))
    assert sp.cancel(ledger-((mu+zeta*w)*(1-q)-1))==0
    assert sp.cancel(delta-k*(1-k)*(k*k-6*k+6)/(12*D))==0
    # A realizable concave square-root section profile that prevents R>=1.
    w_half=sp.factor(w.subs(k,sp.Rational(1,2)))
    j_half=sp.factor(j.subs(k,sp.Rational(1,2)))
    q_half=j_half/w_half
    assert (w_half,j_half,q_half)==(sp.Rational(7,12),sp.Rational(11,48),sp.Rational(11,28))
    assert q_half>w_half/(1+w_half)
    assert R.subs(k,sp.Rational(1,2))==sp.Rational(323,336)<1
    # K={|t|<=1, |z1|,|z2|<=1-|t|/2}, C=K^polar.
    W=8*w_half; I=8*j_half; V=sp.Rational(8,3); A=sp.Integer(2)
    E=sp.factor((V+2*A/3)*(W-I))
    assert V*W==sp.Rational(112,9)
    assert E==sp.Rational(34,3)>sp.Rational(32,3)
    # Reference numerical constants are NOT the proof; isolate critical roots exactly.
    deriv_num=sp.Poly(sp.fraction(sp.factor(sp.diff(R,k)))[0],k,domain=sp.QQ)
    assert deriv_num.count_roots(0,1)==1
    critical_intervals=sp.polys.polytools.intervals(deriv_num,eps=sp.Rational(1,10**15))
    in_unit=[(pair,mult) for pair,mult in critical_intervals if 0<pair[0]<pair[1]<1]
    assert len(in_unit)==1 and in_unit[0][1]==1
    rec={
      'status':'PASS',
      'analytic_interfaces_not_formalized':['Brunn-Minkowski square-root concavity of planar sections',
         'single-crossing moment comparison in report_zh.md',
         'planar origin-symmetric Mahler inequality AB>=8',
         'Iriyeh-Shibata 3D origin-symmetric Mahler theorem M(C)>=32/3'],
      'section_comparator':{'f_k':'1-k*t','w':str(w),'j':str(j),
         'q_upper_bound':'j(k)/w(k)', 'k_domain':'0<=k<=1'},
      'general_bound':{'lower_envelope':'(M(C)+(32/3)*w)*(w-j)/w',
          'R':str(R),'universal_rational_bound':'41/4',
          'universal_bound_is_strict':True,'positivity_polynomial':str(universal_poly),
          'positive_denominator':'36*(1+(1-k)+(1-k)^2)',
          'interval_certificates':universal,
          'reference_envelope_minimum_approx':'10.2505707848127',
          'reference_critical_root_interval':list(map(str,in_unit[0][0]))},
      'sufficient_contact_endpoint_condition':{'M_C_at_least':'91/8',
          'relative_threshold':'273/256','conclusion':'contact endpoint > 32/3',
          'positivity_polynomial':str(threshold_poly),
          'positive_denominator':'3072*(1+(1-k)+(1-k)^2)',
          'interval_certificates':threshold},
      'remaining_possible_counterexample_M_C_interval':'32/3 <= M(C) < 91/8',
      'deficit_ledger':{'mu':'M(C)/(32/3)','zeta':'area(proj C)*area(Cpolar central section)/8',
          'q':'r*I/W','delta':str(delta),
          'identity':'E/(32/3)-1 = -delta+(mu-1)*(1-q)+(zeta-1)*w*(1-q)+(1+w)*(j/w-q)'},
      'failed_scalar_shortcut':{'profile':'1-t/2','w':str(w_half),'j':str(j_half),
          'q':str(q_half),'w_divided_by_1_plus_w':str(w_half/(1+w_half)),
          'R':str(R.subs(k,sp.Rational(1,2))),
          'realizing_C_Mahler_product':str(V*W),'realizing_contact_product':str(E),
          'interpretation':'This disproves a scalar R>=1 shortcut, not the contact inequality.'},
      'general_contact_endpoint_inequality_proved':False,
      'full_4D_conjecture_proved':False}
    (ROOT/'scalar_certificate.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':'PASS','universal_bound':'41/4',
         'sufficient_M_C':'91/8','general_contact_proved':False}))

if __name__=='__main__':main()
