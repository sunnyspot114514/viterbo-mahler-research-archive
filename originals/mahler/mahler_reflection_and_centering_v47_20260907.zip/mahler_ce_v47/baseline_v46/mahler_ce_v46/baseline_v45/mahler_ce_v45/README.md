# Contact endpoint research checkpoint v45

Run `python replay.py --rebuild` in the extracted directory.

The replay verifies payload hashes, reruns the v44 baseline in a fresh directory,
reruns three new exact scripts, and compares their JSON certificates byte for
byte. It does not rebuild the historical v1-v43 proof-candidate chain.

Python dependency: SymPy. The geometry code is copied unmodified from v44 and
uses exhaustive rational convex-hull enumeration, not a floating-point hull.

New claims (with analytic proofs in report_zh.md):
- contact product > 41/4 for every symmetric 3D C and direction;
- M(C)>=91/8 implies contact product >32/3 in every direction;
- every direction is certified for linear images of the 3D cube and octahedron;
- a qualitative epsilon0-neighborhood of the 3D minimum is also excluded,
  by compactness, the exact equality-contact classification, and Kim's theorem;
- a remaining CE counterexample must have 32/3+epsilon0 < M(C) <91/8.

No numerical epsilon0 or overlap of the two excluded regions is established.
The general CE inequality and the full 4D symmetric Mahler conjecture are NOT
proved. Published 2D/3D Mahler theorems, Brunn-Minkowski, Kim's Hanner theorem,
and the written moment and compactness arguments are analytic proof interfaces,
not formal proofs produced by this Python code.
