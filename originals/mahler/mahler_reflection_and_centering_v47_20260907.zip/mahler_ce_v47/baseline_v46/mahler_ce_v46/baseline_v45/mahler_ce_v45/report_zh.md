# v45：接触端点的截面矩估计、近极小区间归约与等号体全方向验证

日期：2026-09-06。

**状态：本轮给出一般解析推导及精确有理数多项式证书；尚未经过独立实现或外部同行审阅。一般接触端点不等式、一般 lambda=1 粘合以及完整四维中心对称 Mahler 猜想均未在本轮证明。**

## 1. 本轮结果及范围

对满维中心对称三维凸体 C、单位方向 e，记

\[
r=\rho_C(e),\quad V=|C|,\quad W=|C^\circ|,\quad
A=|\operatorname{proj}_{e^\perp}C|,\quad
I=\int_{C^\circ}|\langle y,e\rangle|\,dy.
\]

接触端点为

\[
\mathcal E(C,e)=\left(V+\frac{2rA}{3}\right)(W-rI).
\]

本轮证明以下陈述。

1. 对每一个 C 和 e，有统一下界 \(\mathcal E(C,e)>41/4\)。这低于目标 \(32/3\)，不是猜想证明。
2. 若 \(M(C)=VW\ge91/8\)，则对所有 e 有 \(\mathcal E(C,e)>32/3\)。它不要求有限顶点、任何反射对称性或同似截面。
3. 对每个三维平行六面体或八面体的可逆线性像，以及每一个接触方向 e，有 \(\mathcal E(C,e)\ge32/3\)。这是全方向结论，不只是有限方向样本。
4. 使用已发表的三维等号分类，上述两项合并后，一般接触不等式的反例若存在，必须满足

\[
\boxed{\frac{32}{3}<M(C)<\frac{91}{8}}.
\]

该条件只是必要条件，绝不声称区间内所有对象是反例或已经得到其分类。

5. 再结合 Kim 的 Hanner 局部极小定理，存在某个尚未定量的 \(\epsilon_0>0\)，使 \(M(C)\le32/3+\epsilon_0\) 的全部方向也满足接触不等式。第10节给出紧性反证；本轮没有算出 \(\epsilon_0\)，也没有证明该邻域与第2项的高值区间重叠。

v44 的一般粘合恒等式为

\[
Q_a=\operatorname{conv}(\{0\}\times C,[-1,1]\times[-a,a]e),
\quad M(Q_a)=\left(V+\frac{2aA}{3}\right)(W-aI),\quad0\le a\le r.
\]

关于 a 的严格凹性将最小值归约到 0 和 r。因此本轮已证的接触类别同时覆盖这些 C 的整个 \(0\le a\le r\) 参数区间。

## 2. 极体平面截面：归一化但不假设截面同似

令 \(K=C^\circ\)，令

\[
B=|K\cap e^\perp|,
\qquad
f(t)=\sqrt{\frac{|K\cap( (t/r)e+e^\perp)|}{B}},\quad-1\le t\le1.
\]

\(h_K(e)=1/r\)，故该定义覆盖整个截面区间。Brunn–Minkowski 定理说明 f 凹；中心对称性说明 f 偶，而且 f(0)=1。于是

\[
1-t\le f(t)\le1\quad(0\le t\le1).
\]

定义

\[
w=\int_0^1 f(t)^2dt=\frac{rW}{2B},\qquad
j_f=\int_0^1 t f(t)^2dt,\qquad
q=\frac{rI}{W}=\frac{j_f}{w}.
\]

立即得到 \(1/3\le w\le1\)。这里的 f 只表示截面面积的平方根；不同截面本身可以形状不同、中心不同。本轮没有把面积函数凹性误当作同似性。

## 3. 固定零阶矩时的一阶矩比较

有唯一的 \(k\in[0,1]\) 满足

\[
w=w(k)=\int_0^1(1-kt)^2dt=1-k+\frac{k^2}{3}.
\]

令

\[
j(k)=\int_0^1t(1-kt)^2dt=\frac12-\frac{2k}{3}+\frac{k^2}{4}.
\]

**引理。** 对上述 f，有 \(j_f\le j(k)\)。

**证明。** 令 \(d(t)=f(t)-(1-kt)\)。由于 d 凹且 d(0)=0，\(d(t)/t\) 在 t>0 上不增。因此 d 的非零符号只能按“先正、后负”排列。f 与 1-kt 均非负，故 \(f^2-(1-kt)^2\) 具有同样的符号排列。两者积分相等。如果二者不相等，存在分界点 c，使

\[
(t-c)\bigl(f(t)^2-(1-kt)^2\bigr)\le0.
\]

积分并使用零阶矩相等，得到 \(j_f-j(k)\le0\)。若两函数完全相同，结论显然成立。端点 k=0、1 也由相同论证或极限覆盖。证毕。

所以

\[
\boxed{q\le \frac{j(k)}{w(k)}}.
\]

该结论有文字解析证明，不是从 finitely many profiles 拟合得到。

## 4. 接触端点的通用下包络

极性给出

\[
(\operatorname{proj}_{e^\perp}C)^\circ=K\cap e^\perp.
\]

因此二维中心对称 Mahler 定理给出 \(AB\ge8\)。结合上一节，得到

\[
\begin{aligned}
\mathcal E(C,e)
&=\left(M(C)+\frac{2rAW}{3}\right)(1-q)\\
&=\left(M(C)+\frac43 ABw\right)(1-q)\\
&\ge\boxed{\left(M(C)+\frac{32}{3}w\right)\frac{w-j(k)}{w}}.
\end{aligned}
\tag{L}
\]

这是本轮核心估计。其外部一般性输入只有平面 Mahler 和 Brunn–Minkowski；下文统一数值下界再使用三维 Mahler。

## 5. 所有三维凸体上的统一下界 41/4

由三维中心对称 Mahler 定理 \(M(C)\ge32/3\)，(L) 给出

\[
\mathcal E(C,e)\ge\frac{32}{3}R(k),
\qquad
R(k)=\frac{(k^2-4k+6)(k^2-3k+6)}{12(k^2-3k+3)}.
\]

有精确恒等式

\[
\frac{32}{3}R(k)-\frac{41}{4}
=\frac{32k^4-224k^3+399k^2-237k+45}{36(k^2-3k+3)}.
\]

分母严格为正，因为

\[
k^2-3k+3=1+(1-k)+(1-k)^2.
\]

分子在下面五个闭区间上均有严格正的 degree-4 Bernstein 系数表：

| 区间 | 最小 Bernstein 系数 |
|---|---:|
| [0,1/4] | 117/16 |
| [1/4,3/8] | 135/128 |
| [3/8,7/16] | 201/2048 |
| [7/16,1/2] | 1/128 |
| [1/2,1] | 1/4 |

全部表及重构恒等式保存在 scalar_certificate.json。因此

\[
\boxed{\mathcal E(C,e)>41/4}.
\]

同一下包络的实际最低值约为 10.2505707848127，临界 k 约为 0.4585229628754。代码隔离了相应五次多项式在 (0,1) 中唯一的根；这些小数只作参考，41/4 的证明完全使用有理数 Bernstein 证书。

**41/4 不等于 32/3。两者的数值距离不是证明完成度。**

## 6. 非近极小区域的完整排除

若 \(M(C)\ge91/8=(32/3)(273/256)\)，则 (L) 给出

\[
\frac{\mathcal E}{32/3}-1
\ge \left(\frac{273}{256}+w\right)\frac{w-j(k)}w-1
=\frac{256k^4-1792k^3+3123k^2-1740k+306}
{3072(k^2-3k+3)}.
\]

其分子的严格正 Bernstein 证书如下：

| 区间 | 最小 Bernstein 系数 |
|---|---:|
| [0,1/4] | 627/16 |
| [1/4,3/8] | 207/64 |
| [3/8,1/2] | 15/128 |
| [1/2,1] | 35/4 |

故

\[
\boxed{M(C)\ge91/8\Longrightarrow\mathcal E(C,e)>32/3\quad\forall e.}
\]

该阈值是方便的有理充分条件，不声称最优。它把尚未控制的三维体限制到 Mahler 乘积相对最小值不超过 \(17/256\) 的数值范围，但没有给出 Banach–Mazur 距离控制。

## 7. 整个三维等号体类别：平行六面体的所有方向

接触表达式是四维粘合的 Mahler 乘积，故对 C 和接触线段同时施加 GL(3) 时不变。可以先把 C 化为标准 cube，并把接触向量化为

\[
v=(1,b,c),\qquad0\le b,c\le1.
\]

这里使用的是线段 [-v,v]；原来 \(rA\) 是加该线段的体积导数的一半。对 cube，

\[
V=8,\quad W=4/3,\quad rA=4(1+b+c).
\]

令 \(J=\int_{B_1^3}|y_1+by_2+cy_3|dy\)。对互异正系数，逐个 orthant 上积分正部，可得到

\[
J=\frac13\sum_{i=1}^3\frac{v_i^5}{\prod_{j\ne i}(v_i^2-v_j^2)}.
\]

一个核验途径是对三维标准 simplex 上的 \((a\cdot x)_+\) 连续作三次积分，得到四个顶点值 \(0,a_1,a_2,a_3\) 的 divided-difference 公式；再对八个 orthants 求和。化简后

\[
J=\frac{b^3c+b^3+b^2c^2+2b^2c+b^2+bc^3+2bc^2+2bc+b+c^3+c^2+c}
{3(1+b)(1+c)(b+c)}.
\]

这个表达式通过连续性覆盖重复和部分为零的系数；唯一需单独处理的原点 b=c=0 处有 J=1/3。

\[
\mathcal E_\square=\frac83(4+b+c)(4/3-J).
\]

其与 32/3 的差有正分母 \(9(1+b)(1+c)(b+c)\)。分子的 degree-(4,4) tensor-Bernstein 系数表为

\[
\begin{pmatrix}
0&0&4&10&8\\
0&3&35/3&45/2&22\\
4&35/3&80/3&130/3&44\\
10&45/2&130/3&64&62\\
8&22&44&62&48
\end{pmatrix}.
\]

22 个严格正、3 个零、没有负数。所有边界由该表或直接限制到边上覆盖。比如 c=0 时余量为

\[
\frac{8b(3-b-b^2)}{9(1+b)}>0\quad(0<b\le1).
\]

因此平行六面体所有方向均满足接触不等式；标准 cube 中等号恰为坐标轴接触方向。

## 8. 八面体的所有方向：显式非负分解

将 C 化为标准三维 cross-polytope。接触向量可化为

\[
v=(a,b,c),\quad a,b,c\ge0,\quad a+b+c=1,\quad a=\max(a,b,c).
\]

有 \(V=4/3,W=8\)。相应 \(rA=\max(1,2a)\)。

### 8.1 主导坐标区 a>=1/2

极体 cube 上的一阶绝对矩为

\[
J=4a+\frac{4(b^2+c^2)}{3a}.
\]

这是先沿 x 积分 \(|ax+by+cz|\) 的直接结果，因为 \(|by+cz|\le b+c\le a\)。接触余量为

\[
\boxed{
\mathcal E-\frac{32}{3}
=\frac{16}{9a}\left((1-a)(2a-1)(2a+1)+2(1+a)bc\right)\ge0.
}
\]

### 8.2 平衡区 a,b,c<=1/2

对正 a,b,c，cube 上的 truncated-power 积分给出

\[
J=\frac{1-(1-2a)^4-(1-2b)^4-(1-2c)^4}{12abc}.
\]

于是

\[
\boxed{
\mathcal E-\frac{32}{3}
=\frac{(1-2(a^2+b^2+c^2))^2}{3abc}\ge0.
}
\]

若一个系数为零，平衡区只能出现两个非零系数同为 1/2，该点已经由主导区公式覆盖。所有符号和坐标排列均由对称性覆盖。

等号接触向量恰为 \((1,0,0)\) 或 \((1/2,1/2,0)\) 的符号与排列像。

Iriyeh–Shibata 的三维等号分类指出，\(M(C)=32/3\) 当且仅当 C 或其极体为平行六面体。因此，第7、8节一起覆盖了所有三维 Mahler 等号体及所有接触方向。潜在反例的必要区间可以严格写为

\[
32/3<M(C)<91/8.
\]

## 9. 为什么不能把单变量包络直接提高到目标

取合法截面形状函数 \(f(t)=1-t/2\)。则

\[
w=7/12,\quad j=11/48,\quad q=11/28>7/19=\frac{w}{1+w},
\]

并有

\[
R(1/2)=323/336<1.
\]

该 profile 可由真实三维凸体实现：令

\[
K=\{(t,z_1,z_2):|t|\le1,\ |z_i|\le1-|t|/2\},\qquad C=K^\circ.
\]

这个 C 满足

\[
M(C)=112/9,\qquad \mathcal E(C,e)=34/3>32/3.
\]

因此单变量比较的不足是真实的，但对应凸体并不是 CE 反例。它的三维 Mahler 乘积余量补偿了截面一阶矩。这揭示下一步必须使用不同估计之间的几何关联，不能只把三个非负条件独立拼接。

## 10. 三维最小值附近也存在一个无反例邻域

本节是利用外部局部极小定理的解析推论，不是 Python 形式化证明，且不提供有效邻域半径。

**命题。** 存在 \(\epsilon_0>0\)，对任意三维中心对称凸体 C，只要

\[
M(C)\le\frac{32}{3}+\epsilon_0,
\]

就有 \(\mathcal E(C,e)\ge32/3\) 对每个 e 成立。可以把 \(\epsilon_0\) 取小，使其小于 \(17/24\)；其具体值尚未估计。

### 10.1 全部接触等号构造都是四维 Hanner 体

记 \(I\) 为中心对称线段，\(\oplus_1\) 为互补子空间中的 free sum。第7、8节已经分类了三维等号体中使接触表达式等号的方向。

- 对标准 cube C，只有 \(v=e_1\) 型接触。坐标为 \((x,t,z_1,z_2)\) 时，接触体的极体满足
  \[
  |t|+\max\{|x|,|z_1|+|z_2|\}\le1,
  \]
  因而等于 \(I_t\oplus_1(I_x\times B_1^2)\)。
- 对标准 octahedron C，\(v=e_1\) 时接触体本身等于
  \[
  B_\infty^2(x,t)\oplus_1 B_1^2(z_1,z_2).
  \]
- 对 octahedron 的 \(v=(1/2,1/2,0)\) 型接触，极体原坐标满足 \(|y_i|\le1\) 及 \(|x|+|(y_1+y_2)/2|\le1\)。令 \(t=(y_1+y_2)/2\)、\(s=(y_1-y_2)/2\)，即得
  \[
  Q^\circ=(I_t\oplus_1 B_\infty^2(x,s))\times I_{y_3}.
  \]

它们均由线段反复作直积和 free sum 构成，所以都是 Hanner 体或其极体的可逆线性像。stability_interface_verifier.py 另行从三个 contact convex hull 重建极体，并逐点核验这些有限顶点集合等式。

### 10.2 紧性证明

反设不存在这样的 \(\epsilon_0\)。则存在 \(C_j=-C_j\) 及接触向量 \(v_j\in\partial C_j\)，满足

\[
M(C_j)\longrightarrow32/3,
\qquad M(Q(C_j,v_j))<32/3,
\]

其中 \(Q(C,v)=\operatorname{conv}(\{0\}\times C,[-1,1]\times[-v,v])\)。同时对 C 和 v 作可逆线性变换，不改变该四维 Mahler 乘积。用 John 归一化，可设

\[
B_2^3\subset C_j\subset\sqrt3 B_2^3.
\]

由凸体紧性和接触向量的有界性，取子列使 \(C_j\to C_\infty\)、\(v_j\to v_\infty\)。径向/规范函数的连续性给出 \(v_\infty\in\partial C_\infty\)。由极性及体积连续性，\(M(C_\infty)=32/3\)，所以 Iriyeh–Shibata 等号分类迫使 \(C_\infty\) 为 cube 或 octahedron 的线性像。

凸包构造也连续，故 \(Q(C_j,v_j)\to Q(C_\infty,v_\infty)\)。反例序列使极限 Mahler 乘积不大于 \(32/3\)；第7、8节的全方向结论使它不小于 \(32/3\)。因此极限恰好等号。由第10.1节，极限四维体是 Hanner 体的线性像。

Kim 的主定理指出，每个 Hanner 体在中心对称凸体的 Banach–Mazur 拓扑中是局部 volume-product 极小者。这里各 Q 都有共同的非退化内半径，故 Hausdorff 收敛也给出到该 Hanner 体的 Banach–Mazur 距离趋于1。于是充分大的 j 必须满足 \(M(Q(C_j,v_j))\ge32/3\)，与假设矛盾。证毕。

因此潜在 CE 反例甚至必须满足

\[
\boxed{32/3+\epsilon_0<M(C)<91/8.}
\]

**这不是一般 CE 的证明。** \(\epsilon_0\) 没有数值证书，更没有被证明大到 \(91/8-32/3=17/24\)。紧性论证关闭了一个定性邻域，未关闭剩余的中间带。

## 11. 精确的余量补偿恒等式

令 \(m_0=32/3\)，并定义

\[
\mu=\frac{M(C)}{m_0},\quad \zeta=\frac{AB}{8},\quad
q=\frac{rI}{W},\quad q_k=\frac{j(k)}{w(k)},
\]

\[
\delta(k)=1-R(k)=\frac{k(1-k)(k^2-6k+6)}{12(k^2-3k+3)}.
\]

则有**恒等式**

\[
\boxed{
\frac{\mathcal E}{m_0}-1
=-\delta(k)
+(\mu-1)(1-q)
+(\zeta-1)w(1-q)
+(1+w)(q_k-q).
}
\]

后三项分别来自三维 Mahler 余量、二维投影—截面 Mahler 余量、截面一阶矩比较余量；它们均非负。一般 CE 的剩余问题是证明这三项之和总能抵消 \(\delta(k)\)。

这不是一个已经证明的定量联合稳定性定理。本轮证明了 M(C)>=91/8 时补偿一定足够，处理了完整等号体类别，并经 Hanner 局部极小性得到最小值附近的一个定性邻域。该邻域之外与 91/8 以下的中间带尚未得到统一控制。

下一步应尝试为这个明确补偿式建立三维极值稳定性或截面极化估计，而不是恢复已被 v44 否定的同似性猜测。

## 12. 机器复核范围

本轮 scalar_verifier.py 验证所有积分常数、下包络、四次多项式恒等式、分段 Bernstein 证书和补偿恒等式；extremizer_verifier.py 验证 cube 及 octahedron 的全参数有理表达式和符号证书。

另作 6 次独立四维有理凸包重构：cube 的接触向量 (1,1/2,1/4)、(1,1,1)、(1,0,0)，以及 octahedron 的 (3/4,1/6,1/12)、(1/3,1/3,1/3)、(1/2,1/2,0)。每次重新枚举全部支撑、极体顶点、面格和 pulling triangulations，再计算体积与极体绝对矩。它们用于交叉核验，不是全方向证明的替代。

stability_interface_verifier.py 另外作了 3 次四维等号接触体重构并验证其 Hanner 分解；它不计算 epsilon0，也不形式化紧性证明或 Kim 定理。

v44 两个脚本也在临时目录实际重新运行，重新生成的两个证书逐字节匹配，包含原来的 12 次四维重构。本轮没有递归重放 v1–v43 的历史证明候选，也没有再次认证 bounded-12 的穷尽性。

完整重放对代码使用整数、有理数及符号精确运算；没有使用随机样本、浮点凸包或数值优化来判定结论。参考小数不参与证明。

## 13. 外部定理与引用

[1] H. Iriyeh, M. Shibata, *Symmetric Mahler's conjecture for the volume product in the three dimensional case*, Duke Math. J. 169 (2020), 1077–1134; arXiv:1706.01749v3. 本轮使用三维下界及其等号分类。

[2] M. Fradelizi, M. Meyer, A. Zvavitch, *Volume Product*, arXiv:2301.06131v1. Section 1.1 说明 Brunn 截面凹性；Section 3.2 讨论二维 Mahler 定理。上述经典定理不是本包重新形式化的内容。

[3] J. Kim, *Minimal volume product near Hanner polytopes*, arXiv:1212.2544v1. 本轮只使用其 Hanner 局部极小主定理，未重证或形式化该定理。

[4] v44-audit, *复核、结构反例与线段粘合的端点归约*, 2026-09-06。本包附原始 v44 文件，并保持其一般 CE 未证明的状态。

本轮没有进行足以支持世界首创声明的全面文献检索。报告中的“本轮证明”指本次给出的可核查推导，不声称这些估计此前无人得到。
