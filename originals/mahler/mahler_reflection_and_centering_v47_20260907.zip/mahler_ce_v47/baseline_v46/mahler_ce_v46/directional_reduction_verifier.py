#!/usr/bin/env python3
"""Exact finite-direction reduction and all-direction clipped-cube CE certificates.
The log-concavity reduction is proved in report_zh.md, not formalized here.
Only this one-parameter C_s family and the stated finite calibrations are closed.
"""
from __future__ import annotations
import itertools
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json,sys
import sympy as sp
from joint_bound_verifier import bernstein
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'baseline_v45'/'mahler_ce_v45'/'baseline'
sys.path.insert(0,str(BASE))
import segment_moment_reduction as geo
from exact_audit import dot,solve
from simplex_absolute_moment import s,simplex_abs_mean,oct_moment,catalog


def canon_antipodal(v):
    for a in v:
        if a:return tuple(v) if a>0 else tuple(-b for b in v)
    return tuple(v)


def candidates(points,normals):
    normals=sorted(set(canon_antipodal(n) for n in normals))
    out=set()
    for ns in itertools.combinations(normals,3):
        for rhs in itertools.product([-1,0,1],repeat=3):
            if rhs==(0,0,0):continue
            v=solve(ns,rhs)
            if v is None:continue
            if all(abs(dot(n,v))<=1 for n in normals):out.add(canon_antipodal(v))
    assert all(max(abs(dot(n,v)) for n in normals)==1 for v in out)
    return sorted(out)


def affine_feasible_interval(v):
    lo,hi=sp.S.One,sp.Integer(3)
    expressions=[1+x for x in v]+[1-x for x in v]+[s+sum(v),s-sum(v)]
    for z in expressions:
        p=sp.Poly(sp.expand(z),s,domain=sp.QQ)
        if p.degree()>1:raise ValueError(z)
        a=p.nth(1);b=p.nth(0)
        if a>0:lo=max(lo,-b/a)
        elif a<0:hi=min(hi,-b/a)
        elif b<0:return None
    if lo>hi:return None
    return lo,hi


def exact_catalog():
    normals=sp.Matrix([[1,0,0],[0,1,0],[0,0,1],[1/s,1/s,1/s]])
    basic=[('axis',(1,0,0)),('opposite_pair',(1,-1,0)),('same_pair',(1,1,0)),('cube_vertex',(1,1,-1)),('cap_mid',(1,s-1,0)),('cap_vertex',(1,1,s-2))]
    records={};singletons={}
    for ids in itertools.combinations(range(4),3):
        N=normals[list(ids),:]
        assert N.det()!=0
        inv=N.inv()
        for rhs in itertools.product([-1,0,1],repeat=3):
            if rhs==(0,0,0):continue
            v=tuple(sp.factor(z) for z in inv*sp.Matrix(rhs))
            interval=affine_feasible_interval(v)
            if interval is None:continue
            lo,hi=interval
            key=tuple(map(str,v))
            if lo==hi:
                assert lo in (1,2,3)
                singletons[(key,str(lo))]={'v':list(key),'parameter':str(lo)}
                continue
            match=None
            for name,rep in basic:
                for p in itertools.permutations(range(3)):
                    for sign in [-1,1]:
                        if all(sp.factor(v[i]-sign*rep[p[i]])==0 for i in range(3)):
                            match={'orbit':name,'sign':sign,'permutation':list(p)};break
                    if match:break
                if match:break
            assert match, (v,interval)
            records[key]={'v':list(key),'valid_closed_interval':[str(lo),str(hi)],**match}
    cnt=Counter(r['orbit'] for r in records.values())
    assert set(cnt)=={x[0] for x in basic}
    return {'normal_pair_count':4,'normal_triples':4,'raw_right_hand_sides_each':26,
            'nondegenerate_feasible_affine_paths':len(records),'orbits':dict(cnt),
            'records':list(records.values()),'singleton_records':list(singletons.values()),
            'endpoint_coverage':'All contacts at s=1,2,3 follow by continuity; cube and cross-polytope endpoints also separately checked.'}


def no_inner_root(expr,a,b):
    num,den=sp.fraction(sp.cancel(expr))
    for p in (num,den):
        if p==0:continue
        poly=sp.Poly(p,s,domain=sp.QQ)
        for endpoint in (a,b):
            while poly.degree()>0 and poly.eval(endpoint)==0:
                poly=poly.exquo(sp.Poly(s-endpoint,s,domain=sp.QQ))
        assert poly.count_roots(a,b)==0,(expr,a,b)


def interval_positive(p,a,b,depth=0):
    co=bernstein(p,s,a,b)
    if min(co)>0:return [{'interval':[str(a),str(b)],'coefficients':list(map(str,co)),'minimum':str(min(co))}]
    if depth>=12:raise AssertionError((p,a,b,co))
    mid=(a+b)/2
    return interval_positive(p,a,mid,depth+1)+interval_positive(p,mid,b,depth+1)


def positive_rational(expr,a,b):
    a,b=map(sp.Rational,(a,b))
    num,den=sp.fraction(sp.factor(expr))
    if den.subs(s,(a+b)/2)<0:num=-num;den=-den
    records=[]
    for label,p in [('numerator',num),('denominator',den)]:
        factors=[]
        for endpoint,factor in ((a,s-a),(b,b-s)):
            multiplicity=0
            while p.subs(s,endpoint)==0:
                p=sp.cancel(p/factor);multiplicity+=1
            if multiplicity:factors.append({'positive_factor':str(factor),'power':multiplicity})
        records.append({'part':label,'endpoint_factors':factors,'remaining_polynomial':str(sp.expand(p)),
                        'bernstein':interval_positive(p,a,b)})
    return {'interval_open':[str(a),str(b)],'expression':str(expr),'sign':'strictly positive','parts':records}


def symbolic_family():
    V=8-(3-s)**3/3;W=1+1/s
    results=[]
    for name,v,lo,hi in catalog:
        lo,hi=sp.Rational(lo),sp.Rational(hi);sample=(lo+hi)/2
        values_to_audit=[]
        for eps in itertools.product([-1,1],repeat=3):
            values_to_audit.append([sp.S.Zero]+[eps[i]*v[i] for i in range(3)])
        values_to_audit.append(list(v)+[sum(v)/s])
        for vals in values_to_audit:
            for z in vals:no_inner_root(z,lo,hi)
            for a,b in itertools.combinations(vals,2):no_inner_root(a-b,lo,hi)
        J0=oct_moment(v,sample)
        Jp=(3/s-1)/3*simplex_abs_mean(list(v)+[sum(v)/s],sample)
        J=sp.factor(sp.cancel(J0+Jp))
        h=(3-s)**2/2
        Av=sp.factor((4-h)*sum(sp.sign(x.subs(s,sample))*x for x in v)+h*sp.sign(sum(v).subs(s,sample))*sum(v))
        E=sp.factor(sp.cancel((V+2*Av/3)*(W-J)))
        gap=sp.factor(E-sp.Rational(32,3))
        assert not any(x.has(sp.Float) for x in (J,Av,E,gap))
        rec={'orbit':name,'v':list(map(str,v)),'interval':[str(lo),str(hi)],'contact_projection_Av':str(Av),'polar_absolute_moment':str(J),
             'contact_E':str(E),'gap':str(gap),'gap_certificate':positive_rational(gap,lo,hi)}
        results.append(rec)
    # Full profile has no assumption that the slices themselves are homothetic.
    return {'body':'C_s=[-1,1]^3 intersect {|x1+x2+x3|<=s}','parameter':'1<=s<=3',
            'volume':str(sp.factor(V)),'polar_volume':str(W),'three_dimensional_Mahler_gap':str(sp.factor(V*W-sp.Rational(32,3))),'three_dimensional_gap_certificate':positive_rational(sp.factor(V*W-sp.Rational(32,3)),1,3),'planar_area_coefficients':{'coordinate_facet_area':'4-(3-s)^2/2','diagonal_facet_area_divided_by_sqrt3':'(3-s)^2/2'},
            'all_directions_conclusion':'E(C_s,v)>=32/3 for every v in C_s; strict for contact v when 1<s<3',
            'moment_method':'8 octahedral orthants plus 2 attached tetrahedra; confluent divided differences of t_+^4',
            'catalog_moment_intervals':results}


def fracvec(v):return tuple(F(str(sp.cancel(x))) for x in v)


def endpoint_quantities(C,v,reconstruct4=False):
    pts,N,fs=geo.hull(C);v=tuple(F(x) for x in v)
    dfaces=[frozenset(j for j,n in enumerate(N) if dot(n,p)==1) for p in pts]
    V=geo.integrals(pts,fs)[0];W=geo.integrals(N,dfaces)[0]
    assert max(dot(n,v) for n in N)==1
    # Exact coordinate change sending e1 to v. This avoids irrational unit normals.
    for pair in itertools.combinations(range(3),2):
        T=sp.Matrix.hstack(sp.Matrix(v),*[sp.eye(3)[:,i] for i in pair])
        if T.det():break
    det=abs(F(T.det()));Ti=T.inv()
    Cp=[fracvec(Ti*sp.Matrix(p)) for p in pts]
    Kp=[fracvec(T.T*sp.Matrix(n)) for n in N]
    Inew,Wnew=geo.abs_moment(Kp,dfaces,Cp)
    assert Wnew==det*W
    I=Inew/det
    pp,nn,pf=geo.hull([p[1:] for p in Cp]);Av=det*geo.integrals(pp,pf)[0]
    E=(V+F(2,3)*Av)*(W-I)
    record={'v':list(map(str,v)),'C_vertices':len(pts),'C_facets':len(N),'V':str(V),'W':str(W),'Av':str(Av),'I_v':str(I),'E':str(E)}
    if reconstruct4:
        Q=[(F(0),)+p for p in pts]+[(F(x),)+tuple(F(t)*a for a in v) for x in [-1,1] for t in [-1,1]]
        qp,qn,qf=geo.hull(Q)
        qdf=[frozenset(j for j,n in enumerate(qn) if dot(n,p)==1) for p in qp]
        qvol=geo.integrals(qp,qf)[0];qpol=geo.integrals(qn,qdf)[0]
        assert qvol==V/2+Av/3 and qpol==2*(W-I) and qvol*qpol==E
        record['independent_4D_reconstruction']={'vertices':len(qp),'facets':len(qn),'volume':str(qvol),'polar_volume':str(qpol),'product':str(qvol*qpol)}
    return record


def Cs_points(a):
    a=F(a)
    cube=[tuple(F(x) for x in p) for p in itertools.product([-1,1],repeat=3) if abs(sum(p))==1]
    cap=set(itertools.permutations([F(1),F(1),a-2]))
    cap|={tuple(-x for x in p) for p in list(cap)}
    return sorted(set(cube)|cap)


def calibrations(family):
    cube=list(itertools.product([-1,1],repeat=3))
    octa=[tuple(eps if j==i else 0 for j in range(3)) for i in range(3) for eps in [-1,1]]
    out=[]
    for name,C,expected in [('cube',cube,13),('octahedron',octa,9)]:
        pts,N,fs=geo.hull(C);cand=candidates(pts,N)
        assert len(cand)==expected,(name,len(cand))
        values=[endpoint_quantities(pts,v) for v in cand]
        assert min(F(x['E']) for x in values)==F(32,3)
        # Antipodal class geometry and orbit counts are checked exactly.
        hist=Counter(x['E'] for x in values)
        if name=='cube':assert hist=={'32/3':3,'100/9':6,'34/3':4},hist
        else:assert hist=={'32/3':9},hist
        out.append({'body':name,'unoriented_candidate_count':len(cand),'product_histogram':dict(hist),'records':values})
    recon=[]
    for row in family['catalog_moment_intervals']:
        a,b=map(sp.Rational,row['interval']);x=(a+b)/2
        v=fracvec([sp.sympify(z,locals={'s':s}).subs(s,x) for z in row['v']])
        rec=endpoint_quantities(Cs_points(F(x)),v,True)
        for label,field in [('Av','contact_projection_Av'),('I_v','polar_absolute_moment'),('E','contact_E')]:
            expected=F(sp.cancel(sp.sympify(row[field],locals={'s':s}).subs(s,x)))
            assert F(rec[label])==expected,(row['orbit'],label,rec[label],expected)
        rec.update({'parameter_s':str(x),'orbit':row['orbit']});recon.append(rec)
        print('reconstructed',row['orbit'],str(x),rec['independent_4D_reconstruction'],flush=True)
    # Independent example in the old unresolved numerical M(C) band.
    diag_s=F(5,2);diag_v=(diag_s/3,)*3
    diag_rec=endpoint_quantities(Cs_points(diag_s),diag_v,True)
    diag_rec.update({'parameter_s':str(diag_s),'orbit':'diagonal_joint_test'})
    rec_M=F(diag_rec['V'])*F(diag_rec['W'])
    assert rec_M==F(1337,120)<F(91,8)
    projection=[(p[0]-p[2],p[1]-p[2]) for p in Cs_points(diag_s)]
    pp,pn,pf=geo.hull(projection)
    pa=geo.integrals(pp,pf)[0]
    pdual=[frozenset(i for i,n in enumerate(pn) if dot(n,p)==1) for p in pp]
    pb=geo.integrals(pn,pdual)[0]
    assert pa==12 and pb==F(3,4) and pa*pb==9
    assert 64*rec_M+51*pa*pb>1136
    diag_rec['joint_criterion']={'M_C':str(rec_M),'Sigma':str(pa*pb),
       'left_hand_side':str(64*rec_M+51*pa*pb),'threshold':'1136',
       'projection_quotient_area':str(pa),'polar_central_section_dual_coordinate_area':str(pb)}
    recon.append(diag_rec)
    census=[]
    for x in [F(1),F(3,2),F(2),F(5,2),F(3)]:
        pts,N,fs=geo.hull(Cs_points(x));cand=candidates(pts,N)
        census.append({'s':str(x),'C_vertices':len(pts),'C_facets':len(N),'unoriented_directional_candidates':len(cand),'candidate_vectors':[list(map(str,v)) for v in cand]})
    return {'Hanner_directional_calibrations':out,'new_4D_reconstruction_count':len(recon),'reconstructions':recon,'exact_candidate_census':census}


def main():
    cat=exact_catalog();family=symbolic_family();cal=calibrations(family)
    out={'status':'PASS','general_directional_reduction':{'statement':'For fixed polytope C, min_{v in C} E(C,v) is attained at 0 or a feasible intersection of d independent hyperplanes n_i.v in {-1,0,1}.','proof_interface':'On each facet-normal sign cell, A_C(v) is linear and log[(V+2A_C(v)/3)(W-I_K(v))] is concave.','unoriented_bound_3D':'at most 13*binomial(m,3), where m is number of facet pairs; singular triples skipped','affine_invariant_pair':'Both C and v transform together.'},
      'symbolic_catalog_exhaustion':cat,'all_direction_family':family,**cal,
      'limitations':{'direction_count_not_uniform_in_C_complexity':True,'arbitrary_three_dimensional_C_not_solved':True,'independent_implementation':False,'general_CE_proved':False,'full_4D_conjecture_proved':False}}
    (ROOT/'directional_reduction_certificate.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':'PASS','new_4D_reconstructions':len(cal['reconstructions']),'all_direction_family':'C_s, 1<=s<=3','general_CE_proved':False},indent=2))
if __name__=='__main__':main()
