#!/usr/bin/env python3
"""Exact absolute affine moments on rational/algebraic 3-simplices.

The sign of every vertex value and all coincident-node cases must be constant
on the caller's interval. directional_reduction_verifier.py certifies this by
exact polynomial root counting before using the sample to choose signs.
Confluent divided differences handle repeated vertex values analytically.
"""
import sympy as sp
from itertools import product
from functools import lru_cache
s=sp.symbols('s', real=True)

def zero(e):return sp.cancel(e)==0

def simplex_abs_mean(vals, sample):
    # Four barycentric vertex values. Uniform mean of |affine value| on a 3-simplex.
    groups=[]
    for a in vals:
        a=sp.factor(a)
        for group in groups:
            if zero(a-group[0]):group[1]+=1;break
        else:groups.append([a,1])
    z=sp.symbols('z')
    positive=sp.S.Zero
    for a,m in groups:
        sg=sp.sign(a.subs(s,sample))
        if sg<=0:continue
        term=z**4
        for b,n in groups:
            if not zero(a-b):term/=(z-b)**n
        positive+=sp.diff(term,z,m-1).subs(z,a)/sp.factorial(m-1)
    # E[l_+] = divided_difference(t_+^4)/4.
    return sp.factor(sp.cancel(positive/2-sum(vals)/4))

@lru_cache(None)
def oct_moment(v,sample):
    return sp.factor(sp.cancel(sum(simplex_abs_mean([sp.S(0)]+[eps[i]*v[i] for i in range(3)],sample)/6 for eps in product([-1,1],repeat=3))))

V=8-(3-s)**3/3;W=1+1/s
catalog=[('axis',(sp.S(1),sp.S(0),sp.S(0)),1,3),('opposite_pair',(sp.S(1),sp.S(-1),sp.S(0)),1,3),('same_pair',(sp.S(1),sp.S(1),sp.S(0)),2,3),('cube_vertex',(sp.S(1),sp.S(1),sp.S(-1)),1,3),('cap_mid',(sp.S(1),s-1,sp.S(0)),1,2),('cap_vertex_low',(sp.S(1),sp.S(1),s-2),1,2),('cap_vertex_high',(sp.S(1),sp.S(1),s-2),2,3)]
