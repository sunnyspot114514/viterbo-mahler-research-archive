#!/usr/bin/env python3
"""Finite exact calibrations for the v47 reflection-direction theorem.

The general theorem has a written proof using FHMRZ Proposition 2 (and its
intermediate section-sum inequality), planar two-measure equipartition and
the three-dimensional symmetric Mahler theorem. This script does not claim
to formalize those analytic inputs. It reconstructs all 48 partition pieces
for one non-coordinate-unconditional, non-homothetic rational calibration.
"""
from __future__ import annotations
import argparse, itertools, json, math
from pathlib import Path
from fractions import Fraction as F
import sympy as sp
from exact_helpers import (geo, dot, rank, hpoly, from_normals, describe,
                           contact_body, restricted_normals)

ROOT=Path(__file__).resolve().parent


def coordinate_halfspaces(d, signs):
    return [(tuple(-F(sg) if i==j else F(0) for i in range(d)), F(0))
            for j,sg in enumerate(signs)]


def piece_record(pts, facets):
    v,_,nt = geo.integrals(pts, facets)
    return {'vertices':len(pts), 'facets':len(facets),
            'boundary_simplices':nt, 'volume':str(v)}


def section_polygon(c, t):
    # Intersect f(p,q)>=t with [-1,1]^2.
    hs=[((1,0),1),((-1,0),1),((0,1),1),((0,-1),1)]
    for a,b in itertools.product([-1,1],repeat=2):
        hs.append(((c*a+4*c*b/5,c*a-8*c*b/5),1-t))
    p,f=hpoly(hs)
    return p,f


def main(output):
    c=F(1,20); d=4*c/5
    ns=[(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
    ns += [(sg,a*c+b*d,a*c-2*b*d)
           for sg,a,b in itertools.product([-1,1],repeat=3)]
    C,N,cf,cdf=from_normals(ns)
    cr=describe(C,N,cf,cdf)
    V=F(cr['volume']); W=F(cr['polar_volume'])
    J,Wcheck=geo.abs_moment(N,cdf,C)
    assert Wcheck==W
    proj,_,pf=geo.hull([p[1:] for p in C]); A=geo.integrals(proj,pf)[0]
    assert A==4 and 1/max(n[0] for n in N)==1
    Cset=set(C)
    assert all((-p[0],p[1],p[2]) in Cset for p in C)
    assert all((p[0],-p[1],-p[2]) in Cset for p in C)
    # The two transverse coordinate reflections are individually not symmetries.
    flips=[]
    for j in [1,2]:
        flips.append(all(tuple(-x if k==j else x for k,x in enumerate(p)) in Cset for p in C))
    assert flips == [False, False]

    # Exact analytic quadrant integral for the selected roof.
    p,q=sp.symbols('p q', nonnegative=True)
    l1_pp=sp.integrate(p+q,(p,0,1),(q,0,1))
    l1_pm=(sp.integrate(sp.integrate(p-q,(q,0,p)),(p,0,1))
           +sp.integrate(sp.integrate(q-p,(q,p,1)),(p,0,1)))
    l2_pp=sp.integrate(sp.integrate(p-2*q,(q,0,p/2))
                     +sp.integrate(2*q-p,(q,p/2,1)),(p,0,1))
    l2_pm=sp.integrate(p+2*q,(p,0,1),(q,0,1))
    assert [l1_pp,l1_pm,l2_pp,l2_pm] == [1,sp.Rational(1,3),sp.Rational(2,3),sp.Rational(3,2)]
    cp=sp.symbols('c', nonnegative=True)
    Fpp=1-cp*l1_pp-sp.Rational(4,5)*cp*l2_pp
    Fpm=1-cp*l1_pm-sp.Rational(4,5)*cp*l2_pm
    assert sp.expand(Fpp-Fpm)==0
    assert sp.expand(Fpp-(1-sp.Rational(23,15)*cp))==0
    assert V == F(554,75) and W==F(571,375) and J==F(54,125)
    assert V*W==F(316334,28125)
    assert V*W < F(91,8)
    Sigma=F(8) # projection square and its polar diamond
    assert 64*V*W+51*Sigma < 1136

    Q,QN,QF,QDF=contact_body(C)
    qr=describe(Q,QN,QF,QDF)
    QV=F(qr['volume']); QW=F(qr['polar_volume'])
    assert QV==V/2+A/3 and QW==2*(W-J)
    assert QV*QW==F(308386,28125)>F(32,3)
    assert qr['vertex_count']==qr['facet_count']==16

    # All 16 full-dimensional pieces are independently intersected/rebuilt.
    orthants=[]
    for signs in itertools.product([-1,1],repeat=4):
        pts,fs=hpoly([(n,1) for n in QN]+coordinate_halfspaces(4,signs))
        rec=piece_record(pts,fs);rec['signs']=list(signs)
        assert F(rec['volume'])*16==QV
        orthants.append(rec)
    # All four central sections, and all 8 pieces of each, independently rebuilt.
    sections=[]
    section_products=[]
    for deleted in range(4):
        ns3=restricted_normals(QN,deleted)
        ns3=[n for n in ns3 if any(n)]
        S,SN,SF,SDF=from_normals(ns3)
        sr=describe(S,SN,SF,SDF);sv=F(sr['volume'])
        section_products.append(F(sr['Mahler_product']))
        pieces=[]
        for signs in itertools.product([-1,1],repeat=3):
            pts,fs=hpoly([(n,1) for n in SN]+coordinate_halfspaces(3,signs))
            rec=piece_record(pts,fs);rec['signs']=list(signs)
            assert F(rec['volume'])*8==sv
            pieces.append(rec)
        assert F(sr['Mahler_product'])>=F(32,3)
        sr.update(deleted_coordinate=deleted,eight_pieces=pieces)
        sections.append(sr)
    assert F(sections[0]['volume'])==V
    assert F(sections[1]['volume'])==2*A/3
    section_sum_bound=sum(section_products)/4
    simplified_bound=F(32,3)+(V*W-F(32,3))/4+(Sigma-8)/3
    assert QV*QW>=section_sum_bound>=simplified_bound

    # At t=0 the transverse section is a square; sufficiently near t=1 it
    # is a parallelogram with different edge directions, so not homothetic.
    low,lf=section_polygon(c,F(0)); high,hf=section_polygon(c,F(19,20))
    assert set(low)==set(itertools.product([F(-1),F(1)],repeat=2))
    assert len(high)==4
    def edge_slopes(pts,facets):
        ds=set()
        for face in facets:
            i,j=sorted(face); a,b=pts[i],pts[j]
            dx=b[0]-a[0];dy=b[1]-a[1]
            ds.add('vertical' if dx==0 else str(dy/dx))
        return sorted(ds)
    slopes_low=edge_slopes(low,lf);slopes_high=edge_slopes(high,hf)
    assert slopes_low != slopes_high

    # Complete one-parameter polynomial calibration, not just sample checks.
    Vc=8-sp.Rational(184,15)*cp
    Wc=sp.Rational(4,3)+sp.Rational(52,15)*cp+sp.Rational(32,5)*cp**2
    Jc=sp.Rational(1,3)+sp.Rational(26,15)*cp+sp.Rational(24,5)*cp**2
    t=sp.symbols('t')
    # Exact mixed area of the equatorial diamond H and the unit-scale
    # top parallelogram T. For c<=5/14, c*T is contained in H, hence the
    # polar slice is exactly (1-t)H+t*c*T, including nonsmooth boundaries.
    diamond=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(0)),(F(0),F(-1))]
    top=[(F(i)+F(4,5)*j,F(i)-F(8,5)*j)
         for i,j in itertools.product([-1,1],repeat=2)]
    top_pts,_,top_facets=geo.hull(top)
    top_area=geo.integrals(top_pts,top_facets)[0]
    sums=[(x[0]+y[0],x[1]+y[1]) for x in diamond for y in top]
    sums_pts,_,sums_facets=geo.hull(sums)
    sum_area=geo.integrals(sums_pts,sums_facets)[0]
    mixed_area=(sum_area-2-top_area)/2
    assert top_area==F(48,5) and sum_area==22 and mixed_area==F(26,5)
    assert all(F(5,14)*(abs(x)+abs(y))<=1 for x,y in top)
    slice_area=2*(1-t)**2+2*sp.Rational(26,5)*cp*t*(1-t)+sp.Rational(48,5)*cp**2*t**2
    assert sp.expand(Wc-2*sp.integrate(slice_area,(t,0,1)))==0
    assert sp.expand(Jc-2*sp.integrate(t*slice_area,(t,0,1)))==0
    Ec=sp.expand((Vc+sp.Rational(8,3))*(Wc-Jc))
    residual=175-118*cp-552*cp**2
    assert sp.factor(Ec-sp.Rational(32,3)-8*cp*residual/225)==0
    # residual decreasing and still positive on [0,5/14].
    assert residual.subs(cp,sp.Rational(5,14))>0
    assert sp.diff(residual,cp)==-118-1104*cp

    record={
      'status':'PASS',
      'scope':'Exact finite calibrations; general reflection theorem is a written external-theorem corollary',
      'C_definition':'|p|,|q|<=1; |t|+|p+q|/20+|p-2q|/25<=1',
      'C':cr,'contact_Q':qr,
      'contact_radius':'1','projection_area':str(A),'polar_first_absolute_moment':str(J),
      'Sigma':str(Sigma),'old_joint_screen_lhs':str(64*V*W+51*Sigma),
      'old_joint_screen_satisfied':False,
      'unknown_qualitative_neighborhood_membership':'NOT determined',
      'exact_four_dimensional_piece_count':len(orthants),
      'four_dimensional_orthants':orthants,
      'exact_three_dimensional_section_piece_count':sum(len(s['eight_pieces']) for s in sections),
      'central_sections':sections,
      'section_sum_lower_bound':str(section_sum_bound),
      'simplified_coupled_lower_bound':str(simplified_bound),
      'transverse_coordinate_reflections_are_symmetries':flips,
      'nonhomothetic_section_witness':{
          'heights':['0','19/20'],
          'vertices':[[list(map(str,p)) for p in arr] for arr in [low,high]],
          'edge_slopes':[slopes_low,slopes_high]},
      'one_parameter_calibration':{
          'parameter_interval':'0<=c<=5/14; d=4c/5',
          'quadrant_roof_integral':str(Fpp), 'top_parallelogram_area':str(top_area),
          'diamond_plus_top_area':str(sum_area),'mixed_area':str(mixed_area), 'V':str(Vc),'W':str(Wc),'J':str(Jc),
          'E':str(Ec),'E_minus_32_3':str(sp.factor(Ec-sp.Rational(32,3))),
          'residual_minimum':str(residual.subs(cp,sp.Rational(5,14))),
          'positive_for_c_greater_than_zero':True},
      'external_analytic_interfaces':['FHMRZ arXiv:1904.10765v3 Proposition 2 and intermediate 4/n^2 section-product sum',
          'Fradelizi--Nakhle arXiv:2412.12372v2 Lemma 3.5 with m=1',
          'Iriyeh--Shibata arXiv:1706.01749v3'],
      'general_CE_proved':False,'all_lambda1_gluings_proved':False,'full_4D_Mahler_proved':False,
    }
    output.write_text(json.dumps(record,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['status','exact_four_dimensional_piece_count',
       'exact_three_dimensional_section_piece_count','section_sum_lower_bound','simplified_coupled_lower_bound',
       'old_joint_screen_satisfied','general_CE_proved']},indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'reflection_certificate.json')
    args=parser.parse_args();main(args.output)
