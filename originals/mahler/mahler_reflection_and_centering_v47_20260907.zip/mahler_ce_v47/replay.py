#!/usr/bin/env python3
"""Integrity and clean exact v47 rebuild, including the v46/v45/v44 baseline."""
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest_check():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    if manifest['version']!='v47':
        raise ValueError('Wrong snapshot version')
    total=0
    for rel,record in manifest['files'].items():
        p=ROOT/rel
        if not p.is_file() or p.stat().st_size!=record['bytes'] or sha(p)!=record['sha256']:
            raise AssertionError(('file integrity mismatch',rel))
        total+=record['bytes']
    return manifest,total


def run(script: Path, *args: str):
    result=subprocess.run([sys.executable,str(script),*args],cwd=script.parent,
        capture_output=True,text=True,timeout=1800)
    if result.returncode:
        raise RuntimeError(f'{script.name} failed\n{result.stdout[-5000:]}\n{result.stderr[-5000:]}')
    return result.stdout


def main(rebuild:bool):
    manifest,total=manifest_check()
    expected={name:(ROOT/name).read_bytes() for name in
        ['reflection_certificate.json','centering_certificate.json']}
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v47_exact_') as td:
            fresh=Path(td)
            for rel in manifest['files']:
                dest=fresh/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/rel,dest)
            shutil.copy2(ROOT/'manifest.json',fresh/'manifest.json')
            run(fresh/'baseline_v46/mahler_ce_v46/replay.py','--rebuild')
            for script,name in [('reflection_equipartition_verifier.py','reflection_certificate.json'),
                                ('centering_verifier.py','centering_certificate.json')]:
                (fresh/name).unlink()
                run(fresh/script,'--output',str(fresh/name))
                if (fresh/name).read_bytes()!=expected[name]:
                    raise AssertionError(('fresh certificate differs from archived bytes',name))
            # Source and baseline inputs in the original tree were never modified.
            manifest_check()
    reflection=json.loads(expected['reflection_certificate.json'])
    center=json.loads(expected['centering_certificate.json'])
    assert reflection['status']==center['status']=='PASS'
    assert reflection['exact_four_dimensional_piece_count']==16
    assert reflection['exact_three_dimensional_section_piece_count']==32
    assert center['exact_three_dimensional_reconstruction_count']==5
    assert center['independent_exact_four_dimensional_reconstruction_count']==3
    assert center['full_parameter_inequality_proved'] is True
    for rec in [reflection,center]:
        assert rec['general_CE_proved'] is False
        assert rec['all_lambda1_gluings_proved'] is False
        assert rec['full_4D_Mahler_proved'] is False
    out={
        'status':'PASS','rebuild':rebuild,
        'files_integrity_checked':len(manifest['files']), 'bytes_integrity_checked':total,
        'baseline_v44_v45_v46_rebuilt':rebuild,
        'v1_through_v43_history_rebuilt':False,
        'new_certificates_regenerated_and_byte_compared':2 if rebuild else 0,
        'reflection_direction_theorem':'written analytic corollary, arbitrary complexity and nonhomothetic sections allowed',
        'reflection_coupled_bound':'E-32/3 >= (M(C)-32/3)/4 + (Sigma-8)/3 under the reflection hypothesis',
        'exact_4D_equipartition_piece_count':16,
        'exact_3D_central_section_piece_count':32,
        'new_independent_full_4D_contact_hulls':4,
        'two_parameter_center_family':'alpha,beta>=0,alpha+beta<=2; specified t direction and radial subsegments',
        'center_family_all_directions_proved':False,
        'Steiner_centering_comparison':'E(original)<=E(centered); the opposite reduction is invalid',
        'strict_centering_gap_sample':'161/1800',
        'general_contact_endpoint_inequality_proved':False,
        'all_lambda1_gluings_proved':False,
        'full_4D_conjecture_proved':False,
        'proof_scope':'Finite exact algebra, support reconstruction, partition volumes and sign certificates. Analytic theorem interfaces are written proofs, not Python formalizations.',
        'manifest_sha256':sha(ROOT/'manifest.json')
    }
    (ROOT/'replay_output.json').write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2))

if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('Do not run verifiers with Python -O; assertions must be enabled')
    p=argparse.ArgumentParser();p.add_argument('--rebuild',action='store_true');main(p.parse_args().rebuild)
