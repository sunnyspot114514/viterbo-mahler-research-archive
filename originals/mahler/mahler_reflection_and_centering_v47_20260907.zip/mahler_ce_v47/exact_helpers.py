"""Exact rational support enumeration; inherited v44 triangulation, new clipping.

The inherited source is included byte-for-byte inside baseline_v46. No stored
PASS status is used to reconstruct a polytope here. Coordinates and moments
are recomputed using fractions.Fraction and SymPy exact ranks/determinants.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations
import sys

BASE = (Path(__file__).resolve().parent / 'baseline_v46' / 'mahler_ce_v46'
        / 'baseline_v45' / 'mahler_ce_v45' / 'baseline')
sys.path.insert(0, str(BASE))
import segment_moment_reduction as geo
from exact_audit import solve, dot, rank


def hpoly(inequalities):
    """Reconstruct a bounded full-dimensional rational polytope n.x <= b.

    Supports b=0, so the origin may lie on the boundary. Enumeration is over
    every d-tuple of constraints. Nonfacets/redundant constraints are removed
    by an exact affine-rank test, not by a floating-point tolerance.
    """
    raw = sorted(set((tuple(map(F, n)), F(b)) for n, b in inequalities))
    if not raw:
        raise ValueError('A nonempty bounded H-representation is required')
    d = len(raw[0][0]); hs = []
    for n, b in raw:
        if len(n) != d:
            raise ValueError('Inconsistent ambient dimensions')
        if not any(n):
            if b < 0:
                raise ValueError('Empty polytope')
            continue
        hs.append((n, b))
    vertices = set()
    for inds in combinations(range(len(hs)), d):
        p = solve([hs[i][0] for i in inds], [hs[i][1] for i in inds])
        if p is not None and all(dot(n, p) <= b for n, b in hs):
            vertices.add(p)
    pts = sorted(vertices)
    if len(pts) < d+1 or rank([[p[j]-pts[0][j] for j in range(d)] for p in pts]) != d:
        raise ValueError('Expected a nonempty full-dimensional bounded polytope')
    facets = {}
    for n, b in hs:
        ids = frozenset(i for i, p in enumerate(pts) if dot(n, p) == b)
        if not ids:
            continue
        a = min(ids)
        if rank([[pts[i][j]-pts[a][j] for j in range(d)] for i in ids]) == d-1:
            facets[ids] = (n, b)
    fs = sorted(facets, key=lambda f: tuple(sorted(f)))
    for i in range(len(pts)):
        assert rank([facets[f][0] for f in fs if i in f]) == d
    return pts, fs


def from_normals(normals):
    hs = [(tuple(map(F,n)), F(1)) for n in normals]
    pts, fs = hpoly(hs)
    ns = []
    for f in fs:
        ns.append(next(n for n,b in hs if all(dot(n,pts[i]) == 1 for i in f)))
    dfs = [frozenset(j for j,n in enumerate(ns) if dot(n,p)==1) for p in pts]
    assert all(rank([ns[j] for j in f]) == len(pts[0]) for f in dfs)
    return pts, ns, fs, dfs


def describe(pts, normals, facets, dual_facets):
    volume, _, nt = geo.integrals(pts, facets)
    polar_volume, _, ntd = geo.integrals(normals, dual_facets)
    return {
        'vertices': [[str(x) for x in p] for p in pts],
        'facet_normals': [[str(x) for x in n] for n in normals],
        'facet_supports': [sorted(f) for f in facets],
        'vertex_count': len(pts), 'facet_count': len(normals),
        'volume': str(volume), 'polar_volume': str(polar_volume),
        'Mahler_product': str(volume*polar_volume),
        'boundary_simplices': nt, 'polar_boundary_simplices': ntd,
    }


def contact_body(pts, a=F(1)):
    points = [(F(0),)+tuple(p) for p in pts]
    points += [(F(x),F(t)*a,F(0),F(0)) for x in [-1,1] for t in [-1,1]]
    qp, qn, qf = geo.hull(points)
    qdf = [frozenset(j for j,n in enumerate(qn) if dot(n,p)==1) for p in qp]
    return qp, qn, qf, qdf


def restricted_normals(normals, deleted_coordinate):
    return [tuple(x for i,x in enumerate(n) if i != deleted_coordinate) for n in normals]


def rational(value):
    return str(F(value))
