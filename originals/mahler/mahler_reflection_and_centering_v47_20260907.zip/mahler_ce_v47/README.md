# v47 replay

This package contains the v47 reflection/equipartition and chord-centering
work, plus the exact v46/v45/v44 source snapshot it reuses. It does not certify
any v1–v43 classification and it does not prove general CE or 4D Mahler.

Requirements: Python 3.10+ and SymPy. Fractions, geometry clipping and all
volume computations are exact; there is no floating-point hull dependency.

Run:

```bash
python replay.py --rebuild
```

The driver first checks the manifest, copies the curated payload to a fresh
temporary directory, runs the inherited v46 full rebuild (including v45/v44),
then runs both v47 verifiers. The two fresh v47 JSON certificates must match
the archived JSON byte for byte. No cached PASS string substitutes for those
runs. The default without `--rebuild` verifies file hashes and certificate
schema/summary only; it is not a mathematical rebuild.

`report_zh.md` contains the proofs and explicitly lists the analytic theorem
interfaces. Python verifies the finite exact calculations, not the external
analytic theorems. Reflection is a condition on the chosen direction, not a
claim about every direction of an arbitrary centrally symmetric body.

No script installs dependencies, makes network requests, or writes outside
the package's replay_output.json and its temporary working directory.
