#!/usr/bin/env python3
"""v47: exact asymmetric chord-center family and wrong-way centering audit.

All formulas are verified over QQ(a,b), including every symbolic polar
support, oriented triangulation and the sign decomposition on a+b<=2.
Five rational 3D configurations and three independent 4D contact hulls are
reconstructed. No numerical optimization, floating-point hull, or sampling
is used to infer a full-parameter inequality.
"""
from __future__ import annotations
import argparse, itertools, json
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
from exact_helpers import geo, dot, from_normals, describe, contact_body

ROOT=Path(__file__).resolve().parent
A,B=sp.symbols('alpha beta',nonnegative=True)


def normals(a,b):
    out=[tuple(F(sg) if i==j else F(0) for i in range(3))
         for j in range(3) for sg in [-1,1]]
    for k,sg in [(a,1),(b,-1)]:
        n=(F(1)/(1+k),sg*k/(1+k),sg*k/(1+k))
        out += [n,tuple(-x for x in n)]
    return out


def symbolic_polar_certificate():
    # K=C^o: octahedron plus two antipodal pairs of tetrahedral caps.
    axes=[sp.Matrix([sg if k==i else 0 for k in range(3)])
          for i in range(3) for sg in [-1,1]]
    na=sp.Matrix([1,A,A])/(1+A)
    nb=sp.Matrix([1,-B,-B])/(1+B)
    points=axes+[na,-na,nb,-nb]
    # All generic facets of K. These are C's vertices.
    cv=[]
    for st,spg in itertools.product([-1,1],repeat=2):
        cv.append(sp.Matrix([st,spg,-spg]))
    for v in [sp.Matrix([1,1,0]),sp.Matrix([1,0,1]),sp.Matrix([1-A,1,1]),
              sp.Matrix([1,-1,0]),sp.Matrix([1,0,-1]),sp.Matrix([1-B,-1,-1])]:
        cv += [v,-v]
    assert len(cv)==16
    fs=[]; records=[]
    for n in cv:
        support=[]; slacks=[]
        for i,p in enumerate(points):
            slack=sp.factor(1-n.dot(p))
            if slack==0:
                support.append(i)
                continue
            num,den=sp.fraction(slack)
            # Both numerator and denominator are affine with nonnegative
            # values at the three closed parameter-triangle vertices.
            pol=sp.Poly(num,A,B)
            assert pol.total_degree()<=1
            corner=[sp.factor(num.subs({A:x,B:y})) for x,y in [(0,0),(2,0),(0,2)]]
            dcorner=[sp.factor(den.subs({A:x,B:y})) for x,y in [(0,0),(2,0),(0,2)]]
            assert all(x>=0 for x in corner) and any(x>0 for x in corner)
            assert sp.Poly(den,A,B).total_degree()<=1 and all(x>0 for x in dcorner)
            slacks.append({'vertex':i,'expression':str(slack),
                           'numerator_triangle_values':list(map(str,corner)),
                           'denominator_triangle_values':list(map(str,dcorner))})
        assert len(support)==3
        det=sp.factor(sp.Matrix.hstack(*[points[i] for i in support]).det())
        assert det!=0
        value=det.subs({A:sp.Rational(1,3),B:sp.Rational(2,3)})
        sg=1 if value>0 else -1
        pos=sp.factor(sg*det)
        # Prove positive on alpha,beta>0, alpha+beta<2 via factor signs.
        npos,dpos=sp.fraction(pos)
        assert sp.Poly(npos,A,B).total_degree()<=1
        nc=[sp.factor(npos.subs({A:x,B:y})) for x,y in [(0,0),(2,0),(0,2)]]
        dc=[sp.factor(dpos.subs({A:x,B:y})) for x,y in [(0,0),(2,0),(0,2)]]
        assert all(x>=0 for x in nc) and any(x>0 for x in nc)
        assert all(x>0 for x in dc)
        fs.append(tuple(support))
        records.append({'normal':list(map(str,n)),'support':support,
                        'signed_origin_determinant':str(pos),'strict_slacks':slacks})
    # Exact 2-sphere checks: each edge in two triangles, connected vertex links.
    edges=Counter(tuple(sorted(e)) for f in fs for e in itertools.combinations(f,2))
    assert set(edges.values())=={2}
    assert len(points)-len(edges)+len(fs)==2
    for i in range(len(points)):
        link_edges=[tuple(x for x in f if x!=i) for f in fs if i in f]
        link_graph={}
        for x,y in link_edges:
            link_graph.setdefault(x,set()).add(y);link_graph.setdefault(y,set()).add(x)
        assert all(len(v)==2 for v in link_graph.values())
        seen=set(); stack=[next(iter(link_graph))]
        while stack:
            v=stack.pop()
            if v not in seen:
                seen.add(v); stack+=list(link_graph[v]-seen)
        assert seen==set(link_graph)
    W=sp.factor(sum(sp.sympify(r['signed_origin_determinant'],locals={'alpha':A,'beta':B}) for r in records)/6)
    targetW=sp.Rational(4,3)+(A/(1+A)+B/(1+B))/3
    assert sp.factor(W-targetW)==0
    # Independent cap triangulation and absolute first moment.
    e1,e2,e3=map(sp.Matrix,[(1,0,0),(0,1,0),(0,0,1)])
    capvols=[];capmoments=[]
    for n,k,sg in [(na,A,1),(nb,B,-1)]:
        p=[e1,sg*e2,sg*e3,n]
        det=sp.factor(sp.Matrix.hstack(*[p[j]-p[0] for j in [1,2,3]]).det())
        z=det.subs({A:sp.Rational(1,3),B:sp.Rational(2,3)})
        vol=sp.factor((1 if z>0 else -1)*det/6)
        assert sp.factor(vol-k/(6*(1+k)))==0
        # First coordinates are nonnegative on each positive cap.
        moment=sp.factor(vol*sum(p[j][0] for j in range(4))/4)
        capvols.append(vol);capmoments.append(moment)
    capW=sp.factor(sp.Rational(4,3)+2*sum(capvols))
    J=sp.factor(sp.Rational(1,3)+2*sum(capmoments))
    targetJ=sp.Rational(1,3)+(A*(2+A)/(1+A)**2+B*(2+B)/(1+B)**2)/12
    assert sp.factor(capW-W)==0 and sp.factor(J-targetJ)==0
    return points,records,W,J


def main(output):
    points,facets,W,J=symbolic_polar_certificate()
    V=8-(A+B)/3
    # Integral of h=(|p+q|-1)_+ on [-1,1]^2 is 1/3.
    p,q=sp.symbols('p q',real=True)
    hinge_integral=2*sp.integrate(sp.integrate(p+q-1,(q,1-p,1)),(p,0,1))
    assert hinge_integral==sp.Rational(1,3)
    E=sp.factor((V+sp.Rational(8,3))*(W-J))
    eta=sp.symbols('eta',nonnegative=True)
    end=sp.factor(E.subs({A:eta,B:0}))
    end_expected=(32-eta)*(12+26*eta+15*eta**2)/(36*(1+eta)**2)
    assert sp.factor(end-end_expected)==0
    end_gap=eta*(52+70*eta-15*eta**2)/(36*(1+eta)**2)
    assert sp.factor(end-sp.Rational(32,3)-end_gap)==0
    # 52+70e-15e² >= 52+40e >0 on 0<=e<=2.
    assert sp.expand((52+70*eta-15*eta**2)-(52+40*eta)-15*eta*(2-eta))==0
    P=(3*A**3*B+2*A**3+6*A**2*B**2+16*A**2*B+8*A**2
       +3*A*B**3+16*A*B**2+22*A*B+8*A+2*B**3+8*B**2+8*B+2)
    coefficients=sp.Poly(P,A,B).terms()
    assert all(c>0 for _,c in coefficients)
    gap=A*B*(32-A-B)*P/(36*(1+A)**2*(1+B)**2*(1+A+B)**2)
    assert sp.factor(E-E.subs({A:A+B,B:0}, simultaneous=True)-gap)==0
    # Center shadow: fixed alpha+beta=1/2, continuously center at s=0.
    s=sp.symbols('s',real=True)
    sub={A:(1+s)/4,B:(1-s)/4}
    Es=sp.factor(E.subs(sub))
    target=7*(9*s**4-354*s**2+4025)/(4*(25-s**2)**2)
    assert sp.factor(Es-target)==0
    deriv=-112*s*(25-3*s**2)/(25-s**2)**3
    drop=56*s**2*(25-2*s**2)/(25*(25-s**2)**2)
    assert sp.factor(sp.diff(Es,s)-deriv)==0
    assert sp.factor(Es.subs(s,0)-Es-drop)==0
    assert Es.subs(s,0)==sp.Rational(1127,100)
    assert Es.subs(s,1)==sp.Rational(805,72)
    assert sp.factor(Es.subs(s,0)-Es.subs(s,1))==sp.Rational(161,1800)
    # Linear midpoint-plane obstruction at s=1: midpoint vanishes on two
    # independent projected points but not at their sum.
    midpoint_points=[([1,0],'0'),([0,1],'0'),([1,1],'-1/4')]
    samples=[]; fourd_count=0
    for av,bv in [(F(1,4),F(1,4)),(F(3,8),F(1,8)),(F(1,2),F(0)),
                  (F(1,3),F(2,3)),(F(1),F(1))]:
        C,N,CF,CDF=from_normals(normals(av,bv))
        rec=describe(C,N,CF,CDF)
        vol=F(rec['volume']);w=F(rec['polar_volume'])
        moment,w2=geo.abs_moment(N,CDF,C)
        assert w==w2
        ss={A:sp.Rational(av.numerator,av.denominator),B:sp.Rational(bv.numerator,bv.denominator)}
        assert sp.Rational(vol.numerator,vol.denominator)==V.subs(ss)
        assert sp.Rational(w.numerator,w.denominator)==W.subs(ss)
        assert sp.Rational(moment.numerator,moment.denominator)==J.subs(ss)
        PP,_,PF=geo.hull([v[1:] for v in C]);area=geo.integrals(PP,PF)[0]
        assert area==4
        val=(vol+2*area/3)*(w-moment)
        assert sp.Rational(val.numerator,val.denominator)==E.subs(ss)
        assert val>=F(32,3)
        rec.update(alpha=str(av),beta=str(bv),moment=str(moment),contact_E=str(val),projection_area='4')
        if av+bv==F(1,2):
            Q,QN,QF,QDF=contact_body(C)
            qr=describe(Q,QN,QF,QDF)
            assert F(qr['volume'])==vol/2+area/3
            assert F(qr['polar_volume'])==2*(w-moment)
            assert F(qr['Mahler_product'])==val
            rec['independent_4D_contact']=qr;fourd_count+=1
        samples.append(rec)
    certificate={
      'status':'PASS',
      'scope':'Two-parameter family, specified t-axis contact and all radial subsegments, not all directions',
      'definition':'|t|,|p|,|q|<=1; |t+alpha*(p+q)|<=1+alpha; |t-beta*(p+q)|<=1+beta',
      'parameter_domain':'alpha>=0, beta>=0, alpha+beta<=2',
      'full_parameter_inequality_proved':True,
      'all_contact_directions_proved':False,
      'generic_polar_vertices':[[str(x) for x in p] for p in points],
      'generic_polar_facet_certificates':facets,
      'generic_polar_f_vector':[10,24,16],
      'V':str(V),'W':str(W),'J':str(J),'E':str(E),
      'extreme_center_endpoint_E':str(end),
      'extreme_center_endpoint_gap':str(end_gap),
      'endpoint_residual_positive_identity':'52+70*eta-15*eta^2=52+40*eta+15*eta*(2-eta)',
      'gap_above_extreme_center_endpoint':str(gap),
      'positive_polynomial_terms':[{'powers':list(m),'coefficient':str(c)} for m,c in coefficients],
      'center_shadow_path':{
        'alpha':'(1+s)/4','beta':'(1-s)/4','interval':'0<=s<=1',
        'V':str(V.subs(sub)),'W':str(sp.factor(W.subs(sub))),'J':str(sp.factor(J.subs(sub))),
        'E':str(Es),'derivative':str(deriv),'drop_from_centered':str(drop),
        'centered_value':'1127/100','uncentered_endpoint_value':'805/72',
        'strict_centering_increase':'161/1800',
        'nonlinear_midpoint_witness':midpoint_points},
      'exact_three_dimensional_reconstruction_count':len(samples),
      'independent_exact_four_dimensional_reconstruction_count':fourd_count,
      'samples':samples,
      'general_centering_comparison':{
        'direction':'E(original)<=E(Steiner-centered)',
        'analytic_status':'written consequence of constant-volume even shadow and Meyer--Reisner convexity, not formalized in this verifier'},
      'general_CE_proved':False,'all_lambda1_gluings_proved':False,'full_4D_Mahler_proved':False,
    }
    output.write_text(json.dumps(certificate,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:certificate[k] for k in ['status','full_parameter_inequality_proved',
        'all_contact_directions_proved','exact_three_dimensional_reconstruction_count',
        'independent_exact_four_dimensional_reconstruction_count','general_CE_proved']},indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'centering_certificate.json')
    main(parser.parse_args().output)
