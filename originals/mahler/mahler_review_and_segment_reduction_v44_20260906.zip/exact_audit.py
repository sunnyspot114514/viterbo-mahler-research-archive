#!/usr/bin/env python3
"""Exact audit of the previously displayed lambda=1 matched-wall polytope.
No inherited PASS flag is used as evidence. All hull supports are recomputed.
"""
import itertools, json, hashlib
from fractions import Fraction as F
from pathlib import Path
import sympy as sp

ROOT=Path(__file__).resolve().parent
V0=[(1,1,0,0),(1,-1,0,0),(0,-2,0,0),
    (1,0,1,1),(1,0,1,-1),(1,0,-1,1),(1,0,-1,-1),
    (0,0,-2,1),(0,0,-2,-1)]

def solve(a,b):
    n=len(a); M=[[F(x) for x in row]+[F(t)] for row,t in zip(a,b)]
    for j in range(n):
        piv=next((i for i in range(j,n) if M[i][j]),None)
        if piv is None:return None
        M[j],M[piv]=M[piv],M[j]
        d=M[j][j];M[j]=[x/d for x in M[j]]
        for i in range(n):
            if i!=j and M[i][j]:
                d=M[i][j];M[i]=[x-d*y for x,y in zip(M[i],M[j])]
    return tuple(row[-1] for row in M)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def enumerate_polar(vertices):
    out=set(); tested=0; independent=0
    d=len(vertices[0])
    for ids in itertools.combinations(range(len(vertices)),d):
        tested+=1
        normal=solve([vertices[i] for i in ids],[1]*d)
        if normal is None:continue
        independent+=1
        if all(dot(p,normal)<=1 for p in vertices):out.add(normal)
    return sorted(out),tested,independent

def rank(rows):
    return sp.Matrix(rows).rank() if rows else 0

def all_faces(facets,n):
    faces={frozenset(range(n)),frozenset()}
    for f in facets:
        faces |= {x & f for x in list(faces)}
    return faces

def stats(points,facets):
    faces=all_faces(facets,len(points))
    edges=sorted(tuple(sorted(f)) for f in faces if len(f)==2)
    degrees=[sum(i in e for e in edges) for i in range(len(points))]
    high=[sum(degrees[i]>=5 for i in f) for f in facets]
    nt=[sum(i in f and len(f)>4 for f in facets) for i in range(len(points))]
    from collections import Counter
    return {'vertices':len(points),'facets':len(facets),'edges':len(edges),
        'degrees':degrees,'high_degree_vertices_per_facet':high,
        'facet_condition_pass':min(high)>=3,
        'nonsimplicial_facets_per_vertex':nt,
        'facet_size_histogram':dict(Counter(map(len,facets)))}

def determinant(rows):
    return F(sp.Matrix(rows).det())

def volume_pulling(points,facets):
    """Purely combinatorial global pulling using the exact complete face lattice."""
    faces=all_faces(facets,len(points))
    dims={f:(-1 if not f else rank([[points[i][k]-points[min(f)][k] for k in range(4)] for i in f])) for f in faces}
    cache={}
    def triang(f):
        if f in cache:return cache[f]
        d=dims[f]
        if len(f)==d+1:return [tuple(sorted(f))]
        a=min(f)
        bfaces=sorted((g for g in faces if g<f and dims[g]==d-1 and a not in g),key=lambda g:tuple(sorted(g)))
        ts=[tuple([a]+list(t)) for g in bfaces for t in triang(g)]
        cache[f]=ts;return ts
    tets=[t for f in facets for t in triang(f)]
    assert len(set(tuple(sorted(t)) for t in tets))==len(tets)
    from collections import Counter
    triangles=Counter(tuple(sorted(s)) for t in tets for s in itertools.combinations(t,3))
    assert set(triangles.values())=={2}
    terms=[abs(determinant([points[i] for i in t])) for t in tets]
    assert all(x>0 for x in terms)
    return sum(terms)/24,tets

def separation_census(representatives):
    """Exhaust all unordered nonempty vector partitions, fixing index 0 left."""
    n=len(representatives); total_rank=rank(representatives)
    zeros=[]; ones=[]
    for mask in range(1 << (n-1)):
        left=[0]+[i for i in range(1,n) if mask & (1 << (i-1))]
        if len(left)==n:continue
        right=[i for i in range(n) if i not in left]
        ra=rank([representatives[i] for i in left])
        rb=rank([representatives[i] for i in right])
        lam=ra+rb-total_rank
        assert lam>=0
        item={'left':left,'right':right,'ranks':[ra,rb,total_rank]}
        if lam==0:zeros.append(item)
        if lam==1 and min(len(left),len(right))>=2:ones.append(item)
    return {'connected':not zeros,'zero_separation_count':len(zeros),
            'proper_lambda1_count':len(ones),'proper_lambda1_partitions':ones}

def antipodal_representatives(points):
    result=[]
    for p in points:
        first=next(x for x in p if x)
        if first>0:result.append(p)
    assert len(result)*2==len(points)
    assert all(tuple(-x for x in p) in points for p in points)
    return result

def main():
    P=[tuple(map(F,v)) for v in V0+ [tuple(-x for x in v) for v in V0]]
    assert rank(V0)==4
    N,tested,independent=enumerate_polar(P)
    facets=[frozenset(i for i,p in enumerate(P) if dot(p,n)==1) for n in N]
    assert all(rank([N[j] for j,f in enumerate(facets) if i in f])==4 for i in range(len(P)))
    dual_facets=[frozenset(j for j,f in enumerate(facets) if i in f) for i in range(len(P))]
    ps,qs=stats(P,facets),stats(N,dual_facets)
    vol,tets=volume_pulling(P,facets);vp,dtets=volume_pulling(N,dual_facets)
    # rank-3 side B is H_(x,y) x [-1,1]_z. The common axis is x, NOT z.
    A=V0[:3];B=V0[3:]
    assert rank(A)==2 and rank(B)==3
    assert rank(A)+rank(B)-rank(A+B)==1
    # B_t = [-(2-|t|),2-|t|] x [-1,1], |t|<=1.
    # Ratios at 0 and 1/2 are unequal, even allowing arbitrary linear maps
    # on the transverse space; homothety is invariant under one common GL(2).
    section0=[(-2,-1),(-2,1),(2,-1),(2,1)]
    sectionhalf=[(F(-3,2),-1),(F(-3,2),1),(F(3,2),-1),(F(3,2),1)]
    assert F(3,2)/2 != F(1)
    Bpoints=sorted(set(tuple(F(p[k]) for k in [0,2,3]) for p in P[3:9]+P[12:18]))
    Bnormals,_,_=enumerate_polar(Bpoints)
    expected_B_normals={(F(s),F(0),F(0)) for s in [-1,1]}
    expected_B_normals|={(F(s,2),F(t,2),F(0)) for s,t in itertools.product([-1,1],repeat=2)}
    expected_B_normals|={(F(0),F(0),F(s)) for s in [-1,1]}
    assert set(Bnormals)==expected_B_normals
    Bfacet_sizes=[sum(dot(n,p)==1 for p in Bpoints) for n in Bnormals]
    assert sorted(Bfacet_sizes)==[4]*6+[6]*2
    vertex_separations=separation_census(V0)
    normal_separations=separation_census(antipodal_representatives(N))
    assert vertex_separations['connected'] and normal_separations['connected']
    assert vertex_separations['proper_lambda1_count']==1
    assert normal_separations['proper_lambda1_count']==0
    # Coordinatewise unconditionality is checked on all vertices.
    verts=set(P)
    unconditional=all(tuple(s*x for s,x in zip(sign,p)) in verts for p in P for sign in itertools.product([-1,1],repeat=4))
    assert unconditional and ps['facet_condition_pass'] and qs['facet_condition_pass']
    assert min(ps['nonsimplicial_facets_per_vertex'])>=3
    assert min(qs['nonsimplicial_facets_per_vertex'])>=3
    assert (vol,vp,vol*vp)==(F(40,3),F(23,24),F(115,9))
    record={'status':'PASS','scope':'fresh exact audit; NOT a proof of the 4D conjecture',
       'positive_vertices':V0,'polar_vertices':[[str(x) for x in n] for n in N],
       'facet_supports':[sorted(f) for f in facets],
       'polar_enumeration_tested':tested,'polar_enumeration_independent':independent,
       'primal':ps,'polar':qs,'primal_volume':str(vol),'polar_volume':str(vp),
       'Mahler_product':str(vol*vp),'Mahler_margin':str(vol*vp-F(32,3)),
       'primal_pulling_tetrahedra':tets,'polar_pulling_tetrahedra':dtets,
       'vertex_matroid':vertex_separations,'normal_matroid':normal_separations,
       'B_exact_facet_normals':[[str(x) for x in n] for n in Bnormals],
       'B_facet_vertex_counts':Bfacet_sizes,
       'separator_rank_profile':[2,3,4],'common_line':[1,0,0,0],
       'B_exact_H_description':'|x|<=1, |y|<=2-|x|, |z|<=1; suppressed coordinate t=0',
       'B_section_0':[[str(x) for x in p] for p in section0],
       'B_section_half':[[str(x) for x in p] for p in sectionhalf],
       'homothetic_sections_along_common_axis':False,'unconditional':True,
       'refuted_implication':'lambda1 + both incidence tests => homothetic rank3 transverse sections',
       'theorem_boundary':'Passing the incidence tests is not proof of local minimality.'}
    (ROOT/'matched_wall_audit.json').write_text(json.dumps(record,indent=2))
    print(json.dumps({k:record[k] for k in ['status','primal_volume','polar_volume','Mahler_product','Mahler_margin','homothetic_sections_along_common_axis','unconditional']},indent=2))
    print('primal',ps);print('polar',qs)
if __name__=='__main__':main()
