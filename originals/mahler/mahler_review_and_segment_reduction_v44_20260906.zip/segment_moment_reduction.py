#!/usr/bin/env python3
"""Exact 3D-to-4D segment-gluing formulas and endpoint certificates.
All hull computations use exhaustive rational linear algebra. No random sampling.
The general contact-endpoint Mahler inequality is NOT asserted or proved.
"""
import itertools,json
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
from exact_audit import solve,dot,rank,all_faces
ROOT=Path(__file__).resolve().parent

def polar_vertices(points):
    d=len(points[0]); out=set()
    for ids in itertools.combinations(range(len(points)),d):
        n=solve([points[i] for i in ids],[1]*d)
        if n is not None and all(dot(n,p)<=1 for p in points):out.add(n)
    return sorted(out)

def hull(points):
    points=sorted(set(tuple(F(x) for x in p) for p in points))
    d=len(points[0]); normals=polar_vertices(points)
    assert normals and rank(points)==d
    pts=[p for p in points if rank([n for n in normals if dot(n,p)==1])==d]
    fs=[frozenset(i for i,p in enumerate(pts) if dot(n,p)==1) for n in normals]
    assert all(len(f)>=d for f in fs)
    return pts,normals,fs

def integrals(pts,fs,first_coordinate=False):
    d=len(pts[0]); faces=all_faces(fs,len(pts))
    dims={f:(-1 if not f else rank([[pts[i][k]-pts[min(f)][k] for k in range(d)] for i in f])) for f in faces}
    cache={}
    def tri(f):
        if f in cache:return cache[f]
        if len(f)==dims[f]+1:return [tuple(sorted(f))]
        a=min(f)
        sub=sorted((g for g in faces if g<f and dims[g]==dims[f]-1 and a not in g),key=lambda g:tuple(sorted(g)))
        ts=[tuple([a]+list(t)) for g in sub for t in tri(g)]
        cache[f]=ts;return ts
    simplices=[t for f in fs for t in tri(f)]
    from collections import Counter
    ridges=Counter(tuple(sorted(u)) for t in simplices for u in itertools.combinations(t,d-1))
    assert set(ridges.values())=={2}
    vol=F(0);moment=F(0)
    for ids in simplices:
        det=abs(F(sp.Matrix([pts[i] for i in ids]).det()))
        v=det/F(sp.factorial(d));vol+=v
        if first_coordinate:moment+=v*sum(pts[i][0] for i in ids)/(d+1)
    return vol,moment,len(simplices)

def abs_moment(poly,facets,normals):
    # Clip the centrally symmetric 3D polar by t>=0 using all exact edges.
    faces=all_faces(facets,len(poly)); edges=[tuple(f) for f in faces if len(f)==2]
    new={p for p in poly if p[0]>=0}
    for i,j in edges:
        p,q=poly[i],poly[j]
        if p[0]*q[0]<0:
            a=-p[0]/(q[0]-p[0]);new.add(tuple(p[k]+a*(q[k]-p[k]) for k in range(3)))
    pts=sorted(new)
    fs=[]
    for n in normals:
        f=frozenset(i for i,p in enumerate(pts) if dot(n,p)==1)
        if len(f)>=3 and rank([[pts[i][k]-pts[min(f)][k] for k in range(3)] for i in f])==2:fs.append(f)
    fs.append(frozenset(i for i,p in enumerate(pts) if p[0]==0))
    vol,mom,nt=integrals(pts,fs,True)
    return 2*mom,2*vol

def test(name,C):
    C,N,fac=hull(C)
    dual_fs=[frozenset(j for j,n in enumerate(N) if dot(n,p)==1) for p in C]
    V=integrals(C,fac)[0]; W=integrals(N,dual_fs)[0]
    proj,_,pf=hull([p[1:] for p in C]);A=integrals(proj,pf)[0]
    I,Wcheck=abs_moment(N,dual_fs,C);assert Wcheck==W
    rho=1/max(p[0] for p in N)
    a=sp.Symbol('a',nonnegative=True)
    formula=sp.expand((srat(V)+2*a*srat(A)/3)*(srat(W)-a*srat(I)))
    records=[]
    for b in [F(0),rho/2,rho]:
        Q=[(F(0),)+p for p in C]+[(x,t,F(0),F(0)) for x in [F(-1),F(1)] for t in [-b,b]]
        qp,qn,qf=hull(Q)
        qdf=[frozenset(j for j,n in enumerate(qn) if dot(n,p)==1) for p in qp]
        qv=integrals(qp,qf)[0];qw=integrals(qn,qdf)[0]
        assert qv==V/2+b*A/3,(name,b,qv,V,A)
        assert qw==2*(W-b*I),(name,b,qw,W,I)
        assert qv*qw==F(formula.subs(a,srat(b)))
        records.append({'a':str(b),'vertices':len(qp),'facets':len(qn),
           'volume':str(qv),'polar_volume':str(qw),'product':str(qv*qw)})
    endpoints=[F(formula.subs(a,0)),F(formula.subs(a,srat(rho)))]
    assert min(endpoints)>=F(32,3)
    return {'name':name,'C_vertices':[[str(x) for x in p] for p in C],
       'C_volume':str(V),'C_polar_volume':str(W),'projection_area':str(A),
       'polar_absolute_first_moment':str(I),'contact_radius':str(rho),
       'Mahler_polynomial':str(formula),'second_derivative':str(sp.diff(formula,a,2)),
       'endpoints':list(map(str,endpoints)),
       'certified_entire_interval':f'0<=a<={rho}',
       'entire_interval_lower_bound':str(min(endpoints)),
       'independent_4D_reconstructions':records}

def srat(x):return sp.Rational(x.numerator,x.denominator)

def main():
    V,W,A,I,a=sp.symbols('V W A I a', positive=True)
    x=sp.symbols('x',nonnegative=True)
    qv=sp.integrate(2*((1-x)**3*V+2*a*x*(1-x)**2*A),(x,0,1))
    assert sp.expand(qv-(V/2+a*A/3))==0
    M=sp.expand(qv*2*(W-a*I))
    assert sp.diff(M,a,2)==-4*A*I/3
    cube=list(itertools.product([-1,1],repeat=3))
    cross=[tuple(s if i==j else 0 for i in range(3)) for j in range(3) for s in [-1,1]]
    hp=[(1,1),(1,-1),(0,-2),(-1,-1),(-1,1),(0,2)]
    prism=[(p[0],p[1],z) for p in hp for z in [-1,1]]
    reps=[(2,0,0),(1,2,0),(0,1,2),(-1,1,1),(0,-1,2)]
    oblique=reps+[tuple(-x for x in p) for p in reps]
    rec=[test('cube',cube),test('cross_polytope',cross),test('hexagonal_prism',prism),test('oblique_rational_C',oblique)]
    # Euclidean ball is an analytic calibration, not a polytope reconstruction.
    ball=sp.expand((4*sp.pi/3+2*a*sp.pi/3)*(4*sp.pi/3-a*sp.pi/2))
    assert sp.factor(ball.subs(a,1))==5*sp.pi**2/3
    relative=sp.factor(ball.subs(a,1)/(16*sp.pi**2/9));assert relative==sp.Rational(15,16)
    out={'status':'PASS','general_identity':'M(Q_a)=(V+2a*A/3)(W-a*I)',
      'general_second_derivative':'-4*A*I/3 < 0',
      'new_reduction':'minimum on 0<=a<=rho_C(e) is at a=0 or a=rho_C(e)',
      'general_contact_endpoint_inequality':'NOT PROVED',
      'historical_checkpoint_rebuilt':False,'full_four_dimensional_conjecture_proved':False,
      'four_fixed_body_families':rec,
      'ball_calibration':{'M_contact':str(ball.subs(a,1)),
            'M_contact_divided_by_M_C':str(relative),
            'refuted_shortcut':'M(Q_contact)>=M(C) is false'},
      'scope':'Identities are analytic; finite exact cases do not prove the contact inequality for arbitrary C.'}
    (ROOT/'segment_moment_certificate.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
