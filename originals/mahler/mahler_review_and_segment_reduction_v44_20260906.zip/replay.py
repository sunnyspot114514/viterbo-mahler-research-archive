#!/usr/bin/env python3
"""Replay only the new v44 audit, not the historical proof-candidate chain."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument('--rebuild',action='store_true')
    args=parser.parse_args()
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for name,entry in manifest['files'].items():
        path=ROOT/name
        if not path.is_file() or path.stat().st_size!=entry['bytes'] or sha(path)!=entry['sha256']:
            raise RuntimeError(f'Integrity mismatch: {name}')
    rebuilt=[]
    if args.rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v44_fresh_') as tmp:
            stage=Path(tmp)
            for name in ['exact_audit.py','segment_moment_reduction.py']:
                shutil.copy2(ROOT/name,stage/name)
            for script,certificate in [('exact_audit.py','matched_wall_audit.json'),
                                       ('segment_moment_reduction.py','segment_moment_certificate.json')]:
                result=subprocess.run([sys.executable,script],cwd=stage,capture_output=True,text=True,timeout=240)
                if result.returncode:
                    raise RuntimeError(f'{script} failed:\n{result.stdout[-3000:]}\n{result.stderr[-3000:]}')
                if sha(stage/certificate)!=sha(ROOT/certificate):
                    raise RuntimeError(f'Rebuilt certificate differs: {certificate}')
                rebuilt.append(script)
    audit=json.loads((ROOT/'matched_wall_audit.json').read_text())
    moment=json.loads((ROOT/'segment_moment_certificate.json').read_text())
    assert audit['status']==moment['status']=='PASS'
    assert audit['homothetic_sections_along_common_axis'] is False
    assert audit['primal']['facet_condition_pass'] and audit['polar']['facet_condition_pass']
    assert audit['Mahler_product']=='115/9'
    assert audit['vertex_matroid']['proper_lambda1_count']==1
    assert moment['general_contact_endpoint_inequality']=='NOT PROVED'
    records=moment['four_fixed_body_families']
    assert len(records)==4
    count=sum(len(case['independent_4D_reconstructions']) for case in records)
    assert count==12
    out={
        'status':'PASS',
        'rebuild':args.rebuild,
        'files_integrity_checked':len(manifest['files']),
        'fresh_scripts_rebuilt':rebuilt,
        'inherited_history_rebuilt':False,
        'both_incidence_tests_imply_homothety':'REFUTED by the exact matched-wall polytope',
        'matched_wall_combinatorics':'18V/22F',
        'matched_wall_Mahler_product':'115/9',
        'matched_wall_unconditional':audit['unconditional'],
        'segment_gluing_formula':'M(Q_a)=(V+2a*A/3)(W-a*I)',
        'segment_gluing_second_derivative':'-4*A*I/3',
        'fixed_C_full_parameter_families_checked':4,
        'independent_exact_4D_reconstructions':count,
        'general_contact_endpoint_inequality_proved':False,
        'full_4D_conjecture_proved':False,
        'scope':'Fresh finite exact audit plus a written general Fubini/polarity identity. No proof of arbitrary contact endpoints or of all lambda=1 bodies.'
    }
    (ROOT/'replay_output.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
