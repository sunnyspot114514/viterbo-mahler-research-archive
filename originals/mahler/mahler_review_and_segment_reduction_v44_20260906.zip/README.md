# Mahler review and segment-gluing reduction, 2026-09-06

Read `report_zh.md` for the mathematical statements, assumptions and open gaps.

```bash
python -m pip install -r requirements.txt
python replay.py --rebuild
```

`--rebuild` reruns both exact scripts in a temporary clean directory, then compares
their two JSON outputs with the archived certificates. Without that flag the
driver checks hashes and certificate semantics only. This is NOT a recursive
rebuild of historical v1–v43 files, NOT a proof of the general contact-endpoint
inequality, and NOT a solution of the full four-dimensional conjecture.

All finite geometric calculations use exact rational arithmetic and exhaustive
support enumeration. General convex-body identities are justified by the written
Fubini/polarity proof, not by the finite examples alone.
