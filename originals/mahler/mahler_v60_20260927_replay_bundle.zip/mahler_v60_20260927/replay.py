#!/usr/bin/env python3
"""Integrity check plus clean deterministic rebuild of the v60 certificates."""
from __future__ import annotations
import argparse,hashlib,json,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def integrity(root,manifest):
    total=0
    for rel,rec in manifest['files'].items():
        p=root/rel
        if not p.is_file() or p.stat().st_size!=rec['bytes'] or sha(p)!=rec['sha256']:
            raise AssertionError(('integrity mismatch',rel))
        total+=rec['bytes']
    return total

def run(script,*args):
    out=subprocess.run([sys.executable,str(script),*args],cwd=script.parent,
                       capture_output=True,text=True,timeout=600)
    if out.returncode:
        raise RuntimeError(f'{script.name}: {out.stdout}\n{out.stderr}')
    return out.stdout.strip()

def main(rebuild):
    manifest=json.loads((ROOT/'manifest.json').read_text())
    assert manifest['version']=='v60'
    checked=integrity(ROOT,manifest)
    rebuilt=[];baseline=None
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v60_replay_') as td:
            fresh=Path(td)/'new';fresh.mkdir()
            for rel in manifest['files']:
                dest=fresh/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/rel,dest)
            for script,name in [('analytic_verifier.py','analytic_certificate.json'),
                                ('geometry_verifier.py','geometry_certificate.json')]:
                expected=(fresh/name).read_bytes();(fresh/name).unlink()
                log=run(fresh/script,'--output',str(fresh/name))
                assert (fresh/name).read_bytes()==expected,('certificate mismatch',name)
                rebuilt.append({'certificate':name,'sha256':sha(fresh/name),'stdout':log})
            base=Path(td)/'old'
            with zipfile.ZipFile(fresh/'baseline_inputs/v59.zip') as z:
                for item in z.infolist():
                    dest=(base/item.filename).resolve()
                    if base.resolve() not in dest.parents:raise ValueError('Unsafe archive path')
                z.extractall(base)
            base=base/'mahler_v59_20260927'
            old_manifest=json.loads((base/'manifest.json').read_text())
            integrity(base,old_manifest)
            dest=Path(td)/'v59_analytic_regenerated.json'
            oldlog=run(base/'analytic_verifier.py','--output',str(dest))
            assert dest.read_bytes()==(base/'analytic_certificate.json').read_bytes()
            baseline={'version':'v59','files_checked':len(old_manifest['files']),
                      'analytic_recomputed_and_byte_equal':True,'geometry_recomputed':False,
                      'analytic_sha256':sha(dest),'stdout':oldlog}
    a=json.loads((ROOT/'analytic_certificate.json').read_text())
    g=json.loads((ROOT/'geometry_certificate.json').read_text())
    assert a['status']==g['status']=='PASS'
    assert a['main_rational_path']['segment_count']==12
    assert g['counts']['total_independent_pairs']==39
    assert g['diagonal_completion'][-1]['Mahler']=='32/3'
    result={'status':'PASS','rebuild':rebuild,'files_checked':len(manifest['files']),
            'bytes_checked':checked,'new_certificates':rebuilt,'baseline':baseline,
            'new_finite_geometry_pairs':39,'rational_complete_path_segments':13,
            'full_4D_Mahler_proved':False,'arbitrary_terminal_reduction_proved':False,
            'analytic_proof_formalized':False,'old_geometry_or_earlier_history_rebuilt':False}
    (ROOT/'replay_output.json').write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--rebuild',action='store_true');args=ap.parse_args();main(args.rebuild)
