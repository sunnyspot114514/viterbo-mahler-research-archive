# v60: non-bridging cube extensions

This snapshot contains a written proof candidate for a geometrically restricted
family in every dimension n >= 2, and a complete rational four-dimensional
example descending in 13 pieces to the cube.

It does **not** prove unrestricted Mahler or a classification of every terminal.
The input condition is the pair of inequalities (C) in `report_zh.md`; it cannot
be removed. A violating input is independently reconstructed as a countercheck.

## Rebuild

Python 3.11 or later is intended; the recorded execution used Python 3.13.5 and
SymPy 1.14.0. Only the latter execution is reported as tested.

```sh
python -m pip install -r requirements.txt
python replay.py --rebuild
```

`--rebuild` copies the payload to a clean temporary directory, deletes and
regenerates both v60 certificates, compares their bytes with the archived
certificates, then extracts the exact v59 baseline and independently regenerates
its analytic certificate. It does not rerun old geometry or any earlier history.

`python replay.py` checks integrity and a few certificate consistency conditions
only. It does not perform the mathematical computations again.

## Files

- `report_zh.md`: definitions, proofs, applicability limits and counterchecks.
- `cube_extension.py`: exact paired-coordinate saturation, rational when all
  required square roots are rational; it rejects other inputs rather than
  converting them to floating point.
- `analytic_verifier.py`: rebuilds the algebra, derivatives and rational paths.
- `geometry_verifier.py`: 39 independent rational primal/polar reconstructions;
  three additional reverse H-to-V checks and a complete symmetry invariant.
- `exact_geometry.py`: unchanged rational geometry utility inherited from v59.
- `baseline_inputs/v59.zip`: exact baseline, including its analytic verifier.
- `manifest.json`: hashes of proof text, sources and certificates.

The continuous geometry and general-dimension argument are written mathematical
proofs, not formal proofs checked by a proof assistant. The n=2,...,8 polynomial
checks are finite calibrations; they are not misrepresented as verification over
all dimensions. No external four-dimensional Mahler theorem is assumed.
