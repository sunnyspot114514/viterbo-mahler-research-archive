#!/usr/bin/env python3
"""Recompute dimension-independent algebra and exact rational path assertions."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from itertools import combinations
from math import prod
from fractions import Fraction as F
import sympy as s
from cube_extension import *
from exact_geometry import jsonable
ROOT=Path(__file__).resolve().parent


def verify():
    a,b,u,v,t,A,B=s.symbols('a b u v t A B', positive=True)
    c=a*b
    dp=(1-u)*(1-v)-c;dm=(1+u)*(1+v)-c
    assert s.expand((1+u)*dp+(1-u)*dm-2*(1-u*u-c))==0
    assert s.expand((1+v)*dp+(1-v)*dm-2*(1-v*v-c))==0
    # Supporting one pyramid side against the other apex.
    ni=(1-u)/(1+a-u);nj=a/(1+a-u)
    assert s.factor(1-(ni*v+nj*(1+b))-dp/(1+a-u))==0
    # Independent sum over either coordinate sign of a polar cap simplex.
    q,y=s.symbols('q y',positive=True)
    assert s.factor(1/(q-y)+1/(q+y)-2*q/(q*q-y*y))==0
    # The two simultaneous boundary coordinates.
    U=1-a*t/(1-t);V=1-b*(1-t)/t
    assert s.factor((1-U)*(1-V)-a*b)==0
    assert s.factor((1+U)*(1+V)-a*b-2*(U+V))==0
    assert s.factor(s.diff(U+V,t,2)+2*a/(1-t)**3+2*b/t**3)==0
    f1=(1-t)**2/(a*(a+2-2*(a+1)*t))
    f2=t**2/(b*(2*(b+1)*t-b))
    assert s.factor(f1-1/((1+a)**2-U**2))==0
    assert s.factor(f2-1/((1+b)**2-V**2))==0
    d1=a+2-2*(a+1)*t;d2=2*(b+1)*t-b
    assert s.factor(s.diff(f1,t,2)-2*a/d1**3)==0
    assert s.factor(s.diff(f2,t,2)-2*b/d2**3)==0
    rad=s.symbols('rad',positive=True)
    endpoint_checks=[]
    for sign in (-1,1):
        te=(1+sign*rad)/(a+1+sign*rad)
        assert s.factor((U+sign*rad).subs(t,te))==0
        assert s.factor((V-sign*rad).subs({t:te,b:(1-rad**2)/a}))==0
        endpoint_checks.append(str(te))
    # General-n remainder expansion is proved in the report for all n.
    # These are finite independent algebraic calibrations, not an n-cutoff proof.
    nchecks=[]
    for n in range(2,9):
        Y=s.symbols('Y');cc=s.symbols(f'c0:{n-1}')
        rem=sum(Y**(n-1-r)*sum(prod(comb) for comb in combinations(cc,r))
                for r in range(2,n))
        assert s.expand(prod(Y+j for j in cc)-(Y+sum(cc))*Y**(n-2)-rem)==0
        nchecks.append({'n':n,'remainder_terms':len(s.Poly(rem,Y,*cc).terms()) if rem else 0})
    xx=s.symbols('x0:4');S=sum(xx)
    e2=sum(xx[i]*xx[j] for i,j in combinations(range(4),2))
    e3=sum(prod(xx[i] for i in inds) for inds in combinations(range(4),3))
    G=4+3*S+2*e2+e3
    for i in range(4):
        Di=prod(2+xx[i]+xx[j] for j in range(4) if j!=i)
        assert s.expand(Di-(4+S)*(1+xx[i])**2-G)==0
    # Direct straight-line motion to a skew endpoint need not descend.
    xx0=[F(3,5)]*4;yy=[[F(0)]*4 for _ in range(4)]
    yy[0][1]=yy[1][0]=F(1,5)
    w=s.symbols('w');us=F(1,5)+w*F(3,5);vs=F(1,5)-w
    coeff=cap_coefficient(xx0,yy,0,1)
    cap=s.Rational(coeff.numerator,coeff.denominator)*(1/(s.Rational(8,5)**2-us**2)+1/(s.Rational(8,5)**2-vs**2))
    md=s.factor(-s.Rational(2,3)*s.Rational(128,5)*s.diff(cap,w).subs(w,0))
    assert md>0
    x0,y0=fixed_example();path=execute_saturation(x0,y0)
    assert path['segment_count']==12
    start=volumes(x0,y0);end=volumes(x0,path['states'][-1])
    assert end[2]==F(208,15)
    # Append a rationally parametrized equal-height E44 descent.
    r=s.symbols('r',positive=True)
    xa=(1-r*r)/(1+r*r)
    Mdiag=s.Rational(16,3)*(2+xa)
    assert s.factor(s.diff(Mdiag,r)+64*r/(3*(1+r*r)**2))==0
    assert Mdiag.subs(r,s.Rational(1,2))==s.Rational(208,15)
    assert Mdiag.subs(r,1)==s.Rational(32,3)
    # Active-boundary cases k=0,1,2,3, plus c=1 collapsed pair.
    boundary_paths=[]
    for k in range(5):
        x=[F(3,5) if i<k else F(0) for i in range(4)]
        y=[[F(0) if i==j else F(((3*i+5*j)%7)-3,20) for j in range(4)] for i in range(4)]
        p=execute_saturation(x,y)
        boundary_paths.append({'k':k,'segments':p['segment_count'],'before':volumes(x,y)[2],
                               'after':volumes(x,p['states'][-1])[2]})
    xc=[F(1),F(1),F(0),F(0)];yc=[[F(0)]*4 for _ in range(4)]
    pc=execute_saturation(xc,yc)
    assert pc['segment_count']==4
    return {'status':'PASS','date':'2026-09-27','dimension_free_bound_identity':nchecks,
            'pair_slack_certificates':True,'boundary_second_derivatives':[str(2*a/d1**3),str(2*b/d2**3)],
            'boundary_endpoint_parameters':endpoint_checks,
            'failed_direct_straight_saturation_M_derivative':str(md),
            'main_rational_path':path,'initial_volumes':start,'saturated_volumes':end,
            'diagonal_completion':{'parameter_interval':['1/2','1'],'M':str(Mdiag),'endpoint':'32/3'},
            'active_boundary_tests':boundary_paths,'collapsed_pair_segments':pc['segment_count'],
            'scope':{'whole_stated_nonbridging_class_all_n_ge_2':'written proof candidate',
                     'finite_4D_saturation_segments_at_most_12':True,
                     '4D_total_segments_at_most_16':'uses v59 completion',
                     'arbitrary_cube_extensions':False,'all_terminals':False,'full_Mahler':False,
                     'analytic_proof_formalized':False}}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'analytic_certificate.json'));args=ap.parse_args()
    cert=jsonable(verify());Path(args.output).write_text(json.dumps(cert,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':cert['status'],'new_segments':len(cert['main_rational_path']['segments']),
                      'completion_segments':1,'all_dimension_checks':len(cert['dimension_free_bound_identity'])}))
