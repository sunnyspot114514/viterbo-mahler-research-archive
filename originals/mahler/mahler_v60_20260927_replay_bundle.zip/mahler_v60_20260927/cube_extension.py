"""Exact operations for non-bridging centrally symmetric cube extensions.

Any dimension n >= 2; one active antipodal apex pair per selected cube facet pair.
Rational path execution is implemented when pair saturation square roots are
rational. The report proves the real-parameter construction separately.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations, product
from math import isqrt, prod, factorial
from copy import deepcopy


def square_root(q: F) -> F:
    q=F(q)
    if q < 0: raise ValueError('Negative radicand')
    a,b=isqrt(q.numerator),isqrt(q.denominator)
    if a*a!=q.numerator or b*b!=q.denominator:
        raise ValueError('This exact rational executor requires rational square roots')
    return F(a,b)


def validate(x,y):
    n=len(x)
    if n<2 or len(y)!=n or any(len(row)!=n for row in y):
        raise ValueError('Expected square coordinate data in dimension n >= 2')
    assert all(a>=0 for a in x)
    active=[i for i,a in enumerate(x) if a>0]
    for i in active:
        assert all(abs(y[i][j])<=1 for j in range(len(x)) if i!=j)
    slacks=[]
    for i,j in combinations(active,2):
        u,v=y[i][j],y[j][i];c=x[i]*x[j]
        ds=[(1-e*u)*(1-e*v)-c for e in (1,-1)]
        assert min(ds)>=0,(i,j,ds)
        assert u*u+c<=1 and v*v+c<=1
        slacks.append([i,j,*ds])
    return slacks


def cap_terms(x,y):
    return [a**len(x)*(1+a)**(len(x)-2)/prod((1+a)**2-y[i][j]**2 for j in range(len(x)) if j!=i)
            if a else F(0) for i,a in enumerate(x)]


def volumes(x,y):
    validate(x,y)
    n=len(x)
    primal=F(2**n)*(1+sum(x)/n)
    polar=F(2**n,factorial(n))*(1-sum(cap_terms(x,y)))
    assert primal>0 and polar>0
    return primal,polar,primal*polar


def cloud(x,y):
    pts=set(product((F(-1),F(1)), repeat=len(x)))
    for i,a in enumerate(x):
        if not a: continue
        q=tuple(1+a if j==i else F(y[i][j]) for j in range(len(x)))
        pts.add(q);pts.add(tuple(-w for w in q))
    return sorted(pts)


def predicted_normals(x,y):
    """All pyramid side facets and unchanged cube facets; duplicates removed."""
    out=set()
    for j,a in enumerate(x):
        if not a:
            for e in (-1,1):
                n=[F(0)]*len(x);n[j]=F(e);out.add(tuple(n))
    for i,a in enumerate(x):
        if not a:continue
        for j in range(len(x)):
            if i==j:continue
            for si,sj in product((-1,1),repeat=2):
                u=si*sj*y[i][j];den=1+a-u
                n=[F(0)]*len(x)
                n[i]=si*(1-u)/den;n[j]=sj*a/den
                out.add(tuple(n))
    return sorted(out)


def cap_coefficient(x,y,i,j):
    a=x[i]
    return a**len(x)*(1+a)**(len(x)-2)/prod((1+a)**2-y[i][k]**2 for k in range(len(x)) if k not in (i,j))


def boundary_point(a,b,t,sign=1):
    return (sign*(1-a*t/(1-t)),sign*(1-b*(1-t)/t))


def boundary_cap_derivative(a,b,A,B,t):
    d1=a+2-2*(a+1)*t;d2=2*(b+1)*t-b
    assert d1>0 and d2>0
    f1=(-2*(1-t)*d1+2*(a+1)*(1-t)**2)/(a*d1*d1)
    f2=(2*t*d2-2*(b+1)*t*t)/(b*d2*d2)
    return A*f1+B*f2


def execute_saturation(x,y):
    """At most (n-1)*k exact monotone segments; each leaves all x fixed."""
    x=list(map(F,x));y=[list(map(F,row)) for row in y];validate(x,y)
    states=[deepcopy(y)];segments=[]
    def append(new,rec):
        before=deepcopy(y);validate(x,new)
        oldv=volumes(x,before);newv=volumes(x,new)
        assert oldv[0]==newv[0]
        assert newv[2]<oldv[2],(rec,oldv,newv)
        rec.update({'start':before,'end':deepcopy(new),
                    'M_start':oldv[2],'M_end':newv[2]})
        segments.append(rec);y[:]=deepcopy(new);states.append(deepcopy(y))
    active=[i for i,a in enumerate(x) if a]
    for i,j in combinations(active,2):
        a,b=x[i],x[j];c=a*b;rad=square_root(1-c)
        u,v=y[i][j],y[j][i]
        if u*u==1-c and v==-u:continue
        ds=[(1-e*u)*(1-e*v)-c for e in (1,-1)]
        if min(ds)>0:
            lo=c/(1+v)-1;hi=1-c/(1-v)
            target=hi if u>=0 else lo
            assert lo<u<hi and (target>=u>=0 or target<=u<0)
            new=deepcopy(y);new[i][j]=target
            mid=deepcopy(y);mid[i][j]=(u+target)/2
            assert volumes(x,new)[2]<volumes(x,mid)[2]<volumes(x,y)[2]
            append(new,{'kind':'straight_to_pair_boundary','pair':[i,j],
                        'coordinate_interval':[lo,hi],'midpoint':mid})
            u,v=y[i][j],y[j][i]
        if u*u==1-c and v==-u:continue
        sign=1 if (1-u)*(1-v)==c else -1
        assert (1-sign*u)*(1-sign*v)==c
        t0=(1-sign*u)/(a+1-sign*u)
        lo=(1-rad)/(a+1-rad);hi=(1+rad)/(a+1+rad)
        assert lo<t0<hi
        A=cap_coefficient(x,y,i,j);B=cap_coefficient(x,y,j,i)
        der=boundary_cap_derivative(a,b,A,B,t0)
        target=hi if der>=0 else lo
        new=deepcopy(y);new[i][j],new[j][i]=boundary_point(a,b,target,sign)
        mid=deepcopy(y);mid[i][j],mid[j][i]=boundary_point(a,b,(t0+target)/2,sign)
        validate(x,mid)
        assert volumes(x,new)[2]<volumes(x,mid)[2]<volumes(x,y)[2]
        append(new,{'kind':'curved_pair_boundary','pair':[i,j],'sign':sign,
                    't_start':t0,'t_end':target,'t_interval':[lo,hi],
                    'cap_derivative_start':der,'positive_weights':[A,B],
                    'midpoint':mid})
        assert y[i][j]==-y[j][i] and y[i][j]**2==1-c
    for i in active:
        for j in range(len(x)):
            if i==j or x[j]:continue
            u=y[i][j]
            if abs(u)==1:continue
            new=deepcopy(y);new[i][j]=F(1 if u>=0 else -1)
            mid=deepcopy(y);mid[i][j]=(u+new[i][j])/2
            assert volumes(x,new)[2]<volumes(x,mid)[2]<volumes(x,y)[2]
            append(new,{'kind':'inactive_coordinate_saturation','pair':[i,j],
                        'midpoint':mid})
    assert len(segments)<=(len(x)-1)*len(active)
    for i in active:
        for j in range(len(x)):
            if i!=j:assert y[i][j]**2==1-x[i]*x[j]
    return {'x':x,'states':states,'segments':segments,'segment_count':len(segments)}


def fixed_example():
    x=[F(3,5)]*4
    vals=[[0,4,-3,2],[1,0,5,-2],[-2,3,0,1],[3,-1,4,0]]
    y=[[F(v,20) for v in row] for row in vals]
    return x,y
