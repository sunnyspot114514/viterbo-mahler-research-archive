#!/usr/bin/env python3
"""Independent rational hull, polar, volume and incidence reconstruction."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
import sympy as sp
from cube_extension import *
from exact_geometry import central_pair,hpoly,volume_moment,dot,rank,jsonable
ROOT=Path(__file__).resolve().parent


def reconstruct(x,y,label,reverse=False):
    pts=cloud(x,y);P,K=central_pair(pts)
    # Boundedness is independent: the input includes the full cube.
    assert K['vertices']==predicted_normals(x,y)
    V,_,vs=volume_moment(P);W,_,ws=volume_moment(K)
    assert (V,W,V*W)==volumes(x,y)
    I=sum(len(f) for f in P['facets'])
    rec={'label':label,'x':x,'y':y,'vertices':len(P['vertices']),'facets':len(K['vertices']),
         'primal_volume':V,'polar_volume':W,'Mahler':V*W,'incidences':I,
         'polar_vertices':K['vertices'],'primal_vertices':P['vertices'],
         'H_to_V_bases':K['bases_enumerated'],'primal_triangulation':vs,'polar_triangulation':ws}
    if reverse:
        again=hpoly([(v,F(1)) for v in K['vertices']],len(x))
        assert again['vertices']==P['vertices']
        assert volume_moment(again)[0]==V
        rec['independent_reverse_H_to_V_bases']=again['bases_enumerated']
    return rec


def verify():
    x,y=fixed_example();path=execute_saturation(x,y)
    states=[];midpoints=[]
    for i,yy in enumerate(path['states']):
        rec=reconstruct(x,yy,f'state_{i}',reverse=(i in (0,12)))
        assert rec['vertices']==24 and rec['facets']==48-2*i
        rec['incidence_potential']=(rec['vertices']+rec['facets'])*(24*48+1)+rec['vertices']*rec['facets']-rec['incidences']
        if states:
            assert rec['Mahler']<states[-1]['Mahler']
            assert rec['incidence_potential']<states[-1]['incidence_potential']
        states.append(rec)
    for i,seg in enumerate(path['segments']):
        rec=reconstruct(x,seg['midpoint'],f'midpoint_{i}')
        assert states[i+1]['Mahler']<rec['Mahler']<states[i]['Mahler']
        assert rec['facets']==states[i]['facets']
        midpoints.append(rec)
    # Complete from the skew boundary to the cube with an explicitly rational arc.
    saturated=path['states'][-1];finish=[]
    for r in [F(3,5),F(4,5),F(1)]:
        xx=[(1-r*r)/(1+r*r)]*4;q=2*r/(1+r*r)
        yy=[[F(0) if i==j else (q if saturated[i][j]>0 else -q) for j in range(4)] for i in range(4)]
        rec=reconstruct(xx,yy,f'diagonal_r_{r}',reverse=(r==1))
        assert rec['Mahler']==F(16,3)*(2+xx[0])
        finish.append(rec)
    assert finish[-1]['primal_volume']==16 and finish[-1]['polar_volume']==F(2,3)
    assert finish[-1]['Mahler']==F(32,3)
    # A complete certificate for absence of additional linear symmetries of the input.
    vv=[sp.Matrix(v) for v in states[0]['primal_vertices']]
    cov=sum((v*v.T for v in vv),sp.zeros(4));iv=cov.inv()
    reps=[v for v in vv if next(c for c in v if c)!=0 and next(c for c in v if c)>0]
    gram=sp.Matrix(len(reps),len(reps),lambda i,j:(reps[i].T*iv*reps[j])[0])
    assert len({gram[i,i] for i in range(len(reps))})==12
    assert all(gram[i,j]!=0 for i in range(len(reps)) for j in range(i))
    symmetry={'vertex_pair_count':12,'distinct_diagonal_invariants':[str(gram[i,i]) for i in range(12)],
              'Gram_matrix':[[str(gram[i,j]) for j in range(12)] for i in range(12)],
              'linear_automorphism_group':['I','-I']}
    # Active-coordinate boundaries and dimensions 2,3.
    other=[]
    for k in [1,2,3]:
        xx=[F(3,5) if i<k else F(0) for i in range(4)]
        yy=[[F(0) if i==j else F(((3*i+5*j)%7)-3,20) for j in range(4)] for i in range(4)]
        pp=execute_saturation(xx,yy)
        for stage,yyy in [('initial',yy),('saturated',pp['states'][-1])]:
            other.append(reconstruct(xx,yyy,f'k_{k}_{stage}'))
    for n in [2,3]:
        xx=[F(3,5)]*n
        yy=[[F(0) if i==j else F(((i+3*j)%5)-2,20) for j in range(n)] for i in range(n)]
        pp=execute_saturation(xx,yy)
        for stage,yyy in [('initial',yy),('saturated',pp['states'][-1])]:
            rec=reconstruct(xx,yyy,f'dimension_{n}_{stage}')
            assert rec['Mahler']>=F(4**n,factorial(n))
            other.append(rec)
    # Counterexample to removing the pair feasibility assumption, not to Mahler.
    xb=[F(2),F(2),F(0),F(0)];yb=[[F(0)]*4 for _ in range(4)]
    pb,kb=central_pair(cloud(xb,yb));VB=volume_moment(pb)[0];WB=volume_moment(kb)[0]
    additive_primal=F(32);wrong_polar=F(2,3)*(1-sum(cap_terms(xb,yb)))
    assert VB>additive_primal and WB>wrong_polar
    bridge=(F(3,2),F(3,2),F(0),F(0))
    assert all(dot(bridge,n)<=1 for n in kb['vertices'])
    outside={'x':xb,'y':yb,'violated_pair_slacks':[-3,-3],
             'bridge_point':bridge,'actual_primal':VB,'false_additive_primal':additive_primal,
             'actual_polar':WB,'false_cap_subtraction_polar':wrong_polar,
             'actual_Mahler':VB*WB,'actual_VF':[len(pb['vertices']),len(kb['vertices'])]}
    return {'status':'PASS','main_states':states,'main_midpoints':midpoints,
            'diagonal_completion':finish,'input_symmetry_certificate':symmetry,
            'boundary_and_low_dimension_checks':other,'excluded_overlap_example':outside,
            'counts':{'main_state_pairs':len(states),'main_midpoint_pairs':len(midpoints),
                      'completion_pairs':len(finish),'other_pairs':len(other),'excluded_pair':1,
                      'total_independent_pairs':len(states)+len(midpoints)+len(finish)+len(other)+1,
                      'reverse_H_to_V_checks':3},
            'scope_warning':'Finite rational checks support the written nonbridging-class proof; no arbitrary-polytope reduction is claimed.'}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'geometry_certificate.json'));args=ap.parse_args()
    cert=jsonable(verify());Path(args.output).write_text(json.dumps(cert,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':cert['status'],**cert['counts'],'initial_M':cert['main_states'][0]['Mahler'],
                      'endpoint_M':cert['diagonal_completion'][-1]['Mahler']}))
