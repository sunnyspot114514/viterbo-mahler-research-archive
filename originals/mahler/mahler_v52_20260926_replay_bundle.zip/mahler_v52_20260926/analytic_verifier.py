#!/usr/bin/env python3
"""Exact finite algebra for v52. Does not formalize the analytic theorems.

Checks a continuum of exponents by polynomial positivity certificates, not by
sampling exponents. New transcendental comparisons use rational enclosures.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import sympy as S


def rational_atan_bounds(x: F, n: int = 32) -> tuple[F, F]:
    terms = [(-1)**k*x**(2*k+1)/F(2*k+1) for k in range(n)]
    value = sum(terms, F(0))
    next_value = value+(-1)**n*x**(2*n+1)/F(2*n+1)
    return min(value,next_value),max(value,next_value)


def pi_bounds() -> tuple[F,F]:
    a,b=rational_atan_bounds(F(1,5))
    c,d=rational_atan_bounds(F(1,239))
    return 16*a-4*d,16*b-4*c


def jdump(obj):
    if isinstance(obj,(F,S.Rational)): return str(obj)
    if isinstance(obj,dict):return {str(k):jdump(v) for k,v in obj.items()}
    if isinstance(obj,(list,tuple)):return [jdump(v) for v in obj]
    return obj


def bernstein(poly, x, lo, hi):
    z=S.symbols('z')
    pp=S.Poly(S.expand(poly.subs(x,lo+(hi-lo)*z)),z)
    n=pp.degree()
    mon=[pp.nth(i) for i in range(n+1)]
    return [S.factor(sum(mon[k]*S.binomial(j,k)/S.binomial(n,k)
                          for k in range(j+1))) for j in range(n+1)]


def run(output: Path):
    s,t,b,a,rho,q,lam = S.symbols('s t b a rho q lam',positive=True)
    band=b+(a-b)*s**2/t**2
    tail=a*(1-s)**2/(1-t)**2
    H=S.factor(S.integrate(band,(s,0,t))+S.integrate(tail,(s,t,1)))
    L=S.factor(S.integrate((1-s)*band,(s,0,t))+
               S.integrate((1-s)*tail,(s,t,1)))
    assert S.factor(H-(a+2*t*b)/3)==0
    assert S.factor(L-(b*(8*t-3*t**2)+a*(3-2*t))/12)==0
    sigma=1/(2*q-1)
    coefficient=S.factor(8*(2*q+1)/(3*(q+2))*L.subs({t:sigma,b:1,a:rho}))
    expected=2*(2*q+1)*((16*q-11)+(12*q**2-16*q+5)*rho)/(9*(q+2)*(2*q-1)**2)
    assert S.factor(coefficient-expected)==0
    assert S.factor(coefficient.subs(q,2)-35*(1+rho)/54)==0
    assert S.factor(coefficient.subs(q,1)-2*(5+rho)/9)==0
    assert S.factor(S.limit(coefficient,q,S.oo)-4*rho/3)==0
    # A continuum q>=1, rho>=7/8 (ellipse case).
    P=24*q**3-340*q**2+1386*q-947
    assert S.factor(coefficient.subs(rho,S.Rational(7,8))-S.Rational(8,7)
                    -P/(252*(q+2)*(2*q-1)**2))==0
    intervals=[(1,3),(3,5),(5,6),(6,7)]
    bcert=[]
    for left,right in intervals:
        cc=bernstein(P,q,S.Integer(left),S.Integer(right))
        assert all(v>0 for v in cc)
        bcert.append({'interval':[left,right],'coefficients':cc})
    x=S.symbols('x',nonnegative=True)
    tailP=S.Poly(S.expand(P.subs(q,x+7)),x)
    assert all(c>0 for c in tailP.all_coeffs())
    # Near-ellipse case: use an absolute area bound a>=0.87*pi, NOT a/b>=0.87.
    N=252*q**3-2260*q**2+9687*q-6710
    assert S.factor(coefficient.subs(rho,S.Rational(87,100))-S.Rational(9,8)
                    -N/(1800*(q+2)*(2*q-1)**2))==0
    assert S.expand(N.subs(q,x+1)-x*(252*x*x-1504*x+5923)-969)==0
    assert S.discriminant(252*x*x-1504*x+5923,x)==-3708368
    # Finite algebra underlying the general radial and perspective argument.
    rr,ss,alpha,beta=S.symbols('r s alpha beta',positive=True)
    ar,apr=S.symbols('ar apr')
    Fprime=-(1-ss)/rr**2+ss*(q-1)*rr**(q-2)-ss*(rr*apr-ar)/rr**2
    assert S.simplify(rr**2*Fprime-(-(1-ss)+ss*(q-1)*rr**q-ss*(rr*apr-ar)))==0
    # Uniform derivative bound is -1+(2q-1)*s at r<=1 and |R|<=(q-1)r^q.
    rupper=S.factor((rr**2*Fprime).subs(apr,(ar-(q-1)*rr**q)/rr))
    assert S.factor(rupper-(-(1-ss)+2*ss*(q-1)*rr**q))==0
    # The non-power profile criterion in terms of I and terminal slope k.
    I,k=S.symbols('I k',positive=True)
    sigma_k=1/(2*k-1)
    profile=S.factor(8*(I+S.Rational(1,6))*L.subs({t:sigma_k,b:1,a:rho}))
    assert S.factor(profile.subs({k:q,I:q/(2*(q+2))})-coefficient)==0
    # A non-power smooth radial profile: phi=1-(r^2+r^4)/2.
    z=S.symbols('z', nonnegative=True)
    phi=1-(z**2+z**4)/2
    mixed_I=S.integrate(z*phi,(z,0,1))
    mixed_k=-S.diff(phi,z).subs(z,1)
    assert mixed_I==S.Rational(7,24) and mixed_k==3
    mixed_ellipse=S.factor(profile.subs({k:mixed_k,I:mixed_I,rho:S.Rational(7,8)}))
    mixed_near=S.factor(profile.subs({k:mixed_k,I:mixed_I,rho:S.Rational(87,100)})
                        /S.Rational(101,100)**2)
    assert mixed_ellipse==S.Rational(8261,7200)
    assert mixed_near==S.Rational(102905,91809)
    # New non-elliptic gauge example, epsilon=1/100.
    eps=S.Rational(1,100)
    matrices=[]
    for sx in (-1,1):
        for sy in (-1,1):
            base=2*S.Matrix([[1+eps,eps*sx*sy],[eps*sx*sy,1+eps]])
            for sign in (-1,1):
                matrix=base+sign*S.diag(2*sx,0)
                assert matrix[0,0]>=0 and matrix[1,1]>=0 and matrix.det()>=0
                matrices.append({'x_sign':sx,'y_sign':sy,'midpoint_sign':sign,
                                 'determinant':matrix.det(),'diagonal':[matrix[0,0],matrix[1,1]]})
    assert 1+2*eps<S.Rational(101,100)**2
    # Axis jump of the gradient of p^2: 4*epsilon*|other coordinate|>=0.
    # m=x|x| has continuous first derivative. These are the analytic gluing conditions.
    # Purely rational transcendental enclosures. Machin identity is an analytic input.
    pl,pu=pi_bounds()
    sl=F(1732050807568877293,10**18)
    su=F(1732050807568877294,10**18)
    assert sl*sl<3<su*su
    assert F(3141592653589793238,10**18)<pl<pu<F(3141592653589793239,10**18)
    ellipse_lower=F(8,7)*pl**2
    assert ellipse_lower>F(32,3)
    kap=F(101,100)
    absolute_area_lower=2*kap**2*(1-su/pl)-4*kap*(kap-1)
    assert absolute_area_lower>F(87,100)
    near_lower=F(9,8)*pl**2/kap**2
    assert near_lower>F(32,3)
    assert F(102905,91809)*pl**2>F(32,3)
    kappa=S.symbols('kappa',positive=True)
    v=S.symbols('v',positive=True) # v denotes sqrt(3)/pi.
    area_function=2*kappa**2*(1-v)-4*kappa*(kappa-1)
    assert S.factor(S.diff(area_function,kappa)+4*((1+v)*kappa-1))==0
    # Four percent parabolic certificate, using the sharp constant-width input.
    G=35*S.pi/(54*kappa**2)*(S.pi+2*kappa**2*(S.pi-S.sqrt(3))
                                      -4*S.pi*kappa*(kappa-1))
    G4=35*S.pi*(1873*S.pi-1352*S.sqrt(3))/36504
    assert S.simplify(G.subs(kappa,S.Rational(26,25))-G4)==0
    assert S.simplify(S.diff(G,kappa)+70*S.pi**2/(27*kappa**2)+35*S.pi**2/(27*kappa**3))==0
    g4_lower=F(65555,36504)*pl**2-F(35,27)*pu*su
    assert g4_lower>F(32,3)
    # Countercheck: universal independent planar bounds do NOT close arbitrary bases.
    assert F(35,54)*(8+6)<F(32,3)
    # Lower bound from Rogers-Shephard alone at q=2, disk, remains too small.
    assert F(175,162)*pu**2<F(32,3)
    results={
        'version':'v52','date':'2026-09-26','status':'PASS',
        'symbolic_integrals':{'H':str(H),'L':str(L),'F_q_rho':str(coefficient),
                              'general_profile_coefficient':str(profile)},
        'ellipse_continuum_certificate':{
            'domain':'all finite real q >= 1', 'rho':'7/8', 'uniform_factor':'8/7',
            'positive_polynomial':str(P), 'bernstein_intervals':bcert,
            'q_ge_7_shift_coefficients':tailP.all_coeffs(),
            'lambda_1_lower_bound':'8*pi^2/7', 'numeric_for_display':float(8*S.pi**2/7)},
        'near_ellipse_continuum_certificate':{
            'geometric_distortion':'101/100', 'absolute_area_a_over_pi_bound':'87/100',
            'warning':'This is NOT a lower bound on a/b.',
            'shifted_polynomial':str(S.expand(N.subs(q,x+1))),
            'quadratic_discriminant':-3708368,
            'lambda_1_lower_bound':'11250*pi^2/10201',
            'numeric_for_display':float(S.Rational(11250,10201)*S.pi**2)},
        'four_percent_parabolic_certificate':{
            'geometric_distortion':'26/25','q':2,
            'lambda_1_lower_bound':str(G4),
            'numeric_for_display':float(G4),
            'strict_margin_for_display':float(G4-S.Rational(32,3))},
        'mixed_profile_certificate':{
            'phi':'1-(r^2+r^4)/2','I':'7/24','terminal_slope':'3','sigma':'1/5',
            'ellipse_lower':'8261*pi^2/7200',
            'near_ellipse_lower':'102905*pi^2/91809',
            'near_numeric_for_display':float(mixed_near*S.pi**2)},
        'constant_enclosures':{'pi_lower':pl,'pi_upper':pu,'sqrt3_lower':sl,'sqrt3_upper':su,
                              'near_absolute_area_lower':absolute_area_lower,
                              'ellipse_gap_lower':ellipse_lower-F(32,3),
                              'near_gap_lower':near_lower-F(32,3),
                              'four_percent_gap_lower':g4_lower-F(32,3)},
        'nonelliptic_example':{'p_squared':'x^2+y^2+(|x|+|y|)^2/100',
                              'm_at_q_2':'x*|x|','hessian_checks':matrices,
                              'axis_gradient_jump':'4*epsilon*|other coordinate| >= 0',
                              'upper_squared_distortion':'51/50 < (101/100)^2'},
        'scope':{
            'checks':'finite exact algebra, polynomial positivity, and rational enclosures',
            'analytic_theorems_formalized':False,'external_peer_review':False,
            'general_CE_proved':False,'full_4D_symmetric_Mahler_proved':False,
            'all_bases_covered':False,'older_proof_history_rebuilt':False}}
    output.write_text(json.dumps(jdump(results),ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('v52 analytic finite checks PASS',flush=True)
    print('Ellipse all-q lower:',results['ellipse_continuum_certificate']['numeric_for_display'])
    print('Near-ellipse all-q lower:',results['near_ellipse_continuum_certificate']['numeric_for_display'])
    print('Parabolic 4% lower:',results['four_percent_parabolic_certificate']['numeric_for_display'])

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',type=Path,default=Path(__file__).with_name('analytic_certificate.json'))
    run(ap.parse_args().output)
