#!/usr/bin/env python3
"""Reconstruct v52 finite certificates in a fresh directory, never old history."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
CERTIFICATES=(('analytic_verifier.py','analytic_certificate.json'),
              ('geometry_verifier.py','geometry_certificate.json'))

def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def integrity(root: Path) -> dict:
    manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
    check(manifest.get('version')=='v52','Unexpected snapshot version')
    for rel,rec in manifest['files'].items():
        p=root/rel
        check(p.resolve().is_relative_to(root.resolve()),'Invalid manifest path')
        check(p.is_file(),f'Missing file {rel}')
        check(p.stat().st_size==rec['bytes'],f'Byte count differs: {rel}')
        check(digest(p)==rec['sha256'],f'SHA-256 differs: {rel}')
    return manifest

def semantics(root: Path) -> dict:
    a=json.loads((root/'analytic_certificate.json').read_text())
    g=json.loads((root/'geometry_certificate.json').read_text())
    for rec in (a,g):
        check(rec['version']=='v52' and rec['status']=='PASS','Certificate status mismatch')
    check(a['ellipse_continuum_certificate']['domain']=='all finite real q >= 1','Exponent domain mismatch')
    check(a['near_ellipse_continuum_certificate']['geometric_distortion']=='101/100','Near-ellipse factor mismatch')
    check(a['four_percent_parabolic_certificate']['geometric_distortion']=='26/25','Parabolic factor mismatch')
    check(a['mixed_profile_certificate']['near_ellipse_lower']=='102905*pi^2/91809','Mixed profile missing')
    check(len(a['nonelliptic_example']['hessian_checks'])==8,'Hessian count mismatch')
    check(g['exact_3D_pairs']==g['exact_4D_pairs']==4,'Geometry pair count mismatch')
    check(g['exact_slices']==27,'Slice count mismatch')
    check(len(g['near_round_planar_examples'])==4,'Planar example count mismatch')
    check(sum(bool(x['is_actual_power_profile_body']) for x in g['band_models'])==1,
          'Interface models must not be promoted to power-profile examples')
    for key in ('general_CE_proved','all_bases_covered'):
        check(a['scope'][key] is False and g[key] is False,'Scope overclaim: '+key)
    check(a['scope']['full_4D_symmetric_Mahler_proved'] is False and
          g['full_4D_Mahler_proved'] is False,'Full conjecture scope overclaim')
    return {'exact_3D_pairs':4,'exact_4D_pairs':4,'exact_slices':27,
            'near_round_planar_examples':4,'quadrant_Hessian_checks':8,
            'continuum_exponent_positivity':'exact polynomial certificates, not sampling',
            'general_CE_proved':False,'all_bases_covered':False,
            'full_4D_symmetric_Mahler_proved':False}

def main(rebuild: bool) -> None:
    if sys.flags.optimize:
        raise RuntimeError('Run without -O; assertion-based finite checks are required.')
    manifest=integrity(ROOT)
    expected={name:(ROOT/name).read_bytes() for _,name in CERTIFICATES}
    log=[]
    if rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v52_clean_') as temp:
            fresh=Path(temp)
            for rel in manifest['files']:
                dest=fresh/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/rel,dest)
            shutil.copy2(ROOT/'manifest.json',fresh/'manifest.json')
            integrity(fresh)
            for script,out in CERTIFICATES:
                (fresh/out).unlink()
                proc=subprocess.run([sys.executable,str(fresh/script),'--output',str(fresh/out)],
                                    cwd=fresh,capture_output=True,text=True,timeout=600)
                log.append(f'=== {script} ===\n{proc.stdout}{proc.stderr}')
                check(proc.returncode==0,f'{script} failed:\n{proc.stdout}\n{proc.stderr}')
                check((fresh/out).read_bytes()==expected[out],f'Fresh certificate differs: {out}')
            integrity(fresh)
            semantics(fresh)
        (ROOT/'clean_rebuild.log').write_text('\n'.join(log)+'\n',encoding='utf-8')
    integrity(ROOT)
    result={'version':'v52','date':'2026-09-26','status':'PASS','rebuild':rebuild,
            'files_integrity_checked':len(manifest['files']),
            'bytes_integrity_checked':sum(v['bytes'] for v in manifest['files'].values()),
            'new_certificates_regenerated_and_byte_compared':2 if rebuild else 0,
            'old_v1_v51_verifiers_rerun':False,
            'analytic_theorems_formalized':False,'external_peer_review':False,
            **semantics(ROOT)}
    (ROOT/'replay_output.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--rebuild',action='store_true',help='Actually reconstruct both new certificates in a fresh directory')
    main(ap.parse_args().rebuild)
