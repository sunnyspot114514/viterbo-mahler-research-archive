#!/usr/bin/env python3
"""Exact finite checks for the variable-height band and near-circular area lemma.

Only the sigma=1 model is identified with an actual power-profile body (q=1).
Other 3D/4D objects are integration-interface models, not samples of smooth
power-profile bodies. The near-circle polygon checks do not assert midpoint
extendibility. All hull and volume operations use rational arithmetic.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
from exact_geometry import (hull2,area2,central_pair,hpoly,volume_moment,jsonable)
from analytic_verifier import pi_bounds


def neg(p):return tuple(-v for v in p)

def minkowski(A,B,a=F(1),b=F(1)):
    return hull2([(a*x[0]+b*y[0],a*x[1]+b*y[1]) for x in A for y in B])

def inside(A,p):
    return all((y[0]-x[0])*(p[1]-x[1])-(y[1]-x[1])*(p[0]-x[0])>=0
               for x,y in zip(A,A[1:]+A[:1]))

def polar2(A):
    A=hull2(A);ans=[]
    for u,v in zip(A,A[1:]+A[:1]):
        det=u[0]*v[1]-u[1]*v[0]
        assert det>0
        ans.append(((v[1]-u[1])/det,(u[0]-v[0])/det))
    ans=hull2(ans)
    assert all(x[0]*y[0]+x[1]*y[1]<=1 for x in A for y in ans)
    return ans


def band_model(q):
    sigma=1/(2*q-1)
    A0=hull2([(F(2),F(0)),(F(-1),F(1)),(F(-1),F(-1))])
    B=minkowski(A0,[neg(a) for a in A0],F(1,2),F(1,2))
    eta=min(F(1),2*sigma)
    A=minkowski(B,A0,1-eta,eta)
    assert all(inside(A,tuple((1-sigma)*v for v in x)) for x in B)
    diff=minkowski(A,[neg(a) for a in A],F(1,2),F(1,2))
    assert set(diff)==set(B)
    a,b=area2(A),area2(B)
    D=polar2(B);d=area2(D)
    points=[(sigma,)+x for x in A]
    points += [neg(x) for x in points]
    points += [(F(1),F(0),F(0)),(F(-1),F(0),F(0))]
    K,C=central_pair(points)
    W,_,_=volume_moment(K)
    V,_,_=volume_moment(C)
    plus=hpoly([(n,F(1)) for n in C['vertices']]+[((F(-1),F(0),F(0)),F(0))],3)
    vp,mp,_=volume_moment(plus,0)
    J=2*mp
    H=(a+2*sigma*b)/3
    L=(b*(8*sigma-3*sigma*sigma)+a*(3-2*sigma))/12
    assert vp*2==W and W==2*H and J==2*(H-L)
    heights=[F(0),sigma/4,sigma/2,3*sigma/4,sigma]
    if sigma<1:heights +=[(1+sigma)/2,(3+sigma)/4]
    else:heights=heights[:-1]+[F(7,8),F(1)]
    checks=[]
    for s in heights:
        actual=hpoly([(n[1:],1-n[0]*s) for n in C['vertices']],2)
        av,_,_=volume_moment(actual)
        if s<=sigma:
            predicted=minkowski(B,A,1-s/sigma,s/sigma)
            area=b+(a-b)*s*s/(sigma*sigma)
        else:
            factor=(1-s)/(1-sigma)
            predicted=hull2([tuple(factor*v for v in a) for a in A])
            area=a*(1-s)**2/(1-sigma)**2
        assert set(actual['vertices'])==set(predicted)
        assert av==area
        checks.append({'height':s,'area':av,'vertices':len(predicted),'all_vertices_match':True})
    assert set(hull2([x[1:] for x in C['vertices']]))==set(D)
    cloud=[(F(0),)+x for x in C['vertices']]
    cloud += [(F(eps),F(sign),F(0),F(0)) for eps in (-1,1) for sign in (-1,1)]
    Q,Qp=central_pair(cloud)
    vq,_,tq=volume_moment(Q);wq,_,tqp=volume_moment(Qp)
    assert vq==V/2+d/3 and wq==2*(W-J)
    assert vq*wq==(V+2*d/3)*(W-J)
    if q==1:
        assert V==2*d/3
        assert vq*wq==2*d*(5*b+a)/9
    return {'nominal_exponent':q,'sigma':sigma,'midpoint_blend':eta,
            'is_actual_power_profile_body':q==1,
            'model_warning':'For sigma<1 the model tests band/tail integration only.',
            'area_A':a,'area_B':b,'area_D':d,
            'C_vertices':len(C['vertices']),'C_facets':len(C['facets']),
            'volume_C':V,'volume_K':W,'absolute_first_moment_K':J,
            'H':H,'L':L,'slices':checks,
            'Q_vertices':len(Q['vertices']),'Q_facets':len(Q['facets']),
            'volume_Q':vq,'volume_Q_polar':wq,'M_Q':vq*wq,
            'Q_boundary_simplices':tq['boundary_simplices'],
            'Q_polar_boundary_simplices':tqp['boundary_simplices']}


def rational_circle(n=16):
    points=[]
    for k in range(n+1):
        t=F(k,n)
        x=(1-t*t)/(1+t*t);y=2*t/(1+t*t)
        for sx in (-1,1):
            for sy in (-1,1):points.append((sx*x,sy*y))
    return hull2(points)


def near_round_example(mode):
    R=F(1003,1000)
    points=[tuple(R*v for v in p) for p in rational_circle()]
    extra=[(R+F(1,500),F(0)),(F(0),R+F(1,1000)),
           (-R-F(1,2000),F(0))]
    A=hull2(points+extra[:mode])
    B=minkowski(A,[neg(x) for x in A],F(1,2),F(1,2))
    kappa=F(101,100)
    max_sq=max(x*x+y*y for x,y in B)
    assert max_sq<=kappa*kappa
    distances=[]
    for u,v in zip(B,B[1:]+B[:1]):
        nx=v[1]-u[1];ny=u[0]-v[0]
        c=nx*u[0]+ny*u[1]
        assert c>0 and c*c>=nx*nx+ny*ny
        distances.append(c*c/(nx*nx+ny*ny))
    D=polar2(B)
    a,b,d=area2(A),area2(B),area2(D)
    pl,pu=pi_bounds()
    sqrt3lo=F(1732050807568877293,10**18)
    area_rhs_upper=2*kappa*(2-kappa)*pu-2*kappa*kappa*sqrt3lo
    assert a>area_rhs_upper
    assert b>pu and d>pu/(kappa*kappa)
    assert a>F(87,100)*pu
    return {'mode':mode,'A_vertices':len(A),'B_vertices':len(B),
            'D_vertices':len(D),'area_A':a,'area_B':b,'area_D':d,
            'maximum_B_vertex_squared_norm':max_sq,
            'minimum_B_facet_squared_distance':min(distances),
            'disk_in_B_in_101_over_100_disk':True,
            'completion_area_bound_checked':True,
            'warning':'Abstract planar section calibration only; no claim of legal midpoint extension.'}


def run(output):
    models=[]
    for q in [F(1),F(3,2),F(3),F(7)]:
        r=band_model(q);models.append(r)
        print(f'band q={q}, sigma={r["sigma"]}: {r["Q_vertices"]}V/{r["Q_facets"]}F PASS',flush=True)
    near=[]
    for mode in range(4):
        r=near_round_example(mode);near.append(r)
        print(f'near-round planar mode={mode}: {r["A_vertices"]}/{r["B_vertices"]} vertices PASS',flush=True)
    T=hull2([(F(2),F(0)),(F(-1),F(1)),(F(-1),F(-1))])
    B=minkowski(T,[neg(t) for t in T],F(1,2),F(1,2));D=polar2(B)
    mu=area2(D)*area2(B);nu=area2(D)*area2(T)
    assert mu==9 and nu==6
    naive=F(35,54)*(mu+nu)
    assert naive==F(175,18)<F(32,3)
    res={'version':'v52','date':'2026-09-26','status':'PASS',
         'band_models':models,'near_round_planar_examples':near,
         'exact_3D_pairs':len(models),'exact_4D_pairs':len(models),
         'exact_slices':sum(len(x['slices']) for x in models),
         'abstract_triangle_obstruction':{'mu':mu,'nu':nu,'old_band_bound':naive,
                 'not_a_CE_counterexample':True,
                 'parabolic_midpoint_extendibility_not_claimed':True},
         'analytic_theorems_formalized':False,
         'all_bases_covered':False,'general_CE_proved':False,'full_4D_Mahler_proved':False}
    output.write_text(json.dumps(jsonable(res),ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('v52 geometry finite checks PASS',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',type=Path,default=Path(__file__).with_name('geometry_certificate.json'))
    run(ap.parse_args().output)
