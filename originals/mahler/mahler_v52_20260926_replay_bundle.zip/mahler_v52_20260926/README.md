# Mahler contact-body research snapshot v52

Date: 2026-09-26. Main proof candidate: `report_zh.md` (Chinese).

## Main scope

For the specified contact direction and half-chord `1-g_D^q`, all finite real
`q>=1` and all legal continuous odd midpoint functions are treated when the
origin-symmetric planar base is elliptic or lies in an explicit 1% linear
elliptic sandwich. For the parabolic exponent `q=2`, the sufficient sandwich
factor extends to `26/25`. A mixed radial profile is also covered.

The proofs use a polar equatorial band, mixed area, Fourier analysis,
constant-width completion, and an explicit deduction of the added planar area.
They are written analytic proof candidates, not externally reviewed or
machine-formalized theorems. Neither general CE nor the full four-dimensional
symmetric Mahler conjecture is proved here. No priority claim is made.

## Reproduce

Python 3.11 or later (the actual tested environment is in `provenance.json`).

```bash
python -m pip install -r requirements.txt
python replay.py --rebuild
```

Do not use `python -O`: the finite verification scripts deliberately use
assertions. The replay driver rejects optimized Python and also performs its
own explicit integrity checks.

`python replay.py` checks hashes and stored certificate semantics only.
`--rebuild` copies the complete manifest payload into a fresh temporary folder,
regenerates both certificates by actually executing the two verification
scripts, and compares the results byte-for-byte with the archived certificates.
It writes `replay_output.json` and, when rebuilding, `clean_rebuild.log`.

## Files and finite coverage

- `analytic_verifier.py`: exact symbolic integrals; whole-real-parameter
  positivity certificates; rational pi/sqrt(3) enclosures; mixed profile;
  eight rational Hessian checks for a genuinely nonelliptic base example.
- `geometry_verifier.py`: four exact 3D primal/polar pairs, four independently
  reconstructed 4D contact pairs, 27 rational sections, four near-circular
  planar difference-body tests, and a failed general relaxation.
- `exact_geometry.py`: unchanged rational geometry utility from v51.
- `*_certificate.json`: the outputs that are reconstructed and byte-compared.
- `provenance.json`: hashes and the precise boundary of inherited checks.
- `manifest.json`: SHA-256 and byte counts for the replay payload. The manifest
  itself and output logs are not self-hashed.

The models for exponents other than q=1 are band/tail integration-interface
models, not claimed samples of the main power-profile theorem. The near-circle
planar bodies are not claimed to have a legal midpoint extension. The analytic
proof is what establishes the general classes, not those finite models.

The prior v51 ZIP and its ten manifest entries were integrity-checked; its
verifiers were not rerun. No v1-v51 mathematical history was recertified.
