#!/usr/bin/env python3
"""Finite exact checks accompanying v50. Not a formalization of analytic proofs.
All certificate data are rational/SymPy exact values; no numerical hull is used.
"""
from __future__ import annotations
import argparse, json
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import sympy as S
from exact_geometry import hpoly,central_pair,volume_moment,hull2,area2,jsonable

ROOT=Path(__file__).resolve().parent

def arctan_bounds(q:F,n:int=18):
    # The alternating series gives exact rational lower/upper bounds.
    terms=[(-1)**j*q**(2*j+1)/F(2*j+1) for j in range(2*n+1)]
    return sum(terms[:-1],F(0)),sum(terms,F(0))

def analytic_checks():
    k,s,x,y,lam,aa=S.symbols('k s x y lam a',real=True)
    t=1/(2-k)
    H=S.factor(S.integrate((1-k*s)**2,(s,0,t))+S.integrate(4*(1-k)*s*(1-s),(s,t,1)))
    L=S.factor(S.integrate((1-s)*(1-k*s)**2,(s,0,t))+S.integrate(4*(1-k)*s*(1-s)**2,(s,t,1)))
    H_expected=(2*k**2-6*k+5)/(3*(2-k))
    L_expected=(23-36*k+20*k**2-4*k**3)/(12*(2-k)**2)
    assert S.cancel(H-H_expected)==S.cancel(L-L_expected)==0
    assert S.cancel((1-k*t)**2-4*(1-k)*t*(1-t))==0
    # Monotonicity on [0,1]. For -L' positivity, put k=1-u:
    u=S.symbols('u', nonnegative=True)
    derivative_numerator=13-22*k+12*k**2-2*k**3
    assert S.expand(derivative_numerator.subs(k,1-u))==2*u**3+6*u**2+4*u+1
    assert S.cancel(S.diff(L,k)+derivative_numerator/(6*(2-k)**3))==0
    # H-L=integral s beta^2 ds >0. Exact endpoint/cubic interval checks.
    J=S.factor(H-L)
    endpoint=S.factor(S.Rational(10,3)*L)
    envelope_a=S.factor(2*(1+S.Rational(2,3)*aa)*(H-aa*J))
    assert S.cancel(S.diff(envelope_a,aa,2)+S.Rational(8,3)*J)==0
    assert endpoint.subs(k,S.Rational(1,3))==S.Rational(353,270)
    assert (2*H).subs(k,S.Rational(1,3))==S.Rational(58,45)
    assert endpoint.subs(k,S.Rational(3,5))==S.Rational(967,882)
    assert endpoint.subs(k,S.Rational(1,4))==S.Rational(135,98)
    assert S.factor(S.Rational(32,3)/(S.Rational(353,270)))==S.Rational(2880,353)
    # Cubic harmonic: exact curvature eigenvalue identity.
    cubic=lam*(x**3-3*x*y**2)/3
    Hess=S.hessian(cubic,(x,y))
    assert S.simplify(Hess*Hess-4*lam**2*(x*x+y*y)*S.eye(2))==S.zeros(2)
    assert S.expand((x*x+y*y)**3-(x**3-3*x*y*y)**2-(3*x*x*y-y**3)**2)==0
    harmonic_checks=[]
    for p in (3,5,7):
        z=S.expand((x+S.I*y)**p)
        for comp in (S.re(z).expand(complex=True),S.im(z).expand(complex=True)):
            comp=S.simplify(comp)
            hess=S.hessian(2*comp/S.Integer(p*(p-1)),(x,y))
            assert S.simplify(hess*hess-4*(x*x+y*y)**(p-2)*S.eye(2))==S.zeros(2)
        harmonic_checks.append({'degree':p,'two_components_checked':True})
    # A generic rational cubic, certified by a Frobenius upper bound.
    generic=x**3/6+x*x*y/12+x*y*y/10+y**3/15
    hg=S.hessian(generic,(x,y))
    rem=S.expand(4*(x*x+y*y)-sum(v*v for v in hg))
    mat=S.Matrix([[rem.coeff(x,2),rem.coeff(x,1).coeff(y,1)/2],
                  [rem.coeff(x,1).coeff(y,1)/2,rem.coeff(y,2)]])
    assert mat[0,0]>0 and mat.det()>0
    # Flat-facet polynomial rigidity: annihilation of two independent directions.
    flat=[]
    for degree in (3,5,7,9):
        powers=[(i,j) for n in range(1,degree+1,2) for i in range(n+1) for j in [n-i]]
        cs=S.symbols('c:'+str(len(powers)))
        poly=sum(c*x**i*y**j for c,(i,j) in zip(cs,powers))
        hh=S.hessian(poly,(x,y)); equations=[]
        for v in (S.Matrix([0,1]),S.Matrix([-2,1])):
            for expr in hh*v:
                equations.extend(S.Poly(expr,x,y).coeffs())
        A,_=S.linear_eq_to_matrix(equations,cs)
        rank=A.rank()
        assert rank==len(cs)-2
        flat.append({'degree':degree,'odd_coefficients':len(cs),'constraint_rank':rank,'kernel_dimension':2})
    low5,up5=arctan_bounds(F(1,5)); low239,up239=arctan_bounds(F(1,239))
    pi_lo=16*low5-4*up239;pi_hi=16*up5-4*low239
    assert F(314159,100000)<pi_lo<pi_hi<F(314160,100000)
    bounds={}
    for kval,label in [(F(1,3),'cubic_endpoint'),(F(3,5),'amplitude_3_5_endpoint'),(F(1,4),'v49_example_endpoint')]:
        coeff=F(endpoint.subs(k,S.Rational(kval.numerator,kval.denominator)))
        gap=coeff*pi_lo*pi_lo-F(32,3)
        assert gap>0
        bounds[label]={'kappa':kval,'pi_squared_coefficient':coeff,'certified_positive_gap_lower':gap}
    uniform=F(58,45)*pi_lo*pi_lo-F(32,3)
    assert uniform>0
    return {'H_formula':str(H_expected),'L_formula':str(L_expected),'J_formula':str(J),
            'beta_piece_matching':True,'L_monotone_decreasing_on_0_1':True,
            'pi_lower':pi_lo,'pi_upper':pi_hi,'explicit_bounds':bounds,
            'cubic_all_a_positive_gap_lower':uniform,
            'harmonic_Hessian_square_checks':harmonic_checks,
            'generic_cubic':str(generic),'generic_Frobenius_remainder_matrix':str(mat),
            'flat_facet_polynomial_checks':flat}

def symmetric_rows(a,b):
    return [(tuple(a),F(b)),(tuple(-v for v in a),F(b))]

def measure(points):
    P,K=central_pair(points)
    V,_,_=volume_moment(P);W,_,_=volume_moment(K)
    # Clip the polar to its positive first-coordinate half.
    hs=[(p,F(1)) for p in P['vertices']]+[((F(-1),F(0),F(0)),F(0))]
    half=hpoly(hs,3);halfvol,Jhalf,_=volume_moment(half,0)
    assert 2*halfvol==W
    D=hull2([p[1:] for p in P['vertices']]);area=area2(D)
    return P,K,V,W,2*Jhalf,area

def contact(points,a):
    cloud=[(F(0),)+tuple(p) for p in points]
    cloud += [(F(sx),F(st)*a,F(0),F(0)) for sx,st in product((-1,1),repeat=2)]
    P,K=central_pair(cloud)
    V,_,_=volume_moment(P);W,_,_=volume_moment(K)
    return {'vertices':len(P['vertices']),'polar_vertices':len(K['vertices']),
            'volume':V,'polar_volume':W,'product':V*W}

def geometry_checks():
    cube=[tuple(map(F,p)) for p in product((-1,1),repeat=3)]
    UP,UK,UV,UW,UJ,UA=measure(cube)
    UQ=contact(cube,F(1))
    assert (UV,UW,UJ,UA)==(F(8),F(4,3),F(1,3),F(4))
    assert UQ['product']==F(32,3)
    records=[]
    for alpha,beta in [(F(1),F(0)),(F(3,4),F(1,4)),(F(1,2),F(0))]:
        hs=[]
        for ax in range(3):
            n=[F(0)]*3;n[ax]=F(1);hs+=symmetric_rows(n,1)
        hs+=symmetric_rows((F(1),alpha,alpha),1+alpha)
        hs+=symmetric_rows((F(1),-beta,-beta),1+beta)
        C=hpoly(hs,3)
        P,K,V,W,J,area=measure(C['vertices'])
        assert area==F(4)
        assert V==8-(alpha+beta)/3
        assert all(max(abs(v) for v in p)<=1 for p in P['vertices'])
        def midpoint(z):
            lower=[]; upper=[]
            for normal,bound in hs:
                residual=bound-sum(normal[j+1]*z[j] for j in range(2))
                if normal[0]>0:upper.append(residual/normal[0])
                elif normal[0]<0:lower.append(residual/normal[0])
                else:assert residual>=0
            lo=max(lower); hi=min(upper);assert lo<=hi
            return (lo+hi)/2
        rec={'alpha':alpha,'beta':beta,'C_vertices':len(P['vertices']),
             'C_facets':len(K['vertices']),'C_volume':V,'polar_volume':W,'absolute_moment':J,
             'projection_area':area,'midpoint_at_1_1':midpoint((F(1),F(1))),
             'midpoint_at_1_0':midpoint((F(1),F(0))),'midpoint_at_0_1':midpoint((F(0),F(1)))}
        assert rec['midpoint_at_1_1']==(beta-alpha)/2!=0
        assert rec['midpoint_at_1_0']==rec['midpoint_at_0_1']==0
        CQ=contact(P['vertices'],F(1))
        assert CQ['volume']==V/2+area/3
        assert CQ['polar_volume']==2*(W-J)
        lower=CQ['volume']/UQ['volume']*UQ['product']
        assert CQ['product']>=lower
        rec.update({'Q':CQ,'outer_Q':UQ,'inclusion_lower_bound':lower,
                    'inclusion_positive_slack':CQ['product']-lower,
                    'original_vertices':P['vertices'],'polar_vertices':K['vertices']})
        records.append(rec)
    return {'three_dimensional_pairs_rebuilt':4,'four_dimensional_pairs_rebuilt':4,
            'absolute_moment_halfspace_clips':4,'records':records,
            'warning':'These polytope tests check the general inclusion comparator and contact formulas, not the smooth family by sampling.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'certificate.json'));args=ap.parse_args()
    out={'version':'v50','status':'PASS','analytic_finite_checks':analytic_checks(),'exact_geometry_checks':geometry_checks(),
         'general_CE_proved':False,'full_4D_Mahler_proved':False,'v1_v49_rebuilt':False,
         'scope':'Finite symbolic and rational checks only; analytic claims require the written proofs, not these flags.'}
    Path(args.output).write_text(json.dumps(jsonable(out),ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'version':'v50','status':'PASS','3D_pairs':4,'4D_pairs':4,
       'flat_facet_systems':4,'general_CE_proved':False,'full_4D_Mahler_proved':False},indent=2))
if __name__=='__main__':main()
