# Mahler contact-envelope v50 (2026-09-25)

Read `report_zh.md` for the mathematical assumptions, proofs and limitations.

The new analytic results concern an outer-envelope comparison and parabolic
half-chord profiles with explicitly bounded, potentially nonhomogeneous odd
midpoints. The general contact-endpoint inequality (CE), all lambda=1 gluings,
and the full four-dimensional centrally symmetric Mahler conjecture are not
proved by this package.

## Reproduction

Requires Python 3.11+ and the SymPy version pinned below.

```bash
python -m pip install -r requirements.txt
python replay.py --rebuild
```

The default `python replay.py` checks file hashes and semantic fields.
`--rebuild` additionally copies the inputs to a fresh temporary directory,
runs the finite verifier, and byte-compares its regenerated certificate.

The finite checks comprise symbolic integrals and Hessian identities, rational
pi intervals, four polynomial constraint ranks, four exhaustive rational 3D
primal/polar reconstructions with moment clipping, and four independent 4D
primal/polar reconstructions. They do not formalize the written analytic
proofs. The polytope calculations check the general inclusion interface, not
a sampled surrogate proof of the smooth family.

`exact_geometry.py` is inherited unchanged from v49; its SHA-256 and the source
archive's SHA-256 are recorded in `provenance.json`. No v1–v49 proof or enumeration
was replayed here. The archived log reports the actual clean v50 rebuild.
