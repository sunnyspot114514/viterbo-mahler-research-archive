#!/usr/bin/env python3
"""Check the v50 files, optionally regenerate the finite certificate in a clean tree."""
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def integrity():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    assert manifest['version']=='v50'
    for rel,rec in manifest['files'].items():
        p=ROOT/rel
        assert p.is_file(),rel
        assert p.stat().st_size==rec['bytes'],rel
        assert digest(p)==rec['sha256'],rel
    return manifest

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--rebuild',action='store_true');args=ap.parse_args()
    manifest=integrity()
    cert_path=ROOT/'certificate.json';archived=cert_path.read_bytes()
    if args.rebuild:
        with tempfile.TemporaryDirectory(prefix='mahler_v50_') as td:
            fresh=Path(td)
            for rel in manifest['files']:
                dst=fresh/rel;dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ROOT/rel,dst)
            generated=fresh/'fresh_certificate.json'
            out=subprocess.run([sys.executable,str(fresh/'envelope_verifier.py'),'--output',str(generated)],
                cwd=fresh,capture_output=True,text=True,timeout=180)
            if out.returncode:
                raise RuntimeError(out.stdout+'\n'+out.stderr)
            assert generated.read_bytes()==archived,'Regenerated certificate differs'
    c=json.loads(archived)
    assert c['status']=='PASS' and c['version']=='v50'
    assert c['exact_geometry_checks']['three_dimensional_pairs_rebuilt']==4
    assert c['exact_geometry_checks']['four_dimensional_pairs_rebuilt']==4
    assert c['general_CE_proved'] is False
    assert c['full_4D_Mahler_proved'] is False
    assert c['v1_v49_rebuilt'] is False
    integrity()
    print(json.dumps({'status':'PASS','version':'v50','files_integrity_checked':len(manifest['files']),
        'clean_rebuild':args.rebuild,'certificate_byte_equal':args.rebuild,
        'general_CE_proved':False,'full_4D_Mahler_proved':False,'historical_rebuild':False,
        'certificate_sha256':digest(cert_path)},indent=2))
if __name__=='__main__':main()
