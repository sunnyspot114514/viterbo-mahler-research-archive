# Local multiplicity-four obstruction for the 4D bounded-12 Mahler program

## Scope

This note records one exact local reduction used in the branch

\[
12V/18F,\qquad c=0,\qquad D=11.
\]

Here the nine antipodal facet pairs consist of seven single-defect rows and two double-defect rows.  The lemma below excludes the single-direction multiplicity profile

\[
(4,1,1,1)
\]

before the two double-defect rows are used.

The accompanying verifier

`viterbo_d11_m4_local_verifier.py`

uses only integer arithmetic and `fractions.Fraction`.

---

## 1. Gale setup

Fix the direction carrying four single-defect rows and call it direction \(0\).  Write the six planar Gale vectors as

\[
g_0,g_1,\ldots,g_5\in\mathbb R^2.
\]

After projective row normalization, the four cube-edge sign patterns form a four-element subset of

\[
\{\pm1\}^5/\{\pm1\}.
\]

Normalize the fifth sign to \(+1\), leaving 16 projective sign vectors.  If the four sign rows form the matrix \(S\in\{\pm1\}^{4\times5}\), then

\[
S h=0,
\qquad
h_k=\det(g_0,g_k).
\]

The signed permutation group \(B_5\) acts on these configurations.

---

## 2. Exact finite classification

The verifier checks all

\[
\binom{16}{4}=1820
\]

four-subsets.

Their exact rank distribution is

\[
1720\text{ of rank }4,
\qquad
100\text{ of rank }3.
\]

### Rank-three subsets

The 100 rank-three subsets form exactly two \(B_5\)-orbits:

\[
(0,1,2,3)\quad\text{of size }40,
\]

\[
(0,1,6,7)\quad\text{of size }60.
\]

After coordinate switching their kernel types may be written as

\[
\text{A}:\quad h=(0,0,p,q,-p-q),
\]

and

\[
\text{B}:\quad h=(0,-p,p,-q,q).
\]

### Rank-four subsets

For every rank-four subset, the primitive cofactor kernel has one of only three absolute patterns:

\[
(0,0,0,1,1)\quad(1160\text{ subsets}),
\]

\[
(0,1,1,1,1)\quad(480\text{ subsets}),
\]

\[
(1,1,1,1,2)\quad(80\text{ subsets}).
\]

The strict second-coordinate Gale equation admits singleton rows in three further coordinate directions only for the first pattern.  Those 1160 subsets form exactly four signed-permutation orbits, of sizes

\[
160,\ 480,\ 480,\ 40.
\]

---

## 3. Rank-four case loses a primal vertex pair

For the only rank-four pattern compatible with three additional singleton directions,

\[
h\sim(0,0,0,1,1).
\]

Thus one row of the two-dimensional Gale matrix is supported on only two primal columns.  Since the two nonzero coefficients have equal absolute value, the corresponding kernel relation is

\[
v_i=\pm v_j.
\]

The two nominal antipodal vertex pairs therefore coincide.  The polytope has at most ten distinct vertices, not twelve.  Hence no genuine bounded-12 realization occurs in the rank-four case.

---

## 4. Rank-three orbit A

Switch coordinates so the four repeated sign rows are

\[
(\varepsilon_1,\varepsilon_2,1,1,1),
\qquad
\varepsilon_1,\varepsilon_2\in\{\pm1\}.
\]

Put

\[
g_0=(1,0),
\qquad
g_k=(\alpha_k,h_k),
\qquad
T=\alpha_3+\alpha_4+\alpha_5.
\]

The four repeated edge intersections are strict only if

\[
\max_{\varepsilon_1,\varepsilon_2}
|T+\varepsilon_1\alpha_1+\varepsilon_2\alpha_2|<1,
\]

or equivalently

\[
|T|+|\alpha_1|+|\alpha_2|<1. \tag{A1}
\]

For a genuine 12-vertex realization, \(p,q,p+q\neq0\); otherwise the second Gale relation has support at most two and again identifies a primal vertex pair.  Therefore a single row in the zero-determinant direction 1 must use the common-sign cancellation among \(p,q,-p-q\).  Its defect coordinate \(y\) would have to satisfy

\[
|\pm1+\varepsilon_2\alpha_2+T|<|\alpha_1|. \tag{A2}
\]

But (A1) gives

\[
|\pm1+(\varepsilon_2\alpha_2+T)|
\ge 1-|\varepsilon_2\alpha_2+T|
>|\alpha_1|,
\]

contradicting (A2).

---

## 5. Rank-three orbit B

After switching, take the repeated sign rows in the form

\[
(\varepsilon,\sigma,\sigma,1,1),
\qquad
\varepsilon,\sigma\in\{\pm1\}.
\]

Let

\[
R=\alpha_2+\alpha_3,
\qquad
S=\alpha_4+\alpha_5.
\]

Strictness of all four repeated intersections gives

\[
|S|+|\alpha_1|+|R|<1. \tag{B1}
\]

As in orbit A, excluding support-two Gale degeneracies leaves only the standard cancellation for a singleton in the zero-determinant direction.  Its defect would require

\[
|\pm1+\sigma R+S|<|\alpha_1|. \tag{B2}
\]

Yet (B1) implies

\[
|\pm1+(\sigma R+S)|
\ge1-|\sigma R+S|
>|\alpha_1|,
\]

contradicting (B2).

---

## 6. Conclusion

Both rank-three orbits are impossible, while the only rank-four possibility loses a primal vertex pair.  Therefore

\[
\boxed{
\text{A genuine 12-vertex }c=0\text{ section cannot have seven strict singles of profile }(4,1,1,1).
}
\]

This exclusion uses neither Mahler-volume calculation nor the two double-defect rows.

---

## 7. Reproduction

Run

```bash
python viterbo_d11_m4_local_verifier.py
```

The script writes `viterbo_d11_m4_local_verifier.json` and asserts all counts internally.  Current SHA-256 values:

```text
fa807956fcec50543947e714b156c8d792186058bfa8f156ba26a56aa60e2b08  viterbo_d11_m4_local_verifier.py
4081b81239460ca46c1cbc3ac4569c4b92583e32ed6dbaba00d59d5f021c0399  viterbo_d11_m4_local_verifier.json
```
