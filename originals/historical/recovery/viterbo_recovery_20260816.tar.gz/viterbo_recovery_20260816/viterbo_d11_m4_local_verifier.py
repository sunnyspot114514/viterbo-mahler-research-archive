#!/usr/bin/env python3
"""Exact local verifier for the multiplicity-4 single-direction lemma.

Context
-------
For one fixed defect direction in a codimension-two cube section, four
single-defect rows determine four projective sign vectors in
{+/-1}^5 / {global sign}.  We normalize the fifth coordinate to +1,
leaving 16 vectors.  This script exhaustively classifies all 4-subsets
under signed coordinate permutations.

The computation is exact: determinants, ranks, RREFs, and kernels use
integers/Fraction only.  No floating point arithmetic is used.

Verified output
---------------
* 1820 total 4-subsets.
* Rank distribution: 1720 of rank 4, 100 of rank 3.
* The 100 rank-3 subsets form exactly two signed-permutation orbits,
  represented by (0,1,2,3) and (0,1,6,7), of sizes 40 and 60.
* Every rank-4 cofactor-kernel has one of only three absolute patterns:
      (0,0,0,1,1), (0,1,1,1,1), (1,1,1,1,2).
* The support-two pattern (0,0,0,1,1) forms exactly four orbits.
* All 560 sign triples have rank 3 and form exactly three orbits of
  sizes 160, 240, and 160.  These are the canonical multiplicity-3
  inputs for the remaining D=11 profiles.
* A rank-4 kernel permits strict singleton equations in three further
  coordinate directions iff its pattern is (0,0,0,1,1); the other two
  patterns permit only one.

These finite facts are the discrete input to the analytic triangle-
inequality argument excluding the D=11 single-direction profile
(4,1,1,1) for a genuine 12-vertex c=0 section.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

Vector = Tuple[int, ...]
Subset = Tuple[int, ...]


def det_int(matrix: Sequence[Sequence[int]]) -> int:
    """Exact determinant by Bareiss elimination."""
    n = len(matrix)
    if n == 0:
        return 1
    a = [list(map(int, row)) for row in matrix]
    if any(len(row) != n for row in a):
        raise ValueError("det_int expects a square matrix")
    sign = 1
    prev = 1
    for k in range(n - 1):
        pivot = next((r for r in range(k, n) if a[r][k] != 0), None)
        if pivot is None:
            return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            sign *= -1
        p = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                a[i][j] = (a[i][j] * p - a[i][k] * a[k][j]) // prev
        prev = p
        for i in range(k + 1, n):
            a[i][k] = 0
    return sign * a[n - 1][n - 1]


def matrix_rank_int(matrix: Sequence[Sequence[int]]) -> int:
    """Exact rank by Fraction-valued Gaussian elimination."""
    a = [[Fraction(x) for x in row] for row in matrix]
    if not a:
        return 0
    m, n = len(a), len(a[0])
    r = 0
    for c in range(n):
        pivot = next((i for i in range(r, m) if a[i][c] != 0), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        p = a[r][c]
        a[r] = [x / p for x in a[r]]
        for i in range(m):
            if i != r and a[i][c] != 0:
                q = a[i][c]
                a[i] = [a[i][j] - q * a[r][j] for j in range(n)]
        r += 1
        if r == m:
            break
    return r


def rref_nullspace(matrix: Sequence[Sequence[int]]) -> List[List[Fraction]]:
    """Return an exact basis for the right nullspace."""
    a = [[Fraction(x) for x in row] for row in matrix]
    m, n = len(a), len(a[0])
    pivot_cols: List[int] = []
    r = 0
    for c in range(n):
        pivot = next((i for i in range(r, m) if a[i][c] != 0), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        p = a[r][c]
        a[r] = [x / p for x in a[r]]
        for i in range(m):
            if i != r and a[i][c] != 0:
                q = a[i][c]
                a[i] = [a[i][j] - q * a[r][j] for j in range(n)]
        pivot_cols.append(c)
        r += 1
        if r == m:
            break
    free_cols = [c for c in range(n) if c not in pivot_cols]
    basis: List[List[Fraction]] = []
    for f in free_cols:
        v = [Fraction(0) for _ in range(n)]
        v[f] = 1
        for row, pcol in enumerate(pivot_cols):
            v[pcol] = -a[row][f]
        basis.append(v)
    return basis


def primitive_integer_vector(values: Sequence[int]) -> Tuple[int, ...]:
    vals = list(map(int, values))
    g = 0
    for x in vals:
        g = math.gcd(g, abs(x))
    if g:
        vals = [x // g for x in vals]
    for x in vals:
        if x:
            if x < 0:
                vals = [-y for y in vals]
            break
    return tuple(vals)


def cofactor_kernel(rows: Sequence[Sequence[int]]) -> Tuple[int, ...]:
    """Primitive right-kernel vector of a rank-4 4x5 matrix."""
    if len(rows) != 4 or any(len(row) != 5 for row in rows):
        raise ValueError("cofactor_kernel expects 4x5 input")
    cofactors = []
    for j in range(5):
        minor = [[row[k] for k in range(5) if k != j] for row in rows]
        cofactors.append(((-1) ** j) * det_int(minor))
    h = primitive_integer_vector(cofactors)
    if all(x == 0 for x in h):
        raise ValueError("matrix is not rank 4")
    # Sanity check M h = 0.
    assert all(sum(row[j] * h[j] for j in range(5)) == 0 for row in rows)
    return h



def admissible_singleton_directions(h: Sequence[int]) -> List[int]:
    """Directions whose second-coordinate Gale equation admits |y|<1.

    For direction j with h_j != 0, a single-defect row requires
        y = -sum_{k != j} eps_k h_k / h_j,  eps_k in {+/-1}.
    For h_j = 0, the second-coordinate equation must have a signed zero
    sum; y is then free at this stage.
    """
    out: List[int] = []
    for j in range(5):
        others = [k for k in range(5) if k != j]
        feasible = False
        for signs in itertools.product((-1, 1), repeat=4):
            signed_sum = sum(signs[i] * h[k] for i, k in enumerate(others))
            if h[j] == 0:
                feasible = signed_sum == 0
            else:
                feasible = abs(signed_sum) < abs(h[j])
            if feasible:
                break
        if feasible:
            out.append(j)
    return out


def projective_sign_vectors() -> List[Vector]:
    """16 representatives of {+/-1}^5 / global sign, last coordinate +1."""
    out: List[Vector] = []
    for idx in range(16):
        first_four = tuple(1 if (idx >> k) & 1 else -1 for k in range(4))
        out.append(first_four + (1,))
    return out


def signed_permutation_actions(vectors: Sequence[Vector]) -> List[Tuple[int, ...]]:
    """All distinct B_5 actions on the 16 projective vectors."""
    index = {v: i for i, v in enumerate(vectors)}
    actions = set()
    for perm in itertools.permutations(range(5)):
        for flips in itertools.product((-1, 1), repeat=5):
            image: List[int] = []
            for v in vectors:
                w = [flips[i] * v[perm[i]] for i in range(5)]
                if w[4] == -1:  # projective normalization
                    w = [-x for x in w]
                image.append(index[tuple(w)])
            actions.add(tuple(image))
    return sorted(actions)


def canonical_subset(subset: Subset, actions: Sequence[Tuple[int, ...]]) -> Subset:
    return min(tuple(sorted(action[i] for i in subset)) for action in actions)


def fraction_vector_to_strings(v: Sequence[Fraction]) -> List[str]:
    return [str(x) for x in v]


def run_verification() -> dict:
    vectors = projective_sign_vectors()
    actions = signed_permutation_actions(vectors)
    assert len(vectors) == 16
    assert len(actions) == 1920

    triples = list(itertools.combinations(range(16), 3))
    assert len(triples) == 560
    triple_ranks = Counter(matrix_rank_int([vectors[i] for i in triple]) for triple in triples)
    assert triple_ranks == Counter({3: 560})
    triple_orbits: defaultdict[Subset, List[Subset]] = defaultdict(list)
    for triple in triples:
        triple_orbits[canonical_subset(triple, actions)].append(triple)
    assert len(triple_orbits) == 3
    assert sorted(len(v) for v in triple_orbits.values()) == [160, 160, 240]
    assert set(triple_orbits) == {(0, 1, 2), (0, 1, 6), (0, 3, 5)}

    subsets = list(itertools.combinations(range(16), 4))
    assert len(subsets) == 1820

    ranks: Counter[int] = Counter()
    rank3_subsets: List[Subset] = []
    rank4_subsets: List[Subset] = []
    kernel_patterns: Counter[Tuple[int, ...]] = Counter()
    support_two_subsets: List[Subset] = []
    admissible_count_by_pattern: Counter[Tuple[Tuple[int, ...], int]] = Counter()

    for subset in subsets:
        rows = [vectors[i] for i in subset]
        rank = matrix_rank_int(rows)
        ranks[rank] += 1
        if rank == 3:
            rank3_subsets.append(subset)
        elif rank == 4:
            rank4_subsets.append(subset)
            h = cofactor_kernel(rows)
            pattern = tuple(sorted(abs(x) for x in h))
            kernel_patterns[pattern] += 1
            admissible_count_by_pattern[(pattern, len(admissible_singleton_directions(h)))] += 1
            if sum(x != 0 for x in h) == 2:
                support_two_subsets.append(subset)
        else:
            raise AssertionError(f"unexpected rank {rank}: {subset}")

    assert ranks == Counter({4: 1720, 3: 100})
    assert kernel_patterns == Counter({
        (0, 0, 0, 1, 1): 1160,
        (0, 1, 1, 1, 1): 480,
        (1, 1, 1, 1, 2): 80,
    })
    assert admissible_count_by_pattern == Counter({
        ((0, 0, 0, 1, 1), 3): 1160,
        ((0, 1, 1, 1, 1), 1): 480,
        ((1, 1, 1, 1, 2), 1): 80,
    })

    rank3_orbits: defaultdict[Subset, List[Subset]] = defaultdict(list)
    for subset in rank3_subsets:
        rank3_orbits[canonical_subset(subset, actions)].append(subset)
    assert len(rank3_orbits) == 2
    assert sorted(len(v) for v in rank3_orbits.values()) == [40, 60]
    assert set(rank3_orbits) == {(0, 1, 2, 3), (0, 1, 6, 7)}

    support_two_orbits: defaultdict[Subset, List[Subset]] = defaultdict(list)
    for subset in support_two_subsets:
        support_two_orbits[canonical_subset(subset, actions)].append(subset)
    assert len(support_two_orbits) == 4
    assert sorted(len(v) for v in support_two_orbits.values()) == [40, 160, 480, 480]

    triple_data = []
    for rep in sorted(triple_orbits):
        rows = [vectors[i] for i in rep]
        basis = rref_nullspace(rows)
        triple_data.append({
            "representative": list(rep),
            "orbit_size": len(triple_orbits[rep]),
            "rows": [list(row) for row in rows],
            "right_nullspace_basis": [fraction_vector_to_strings(v) for v in basis],
        })

    rank3_data = []
    for rep in sorted(rank3_orbits):
        rows = [vectors[i] for i in rep]
        basis = rref_nullspace(rows)
        rank3_data.append({
            "representative": list(rep),
            "orbit_size": len(rank3_orbits[rep]),
            "rows": [list(row) for row in rows],
            "right_nullspace_basis": [fraction_vector_to_strings(v) for v in basis],
        })

    support_two_data = []
    for rep in sorted(support_two_orbits):
        rows = [vectors[i] for i in rep]
        support_two_data.append({
            "representative": list(rep),
            "orbit_size": len(support_two_orbits[rep]),
            "rows": [list(row) for row in rows],
            "primitive_cofactor_kernel": list(cofactor_kernel(rows)),
        })

    return {
        "arithmetic": "exact integer/Fraction; no floating point",
        "projective_sign_vectors": [list(v) for v in vectors],
        "signed_permutation_group_size": len(actions),
        "total_sign_triples": len(triples),
        "sign_triple_rank_distribution": {str(k): triple_ranks[k] for k in sorted(triple_ranks)},
        "sign_triple_orbits": triple_data,
        "total_four_subsets": len(subsets),
        "rank_distribution": {str(k): ranks[k] for k in sorted(ranks)},
        "rank4_absolute_kernel_patterns": {
            str(pattern): count for pattern, count in sorted(kernel_patterns.items())
        },
        "rank4_admissible_singleton_direction_counts": {
            f"{pattern} -> {count} directions": multiplicity
            for (pattern, count), multiplicity in sorted(admissible_count_by_pattern.items())
        },
        "rank3_orbits": rank3_data,
        "rank4_support_two_orbits": support_two_data,
        "assertions": {
            "sign_triple_orbit_count": 3,
            "rank3_orbit_count": 2,
            "rank4_support_two_orbit_count": 4,
            "all_checks_passed": True,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--json",
        type=Path,
        default=Path(__file__).with_suffix(".json"),
        help="output JSON certificate path",
    )
    args = parser.parse_args()
    result = run_verification()
    args.json.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": "PASS",
        "json": str(args.json),
        "sign_triple_orbits": [
            [item["representative"], item["orbit_size"]]
            for item in result["sign_triple_orbits"]
        ],
        "rank_distribution": result["rank_distribution"],
        "rank3_orbits": [
            [item["representative"], item["orbit_size"]]
            for item in result["rank3_orbits"]
        ],
        "support_two_orbits": [
            [item["representative"], item["orbit_size"]]
            for item in result["rank4_support_two_orbits"]
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
