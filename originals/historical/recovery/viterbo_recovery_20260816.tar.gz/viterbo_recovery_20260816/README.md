# Viterbo–Mahler bounded-12 recovery bundle (2026-08-16)

This bundle preserves the exact certificate layers reconstructed after a runtime reset.
It concerns the **four-dimensional centrally symmetric Mahler problem**, not all dimensions.

## Included

- `viterbo_d11_m4_local_*`: persisted exact verifier for the D=11 `(4,1,1,1)` local profile.
- `viterbo_d12_certificate_manifest.json`: the finite-orbit accounting and exceptional keys for D=12.
- `viterbo_d12_analytic_verifier.py`: exact symbolic verification of all recorded factor identities and of the three genuine families' Mahler positivity.
- `bernstein_utils.py`: exact tensor-Bernstein conversion.

Run:

```bash
python viterbo_d11_m4_local_verifier.py
python viterbo_d12_analytic_verifier.py
```

## Proof-status boundary

The D=12 conclusion is a **computer-assisted analytic proof candidate**.  The analytic layer in this bundle is self-checking.  For a publication-grade package, the finite generator that produces the 355 canonical representatives and the 332 duplicate-column certificates should also be retained as source plus representative data; the manifest records its audited output but is not itself a substitute for regenerating that finite list.
