#!/usr/bin/env python3
"""Exact tensor-Bernstein conversion utilities (SymPy QQ arithmetic)."""
from __future__ import annotations
import itertools, math
from typing import Sequence
import sympy as sp

def tensor_bernstein_coefficients(poly, variables: Sequence[sp.Symbol], degrees=None):
    P = sp.Poly(sp.expand(poly), *variables, domain=sp.QQ)
    if degrees is None:
        degrees = tuple(P.degree(v) for v in variables)
    degrees = tuple(int(n) for n in degrees)
    power = P.as_dict()
    out = {}
    for idx in itertools.product(*[range(n + 1) for n in degrees]):
        value = sp.Rational(0)
        for exponent, coefficient in power.items():
            if all(exponent[j] <= idx[j] for j in range(len(variables))):
                weight = sp.Rational(1)
                for j, n in enumerate(degrees):
                    weight *= sp.Rational(
                        math.comb(idx[j], exponent[j]),
                        math.comb(n, exponent[j]),
                    )
                value += coefficient * weight
        out[idx] = sp.factor(value)
    return out

def coefficient_summary(coefficients):
    vals = list(coefficients.values())
    positive = [x for x in vals if x > 0]
    negative = [x for x in vals if x < 0]
    zero = [x for x in vals if x == 0]
    return {
        "total": len(vals),
        "positive": len(positive),
        "zero": len(zero),
        "negative": len(negative),
        "minimum_positive": str(min(positive)) if positive else None,
    }
