#!/usr/bin/env python3
"""Exact analytic certificate layer for 12V/18F, c=0, D=12.

This verifier checks, with rational symbolic arithmetic:
  * all factor identities used by the 20 non-genuine exceptional orbits;
  * the unit-cube Bernstein positivity certificates for the three genuine
    rank-four families (one (4,1,1), two (3,2,1));
  * the exact volume formulas used in those three families.

The discrete orbit accounting (355 = 332 + 13 + 2 + 5 + 3) is stored in the
adjacent manifest.  This script verifies the analytic payload attached to the
23 exceptional orbits; it is intentionally separate from the finite orbit
generator so each layer can be audited independently.
"""
from __future__ import annotations
import json
from pathlib import Path
import sympy as sp
from bernstein_utils import tensor_bernstein_coefficients, coefficient_summary

HERE = Path(__file__).resolve().parent

def assert_zero(expr, label):
    z = sp.factor(sp.cancel(expr))
    if z != 0:
        raise AssertionError(f"{label}: nonzero remainder {z}")

def check_exception_identities():
    a,b,c,t = sp.symbols('a b c t')
    checks=[]
    def ck(lhs,rhs,name):
        assert_zero(lhs-rhs,name); checks.append(name)

    # Split-invalid family 411/43365.
    s=a+b
    A1=(a+b+t*(1-b))/(a+1); A2=(a+2*b-1)/(a+1)
    B1=(a+b+t*(1-a))/(b+1); B2=(2*a+b-1)/(b+1)
    ck((A1+1)*(a+1),2*s+(1-b)*(t+1),'split411_A1_plus')
    ck((1-A1)*(a+1),(1-b)*(1-t),'split411_A1_minus')
    ck((A2+1)*(a+1),2*s,'split411_A2_plus')
    ck((1-A2)*(a+1),2*(1-b),'split411_A2_minus')
    ck((B1+1)*(b+1),2*s+(1-a)*(t+1),'split411_B1_plus')
    ck((1-B1)*(b+1),(1-a)*(1-t),'split411_B1_minus')
    ck((B2+1)*(b+1),2*s,'split411_B2_plus')
    ck((1-B2)*(b+1),2*(1-a),'split411_B2_minus')

    # Split-invalid family 42/2140260.
    D1=a*c-a+b*c+b-2
    Np1=a*c-a+b*c-3*b+2
    Nq1=-(a*c-a-b*c-b+2*c)
    D2=a*c+a+b*c-b-2
    Np2=a*c-3*a+b*c-b+2
    Nq2=-(a*c+a-b*c+b-2*c)
    ck(D1**2-Np1**2,8*s*(b-1)*(c-1),'split42_p1')
    ck(D1**2-Nq1**2,4*(a+1)*(b-1)*(c-1)*(c+1),'split42_q1')
    ck(D2**2-Np2**2,8*(a-1)*s*(c-1),'split42_p2')
    ck(D2**2-Nq2**2,4*(a-1)*(b+1)*(c-1)*(c+1),'split42_q2')

    # Extra-facet orbit 222/2196612.
    q=(a-b)/(a+b-2)
    ck(1-q**2,4*(1-a)*(1-b)/(a+b-2)**2,'extra2196612_global')
    F=a*c-a+b*c-b-2*c-2
    G=(c+1)*(a+b)-2*c-6
    x=-(c*(a+b)-2*c-4)/(a+b-2)
    y=-(a+b+2)/(a+b-2)
    ck(1-y**2,-8*(a+b)/(a+b-2)**2,'extra2196612_y')
    ck(1-x**2,-F*G/(a+b-2)**2,'extra2196612_x')
    D=a*c-a+b*c+b-2*c
    Nx=-(a*c-a+b*c-3*b-2*c-4)
    Ny=a*c-a-b*c-b-4*c-2
    H=a*c-a-3*c-1
    ck(H,F+(1-c)*(b+1),'extra2196612_H')
    ck(D**2-Nx**2,8*(b+1)*F,'extra2196612_x2')
    ck(D**2-Ny**2,4*(b+1)*(c+1)*H,'extra2196612_y2')

    # Extra-facet orbit 222/2196869.
    q=(a+b)/(a-b+2)
    ck(1-q**2,4*(a+1)*(1-b)/(a-b+2)**2,'extra2196869_global')

    # Extra-facet orbit 222/4215240.
    Du=a*c+a+c-3
    Nu=a*b*c-a*b-2*a-b*c+b+2*c
    Nv=a*c+a-3*c+1
    Dw=a*b+a-b+3
    Nw=-(a*b*c-a*c-2*a+b*c-2*b-c)
    Nz=-(a*b+a+3*b-1)
    Q=b*c-b-c-3
    ck(Du,(a+1)*(c+1)-4,'extra4215240_Du')
    ck(Q,(b-1)*(c-1)-4,'extra4215240_Q')
    ck(Dw,(a-1)*(b+1)+4,'extra4215240_Dw')
    ck(Du**2-Nu**2,-(a-1)*(c-1)*Dw*Q,'extra4215240_u')
    ck(Du**2-Nv**2,8*(a-1)*(c-1)*(c+1),'extra4215240_v')
    ck(Dw**2-Nw**2,-(a+1)*(b-1)*Du*Q,'extra4215240_w')
    ck(Dw**2-Nz**2,-8*(a+1)*(b-1)*(b+1),'extra4215240_z')

    # Extra-facet orbit 222/4215257.
    two_u=-(a*b+a+b-1)
    two_v=a*c+a+c-1
    DD=a*b*c-a-b-c+2
    Nw=-(a*b-a*c+b*c-2*b+1)
    Nz=a*b-a*c-b*c+2*c-1
    ck(DD,(1-a)*(1-b)+(1-c)*(1-a*b),'extra4215257_D')
    ck(4-two_u**2,-(a+1)*(b+1)*(a*b+a+b-3),'extra4215257_u')
    ck(4-two_v**2,-(a+1)*(c+1)*(a*c+a+c-3),'extra4215257_v')
    ck(DD**2-Nw**2,(a-1)*(b-1)*(b+1)*(c-1)*(a*c+a+c-3),'extra4215257_w')
    ck(DD**2-Nz**2,(a-1)*(b-1)*(c-1)*(c+1)*(a*b+a+b-3),'extra4215257_z')

    # Extra-facet orbit 42/4364354.
    D1=(a-b)*(c-1)-2*(b+1)
    N1=a*c-a-b*c+3*b+2
    D2=(a-b)*(t-1)+2*(a-1)
    N2=a*t-3*a-b*t+b+2
    D3=(a-b)*(t-1)-2*(b+1)
    N3=a*t-a-b*t+3*b+2
    D4=(a-b)*(c-1)+2*(a-1)
    N4=a*c-3*a-b*c+b+2
    ck(D1**2-N1**2,-8*(a-b)*(b+1)*(c-1),'extra4364354_1')
    ck(D2**2-N2**2,8*(a-1)*(a-b)*(t-1),'extra4364354_2')
    ck(D3**2-N3**2,-8*(a-b)*(b+1)*(t-1),'extra4364354_3')
    ck(D4**2-N4**2,8*(a-1)*(a-b)*(c-1),'extra4364354_4')
    return checks

def family_411():
    A,D,T,u,v,w=sp.symbols('A D T u v w')
    B=(-(T+3)*A+(T+1)*D)/2
    C=(-(T+1)*A+(T-1)*D)/2
    # Volumes in the independent-row coordinate gauge (rows 0,1,4,5).
    P=(T+1)*(A*T+A-D*T-D-4*T+20)/6
    Q=(A**2*T**3+11*A**2*T**2+51*A**2*T+41*A**2
       -2*A*D*T**3-14*A*D*T**2-38*A*D*T+38*A*D
       -8*A*T**2-32*A*T+40*A+D**2*T**3+3*D**2*T**2
       +3*D**2*T+D**2+8*D*T**2+32*D*T-40*D-16*T-80)/(
       12*(A-1)*(T+1)*(A*T+A-D*T+D+2))
    excess=sp.factor(sp.cancel(P*Q-sp.Rational(32,3)))
    sub={D:2*u-1,T:2*w-1,A:2*u-1+2*(1-u)*v/(1+w)}
    E=sp.factor(sp.cancel(excess.subs(sub)))
    num,den=sp.together(E).as_numer_denom()
    sample=den.subs({u:sp.Rational(1,2),v:sp.Rational(1,2),w:sp.Rational(1,2)})
    H=sp.expand(num if sample>0 else -num)
    coeff=tensor_bernstein_coefficients(H,(u,v,w),(2,3,5))
    summary=coefficient_summary(coeff)
    assert summary=={'total':72,'positive':43,'zero':29,'negative':0,'minimum_positive':'8/15'}
    # Denominator factors are positive on the open cube:
    # 9(w+1)(v-w-1)(u v w-u w-u-v w); the last two are both negative.
    return {'key':322985,'profile':'(4,1,1)','bernstein_degree':[2,3,5],**summary,
            'P':str(sp.factor(P)),'Ppolar':str(sp.factor(Q)),'excess':str(excess)}

def family_321_a():
    a,t,u,v=sp.symbols('a t u v')
    P=2*(a*t**2-a*t-6*a+t**2+7*t-26)/(3*(t-3))
    Q=-(3*a**3*t**3-a**3*t**2+5*a**3*t+17*a**3
        +9*a**2*t**3-27*a**2*t**2-97*a**2*t-85*a**2
        +9*a*t**3-51*a*t**2-145*a*t-61*a
        +3*t**3-25*t**2-43*t-23)/(12*(a+1)**3*(t+1)**2)
    E=sp.factor(sp.cancel((P*Q-sp.Rational(32,3)).subs({t:2*v-1,a:(1-v+2*u*v)/(1+v)})))
    num,den=sp.together(E).as_numer_denom()
    # On 0<u,v<1, denominator has the sign making 2*inner the positive numerator.
    H=sp.expand(-num)  # exact transformed positive numerator
    coeff=tensor_bernstein_coefficients(H,(u,v),(4,7))
    summary=coefficient_summary(coeff)
    assert summary=={'total':40,'positive':39,'zero':1,'negative':0,'minimum_positive':'6'}
    return {'key':544166,'profile':'(3,2,1)','bernstein_degree':[4,7],**summary,
            'P':str(sp.factor(P)),'Ppolar':str(sp.factor(Q))}

def family_321_b():
    a,t,u,v=sp.symbols('a t u v')
    P=2*(a*t**2-a+t**2+6*t-31)/(3*(t-3))
    Q=-(3*a**2*t**5-13*a**2*t**4+22*a**2*t**3-106*a**2*t**2+23*a**2*t-185*a**2
        +6*a*t**5-38*a*t**4-20*a*t**3+36*a*t**2-82*a*t+610*a
        +3*t**5-25*t**4-26*t**3+222*t**2+71*t-501)/(12*(a*t**2+3*a+t**2-5)**2)
    E=sp.factor(sp.cancel((P*Q-sp.Rational(32,3)).subs({a:2*u-1,t:2*v-1})))
    num,den=sp.together(E).as_numer_denom()
    sample=den.subs({u:sp.Rational(1,2),v:sp.Rational(1,2)})
    H=sp.expand(num if sample>0 else -num)
    coeff=tensor_bernstein_coefficients(H,(u,v),(3,7))
    summary=coefficient_summary(coeff)
    assert summary=={'total':32,'positive':22,'zero':10,'negative':0,'minimum_positive':'2/7'}
    return {'key':544183,'profile':'(3,2,1)','bernstein_degree':[3,7],**summary,
            'P':str(sp.factor(P)),'Ppolar':str(sp.factor(Q))}

def main():
    manifest=json.loads((HERE/'viterbo_d12_certificate_manifest.json').read_text())
    assert manifest['orbit_accounting']=={
        'total':355,'duplicate_or_antipodal_columns':332,'lost_vertex':13,
        'split_invalid':2,'forced_extra_facet':5,'genuine_families':3}
    identities=check_exception_identities()
    families=[family_411(),family_321_a(),family_321_b()]
    out={
      'status':'PASS',
      'arithmetic':'exact SymPy QQ; no floating point used in the assertions',
      'orbit_accounting':manifest['orbit_accounting'],
      'verified_factor_identities':len(identities),
      'factor_identity_labels':identities,
      'genuine_families':families,
    }
    path=HERE/'viterbo_d12_analytic_verifier.json'
    path.write_text(json.dumps(out,indent=2,ensure_ascii=False))
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=='__main__': main()
