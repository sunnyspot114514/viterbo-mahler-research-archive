#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,sys
from pathlib import Path
OLD=Path('/mnt/data/viterbo_22f_d17_structural_accounting_certificate.json')
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
F952=Path('/mnt/data/viterbo_22f_d17_family952_verifier.py')
BND=Path('/mnt/data/viterbo_22f_d17_boundary_only_verifier.py')
F952O=Path('/mnt/data/viterbo_22f_d17_family952_verifier_output.json')
BNDO=Path('/mnt/data/viterbo_22f_d17_boundary_only_verifier_output.json')
CERT=Path('/mnt/data/viterbo_22f_d17_progress_accounting_certificate_v2.json')
OUT=Path('/mnt/data/viterbo_22f_d17_progress_accounting_verifier_output_v2.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 subprocess.run([sys.executable,str(BND)],check=True,stdout=subprocess.DEVNULL)
 # Family 952 is the expensive exact analytic verifier; rerun it here as part of the aggregate certificate.
 subprocess.run([sys.executable,str(F952)],check=True,stdout=subprocess.DEVNULL)
 old=json.loads(OLD.read_text());pre=json.loads(PRE.read_text());f=json.loads(F952O.read_text());b=json.loads(BNDO.read_text())
 assert f['status']=='PASS' and f['canonical_family']==952
 assert b['status']=='PASS' and sorted(b['closed_families'])==[1439,2078]
 oldrem=set(old['categories']['remaining_algebraic_survivors']);newclosed={952,1439,2078};assert newclosed<=oldrem
 rem=sorted(oldrem-newclosed);assert len(rem)==65
 cats={
  'facet_containment':old['disjoint_classification']['facet_containment'],
  'rank_ge_5_after_antichain':old['disjoint_classification']['rank_ge_5_after_antichain'],
  'segment_loss_after_antichain':old['disjoint_classification']['segment_loss_after_antichain'],
  'forced_duplicate_or_antipodal_primal_pair':old['disjoint_classification']['forced_duplicate_or_antipodal_primal_pair'],
  'Mahler_positive_exact_family':2,
  'strict_rank4_boundary_only':2,
  'remaining_algebraic_survivors':65,
 }
 assert sum(cats.values())==2395
 cert={'scope':'4D symmetric Mahler bounded-12, 12V/22F,c=0,D=17','status':'PASS','total_pairing_templates':2395,
  'disjoint_classification':cats,'Mahler_positive_exact_families':[606,952],'strict_rank4_boundary_only':[1439,2078],
  'remaining_ids':rem,'survivor_level_accounting':{'initial':121,'facet_containment':26,'additional_segment_loss':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':2,'strict_rank4_boundary_only':2,'remaining':65},
  'source_hashes':{str(OLD):sha(OLD),str(PRE):sha(PRE),str(F952O):sha(F952O),str(BNDO):sha(BNDO)}}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 out={'status':'PASS','total_templates':2395,'remaining_survivors':65,'newly_closed':{'Mahler_positive':[952],'boundary_only':[1439,2078]},'certificate':str(CERT),'certificate_sha256':sha(CERT)}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
