# 4D symmetric Mahler bounded-12 progress: 22F, D=17

## New exact results

Three additional canonical survivors are closed:

- Family 952: a genuine three-parameter realization family, with exact Mahler product strictly above \(32/3\) on its full strict domain;
- Families 1439 and 2078: no strict rank-four realization exists, because the Schur equations force a defect to equal \(-1\) or \(+1\).

## Updated disjoint accounting

\[
\boxed{
2395=
1230\text{ facet-containment}
+1070\text{ rank}\ge5
+22\text{ segment loss}
+4\text{ duplicate/antipodal primal pair}
+2\text{ Mahler-positive}
+2\text{ strict-boundary-only}
+65\text{ remaining}.
}
\]

At the original algebraic-survivor level:

\[
\boxed{
121=26+22+4+2+2+65.
}
\]

The aggregate verifier reruns both new exact verifiers and checks that the categories are disjoint and cover all 2395 pairing templates.

## Scope

All closed layers and families remain computer-assisted analytic proof candidates.  This is progress within the bounded-12 finite core of the four-dimensional symmetric Mahler conjecture, not a proof of the unrestricted four-dimensional conjecture.
