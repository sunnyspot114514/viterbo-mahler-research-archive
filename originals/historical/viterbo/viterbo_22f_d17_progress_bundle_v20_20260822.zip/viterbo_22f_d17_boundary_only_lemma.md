# Two strict-boundary exclusions in the 12V/22F, c=0, D=17 layer

## Family 1439

Use rows \((0,1,2,9)\) and columns \((2,3,4,5)\) as a constant determinant-\(8\) pivot.  The Schur equations first force

\[
x_{0,0}=x_{1,0},\quad x_{2,0}=x_{3,0},\quad
x_{0,1}=x_{1,1},\quad x_{10,1}=x_{9,1}.
\]

Solving three further equations only divides by

\[
x_{9,1}-1,
\qquad
x_{8,3}+1,
\]

which are nonzero on the strict defect domain.  A remaining Schur equation then becomes

\[
2(x_{4,0}+1)=0.
\]

Hence every rank-at-most-four realization has \(x_{4,0}=-1\), contradicting \(|x_{4,0}|<1\).

## Family 2078

Use rows \((4,6,8,9)\) and columns \((0,1,2,5)\) as a constant determinant-\(8\) pivot.  Exact triangular elimination divides only by strict-boundary factors

\[
x_{4,4}+1,
\quad x_{5,2}-1,
\quad x_{9,3}-1,
\quad x_{6,3}-1.
\]

The equations first force

\[
x_{6,3}+x_{8,3}=0.
\]

After substitution, another Schur equation is

\[
-(x_{1,1}-1)(x_{9,3}-1)=0.
\]

Strictness excludes \(x_{9,3}=1\), so \(x_{1,1}=1\), again contradicting a strict defect.

## Conclusion

\[
\boxed{
\text{Families 1439 and 2078 have no strict rank-four realization.}
}
\]
