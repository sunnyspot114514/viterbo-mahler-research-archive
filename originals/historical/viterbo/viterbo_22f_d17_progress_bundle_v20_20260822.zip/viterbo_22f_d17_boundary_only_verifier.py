#!/usr/bin/env python3
"""Exact strict-boundary exclusions for D=17 canonical families 1439 and 2078."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import sympy as sp
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_boundary_only_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_boundary_only_verifier_output.json')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def matrix(cid):
 d=json.loads(PRE.read_text());rec=d['records'][cid];assert rec['status']=='algebraic_survivor';rows=rec['rows'];M=sp.zeros(11,6)
 for i,row in enumerate(rows):
  for j,v in enumerate(row):M[i,j]=sp.Symbol(f'x{i}_{j}') if v==0 else v
 return rec['canonical_key'],rows,M

def schur(M,rr,cc):
 P=M.extract(rr,cc);assert abs(P.det())==8
 oi=[i for i in range(11) if i not in rr];oj=[j for j in range(6) if j not in cc]
 return P,[sp.factor(2*e) for e in (M.extract(oi,oj)-M.extract(oi,cc)*P.inv()*M.extract(rr,oj))]

def family1439():
 key,rows,M=matrix(1439);P,E=schur(M,[0,1,2,9],[2,3,4,5]);assert P.det()==8
 # E12,E1,E13,E0 force the elementary equalities below.
 subs={M[0,0]:M[1,0],M[0,1]:M[1,1],M[10,1]:M[9,1],M[2,0]:M[3,0]}
 assert sp.factor(E[12].subs(subs))==0 and sp.factor(E[1].subs(subs))==0 and sp.factor(E[13].subs(subs))==0 and sp.factor(E[0].subs(subs))==0
 # Solve three equations using denominators which are nonzero for strict defects.
 subs[M[8,3]]=sp.factor(-(2*M[1,1]+M[9,1]+1)/(M[9,1]-1))
 subs[M[4,3]]=sp.factor((2*M[1,1]+M[9,1]+1)/(M[9,1]-1))
 subs[M[3,0]]=sp.factor((2*M[1,0]+M[8,3]-1)/(M[8,3]+1)).subs(subs)
 assert sp.factor(sp.cancel(E[11].subs(subs)))==0
 assert sp.factor(sp.cancel(E[3].subs(subs)))==0
 assert sp.factor(sp.cancel(E[10].subs(subs)))==0
 terminal=sp.factor(sp.cancel(E[2].subs(subs)))
 assert sp.factor(terminal-2*(M[4,0]+1))==0
 return {'canonical_id':1439,'canonical_key':key,'pivot_rows':[0,1,2,9],'pivot_cols':[2,3,4,5],'pivot_determinant':8,
  'strict_nonzero_denominators':['x9_1-1','x8_3+1'],'terminal_equation':str(terminal),'conclusion':'rank<=4 forces x4_0=-1, contradicting strict defect.'}

def family2078():
 key,rows,M=matrix(2078);P,E=schur(M,[4,6,8,9],[0,1,2,5]);assert P.det()==8
 subs={M[2,0]:M[9,4]}
 subs[M[10,2]]=sp.factor(-(M[4,4]-2*M[9,4]-1)/(M[4,4]+1))
 subs[M[3,2]]=sp.factor(-(2*M[3,0]+M[4,4]-1)/(M[4,4]+1))
 subs[M[4,4]]=sp.factor(-(M[5,2]+2*M[9,4]+1)/(M[5,2]-1))
 subs[M[7,1]]=sp.factor(-(2*M[8,3]-M[9,3]-1)/(M[9,3]-1))
 subs[M[5,2]]=sp.factor((M[6,3]+2*M[9,3]+1)/(M[6,3]-1))
 # All divisions are by strict-defect boundary factors.
 for k in [5,13,7,9,10,12]:assert sp.factor(sp.cancel(E[k].subs(subs)))==0
 relation=sp.factor(sp.cancel(E[8].subs(subs)));assert sp.factor(relation+2*(M[6,3]+M[8,3]))==0
 subs[M[6,3]]=-M[8,3]
 terminal=sp.factor(sp.cancel(E[2].subs(subs)))
 assert sp.factor(terminal+(M[1,1]-1)*(M[9,3]-1))==0
 return {'canonical_id':2078,'canonical_key':key,'pivot_rows':[4,6,8,9],'pivot_cols':[0,1,2,5],'pivot_determinant':8,
  'strict_nonzero_denominators':['x4_4+1','x5_2-1','x9_3-1','x6_3-1'],
  'intermediate_relation':str(relation),'terminal_equation':str(terminal),
  'conclusion':'strict x9_3!=1 makes rank<=4 force x1_1=1, contradicting strict defect.'}

def main():
 records=[family1439(),family2078()]
 cert={'scope':'4D symmetric Mahler bounded-12, 12V/22F,c=0,D=17','status':'PASS','source_sha256':sha(PRE),'records':records,
  'conclusion':'Both canonical families have no strict rank-four realization.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 out={'status':'PASS','closed_families':[1439,2078],'count':2,'certificate':str(CERT),'certificate_sha256':sha(CERT),'conclusion':cert['conclusion']}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
