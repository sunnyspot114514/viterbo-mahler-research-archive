#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical family 952."""
from __future__ import annotations
import hashlib, importlib.util, json
from collections import Counter
from pathlib import Path
import sympy as sp

PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
HELPER_PATH=Path('/mnt/data/viterbo_22f_d17_family606_verifier.py')
CERT=Path('/mnt/data/viterbo_22f_d17_family952_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family952_verifier_output.json')

spec=importlib.util.spec_from_file_location('d17helper',HELPER_PATH)
h=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(h)
SignEngine=h.SignEngine; verify_chart=h.verify_chart

def sha256(path:Path)->str:
 x=hashlib.sha256();x.update(path.read_bytes());return x.hexdigest()

def decode(cid=952):
 d=json.loads(PRE.read_text());r=d['records'][cid]
 assert r['canonical_id']==cid and r['status']=='algebraic_survivor'
 rows=r['rows'];assert Counter(row.count(0) for row in rows)==Counter({2:6,1:5})
 return r['canonical_key'],rows

def build(rows):
 M=sp.zeros(11,6); variables=[]
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:
    x=sp.Symbol(f'x{i}_{j}');M[i,j]=x;variables.append(x)
   else:M[i,j]=v
 rr=[0,1,2,3];cc=[2,3,4,5];P=M.extract(rr,cc);assert P.det()==8
 oi=[i for i in range(11) if i not in rr];oj=[j for j in range(6) if j not in cc]
 S=M.extract(oi,oj)-M.extract(oi,cc)*P.inv()*M.extract(rr,oj)
 E=[sp.factor(2*e) for e in S]
 # x1_0=x2_0.
 assert sp.factor(E[10]-E[12]+2*(M[1,0]-M[2,0]))==0
 p,q,r=sp.symbols('p q r',real=True)
 # First-coordinate edge pair.  Use x0_0=p+x3_0-1 from E10.
 first=sp.factor((E[6]-E[8]).subs({M[1,0]:p,M[2,0]:p,M[0,0]:p+M[3,0]-1}))
 assert sp.factor(first-(M[3,0]-1)*(M[7,4]-M[8,5]))==0
 # Strict x3_0 != 1 forces x7_4=x8_5=r.
 # Second-coordinate pair then forces x1_1=x2_1 because r != 1.
 # E11,E13 give the corresponding equality x9_1=x10_1.
 x01,a,b,y,z=sp.symbols('x01 a b y z')
 second=sp.factor((E[7]-E[9]).subs({M[7,4]:r,M[8,5]:r,M[0,1]:x01,M[1,1]:a,M[2,1]:b}))
 assert sp.factor(second-(r-1)*(a-b))==0
 rel=sp.factor((E[11]-E[13]).subs({M[0,1]:x01,M[1,1]:a,M[2,1]:b,M[9,1]:y,M[10,1]:z})/2)
 assert sp.factor(rel-(-a+b+y-z))==0
 forced={M[1,0]:p,M[2,0]:p,M[1,1]:q,M[2,1]:q,M[7,4]:r,M[8,5]:r,M[9,1]:M[10,1]}
 # Solve x0_0,x0_1,x3_0 first; use their formulas to certify the
 # 2x2 system forcing the remaining paired defects equal.
 x00=(p*r+3*p-2)/(r+1);x01f=(q*r+3*q+2)/(r+1);x30=(2*p+r-1)/(r+1)
 A1=sp.factor(-x00+2*p+x30);B1=sp.factor(x00-p)
 A2=sp.factor(-x01f+2*q+1);B2=sp.factor(x01f-q)
 detpair=sp.factor(A1*B2-A2*B1)
 assert sp.factor(detpair-4*(p+r)*(q+1)/(r+1)**2)==0
 forced.update({M[5,3]:M[6,3],M[5,4]:M[6,5]})
 reduced=[sp.factor(sp.cancel(e.subs(forced))) for e in S]
 reduced=[e for e in reduced if e!=0]
 reps=[M[0,0],M[0,1],M[3,0],M[4,0],M[4,3],M[6,3],M[6,5],M[10,1]]
 field=sp.QQ.frac_field(p,q,r)
 G=sp.groebner([sp.Poly(sp.together(e).as_numer_denom()[0],*reps,domain=field).as_expr() for e in reduced],*reps,order='lex',domain=field)
 assert G.is_zero_dimensional and len(G.polys)==8
 sol={
  M[0,0]:sp.factor(x00),
  M[0,1]:sp.factor(x01f),
  M[3,0]:sp.factor(x30),
  M[4,0]:sp.factor(-(2*p*q*r+6*p*q-2*p*r**2-2*p*r+4*p+q*r**2+6*q*r+q-r**2+2*r-1)/((q+1)*(r-1)*(r+1))),
  M[4,3]:sp.factor((q*r+7*q-3*r+3)/((q+1)*(r-1))),
  M[6,3]:sp.factor((p*q-2*p*r-p-q*r-2*q+r)/((p+r)*(q+1))),
  M[6,5]:sp.factor(-(p*q*r+2*p*q-p*r**2-p*r+p+2*q*r+q-r**2)/((p+r)*(q+1))),
  M[10,1]:sp.factor(-(2*q-r+1)/(r+1)),
 }
 full={M[1,0]:p,M[2,0]:p,M[1,1]:q,M[2,1]:q,M[7,4]:r,M[8,5]:r,
       M[5,3]:sol[M[6,3]],M[6,3]:sol[M[6,3]],M[5,4]:sol[M[6,5]],M[6,5]:sol[M[6,5]],
       M[9,1]:sol[M[10,1]],M[10,1]:sol[M[10,1]]}
 full.update(sol)
 completed=M.subs(full).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(e.subs(full))==0 for e in S)
 assert all(sp.factor(g.as_expr().subs(sol))==0 for g in G.polys)
 return M,completed,variables,(p,q,r),rr,cc,G,sol,detpair

def main():
 key,rows=decode();M,X,variables,free,rr,cc,G,sol,detpair=build(rows);p,q,r=free
 A,B,R=sp.symbols('A B R',real=True)
 chart={r:2*R-1,
        q:sp.factor(-(R-1)*(B*R-R-1)/(R+1)),
        p:sp.factor((4*A*B*R-3*B*R+B+R+1)/((B+1)*(R+1)))}
 sample={A:sp.Rational(1,2),B:sp.Rational(1,2),R:sp.Rational(1,2)}
 result,Vp,Vq,margin=verify_chart(X,variables,rows,chart,(A,B,R),sample,'full strict rank-four branch')
 eng=SignEngine((A,B,R),sample)
 nonzero={name:eng.positive_rational(expr.subs(chart),name) for name,expr in {
  'r_plus_1':r+1,'q_plus_1':q+1,'p_plus_r':p+r,'forcing_determinant':detpair}.items()}
 L=(r-1)/2;U=(r-1)/(r+3);coef=q*r+3*q-r**2-r+2
 plow=sp.factor(-(3*q*r+q-r**2+r)/coef)
 invB=sp.factor((q-L)/(U-L));invA=sp.factor((p-plow)/(1-plow))
 assert sp.factor(invB.subs(chart)-B)==0 and sp.factor(invA.subs(chart)-A)==0
 cert={'scope':'4D symmetric Mahler bounded-12, 12V/22F,c=0,D=17, family 952','status':'PASS','canonical_template':key,
  'source_hashes':{str(PRE):sha256(PRE),str(HELPER_PATH):sha256(HELPER_PATH)},
  'rank_branch':{'pivot_rows':rr,'pivot_cols':cc,'pivot_determinant':8,'groebner_basis_length':len(G.polys),'zero_dimensional':bool(G.is_zero_dimensional),
   'forced_equalities':['x1_0=x2_0','x7_4=x8_5','x1_1=x2_1','x9_1=x10_1','x5_3=x6_3','x5_4=x6_5'],
   'forcing_determinant':str(detpair),'unique_solution':{str(k):str(v) for k,v in sol.items()},'nonzero_certificates':nonzero},
  'domain':{'original':'-1<r<1, (r-1)/2<q<(r-1)/(r+3), p_lower(q,r)<p<1','p_lower':str(plow),
   'unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse_A':str(invA),'inverse_B':str(invB)},
  'full_domain':result,'conclusion':'Mahler product is strictly greater than 32/3 on the full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 out={'status':'PASS','canonical_family':952,'scope':cert['scope'],'primal_vertices':result['primal_vertices'],'polar_vertices':result['polar_vertices'],
      'tetrahedra_primal':result['tetrahedra_primal'],'tetrahedra_polar':result['tetrahedra_polar'],'volume_P':result['volume_P'],'volume_polar':result['volume_polar'],
      'margin_certificate':result['margin_certificate'],'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
