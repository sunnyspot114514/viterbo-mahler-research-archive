# Canonical Family 952 in the 12V/22F, c=0, D=17 layer

## Statement

For every strict rank-four realization of canonical pairing template 952,

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

The result is a computer-assisted analytic proof candidate.  The exact verifier reconstructs the rank branch from the canonical sign template, proves the full strict parameter domain, verifies all 12 primal and 22 polar vertices, certifies fixed facetwise triangulations, computes exact volumes, and proves the Mahler margin by tensor-Bernstein positivity.

## 1. Forced strict rank-four branch

Use the constant pivot formed by rows \(0,1,2,3\) and columns \(2,3,4,5\), whose determinant is \(8\).  Vanishing of its Schur complement gives fourteen equations.

On the strict defect domain, these equations force

\[
x_{1,0}=x_{2,0}=:p,
\qquad
x_{7,4}=x_{8,5}=:r,
\]

\[
x_{1,1}=x_{2,1}=:q,
\qquad
x_{9,1}=x_{10,1},
\]

and

\[
x_{5,3}=x_{6,3},
\qquad
x_{5,4}=x_{6,5}.
\]

The key nontrivial step is the last pair.  After the first four equalities, the differences of the two relevant Schur-equation pairs form a \(2\times2\) linear system with determinant

\[
\frac{4(p+r)(q+1)}{(r+1)^2}.
\]

Strictness gives \(p+r>0\), \(q+1>0\), and \(r+1>0\), so the determinant cannot vanish.

Over \(\mathbb Q(p,q,r)\), the remaining ideal is zero-dimensional with a Gröbner basis of length eight.  The unique completion is

\[
x_{0,0}=\frac{pr+3p-2}{r+1},
\qquad
x_{0,1}=\frac{qr+3q+2}{r+1},
\]

\[
x_{3,0}=\frac{2p+r-1}{r+1},
\qquad
x_{9,1}=x_{10,1}=-\frac{2q-r+1}{r+1},
\]

\[
x_{4,3}=\frac{qr+7q-3r+3}{(q+1)(r-1)},
\]

\[
x_{5,3}=x_{6,3}
=\frac{pq-2pr-p-qr-2q+r}{(p+r)(q+1)},
\]

\[
x_{5,4}=x_{6,5}
=-\frac{pqr+2pq-pr^2-pr+p+2qr+q-r^2}{(p+r)(q+1)},
\]

with the exact expression for \(x_{4,0}\) recorded in the machine certificate.

## 2. Full strict domain

The defect inequalities reduce exactly to

\[
-1<r<1,
\]

\[
\frac{r-1}{2}<q<\frac{r-1}{r+3},
\]

and

\[
p_0(q,r)<p<1,
\]

where

\[
p_0(q,r)
=-\frac{3qr+q-r^2+r}{qr+3q-r^2-r+2}.
\]

The entire domain is rationally equivalent to the open unit cube.  For \(0<A,B,R<1\), set

\[
r=2R-1,
\]

\[
q=-\frac{(R-1)(BR-R-1)}{R+1},
\]

\[
p=\frac{4ABR-3BR+B+R+1}{(B+1)(R+1)}.
\]

The verifier checks the inverse map and proves all seventeen inequalities \(1-x_{ij}^2>0\) by exact Bernstein certificates.

## 3. Combinatorial closure and volumes

The exact rank factorization retains

\[
f_0(P)=12,
\qquad
f_0(P^\circ)=22.
\]

A fixed global boundary decomposition uses

\[
35\text{ primal tetrahedra}
\qquad\text{and}\qquad
77\text{ polar-facet tetrahedra}.
\]

Every selected simplex determinant has a fixed strict sign on the full parameter cube.  Thus the exact rational formulas for \(|P|\) and \(|P^\circ|\) are valid globally, rather than only in a sampled oriented-matroid chamber.

## 4. Mahler margin

After substitution of the unit-cube chart,

\[
|P|\,|P^\circ|-\frac{32}{3}
=\frac{N(A,B,R)}{D(A,B,R)}.
\]

The tensor-Bernstein data are:

- numerator degree \((3,7,10)\), with \(330\) positive coefficients, \(22\) zero coefficients, and no negative coefficients; the smallest positive coefficient is \(3\);
- denominator degree \((2,6,7)\), with \(164\) positive coefficients, \(4\) zero coefficients, and no negative coefficients; the smallest positive coefficient is \(9\).

Therefore the margin is strictly positive throughout the open cube.

## Conclusion

\[
\boxed{
\text{Family 952 satisfies }|P|\,|P^\circ|>\frac{32}{3}
\text{ on its full strict realization space.}
}
\]
