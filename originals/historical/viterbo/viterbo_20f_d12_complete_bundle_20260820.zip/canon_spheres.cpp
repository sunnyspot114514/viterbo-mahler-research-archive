#include <bits/stdc++.h>
using namespace std;using Row=array<int8_t,6>;
Row normrow(Row a){for(int i=0;i<6;i++)if(a[i]){if(a[i]<0)for(auto&x:a)x=-x;break;}return a;}
string rk(const Row&a){string s;for(auto x:a)s.push_back(char('1'+x));return s;}
string sk(vector<int>v){sort(v.begin(),v.end());string s(v.size(),'\0');for(size_t i=0;i<v.size();i++)s[i]=char(v[i]);return s;}
int main(int argc,char**argv){string work=argc>1?argv[1]:".";vector<Row>facets;set<string>seen;
 for(int mask=0;mask<64;mask++)if(__builtin_popcount((unsigned)mask)==4){vector<int>ind;for(int j=0;j<6;j++)if(mask>>j&1)ind.push_back(j);for(int bits=0;bits<16;bits++){Row a{};for(int z=0;z<4;z++)a[ind[z]]=(bits>>z&1)?1:-1;a=normrow(a);if(seen.insert(rk(a)).second)facets.push_back(a);}}
 sort(facets.begin(),facets.end());unordered_map<string,int>idx;for(int i=0;i<120;i++)idx[rk(facets[i])]=i;
 vector<array<int,120>>acts;array<int,6>p={0,1,2,3,4,5};do{for(int bits=0;bits<32;bits++){int sg[6];sg[0]=1;for(int i=1;i<6;i++)sg[i]=(bits>>(i-1)&1)?-1:1;array<int,120>mp{};for(int f=0;f<120;f++){Row b{};for(int i=0;i<6;i++)b[p[i]]=facets[f][i]*sg[i];b=normrow(b);mp[f]=idx[rk(b)];}acts.push_back(mp);}}while(next_permutation(p.begin(),p.end()));
 vector<vector<int>>sols;unordered_map<string,int>idof;ifstream in(work+"/valid_spheres.txt");string line;while(getline(in,line)){stringstream ss(line);vector<int>v;int x;while(ss>>x)v.push_back(x);sort(v.begin(),v.end());idof[sk(v)]=sols.size();sols.push_back(v);}
 vector<int>orb(sols.size(),-1),sizes;vector<vector<int>>reps;int oid=0;
 for(int i=0;i<(int)sols.size();i++)if(orb[i]<0){unordered_set<int>hit;for(auto&mp:acts){vector<int>w;for(int f:sols[i])w.push_back(mp[f]);sort(w.begin(),w.end());auto it=idof.find(sk(w));if(it!=idof.end())hit.insert(it->second);}for(int j:hit)orb[j]=oid;reps.push_back(sols[i]);sizes.push_back(hit.size());oid++;}
 ofstream out(work+"/sphere_orbits.txt");for(int k=0;k<oid;k++){vector<int>best;bool first=true;for(auto&mp:acts){vector<int>w;for(int f:reps[k])w.push_back(mp[f]);sort(w.begin(),w.end());if(first||w<best){best=w;first=false;}}out<<k<<" "<<sizes[k]<<" :";for(int f:best)out<<" "<<f;out<<'\n';}
 cerr<<"actions="<<acts.size()<<" valid="<<sols.size()<<" orbits="<<oid<<" sizes=";for(int x:sizes)cerr<<x<<',';cerr<<"\n";
}
