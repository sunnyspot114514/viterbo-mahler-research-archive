#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
W=Path('/mnt/data/viterbo_d12_work')
d=json.loads((W/'viterbo_20f_d12_preclassification_certificate.json').read_text())
assert d['fixed_facet_enumeration']=={'search_nodes':21114700,'closed_pseudomanifolds':304920,'valid_spheres_fixed_facet':132936}
assert d['sphere_orbit_count']==65 and d['ridge_merge']['local_matching_representatives']==33548
assert d['global_pairing_templates']==17841
assert d['minor_classification']=={'rank_ge_5':17512,'duplicate_facet_rows':322,'algebraic_survivors':7}
assert d['survivor_classification']=={'primal_vertex_loss':6,'Mahler_positive':1,'remaining':0}
assert len(d['records'])==17841
for f,h in d['hashes'].items():assert hashlib.sha256((W/f).read_bytes()).hexdigest()==h
s=json.loads((W/'viterbo_20f_d12_survivor_verifier_output.json').read_text());assert s['status']=='PASS'
print(json.dumps({'status':'PASS','scope':d['scope'],'accounting':{'rank_ge_5':17512,'duplicate_rows':322,'primal_vertex_loss':6,'Mahler_positive':1,'total':17841},'remaining':0},indent=2))
