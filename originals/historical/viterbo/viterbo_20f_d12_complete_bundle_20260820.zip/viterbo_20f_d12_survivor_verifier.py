#!/usr/bin/env python3
from __future__ import annotations
import itertools,json,math
from pathlib import Path
from collections import Counter
import sympy as sp
import numpy as np
from scipy.spatial import ConvexHull
WORK=Path(__file__).resolve().parent
KEYS={int(l.split()[0]):l.split()[1] for l in (WORK/'canonical_unique_with_id.txt').read_text().splitlines()}
OUT=WORK/'viterbo_20f_d12_survivor_verifier_output.json'
A,TU=sp.symbols('A TU',real=True)

def matrix_for(idx):
 key=KEYS[idx];T=[];M=[];d={}
 for i in range(10):
  tr=[];row=[]
  for j,c in enumerate(key[6*i:6*i+6]):
   z=int(c)-1;tr.append(z)
   if z==0:x=sp.Symbol(f'x{i}_{j}');d[str(x)]=x;row.append(x)
   else:row.append(sp.Integer(z))
  T.append(tr);M.append(row)
 return np.array(T,int),sp.Matrix(M),d

def schur(M,rs,cs):
 rr=[i for i in range(10) if i not in rs];cc=[j for j in range(6) if j not in cs];P=M.extract(rs,cs)
 S=(M.extract(rr,cc)-M.extract(rr,cs)*P.inv()*M.extract(rs,cc)).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 return P,S

def structural(idx,sub,free,rs,cs,relation,coeffs,reason):
 TT,M,d=matrix_for(idx);P,S=schur(M,rs,cs);assert P.det()!=0
 assert all(sp.factor(sp.cancel(z.subs(sub)))==0 for z in S)
 Mc=M.subs(sub);V=(P.inv()*Mc.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(sp.cancel(z))==0 for z in relation(V))
 return {'origin_id':idx,'status':'primal_vertex_loss','pivot_det':int(P.det()),'free_variables':[str(x) for x in free],
         'convex_coefficients':coeffs,'strict_reason':reason,'relation_verified':True}

def bern2(poly):
 P=sp.Poly(sp.expand(poly),A,TU,domain='QQ');deg=tuple(map(int,P.degree_list()));co=dict(P.terms());arr=[]
 for i in range(deg[0]+1):
  for j in range(deg[1]+1):
   z=sp.Rational(0)
   for (k,l),c in co.items():
    if k<=i and l<=j:z+=c*sp.Rational(math.comb(i,k),math.comb(deg[0],k))*sp.Rational(math.comb(j,l),math.comb(deg[1],l))
   arr.append(sp.factor(z))
 return deg,arr

def project3(x):
 d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T

def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)

def family14069():
 idx=14069;TT,M,d=matrix_for(idx);a,t=sp.symbols('a t',real=True)
 sub={d['x0_0']:-a,d['x1_0']:a,d['x2_4']:a,d['x3_5']:-t,d['x4_2']:0,d['x4_3']:0,d['x5_1']:t,d['x6_1']:-t,d['x7_4']:a,d['x8_2']:0,d['x8_3']:0,d['x9_5']:t}
 rs=(2,3,7,9);cs=(0,1,2,3);P,S=schur(M,rs,cs);assert int(P.det())==8 and all(sp.factor(z.subs(sub))==0 for z in S)
 Mc=M.subs(sub);V=(P.inv()*Mc.extract(rs,range(6))).applyfunc(sp.factor);F=Mc.extract(range(10),cs)
 amap={a:2*A-1,t:2*TU-1};sample={A:sp.Rational(2,5),TU:sp.Rational(3,5)}
 Vn=np.array(V.subs(amap).subs(sample),float);Fn=np.array(F.subs(amap).subs(sample),float);ptsP=np.vstack([Vn.T,-Vn.T]);ptsQ=np.vstack([Fn,-Fn])
 assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
 facP=[]
 for i in range(10):facP += [sorted(j if TT[i,j]==1 else j+6 for j in range(6) if TT[i,j]),sorted(j+6 if TT[i,j]==1 else j for j in range(6) if TT[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if TT[i,j]==1 else i+10 for i in range(10) if TT[i,j]),sorted(i+10 if TT[i,j]==1 else i for i in range(10) if TT[i,j])]
 tP=[q for f in facP for q in pull(f,ptsP)];tQ=[q for f in facQ for q in pull(f,ptsQ)]
 def pv(i):return V[:,i].subs(amap) if i<6 else -V[:,i-6].subs(amap)
 def qv(i):return F[i,:].T.subs(amap) if i<10 else -F[i-10,:].T.subs(amap)
 def oriented(ts,fun):
  vals=[];uniq=set()
  for z in ts:
   de=sp.factor(sp.Matrix.hstack(*[fun(i) for i in z]).det());sg=1 if sp.N(de.subs(sample))>0 else -1;e=sp.factor(sg*de);deg,bc=bern2(e)
   assert not any(x.is_negative for x in bc) and any(x.is_positive for x in bc);vals.append(e);uniq.add(str(e))
  return vals,len(uniq)
 vp,up=oriented(tP,pv);vq,uq=oriented(tQ,qv)
 volP=sp.factor(sum(vp)/24);volQ=sp.factor(sum(vq)/24);margin=sp.factor(volP*volQ-sp.Rational(32,3))
 assert sp.factor(volP-(A*TU-2*A-2*TU+5)/3)==0
 assert sp.factor(volQ-4*(A*TU+3*A+3*TU+5)/3)==0
 H=sp.factor(sp.Rational(9,4)*margin);deg,bc=bern2(H);assert deg==(2,2) and not any(x.is_negative for x in bc) and any(x.is_positive for x in bc)
 return {'origin_id':idx,'status':'Mahler_positive','domain':'0<A,T<1','rank':4,'strict_defects':12,'primal_vertices':12,'polar_vertices':20,
         'primal_tetrahedra':len(tP),'polar_tetrahedra':len(tQ),'fixed_sign_primal_polynomials':up,'fixed_sign_polar_polynomials':uq,
         'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),
         'margin_bernstein':{'degree':list(deg),'positive':sum(x.is_positive for x in bc),'zero':sum(x.is_zero for x in bc),'negative':sum(x.is_negative for x in bc),'min_positive':str(min(x for x in bc if x.is_positive))}}

def main():
 rec=[]
 # 24828
 for idx,aux in [(24828,'x6_2'),(24807,'x7_1')]:
  TT,M,d=matrix_for(idx);a=d['x2_0'];t=d['x9_4'];p=d['x0_1'];u=d[aux]
  sub={d['x0_0']:-a,d['x1_0']:-a,d['x3_0']:-a,d['x4_0']:a,d['x5_4']:t,d['x6_4']:t,d['x7_4']:t,d['x8_4']:t}
  rec.append(structural(idx,sub,[a,t,p,u],(1,2,5,9),(1,2,3,5),lambda V:[V[k,0]+(1-a)*V[k,3]/2-(1+a)*V[k,5]/2 for k in range(4)],['(1-x2_0)/2','(1+x2_0)/2'],'|x2_0|<1'))
 # 25687
 idx=25687;TT,M,d=matrix_for(idx);a=d['x3_0'];p=d['x4_5'];q=d['x9_5'];h=(p+q)/(p-q+2)
 sub={d['x0_0']:-a,d['x0_1']:p-q+1,d['x1_0']:-a,d['x2_0']:-a,d['x2_5']:-p+q-1,d['x5_2']:h,d['x6_1']:-p,d['x7_1']:-q,d['x8_2']:h}
 rec.append(structural(idx,sub,[a,p,q],(1,3,4,9),(1,2,3,4),lambda V:[V[k,0]+(1-a)*V[k,3]/2-(1+a)*V[k,4]/2 for k in range(4)],['(1-x3_0)/2','(1+x3_0)/2'],'|x3_0|<1'))
 # 7184
 idx=7184;TT,M,d=matrix_for(idx);a=d['x0_0'];t=d['x9_1'];u=d['x6_4'];w=d['x5_2']
 sub={d['x0_1']:-a-t-1,d['x1_0']:t,d['x2_0']:t,d['x3_4']:u,d['x4_4']:-u,d['x5_4']:u,d['x7_4']:-u,d['x8_1']:t}
 rec.append(structural(idx,sub,[a,t,u,w],(6,7,8,9),(0,2,3,5),lambda V:[V[k,4]-(1-u)*V[k,3]/2-(1+u)*V[k,5]/2 for k in range(4)],['(1-x6_4)/2','(1+x6_4)/2'],'|x6_4|<1'))
 # 5268 and 7187
 for idx,aname,aux in [(5268,'x3_0','x1_1'),(7187,'x2_0','x7_1')]:
  TT,M,d=matrix_for(idx);a=d[aname];t=d['x9_3'];p=d['x0_1'];u=d[aux]
  if idx==5268:sub={d['x0_0']:-a,d['x1_0']:-a,d['x2_0']:a,d['x4_0']:-a,d['x5_0']:-a,d['x6_4']:-t,d['x7_3']:t,d['x8_4']:-t};rs=(3,5,7,9);cs=(1,2,4,5)
  else:sub={d['x0_0']:-a,d['x1_0']:a,d['x3_0']:-a,d['x4_0']:-a,d['x5_4']:-t,d['x6_3']:t,d['x7_4']:-t,d['x8_4']:-t};rs=(2,4,6,9);cs=(1,2,4,5)
  rec.append(structural(idx,sub,[a,t,p,u],rs,cs,lambda V:[V[k,0]+(1+a)*V[k,2]/2-(1-a)*V[k,5]/2 for k in range(4)],['(1+'+aname+')/2','(1-'+aname+')/2'],'|'+aname+'|<1'))
 rec.append(family14069())
 out={'status':'PASS','scope':'12V/20F,c=0,D=12','survivors':rec,'classification':{'primal_vertex_loss':6,'Mahler_positive':1,'remaining':0},'conclusion':'all seven algebraic survivors are closed'}
 OUT.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
