#include <bits/stdc++.h>
using namespace std;
using Row=array<int8_t,6>;
Row normrow(Row a){for(int i=0;i<6;i++)if(a[i]){if(a[i]<0)for(auto&x:a)x=-x;break;}return a;}
struct ArrHash{template<class T,size_t N> size_t operator()(array<T,N> const&a)const noexcept{size_t h=0;for(auto x:a)h=h*1315423911u+std::hash<int>{}(int(x)+17);return h;}};
array<int,4> tet_from(Row const&r,int sg){array<int,4>T{};int z=0;for(int i=0;i<6;i++)if(r[i])T[z++]=sg*int(r[i])*(i+1);sort(T.begin(),T.end());return T;}
array<int,3> tri3(int a,int b,int c){array<int,3>x={a,b,c};sort(x.begin(),x.end());return x;}
array<int,2> edge2(int a,int b){array<int,2>x={a,b};sort(x.begin(),x.end());return x;}
bool link_sphere(vector<array<int,4>> const&tets,int v){
 vector<array<int,3>> tris; unordered_set<array<int,3>,ArrHash> seen;
 for(auto const&T:tets){bool has=false;for(int x:T)if(x==v)has=true;if(!has)continue;array<int,3>tr{};int z=0;for(int x:T)if(x!=v)tr[z++]=x;sort(tr.begin(),tr.end());if(seen.insert(tr).second)tris.push_back(tr);}
 if(tris.empty())return false;
 unordered_map<array<int,2>,vector<int>,ArrHash> et; unordered_set<int> verts;
 for(int i=0;i<(int)tris.size();i++){auto tr=tris[i];for(int x:tr)verts.insert(x);et[edge2(tr[0],tr[1])].push_back(i);et[edge2(tr[0],tr[2])].push_back(i);et[edge2(tr[1],tr[2])].push_back(i);}
 for(auto &kv:et)if(kv.second.size()!=2)return false;
 vector<vector<int>> adj(tris.size());for(auto &kv:et){int a=kv.second[0],b=kv.second[1];adj[a].push_back(b);adj[b].push_back(a);}vector<char>vis(tris.size());queue<int>q;q.push(0);vis[0]=1;int cnt=0;while(!q.empty()){int x=q.front();q.pop();cnt++;for(int y:adj[x])if(!vis[y])vis[y]=1,q.push(y);}if(cnt!=(int)tris.size())return false;
 // vertex links inside the 2D link are connected cycles
 for(int w:verts){unordered_map<int,vector<int>>g;for(auto tr:tris){bool h=false;for(int x:tr)if(x==w)h=true;if(!h)continue;int a=0,b=0,z=0;for(int x:tr)if(x!=w){if(z++==0)a=x;else b=x;}g[a].push_back(b);g[b].push_back(a);}if(g.empty())return false;for(auto&kv:g)if(kv.second.size()!=2)return false;unordered_set<int>vv;queue<int>qq;int st=g.begin()->first;vv.insert(st);qq.push(st);while(!qq.empty()){int x=qq.front();qq.pop();for(int y:g[x])if(vv.insert(y).second)qq.push(y);}if(vv.size()!=g.size())return false;}
 long V=verts.size(),E=et.size(),F=tris.size();return V-E+F==2;
}
int main(int argc,char**argv){string work=argc>1?argv[1]:".";vector<Row>facets;set<Row>seen;
 for(int mask=0;mask<64;mask++)if(__builtin_popcount((unsigned)mask)==4){vector<int>ind;for(int j=0;j<6;j++)if(mask>>j&1)ind.push_back(j);for(int bits=0;bits<16;bits++){Row a{};for(int z=0;z<4;z++)a[ind[z]]=(bits>>z&1)?1:-1;a=normrow(a);if(seen.insert(a).second)facets.push_back(a);}}sort(facets.begin(),facets.end());
 ifstream in(work+"/sphere_solutions.txt");ofstream out(work+"/valid_spheres.txt");string line;long long total=0,valid=0;map<array<int,4>,long long>fvec;
 while(getline(in,line)){total++;stringstream ss(line);vector<int>ids;int id;while(ss>>id)ids.push_back(id);vector<array<int,4>>tets;tets.reserve(ids.size()*2);for(int i:ids){tets.push_back(tet_from(facets[i],1));tets.push_back(tet_from(facets[i],-1));}
  set<int>vs;unordered_map<array<int,2>,int,ArrHash>edges;unordered_map<array<int,3>,int,ArrHash>tc;for(auto T:tets){for(int x:T)vs.insert(x);for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)edges[edge2(T[i],T[j])]++;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)for(int k=j+1;k<4;k++)tc[tri3(T[i],T[j],T[k])]++;}
  bool ok=vs.size()==12; if(ok)for(auto&kv:tc)if(kv.second!=2){ok=false;break;}if(ok)for(int v=-6;v<=6;v++)if(v&& !link_sphere(tets,v)){ok=false;break;}if(ok){valid++;sort(ids.begin(),ids.end());for(int x:ids)out<<x<<' ';out<<'\n';fvec[{12,(int)edges.size(),(int)tc.size(),(int)tets.size()}]++;}
 }
 ofstream js(work+"/filter_output.json");js<<"{\n  \"closed_pseudomanifolds\": "<<total<<",\n  \"valid_spheres_fixed_facet\": "<<valid<<",\n  \"f_vectors\": {";bool first=true;for(auto &kv:fvec){if(!first)js<<",";first=false;auto a=kv.first;js<<"\n    \"("<<a[0]<<", "<<a[1]<<", "<<a[2]<<", "<<a[3]<<")\": "<<kv.second;}if(!first)js<<"\n  ";js<<"}\n}\n";cerr<<"total="<<total<<" valid="<<valid<<" fvec=";for(auto&kv:fvec){auto a=kv.first;cerr<<"("<<a[0]<<","<<a[1]<<","<<a[2]<<","<<a[3]<<"):"<<kv.second<<",";}cerr<<"\n";
}
