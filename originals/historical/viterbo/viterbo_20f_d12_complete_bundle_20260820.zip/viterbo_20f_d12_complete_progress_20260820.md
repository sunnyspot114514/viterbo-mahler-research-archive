# 四维中心对称 Mahler：`12V/20F, c=0, D=12` 整层完成报告

日期：2026-08-20

## 1. 直接组合枚举

`D=12` 对应八条 single-defect rows 与两条 double-defect rows。三角化后：

\[
f=(12,48,72,36),\qquad g_2=10.
\]

固定一对 tetrahedra 的精确搜索得到：

\[
21{,}114{,}700\text{ 个搜索节点},
\quad304{,}920\text{ 个闭合 pseudomanifolds},
\quad132{,}936\text{ 个真正的 cs }3\text{-spheres}.
\]

它们在 `B6/{±I}` 下形成

\[
\boxed{65\text{ 个组合轨道}}.
\]

选择八对相容 antipodal ridges 合并后，有

\[
75{,}468\text{ 个 raw matchings},
\qquad
\boxed{33{,}548\text{ 个 local matching representatives}}.
\]

全局 canonicalization 给出

\[
\boxed{17{,}841\text{ 个 pairing sign templates}}.
\]

## 2. Exact minor 分类

\[
\boxed{
17{,}841
=17{,}512\text{ 个 rank}\ge5
+322\text{ 个重复 facet rows}
+7\text{ 个 algebraic survivors}.
}
\]

## 3. 六个 survivors 直接丢失 primal vertices

六族都出现参数无关的严格凸组合。典型形式为

\[
v_0=\frac{1-a}{2}(-v_i)+\frac{1+a}{2}v_j,
\qquad |a|<1,
\]

或

\[
v_4=\frac{1-u}{2}v_i+\frac{1+u}{2}v_j,
\qquad |u|<1.
\]

因此相应候选点位于一条边的相对内部，实际至多只有十个 primal vertices。

## 4. 唯一 genuine family

最后一族可取

\[
a=2A-1,\qquad t=2T-1,\qquad0<A,T<1.
\]

在 `GL(4)` 规范下，六个正向 primal columns 为

\[
\begin{aligned}
v_0&=e_1,&v_1&=e_2,&v_2&=e_3,&v_3&=e_4,\\
v_4&=e_1+(1-A)e_3+(1-A)e_4,\\
v_5&=e_2-(1-T)e_3+(1-T)e_4.
\end{aligned}
\]

完整 facet-wise exact triangulations 使用

\[
36\text{ 个 primal tetrahedra},
\qquad68\text{ 个 polar tetrahedra}.
\]

所有非零 orientation determinants 在整个开方形上保持固定符号。精确体积为

\[
\boxed{|P|=\frac{AT-2A-2T+5}{3}},
\]

\[
\boxed{|P^\circ|=\frac{4(AT+3A+3T+5)}{3}}.
\]

于是

\[
|P||P^\circ|-\frac{32}{3}=\frac{4H(A,T)}9,
\]

其中

\[
H=A^2T^2+A^2T-6A^2+AT^2-2AT+5A-6T^2+5T+1.
\]

`H` 的 degree-`(2,2)` tensor Bernstein coefficients 为

\[
1,\frac72,0,\frac72,\frac{11}{2},2,0,2,0.
\]

因此

\[
\boxed{6>0,\quad3=0,\quad0<0},
\]

并在开方形内严格有 `H>0`。

## 5. 结论

\[
\boxed{12V/20F,\quad c=0,\quad D=12\quad\checkmark}.
\]

勾号表示 **computer-assisted analytic proof candidate**。
