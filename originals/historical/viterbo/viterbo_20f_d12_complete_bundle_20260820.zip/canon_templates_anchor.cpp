#include <bits/stdc++.h>
using namespace std;
using Row=array<signed char,6>;

string canon_anchor(const array<Row,10>& A){
    vector<int> singles;
    for(int i=0;i<10;i++){int zc=0;for(int j=0;j<6;j++)zc+=(A[i][j]==0);if(zc==1)singles.push_back(i);} 
    if(singles.empty()) throw runtime_error("no single row");
    string best(60,'9');
    for(int ai:singles){
        int z=-1; vector<int> oth;
        for(int j=0;j<6;j++) if(A[ai][j]==0) z=j; else oth.push_back(j);
        sort(oth.begin(),oth.end());
        do{
            for(int fz : {-1,1}){
                int orig[6]; orig[0]=z; for(int k=0;k<5;k++)orig[k+1]=oth[k];
                int flip[6]; flip[z]=fz; for(int j=0;j<6;j++)if(j!=z)flip[j]=A[ai][j];
                array<Row,10>B;
                for(int i=0;i<10;i++){
                    Row r{};
                    for(int k=0;k<6;k++)r[k]=A[i][orig[k]]*flip[orig[k]];
                    int f=0;while(f<6&&!r[f])f++;
                    if(f<6&&r[f]<0)for(auto&x:r)x=-x;
                    B[i]=r;
                }
                sort(B.begin(),B.end());
                string key;key.reserve(60);for(auto&r:B)for(auto x:r)key.push_back(char('1'+x));
                if(key<best)best=move(key);
            }
        }while(next_permutation(oth.begin(),oth.end()));
    }
    return best;
}

int main(){ios::sync_with_stdio(false);cin.tie(nullptr);int id;string s;while(cin>>id>>s){array<Row,10>A;int z=0;for(int i=0;i<10;i++)for(int j=0;j<6;j++)A[i][j]=(signed char)(s[z++]-'1');cout<<id<<' '<<canon_anchor(A)<<'\n';}}
