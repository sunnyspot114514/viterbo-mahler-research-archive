#!/usr/bin/env python3
"""Exact artifact verifier for 12V/22F,c=0,D=17 preclassification."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
CERT=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_preclassification_verifier_output.json')

def sha(p):
 h=hashlib.sha256();
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def bareiss(a):
 m=[list(map(int,r)) for r in a];n=len(m);sg=1;prev=1
 for k in range(n-1):
  if m[k][k]==0:
   q=next((i for i in range(k+1,n) if m[i][k]),None)
   if q is None:return 0
   m[k],m[q]=m[q],m[k];sg=-sg
  piv=m[k][k]
  for i in range(k+1,n):
   for j in range(k+1,n):
    z=m[i][j]*piv-m[i][k]*m[k][j];assert z%prev==0;m[i][j]=z//prev
  prev=piv
  for i in range(k+1,n):m[i][k]=0
 return sg*m[-1][-1]
def facets(rows):
 out=[]
 for r in rows:
  f=frozenset(j+1 if x>0 else -(j+1) for j,x in enumerate(r) if x)
  out.extend([f,frozenset(-x for x in f)])
 return list(dict.fromkeys(out))
def combinatorics(rows):
 fs=facets(rows);assert len(fs)==22;vs=sorted(set().union(*fs));assert vs==list(range(-6,0))+list(range(1,7))
 edges=[]
 for a,b in itertools.combinations(vs,2):
  if a==-b:continue
  cc=[f for f in fs if a in f and b in f]
  if not cc:continue
  q=set(cc[0])
  for f in cc[1:]:q&=f
  if q=={a,b}:edges.append((a,b))
 deg={v:0 for v in vs}
 for a,b in edges:deg[a]+=1;deg[b]+=1
 high={v for v,z in deg.items() if z>=5};nons=[f for f in fs if len(f)==5]
 ns={v:sum(v in f for f in nons) for v in vs};fh=[sum(v in high for v in f) for f in fs]
 return {'vertex_ok':all(z>=3 for z in ns.values()),'facet_ok':all(z>=3 for z in fh),'min_ns':min(ns.values()),'min_facet_high':min(fh)}
def verify_minor(rows,c):
 rr,cc=c['rows'],c['cols'];m=[[rows[i][j] for j in cc] for i in rr];zp=[(i,j) for i in range(5) for j in range(5) if m[i][j]==0];assert len(zp)==c['zero_count'];vals=[]
 for corner in itertools.product((-1,1),repeat=len(zp)):
  a=[r[:] for r in m]
  for z,(i,j) in zip(corner,zp):a[i][j]=z
  vals.append(bareiss(a))
 assert sorted(vals)==sorted(c['corner_dets']);nz=[z for z in vals if z]
 assert nz and (all(z>0 for z in nz) or all(z<0 for z in nz))
def main():
 d=json.loads(CERT.read_text());assert d['global_templates']==2395;assert d['classification']=={'algebraic_survivor':121,'rank_ge_5':2274};assert len(d['records'])==2395
 assert d['guberman_filter']['classification']=={'facet_fail':225,'pass':3031,'vertex_fail':9571}
 keys=set();cnt=Counter()
 for i,r in enumerate(d['records']):
  assert r['canonical_id']==i;key=r['canonical_key'];assert len(key)==66 and key not in keys;keys.add(key)
  rows=r['rows'];assert [ord(ch)-49 for ch in key]==[x for row in rows for x in row]
  assert sorted(sum(x==0 for x in row) for row in rows)==[1]*5+[2]*6
  co=combinatorics(rows);assert co['vertex_ok'] and co['facet_ok']
  cnt[r['status']]+=1
  if r['status']=='rank_ge_5':verify_minor(rows,r['minor_certificate'])
  else:assert r['status']=='algebraic_survivor'
 assert dict(cnt)==d['classification']
 result={'status':'PASS','scope':d['scope'],'global_templates':2395,'classification':dict(cnt),'remaining_survivors':121,'source_certificate':str(CERT),'source_certificate_sha256':sha(CERT)}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
