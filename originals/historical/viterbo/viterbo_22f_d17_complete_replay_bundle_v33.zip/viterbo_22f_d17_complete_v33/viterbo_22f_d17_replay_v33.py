#!/usr/bin/env python3
"""Integrity and optional exact rebuild driver for D=17 completion v33."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "viterbo_22f_d17_progress_manifest_v33.json"
OUT = ROOT / "viterbo_22f_d17_replay_output_v33.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def run(script: str, timeout: int = 1800) -> None:
    path = ROOT / script
    completed = subprocess.run(
        [sys.executable, str(path)],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if completed.returncode != 0:
        raise AssertionError(
            {
                "script": script,
                "returncode": completed.returncode,
                "stdout_tail": completed.stdout[-6000:],
                "stderr_tail": completed.stderr[-6000:],
            }
        )


def verify_manifest() -> dict:
    manifest = json.loads(MANIFEST.read_text())
    assert manifest["status"] == "PASS"
    checked = 0
    total_bytes = 0
    for name, record in manifest["files"].items():
        path = ROOT / name
        assert path.is_file(), name
        assert path.stat().st_size == record["bytes"], name
        assert sha256(path) == record["sha256"], name
        checked += 1
        total_bytes += path.stat().st_size
    return {
        "manifest_sha256": sha256(MANIFEST),
        "files_checked": checked,
        "bytes_checked": total_bytes,
    }


def verify_semantics() -> dict:
    pre = json.loads(
        (ROOT / "viterbo_22f_d17_preclassification_verifier_output.json").read_text()
    )
    shadow = json.loads(
        (ROOT / "viterbo_22f_d17_shadow_batch_verifier_output.json").read_text()
    )
    family = json.loads(
        (ROOT / "viterbo_22f_d17_family1656_verifier_output.json").read_text()
    )
    accounting = json.loads(
        (ROOT / "viterbo_22f_d17_progress_accounting_verifier_output_v16.json").read_text()
    )
    status = json.loads(
        (ROOT / "viterbo_bounded12_status_20260903_v33.json").read_text()
    )

    assert pre["status"] == "PASS"
    assert pre["global_templates"] == 2395
    assert pre["remaining_survivors"] == 121

    assert shadow["status"] == "PASS"
    assert shadow["shadow_nonminimal_count"] == 31
    assert shadow["unmatched_ids"] == [1656]

    assert family["status"] == "PASS"
    assert family["canonical_id"] == 1656
    assert family["rank"] == 4
    assert family["strict_defects"] == 17
    assert family["primal_vertices"] == 12
    assert family["polar_vertices"] == 22
    assert family["tetrahedra_primal"] == 36
    assert family["tetrahedra_polar"] == 77
    assert family["margin_certificate"]["numerator"] == {
        "degree": [4, 5, 4],
        "positive": 136,
        "zero": 14,
        "min_positive": "4",
    }
    assert family["margin_certificate"]["denominator"] == {
        "degree": [2, 2, 2],
        "positive": 27,
        "zero": 0,
        "min_positive": "9",
    }

    assert accounting["status"] == "PASS"
    assert accounting["Mahler_positive_exact_total"] == 25
    assert accounting["shadow_nonminimal_total"] == 31
    assert accounting["remaining"] == 0
    assert accounting["total_pairing_templates"] == 2395
    assert accounting["survivor_level_total"] == 121

    frontier = status["frontier"]
    assert status["status"] == "bounded-12 finite core closed as a computer-assisted analytic proof candidate"
    assert frontier["remaining"] == 0
    assert frontier["remaining_ids"] == []
    assert frontier["accounting"]["total"] == 2395
    assert frontier["accounting"]["shadow_flow_nonminimal"] == 31
    assert frontier["accounting"]["Mahler_positive_exact"] == 25
    assert status["bounded12_closed"] is True

    return {
        "preclassification": "PASS",
        "shadow_nonminimal": 31,
        "exact_family": 1656,
        "Mahler_positive_exact_total": 25,
        "remaining": 0,
        "bounded12_finite_core": "closed proof candidate",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--rebuild",
        action="store_true",
        help="rerun exact verifiers before integrity/semantic checks",
    )
    args = parser.parse_args()

    if args.rebuild:
        if ROOT != Path("/mnt/data"):
            raise AssertionError(
                "The exact scripts use /mnt/data as artifact root; "
                "copy/extract the payload there before --rebuild."
            )
        run("viterbo_22f_d17_preclassification_verifier.py", timeout=900)
        # v16 itself reruns shadow_batch and Family 1656.
        run("viterbo_22f_d17_progress_accounting_verifier_v16.py", timeout=1800)

    integrity = verify_manifest()
    semantics = verify_semantics()
    result = {
        "status": "PASS",
        "rebuild": bool(args.rebuild),
        **integrity,
        **semantics,
        "scope_warning": (
            "D=17 and bounded-12 are computer-assisted analytic proof "
            "candidates; the unrestricted 4D symmetric Mahler conjecture "
            "still needs a complexity-independent reduction theorem."
        ),
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
