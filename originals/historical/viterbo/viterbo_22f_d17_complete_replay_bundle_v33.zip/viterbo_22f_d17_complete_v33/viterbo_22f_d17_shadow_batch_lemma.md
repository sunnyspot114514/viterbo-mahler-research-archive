# 四维六顶点对的 circuit-collinearity shadow 引理

**用途：** 四维中心对称 Mahler 猜想的 bounded-12 分支，尤其是

\[
12V/22F,\qquad c=0,\qquad D=17.
\]

**证明状态：** computer-assisted analytic proof candidate。有限组合前提由配套 exact verifier 从原始 canonical pairing templates 重建；解析部分写在本文中。尚未经过外部同行审阅或独立实现复核。

---

## 1. 设置

令

\[
P=\operatorname{conv}\{\pm v_1,\ldots,\pm v_6\}\subset\mathbb R^4
\]

是满维中心对称多胞体，六个正向 representatives 记成

\[
V=(v_1\ \cdots\ v_6)\in\mathbb R^{4\times6},
\qquad \operatorname{rank}V=4.
\]

考虑平行于非零方向 \(\theta\in\mathbb R^4\) 的中心对称 shadow movement：

\[
v_j(t)=v_j+t a_j\theta,
\qquad
-v_j(t)=-v_j-t a_j\theta,
\]

其中

\[
a=(a_1,\ldots,a_6)\in\mathbb R^6
\]

是 odd speed vector。

由线性坐标变化产生的平凡 speeds 为

\[
T_\theta
=
\{(w\cdot v_1,\ldots,w\cdot v_6):w\in\mathbb R^4\}.
\]

因为 \(v_1,\ldots,v_6\) 张成 \(\mathbb R^4\)，有

\[
\dim T_\theta=4.
\]

本层的 11 对 facets 中有五对五顶点 facets 和六对 tetrahedral facets。tetrahedron 在固定方向 shadow 下自动保持仿射三维，不产生 speed constraint。可能需要约束的非单纯 faces 只有：

1. 五顶点三维 facets；
2. 两个五顶点 facets 共有的 quadrilateral ridges。

---

## 2. 五顶点 facet 的 kernel circuit

设五顶点 facet \(F\) 省略第 \(j\) 个 antipodal vertex pair，并取其中一个有向代表

\[
F=\operatorname{conv}\{\varepsilon_kv_k:k\ne j\},
\qquad \varepsilon_k\in\{\pm1\}.
\]

这五个点在一个不经过原点的三维支撑超平面内仿射张成。它们存在唯一到比例的 affine circuit

\[
\sum_{k\ne j}\lambda_k\varepsilon_kv_k=0,
\qquad
\sum_{k\ne j}\lambda_k=0.
\]

定义六维 circuit row

\[
(r_F)_j=0,
\qquad
(r_F)_k=\lambda_k\varepsilon_k\quad(k\ne j).
\]

于是

\[
r_F\in\ker V.
\]

五个 columns \(\{v_k:k\ne j\}\) 线性张成 \(\mathbb R^4\)，因此

\[
\boxed{
\ker V\cap\{z_j=0\}=\mathbb Rr_F.
}
\]

当 \(\theta\) 不平行于 \(F\) 时，移动后的五点继续共超平面的充要条件是 speed 在这五点上为 affine function，即

\[
\boxed{r_F\cdot a=0.}
\]

当 \(\theta\parallel F\) 时，所有移动仍位于原支撑超平面方向内，该 facet 不产生约束。

### 直接推论：相同 missing pair

若两个五顶点 facets 省略同一 vertex pair \(j\)，它们的 circuit rows 都生成

\[
\ker V\cap\{z_j=0\},
\]

所以二者严格成比例。

---

## 3. Quadrilateral ridge 也会识别两条 circuit lines

设两个五顶点 facets \(F_j,F_k\) 共有一个 quadrilateral ridge \(R\)。它的四个 signed vertices 省略 vertex pairs \(j,k\)，并在一个不经过原点的二维 affine plane 中张成。其唯一 affine circuit 延拓为

\[
0\ne r_R\in
\ker V\cap\{z_j=z_k=0\}.
\]

另一方面，

\[
r_R\in\ker V\cap\{z_j=0\}=\mathbb Rr_{F_j},
\]

且

\[
r_R\in\ker V\cap\{z_k=0\}=\mathbb Rr_{F_k}.
\]

因此

\[
\boxed{
\mathbb Rr_{F_j}=\mathbb Rr_R=\mathbb Rr_{F_k}.
}
\]

所以两种纯组合机制都能证明五顶点 facet circuits 共线：

- 两个 facets 省略同一 vertex pair；
- 两个 facets 共有 quadrilateral ridge。

以五个 single-defect facet pairs 为 vertices，把上述两种关系作为 edges，得到 **circuit-collinearity graph**。

---

## 4. 一条 graph edge 给出至少五维 admissible speed space

假设 circuit-collinearity graph 至少有一条 edge。取同一非平凡 connected component 中的两个 facet pairs \(F_p,F_q\) 保留，把其余三个五顶点 facet pairs 记为

\[
F_{i_1},F_{i_2},F_{i_3}.
\]

选择

\[
0\ne\theta\in
\operatorname{lin}(F_{i_1}-F_{i_1})
\cap
\operatorname{lin}(F_{i_2}-F_{i_2})
\cap
\operatorname{lin}(F_{i_3}-F_{i_3}).
\]

这是三个三维线性超平面在 \(\mathbb R^4\) 中的交，因此维数至少为一。

三个与 \(\theta\) 平行的五顶点 facets 不产生约束。未被丢弃的两个 facet constraints 共线，只留下至多一条独立方程。

还需检查 quadrilateral ridges：

- 若 ridge 的两个 incident facet pairs 都属于被设为平行的三个，则 \(\theta\) 位于两条 facet direction hyperplanes 的交，也就是 ridge direction plane；该 ridge 不产生约束。
- 若 ridge 至少接触一个未平行 facet，它在 graph 中把两个 incident facets 放进同一个 circuit-collinearity component；其 circuit constraint 与保留的唯一 circuit line 共线。

因此全部非单纯 faces 合起来仍只有至多一条独立 speed equation。记对称 admissible speed space 为 \(A^s_\theta(P)\)，则

\[
\boxed{
\dim A^s_\theta(P)\ge6-1=5.
}
\]

由于 \(\dim T_\theta=4\)，存在非平凡 symmetric admissible speed。

---

## 5. 四维 merged-boundary persistence 与体积仿射性

这里补上把三维 admissible-movement 思路用于当前四维多胞体所需的局部几何环节。

对 \(P\) 的 boundary 取一个 global pulling triangulation \(\mathcal T\)，并让它在每个 facet 及 quadrilateral ridge 上相容。所有五顶点 facets 和 quadrilateral ridges 的 affine dependencies 由上述 speed equations 保持；与 \(\theta\) 平行的 faces 则保持在原 affine direction 中。

因此，对充分小的正负 \(t\)：

1. 每个原非单纯 face 的 pulling subdivision 仍落在同一个相应 affine hull 中；
2. 原来非零的有限多个 simplex orientation determinants 依连续性保持符号；
3. incident/nonincident vertex 的严格支撑不等式保持；
4. 有限 PL complex \(\mathcal T\) 的 straight-line realization 保持为嵌入的中心对称三维球，并仍是 \(P_t\) 的 boundary triangulation。

这一步只使用有限个严格条件的 openness；允许某些顶点在扰动后失去 extremality，因为

\[
P_t=\operatorname{conv}\{\pm v_1(t),\ldots,\pm v_6(t)\}
\]

始终有至多 12 个 vertices，仍留在 bounded-12 竞争类中。

把每个 boundary tetrahedron 与原点作锥。对任意四个 moving vertices，行列式

\[
\det(v_{j_1}+ta_{j_1}\theta,\ldots,
     v_{j_4}+ta_{j_4}\theta)
\]

是 \(t\) 的 affine function：所有二次及更高项都至少含两列平行的 \(\theta\)，因而行列式为零。小区间内 orientation signs 固定，故固定锥分解给出

\[
\boxed{|P_t|=|P_0|+tL(a)}
\]

其中 \(L\) 是 speed 的线性泛函。

---

## 6. 从五维 speeds 取出非平凡 constant-volume shadow

平凡 speed \(a_w=(w\cdot v_j)_{j=1}^6\) 对应线性 shear

\[
P_t=(I+t\,\theta\otimes w)P_0.
\]

所以

\[
L(a_w)=|P_0|\,w\cdot\theta.
\]

由于 \(\theta\ne0\)，\(L\) 在四维平凡空间 \(T_\theta\) 上不是零泛函，因而

\[
\dim(T_\theta\cap\ker L)=3.
\]

另一方面，

\[
\dim(A^s_\theta(P)\cap\ker L)
\ge5-1=4.
\]

所以可选择

\[
a\in A^s_\theta(P)\cap\ker L,
\qquad a\notin T_\theta.
\]

对应 shadow 在一个双侧小区间上满足

\[
\boxed{|P_t|\equiv|P_0|}
\]

而且不是 affine-trivial movement。

---

## 7. 局部 Mahler 极小者排除

Meyer--Reisner 的 shadow-system 定理对任意维成立：对中心对称 shadow system，原点是 Santaló point，且

\[
t\longmapsto |P_t^\circ|^{-1}
\]

为 convex function。其 equality characterization 表明：若该函数在非退化区间上线性到足以产生内部最大值的 equality 情形，则 shadow system 必须由沿 \(\theta\) 的 affine shears 生成；在当前 odd-speed 表示中，这等价于

\[
a\in T_\theta.
\]

若 \(P_0\) 是至多 12 vertices 的中心对称四维多胞体类中的局部 Mahler 极小者，那么 constant-volume shadow 上

\[
|P_t||P_t^\circ|=|P_0|\,|P_t^\circ|
\]

在 \(t=0\) 有局部最小值。于是 convex function \(|P_t^\circ|^{-1}\) 在区间内部有局部最大值，只能在邻域内为常数。equality rigidity 随即强制 movement affine-trivial，与所选

\[
a\notin T_\theta
\]

矛盾。

因此得到统一结论：

\[
\boxed{
\text{circuit-collinearity graph 有 edge}
\Longrightarrow
P\text{ 不可能是 bounded-12 局部 Mahler 极小者}.}
\]

该结论是局部极小者排除，不声称该 family 内每个点都满足一张显式 pointwise Bernstein margin certificate。

---

## 8. 对 D=17 剩余 32 个 templates 的应用

配套 verifier 从 v32 的 32 个 remaining canonical templates 重建五个 single-defect facets、它们省略的 vertex pairs，以及全部四顶点 facet intersections。

结果：

- 30 个 templates 直接存在相同 missing vertex pair；
- Family `961` 的五个 missing pairs 虽互异，但其中两对五顶点 facets 共有 quadrilateral ridge，因此仍产生 graph edge；
- 唯一没有 graph edge 的 template 是 Family `1656`。

所以

\[
\boxed{31\text{ 个 templates 被统一排除为 bounded-class 局部极小者}.}
\]

Family `1656` 必须另行处理。其 exact rank branch 和 pointwise Mahler certificate 由独立 verifier 完成，不依赖本引理。

---

## 9. 外部理论接口

使用的外部一般性输入是：

1. Meyer and Reisner, *Shadow systems and volumes of polar convex bodies*, Mathematika 53 (2006), 129--148：polar-volume reciprocal convexity及 equality structure；
2. Meyer, Reisner and Schmuckenschläger, *The volume of the polar of a convex body and related problems*, Monatsh. Math. 126 (1998), 231--243：更早的 shadow-system polar convexity框架；
3. Alexander, Fradelizi and Zvavitch, *Polytopes of maximal volume product*, Discrete Comput. Geom. 62 (2019), 583--600：admissible movement、affine speed 与局部 extremizer 的线性代数接口；
4. Fradelizi, Langharst, Madiman and Zvavitch, *Weighted Brunn--Minkowski Theory II: Inequalities for Mixed Measures and Applications*, Math. Ann. 395 (2026), 319--393：Theorem 5.13 给出适用于一般 measures 的 reciprocal polar shadow convexity，Lebesgue 情形回收本处所需结论。

本文没有把三维 polytope 的 simple-edge 计数原样外推到四维；四维所需的部分由 Sections 2--6 的 kernel-circuit、merged-boundary persistence 和 constant-volume dimension argument单独给出。
