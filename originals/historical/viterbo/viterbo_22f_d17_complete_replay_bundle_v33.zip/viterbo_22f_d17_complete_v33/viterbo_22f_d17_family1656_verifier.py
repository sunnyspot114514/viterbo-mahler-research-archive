#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 1656.

The verifier reconstructs the unique strict rank-four branch from the original
pairing template, proves that its full strict realization space is the open
cube (-1,1)^3, certifies the primal/polar combinatorics, derives exact volumes
from fixed-sign global pulling triangulations, and proves the Mahler margin by
tensor-Bernstein positivity.
"""
from __future__ import annotations

import hashlib
import importlib.util
import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

ROOT = Path('/mnt/data')
PRE = ROOT / 'viterbo_22f_d17_preclassification_certificate.json'
CERT = ROOT / 'viterbo_22f_d17_family1656_certificate.json'
OUT = ROOT / 'viterbo_22f_d17_family1656_verifier_output.json'
CID = 1656

spec = importlib.util.spec_from_file_location(
    'base', ROOT / 'viterbo_22f_d17_family768_verifier.py'
)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

spec2 = importlib.util.spec_from_file_location(
    'gbase', ROOT / 'viterbo_22f_d17_family2060_verifier.py'
)
gbase = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(gbase)


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def factorized_positive(
    expression: sp.Expr,
    chart: dict[sp.Symbol, sp.Expr],
    engine,
    sample_original: dict[sp.Symbol, sp.Rational],
    label: str,
) -> dict:
    """Prove a rational expression positive by certifying each factor."""
    expression = sp.factor(sp.cancel(expression))
    assert sp.N(expression.subs(sample_original)) > 0, (
        label,
        expression.subs(sample_original),
        expression,
    )
    numerator, denominator = map(
        sp.factor, sp.together(expression).as_numer_denom()
    )
    records = []
    total_sign = sp.Rational(1)
    for side, polynomial, exponent_sign in [
        ('numerator', numerator, 1),
        ('denominator', denominator, -1),
    ]:
        coefficient, factors = sp.factor_list(polynomial)
        side_sign = 1 if coefficient > 0 else -1
        record = {
            'side': side,
            'coefficient': str(coefficient),
            'factors': [],
        }
        for factor, multiplicity in factors:
            pulled_back = sp.factor(sp.cancel(factor.subs(chart)))
            value = sp.N(pulled_back.subs(engine.sample))
            assert value != 0, (label, side, factor, pulled_back)
            sign = 1 if value > 0 else -1
            factor_certificate = engine.positive_rational(
                sign * pulled_back,
                f'{label} {side} factor',
            )
            record['factors'].append(
                {
                    'factor': str(factor),
                    'multiplicity': int(multiplicity),
                    'sign': int(sign),
                    'certificate': factor_certificate,
                }
            )
            if multiplicity % 2:
                side_sign *= sign
        record['sign'] = side_sign
        records.append(record)
        total_sign *= side_sign**exponent_sign
    assert total_sign > 0, (label, total_sign, expression)
    return {'factorized': True, 'records': records}


def proportional_member(expressions, target: sp.Expr) -> str:
    target = sp.factor(target)
    for expression in expressions:
        ratio = sp.factor(sp.cancel(expression / target))
        if ratio.is_Rational and ratio != 0:
            return str(ratio)
    raise AssertionError(('target equation not found', target))


def build_branch() -> dict:
    data = json.loads(PRE.read_text())
    record = data['records'][CID]
    assert record['status'] == 'algebraic_survivor'
    rows = record['rows']

    matrix = sp.zeros(11, 6)
    variables: list[sp.Symbol] = []
    names: dict[str, sp.Symbol] = {}
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            if value == 0:
                variable = sp.Symbol(f'x{i}_{j}', real=True)
                matrix[i, j] = variable
                variables.append(variable)
                names[str(variable)] = variable
            else:
                matrix[i, j] = value

    # This pivot contains defect entries, but its determinant is identically 8.
    pivot_rows = (2, 4, 5, 7)
    pivot_cols = (1, 2, 4, 5)
    pivot = matrix.extract(pivot_rows, pivot_cols)
    assert sp.factor(pivot.det(method='domain-ge')) == 8

    other_rows = [i for i in range(11) if i not in pivot_rows]
    other_cols = [j for j in range(6) if j not in pivot_cols]
    schur = (
        matrix.extract(other_rows, other_cols)
        - matrix.extract(other_rows, pivot_cols)
        * pivot.inv()
        * matrix.extract(pivot_rows, other_cols)
    )
    equations = [sp.factor(sp.cancel(value)) for value in schur]

    constant_solution, unsolved, reduced, constant_trace = (
        base.constant_eliminate(equations, variables)
    )
    assert sorted(map(str, unsolved)) == sorted(
        [
            'x0_1',
            'x10_1',
            'x10_4',
            'x1_1',
            'x2_0',
            'x3_4',
            'x5_4',
            'x6_2',
            'x7_3',
            'x8_1',
            'x9_1',
        ]
    )

    relation = sp.factor(
        (names['x7_3'] - 1)
        * (
            2 * names['x3_4']
            + names['x5_4'] * names['x6_2']
            - names['x5_4']
            - names['x6_2']
            - 1
        )
    )
    reduced_numerators = [
        sp.factor(sp.together(value).as_numer_denom()[0])
        for value in reduced
    ]
    relation_ratio = proportional_member(reduced_numerators, relation)

    # x7_3 is a strict defect, hence x7_3<1 and the second factor vanishes.
    a, b, c = sp.symbols('a b c', real=True)
    x34 = sp.factor((-a * b + a + b + 1) / 2)
    stage = dict(constant_solution)
    stage.update(
        {
            names['x5_4']: a,
            names['x6_2']: b,
            names['x7_3']: c,
            names['x3_4']: x34,
        }
    )
    reduced2 = [base.apply_all(value, stage) for value in reduced]
    reduced2 = [sp.factor(value) for value in reduced2 if value != 0]
    unknown = sorted(
        set().union(*(value.free_symbols for value in reduced2)) - {a, b, c},
        key=str,
    )
    assert list(map(str, unknown)) == [
        'x0_1',
        'x10_1',
        'x10_4',
        'x1_1',
        'x2_0',
        'x8_1',
        'x9_1',
    ]
    numerators = [
        sp.factor(sp.together(value).as_numer_denom()[0])
        for value in reduced2
    ]
    groebner = sp.groebner(
        numerators,
        *unknown,
        order='lex',
        domain=sp.QQ.frac_field(a, b, c),
    )
    assert groebner.is_zero_dimensional
    assert len(groebner.polys) == 7

    dplus = sp.factor(
        a * b * c - a * b + a * c - a - b * c + b - c + 9
    )
    dminus = sp.factor(
        a * b * c + a * b - a * c - a + b * c + b - c - 9
    )
    completion = {
        names['x0_1']: sp.factor(
            (
                a * b * c
                - a * b
                - 3 * a * c
                + 3 * a
                - b * c
                + b
                + 3 * c
                + 5
            )
            / dplus
        ),
        names['x10_1']: sp.factor(
            -(
                a * b * c**2
                - a * b * c
                + a * c**2
                - a * c
                + b * c**2
                + b * c
                - 2 * b
                + c**2
                + c
                + 6
            )
            / dplus
        ),
        names['x10_4']: sp.factor(
            (a * b * c + a * b + a * c + a + b * c + b + c - 3)
            / 4
        ),
        names['x1_1']: sp.factor(
            -(
                a * b * c
                - a * b
                + a * c
                - a
                - b * c
                + b
                - 9 * c
                + 1
            )
            / dplus
        ),
        names['x2_0']: sp.factor(
            -(
                a * b * c
                + a * b
                + 3 * a * c
                - 5 * a
                + b * c
                + b
                + 3 * c
                + 3
            )
            / dminus
        ),
        names['x8_1']: sp.factor(
            -(
                a * b * c
                - a * b
                - 3 * a * c
                + 3 * a
                - b * c
                + b
                - 5 * c
                - 3
            )
            / dplus
        ),
        names['x9_1']: sp.factor(
            (
                a * b * c
                - a * b
                + a * c
                - a
                + 3 * b * c
                + 5 * b
                + 3 * c
                - 3
            )
            / dplus
        ),
    }
    for polynomial in groebner.polys:
        assert (
            sp.factor(sp.cancel(polynomial.as_expr().subs(completion))) == 0
        )

    stage.update(completion)
    full_solution = {
        variable: base.apply_all(variable, stage) for variable in variables
    }
    assert all(
        not (value.free_symbols & set(variables))
        for value in full_solution.values()
    )
    completed = matrix.subs(full_solution).applyfunc(
        lambda value: sp.factor(sp.cancel(value))
    )
    assert all(
        sp.factor(sp.cancel(value.subs(full_solution))) == 0
        for value in equations
    )

    return {
        'record': record,
        'rows': rows,
        'original': matrix,
        'variables': variables,
        'completed': completed,
        'free': (a, b, c),
        'pivot_rows': pivot_rows,
        'pivot_cols': pivot_cols,
        'constant_trace': constant_trace,
        'relation': relation,
        'relation_ratio': relation_ratio,
        'groebner': groebner,
        'completion': {names['x3_4']: x34, **completion},
        'dplus': dplus,
        'dminus': dminus,
    }


def main() -> None:
    branch = build_branch()
    record = branch['record']
    rows = branch['rows']
    variables = branch['variables']
    completed0 = branch['completed']
    a, b, c = branch['free']
    pivot_rows = branch['pivot_rows']
    pivot_cols = branch['pivot_cols']

    A, B, C = sp.symbols('A B C', real=True)
    chart = {a: 2 * A - 1, b: 2 * B - 1, c: 2 * C - 1}
    cube_variables = (A, B, C)
    sample_cube = {
        A: sp.Rational(1, 2),
        B: sp.Rational(1, 2),
        C: sp.Rational(1, 2),
    }
    sample_original = {a: 0, b: 0, c: 0}
    engine = base.SignEngine(cube_variables, sample_cube)

    coefficient_certificates = {
        'one_plus_a': engine.positive_rational((a + 1).subs(chart), 'a+1'),
        'one_minus_a': engine.positive_rational((1 - a).subs(chart), '1-a'),
        'one_plus_b': engine.positive_rational((b + 1).subs(chart), 'b+1'),
        'one_minus_b': engine.positive_rational((1 - b).subs(chart), '1-b'),
        'one_plus_c': engine.positive_rational((c + 1).subs(chart), 'c+1'),
        'one_minus_c': engine.positive_rational((1 - c).subs(chart), '1-c'),
        'dplus': engine.positive_rational(
            branch['dplus'].subs(chart), 'dplus'
        ),
        'minus_dminus': engine.positive_rational(
            (-branch['dminus']).subs(chart), '-dminus'
        ),
    }

    # Since a,b,c themselves are original defects, strictness forces the cube.
    # Conversely, certify all 17 original defect inequalities on the cube.
    defect_certificates = {}
    for variable in variables:
        i, j = map(int, str(variable)[1:].split('_'))
        defect_certificates[str(variable)] = factorized_positive(
            1 - completed0[i, j] ** 2,
            chart,
            engine,
            sample_original,
            'defect ' + str(variable),
        )
    assert len(defect_certificates) == 17

    completed = completed0.subs(chart).applyfunc(
        lambda value: sp.factor(sp.cancel(value))
    )
    pivot = completed.extract(pivot_rows, pivot_cols)
    assert sp.factor(pivot.det(method='domain-ge')) == 8
    vertex_matrix = (
        pivot.inv() * completed.extract(pivot_rows, range(6))
    ).applyfunc(lambda value: sp.factor(sp.cancel(value)))
    facet_matrix = completed.extract(range(11), pivot_cols)
    assert all(
        sp.factor(value) == 0
        for value in facet_matrix * vertex_matrix - completed
    )

    extremality = []
    for vertex_pair in range(6):
        incident = [
            i for i in range(11) if rows[i][vertex_pair] != 0
        ]
        witness = None
        for selected_rows in itertools.combinations(incident, 4):
            determinant = sp.factor(
                sp.cancel(
                    facet_matrix.extract(
                        selected_rows, range(4)
                    ).det(method='domain-ge')
                )
            )
            if determinant == 0:
                continue
            sample_value = determinant.subs(sample_cube)
            if sample_value == 0:
                continue
            sign = 1 if sample_value > 0 else -1
            try:
                certificate = factorized_positive(
                    sign * determinant,
                    {},
                    engine,
                    sample_cube,
                    f'extremality {vertex_pair}',
                )
            except AssertionError:
                continue
            witness = {
                'vertex_pair': vertex_pair,
                'facet_rows': list(selected_rows),
                'determinant': str(determinant),
                'sign': sign,
                'certificate': certificate,
            }
            break
        assert witness is not None, vertex_pair
        extremality.append(witness)

    code = np.array(rows, dtype=int)
    primal_facets = []
    for i in range(11):
        primal_facets += [
            sorted(
                j if code[i, j] == 1 else j + 6
                for j in range(6)
                if code[i, j]
            ),
            sorted(
                j + 6 if code[i, j] == 1 else j
                for j in range(6)
                if code[i, j]
            ),
        ]
    polar_facets = []
    for j in range(6):
        polar_facets += [
            sorted(
                i if code[i, j] == 1 else i + 11
                for i in range(11)
                if code[i, j]
            ),
            sorted(
                i + 11 if code[i, j] == 1 else i
                for i in range(11)
                if code[i, j]
            ),
        ]

    numeric_vertices = np.array(vertex_matrix.subs(sample_cube), dtype=float)
    numeric_facets = np.array(facet_matrix.subs(sample_cube), dtype=float)
    points_primal = np.vstack([numeric_vertices.T, -numeric_vertices.T])
    points_polar = np.vstack([numeric_facets, -numeric_facets])
    assert len(ConvexHull(points_primal).vertices) == 12
    assert len(ConvexHull(points_polar).vertices) == 22

    tetrahedra_primal, primal_ridges = (
        gbase.global_boundary_triangulation(primal_facets, points_primal)
    )
    tetrahedra_polar, polar_ridges = (
        gbase.global_boundary_triangulation(polar_facets, points_polar)
    )
    assert len(tetrahedra_primal) == 36
    assert len(tetrahedra_polar) == 77
    primal_boundary = base.check_closed_sphere(tetrahedra_primal)
    polar_boundary = base.check_closed_sphere(tetrahedra_polar)
    primal_facet_tetrahedra = base.check_facet_balls(
        tetrahedra_primal, primal_facets
    )
    polar_facet_tetrahedra = base.check_facet_balls(
        tetrahedra_polar, polar_facets
    )

    def primal_point(index: int) -> sp.Matrix:
        return (
            vertex_matrix[:, index]
            if index < 6
            else -vertex_matrix[:, index - 6]
        )

    def polar_point(index: int) -> sp.Matrix:
        return (
            facet_matrix[index, :].T
            if index < 11
            else -facet_matrix[index - 11, :].T
        )

    def oriented(tetrahedra, point, label: str):
        positive_terms = []
        records = []
        for index, ids in enumerate(tetrahedra):
            determinant = sp.factor(
                sp.cancel(
                    sp.Matrix.hstack(
                        *[point(i) for i in ids]
                    ).det(method='domain-ge')
                )
            )
            assert determinant != 0, (label, index, ids)
            sample_value = determinant.subs(sample_cube)
            assert sample_value != 0, (label, index, ids)
            sign = 1 if sample_value > 0 else -1
            certificate = factorized_positive(
                sign * determinant,
                {},
                engine,
                sample_cube,
                f'{label} tetrahedron {index}',
            )
            positive_terms.append(sp.factor(sign * determinant))
            records.append(
                {
                    'ids': list(ids),
                    'signed_determinant': str(determinant),
                    'sign': sign,
                    'certificate': certificate,
                }
            )
        return positive_terms, records

    primal_terms, primal_orientation_records = oriented(
        tetrahedra_primal, primal_point, 'primal'
    )
    polar_terms, polar_orientation_records = oriented(
        tetrahedra_polar, polar_point, 'polar'
    )
    volume_primal = sp.factor(
        sp.cancel(sp.together(sum(primal_terms)) / 24)
    )
    volume_polar = sp.factor(
        sp.cancel(sp.together(sum(polar_terms)) / 24)
    )
    mahler_margin = sp.factor(
        sp.cancel(
            sp.together(
                volume_primal * volume_polar - sp.Rational(32, 3)
            )
        )
    )
    margin_certificate = engine.positive_rational(
        mahler_margin, 'Mahler margin'
    )
    assert margin_certificate == {
        'numerator': {
            'degree': [4, 5, 4],
            'positive': 136,
            'zero': 14,
            'min_positive': '4',
        },
        'denominator': {
            'degree': [2, 2, 2],
            'positive': 27,
            'zero': 0,
            'min_positive': '9',
        },
    }

    certificate = {
        'status': 'PASS',
        'scope': (
            '4D symmetric Mahler bounded-12; '
            '12V/22F,c=0,D=17 Family 1656'
        ),
        'canonical_id': CID,
        'canonical_key': record['canonical_key'],
        'source_local_id': record['source_local_id'],
        'rank': 4,
        'rank_branch': {
            'pivot_rows': list(pivot_rows),
            'pivot_cols': list(pivot_cols),
            'pivot_determinant': 8,
            'pivot_note': (
                'The pivot contains defects but its determinant is '
                'identically the nonzero constant 8.'
            ),
            'strict_relation': (
                '2*x3_4+x5_4*x6_2-x5_4-x6_2-1=0 because '
                '(x7_3-1) times this factor is zero and x7_3<1'
            ),
            'relation_equation': str(branch['relation']),
            'relation_ratio': branch['relation_ratio'],
            'constant_elimination_steps': branch['constant_trace'],
            'groebner_length': len(branch['groebner'].polys),
            'completion': {
                str(key): str(value)
                for key, value in branch['completion'].items()
            },
        },
        'parameter_domain': {
            'original': '-1<a,b,c<1',
            'free_parameters': {
                'a': 'x5_4',
                'b': 'x6_2',
                'c': 'x7_3',
            },
            'unit_cube_chart': {
                str(key): str(value) for key, value in chart.items()
            },
            'inverse': {
                'A': str((a + 1) / 2),
                'B': str((b + 1) / 2),
                'C': str((c + 1) / 2),
            },
            'necessity': (
                'a,b,c are original strict defects; all other defects '
                'are uniquely completed and certified strict on the cube.'
            ),
        },
        'coefficient_certificates': coefficient_certificates,
        'strict_defects': len(defect_certificates),
        'defect_certificates': defect_certificates,
        'primal_vertices': 12,
        'polar_vertices': 22,
        'extremality': extremality,
        'facet_size_counts_primal': dict(Counter(map(len, primal_facets))),
        'facet_size_counts_polar': dict(Counter(map(len, polar_facets))),
        'primal_boundary': primal_boundary,
        'polar_boundary': polar_boundary,
        'primal_ridge_sizes': dict(Counter(map(len, primal_ridges))),
        'polar_ridge_sizes': dict(Counter(map(len, polar_ridges))),
        'primal_facet_tetrahedra': primal_facet_tetrahedra,
        'polar_facet_tetrahedra': polar_facet_tetrahedra,
        'tetrahedra_primal': len(tetrahedra_primal),
        'tetrahedra_polar': len(tetrahedra_polar),
        'orientation_records_primal': primal_orientation_records,
        'orientation_records_polar': polar_orientation_records,
        'volume_P': str(volume_primal),
        'volume_polar': str(volume_polar),
        'Mahler_margin': str(mahler_margin),
        'margin_certificate': margin_certificate,
        'fixed_sign_polynomials': len(engine.cache),
        'source_hashes': {str(PRE): sha256(PRE)},
        'conclusion': (
            'Family 1656 has Mahler product >32/3 throughout its full '
            'strict realization space.'
        ),
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    output = {
        'status': 'PASS',
        'canonical_id': CID,
        'rank': 4,
        'strict_defects': len(defect_certificates),
        'primal_vertices': 12,
        'polar_vertices': 22,
        'tetrahedra_primal': len(tetrahedra_primal),
        'tetrahedra_polar': len(tetrahedra_polar),
        'volume_P': str(volume_primal),
        'volume_polar': str(volume_polar),
        'Mahler_margin': str(mahler_margin),
        'margin_certificate': margin_certificate,
        'certificate': str(CERT),
        'certificate_sha256': sha256(CERT),
        'conclusion': certificate['conclusion'],
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
