#!/usr/bin/env python3
"""Exact combinatorial verifier for the D=17 circuit-collinearity shadow batch.

The program checks the finite hypotheses of the analytic shadow lemma:
for 31 of the 32 v32 survivors, two of the five single-defect facet pairs
have proportional Gale-kernel circuit lines, forced either by a repeated
missing vertex pair or by a common quadrilateral ridge.

The theorem interface (small-time merged-boundary shadow persistence plus
Meyer--Reisner polar reciprocal convexity/equality rigidity) is documented in
viterbo_22f_d17_shadow_batch_lemma.md.  This script does not treat that
analytic theorem as a black-box numerical test; it verifies every finite
combinatorial premise to which the theorem is applied.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path('/mnt/data')
PRE = ROOT / 'viterbo_22f_d17_preclassification_certificate.json'
STATUS = ROOT / 'viterbo_bounded12_status_20260903_v32.json'
CERT = ROOT / 'viterbo_22f_d17_shadow_batch_certificate.json'
OUT = ROOT / 'viterbo_22f_d17_shadow_batch_verifier_output.json'
LEMMA = ROOT / 'viterbo_22f_d17_shadow_batch_lemma.md'
EXPECTED_UNMATCHED = [1656]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def actual_facets(rows: list[list[int]]) -> list[dict]:
    facets: list[dict] = []
    for row_index, row in enumerate(rows):
        positive = frozenset(
            (column + 1 if value > 0 else -(column + 1))
            for column, value in enumerate(row)
            if value
        )
        assert len(positive) in (4, 5)
        facets.append(
            {'row': row_index, 'sign': 1, 'vertices': positive}
        )
        facets.append(
            {
                'row': row_index,
                'sign': -1,
                'vertices': frozenset(-vertex for vertex in positive),
            }
        )
    assert len(facets) == 22
    assert len({facet['vertices'] for facet in facets}) == 22
    return facets


def relation_record(rows: list[list[int]]) -> dict:
    assert len(rows) == 11 and all(len(row) == 6 for row in rows)
    defect_profile = sorted(row.count(0) for row in rows)
    assert defect_profile == [1] * 5 + [2] * 6

    single_rows = [i for i, row in enumerate(rows) if row.count(0) == 1]
    missing = {i: rows[i].index(0) for i in single_rows}
    edges: list[dict] = []

    # If two 5-vertex facets omit the same antipodal vertex pair j, both
    # affine-circuit rows lie in the one-dimensional line
    # ker(V) cap {z_j=0}.
    for first, second in itertools.combinations(single_rows, 2):
        if missing[first] == missing[second]:
            edges.append(
                {
                    'kind': 'same_missing_column',
                    'rows': [first, second],
                    'missing_columns': [missing[first]],
                }
            )

    # A 4-vertex intersection of two distinct 5-vertex facets is a
    # quadrilateral ridge in any genuine strict realization.  Its affine
    # circuit has both omitted coordinates zero, and hence identifies the
    # two corresponding facet-circuit lines.
    facets = actual_facets(rows)
    quadrilateral_ridges: list[dict] = []
    seen_ridge_orbits: set[tuple] = set()
    for first, second in itertools.combinations(facets, 2):
        if first['row'] == second['row']:
            continue
        intersection = first['vertices'] & second['vertices']
        if len(intersection) != 4:
            continue
        row_pair = tuple(sorted((first['row'], second['row'])))
        if row_pair[0] not in single_rows or row_pair[1] not in single_rows:
            raise AssertionError(
                ('four-vertex facet intersection outside single rows', row_pair)
            )
        absolute_vertices = tuple(sorted(abs(v) for v in intersection))
        orbit_key = (row_pair, absolute_vertices)
        if orbit_key in seen_ridge_orbits:
            continue
        seen_ridge_orbits.add(orbit_key)
        omitted_columns = sorted(
            set(range(6)) - {abs(v) - 1 for v in intersection}
        )
        # If the two facets have distinct missing columns, the ridge omits
        # exactly those two pairs.  If they already share one missing column,
        # the second omitted pair comes from the opposite signs on their
        # fifth vertices.  In both cases the ridge circuit lies on both
        # facet-circuit lines.
        assert set(
            [missing[row_pair[0]], missing[row_pair[1]]]
        ) <= set(omitted_columns)
        ridge = {
            'rows': list(row_pair),
            'representative_vertices': sorted(intersection),
            'omitted_columns': omitted_columns,
        }
        quadrilateral_ridges.append(ridge)
        edges.append(
            {
                'kind': 'quadrilateral_ridge',
                'rows': list(row_pair),
                'missing_columns': [
                    missing[row_pair[0]],
                    missing[row_pair[1]],
                ],
                'ridge_omitted_columns': omitted_columns,
            }
        )

    # Circuit-collinearity components generated by the two exact mechanisms.
    adjacency = {row: set() for row in single_rows}
    for edge in edges:
        first, second = edge['rows']
        adjacency[first].add(second)
        adjacency[second].add(first)

    unseen = set(single_rows)
    components: list[list[int]] = []
    while unseen:
        root = min(unseen)
        unseen.remove(root)
        stack = [root]
        component: list[int] = []
        while stack:
            current = stack.pop()
            component.append(current)
            for neighbour in sorted(adjacency[current]):
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    stack.append(neighbour)
        components.append(sorted(component))
    components.sort(key=lambda component: (-len(component), component))

    witness = None
    if components and len(components[0]) >= 2:
        # Keep two collinear constraints.  Make theta parallel to the other
        # three single-defect facets.  The intersection of three direction
        # hyperplanes in R^4 is nonzero.
        kept_rows = components[0][:2]
        parallel_rows = sorted(set(single_rows) - set(kept_rows))
        assert len(parallel_rows) == 3
        witness = {
            'collinear_component': components[0],
            'kept_rows': kept_rows,
            'theta_parallel_facet_rows': parallel_rows,
            'constraint_rank_upper_bound': 1,
            'symmetric_speed_dimension_lower_bound': 5,
            'trivial_speed_dimension': 4,
        }

    return {
        'single_rows': single_rows,
        'single_missing_columns': {
            str(row): missing[row] for row in single_rows
        },
        'relation_edges': edges,
        'quadrilateral_ridges': quadrilateral_ridges,
        'circuit_collinearity_components': components,
        'witness': witness,
    }


def main() -> None:
    preclassification = json.loads(PRE.read_text())
    status = json.loads(STATUS.read_text())
    assert preclassification['global_templates'] == 2395
    assert preclassification['classification'] == {
        'algebraic_survivor': 121,
        'rank_ge_5': 2274,
    }
    remaining = status['frontier']['remaining_ids']
    assert len(remaining) == 32

    records: list[dict] = []
    matched: list[int] = []
    unmatched: list[int] = []
    for canonical_id in remaining:
        source = preclassification['records'][canonical_id]
        assert source['canonical_id'] == canonical_id
        assert source['status'] == 'algebraic_survivor'
        record = relation_record(source['rows'])
        record.update(
            {
                'canonical_id': canonical_id,
                'canonical_key': source['canonical_key'],
                'source_local_id': source['source_local_id'],
            }
        )
        records.append(record)
        if record['witness'] is None:
            unmatched.append(canonical_id)
        else:
            matched.append(canonical_id)

    assert unmatched == EXPECTED_UNMATCHED
    assert len(matched) == 31
    assert set(matched).isdisjoint(unmatched)
    assert sorted(matched + unmatched) == sorted(remaining)

    certificate = {
        'status': 'PASS',
        'scope': (
            '4D symmetric Mahler bounded-12; '
            '12V/22F,c=0,D=17 circuit-collinearity shadow batch'
        ),
        'scope_warning': (
            'The 31 classifications are bounded-class local-minimizer '
            'exclusions, not pointwise Mahler inequalities.  The analytic '
            'interface is a proof candidate and has not been externally '
            'peer reviewed.'
        ),
        'theorem_interface': {
            'vertex_pairs': 6,
            'ambient_dimension': 4,
            'single_defect_facet_pairs': 5,
            'input_speed_dimension': 6,
            'trivial_affine_speed_dimension': 4,
            'mechanism': (
                'A repeated omitted vertex pair or a quadrilateral ridge '
                'forces two five-facet circuit lines in ker(V) to coincide. '
                'Choose theta parallel to the other three five-facets; after '
                'preserving the certified merged boundary, at most one '
                'independent speed constraint remains, so dim A_theta^s>=5. '
                'A constant-volume nontrivial speed then contradicts '
                'Meyer-Reisner equality rigidity at a local minimum.'
            ),
            'analytic_lemma_file': str(LEMMA),
            'analytic_lemma_sha256': sha256(LEMMA),
        },
        'input_remaining_ids': remaining,
        'shadow_nonminimal_ids': matched,
        'unmatched_ids': unmatched,
        'shadow_nonminimal_count': len(matched),
        'unmatched_count': len(unmatched),
        'records': records,
        'source_hashes': {
            str(PRE): sha256(PRE),
            str(STATUS): sha256(STATUS),
        },
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    output = {
        'status': 'PASS',
        'shadow_nonminimal_count': len(matched),
        'shadow_nonminimal_ids': matched,
        'unmatched_count': len(unmatched),
        'unmatched_ids': unmatched,
        'certificate': str(CERT),
        'certificate_sha256': sha256(CERT),
        'analytic_lemma_sha256': sha256(LEMMA),
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
