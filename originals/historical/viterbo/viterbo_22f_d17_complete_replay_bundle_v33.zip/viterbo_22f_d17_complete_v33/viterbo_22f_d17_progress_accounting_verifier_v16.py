#!/usr/bin/env python3
"""Aggregate exact/theorem-interface verifier closing the D=17 frontier.

This verifier re-runs:
  * the 31-family circuit-collinearity shadow batch checker; and
  * the standalone pointwise exact verifier for Family 1656.
It then checks disjointness and both accounting levels against v15/v32.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path('/mnt/data')
OLD = ROOT / 'viterbo_22f_d17_progress_accounting_certificate_v15.json'
OLD_STATUS = ROOT / 'viterbo_bounded12_status_20260903_v32.json'
PRE = ROOT / 'viterbo_22f_d17_preclassification_certificate.json'
SHADOW_SCRIPT = ROOT / 'viterbo_22f_d17_shadow_batch_verifier.py'
SHADOW_CERT = ROOT / 'viterbo_22f_d17_shadow_batch_certificate.json'
SHADOW_OUT = ROOT / 'viterbo_22f_d17_shadow_batch_verifier_output.json'
SHADOW_LEMMA = ROOT / 'viterbo_22f_d17_shadow_batch_lemma.md'
FAMILY_ID = 1656
FAMILY_SCRIPT = ROOT / f'viterbo_22f_d17_family{FAMILY_ID}_verifier.py'
FAMILY_CERT = ROOT / f'viterbo_22f_d17_family{FAMILY_ID}_certificate.json'
FAMILY_OUT = ROOT / f'viterbo_22f_d17_family{FAMILY_ID}_verifier_output.json'
CERT = ROOT / 'viterbo_22f_d17_progress_accounting_certificate_v16.json'
OUT = ROOT / 'viterbo_22f_d17_progress_accounting_verifier_output_v16.json'


def sha(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sign_fraction(value: str) -> int:
    number = Fraction(str(value))
    return 1 if number > 0 else -1 if number < 0 else 0


def check_basis(record: dict) -> None:
    expected = 1
    for degree in record['degree']:
        expected *= degree + 1
    assert record['positive'] > 0
    assert record['positive'] + record['zero'] == expected
    assert Fraction(record['min_positive']) > 0


def check_positive_certificate(certificate: dict) -> None:
    if 'numerator' in certificate:
        check_basis(certificate['numerator'])
        check_basis(certificate['denominator'])
        return
    assert certificate.get('factorized') is True
    side_signs = {}
    for record in certificate['records']:
        total = sign_fraction(record['coefficient'])
        assert total != 0
        for factor in record['factors']:
            check_basis(factor['certificate']['numerator'])
            check_basis(factor['certificate']['denominator'])
            assert factor['sign'] in (-1, 1)
            assert factor['multiplicity'] >= 1
            total *= factor['sign'] ** factor['multiplicity']
        assert total == record['sign']
        side_signs[record['side']] = total
    assert set(side_signs) == {'numerator', 'denominator'}
    assert side_signs['numerator'] == side_signs['denominator']


def rerun(command: list[str], timeout: int = 900) -> None:
    completed = subprocess.run(
        command,
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if completed.returncode != 0:
        raise AssertionError(
            {
                'command': command,
                'returncode': completed.returncode,
                'stdout_tail': completed.stdout[-5000:],
                'stderr_tail': completed.stderr[-5000:],
            }
        )


def main() -> None:
    old = json.loads(OLD.read_text())
    old_status = json.loads(OLD_STATUS.read_text())
    pre = json.loads(PRE.read_text())
    assert old['status'] == 'PASS'
    assert old_status['status'] == 'computer-assisted analytic proof candidate'
    assert old['total_pairing_templates'] == 2395
    assert old['remaining_ids'] == old_status['frontier']['remaining_ids']
    assert len(old['remaining_ids']) == 32
    assert pre['classification']['algebraic_survivor'] == 121

    rerun([sys.executable, str(SHADOW_SCRIPT)])
    shadow = json.loads(SHADOW_CERT.read_text())
    shadow_output = json.loads(SHADOW_OUT.read_text())
    assert shadow['status'] == shadow_output['status'] == 'PASS'
    assert shadow_output['certificate_sha256'] == sha(SHADOW_CERT)
    assert shadow_output['analytic_lemma_sha256'] == sha(SHADOW_LEMMA)
    shadow_ids = shadow['shadow_nonminimal_ids']
    assert shadow_ids == shadow_output['shadow_nonminimal_ids']
    assert len(shadow_ids) == 31
    assert shadow['unmatched_ids'] == shadow_output['unmatched_ids'] == [FAMILY_ID]

    rerun([sys.executable, str(FAMILY_SCRIPT)])
    family = json.loads(FAMILY_CERT.read_text())
    family_output = json.loads(FAMILY_OUT.read_text())
    assert family['status'] == family_output['status'] == 'PASS'
    assert family['canonical_id'] == family_output['canonical_id'] == FAMILY_ID
    assert family_output['certificate_sha256'] == sha(FAMILY_CERT)
    assert family_output['rank'] == 4
    assert family_output['strict_defects'] == 17
    assert family_output['primal_vertices'] == 12
    assert family_output['polar_vertices'] == 22
    assert family_output['tetrahedra_primal'] == 36
    assert family_output['tetrahedra_polar'] == 77
    check_positive_certificate(family['margin_certificate'])

    old_remaining = old['remaining_ids']
    assert sorted(shadow_ids + [FAMILY_ID]) == old_remaining
    assert not (set(shadow_ids) & {FAMILY_ID})
    remaining_ids: list[int] = []
    mahler_positive = sorted(
        set(old['Mahler_positive_exact_families']) | {FAMILY_ID}
    )
    assert len(mahler_positive) == 25
    assert not (set(mahler_positive) & set(shadow_ids))
    boundary = old['strict_rank4_boundary_or_interval_impossible']
    assert len(boundary) == 13

    disjoint = {
        'facet_containment': 1230,
        'rank_ge_5_after_antichain': 1070,
        'segment_loss_after_antichain': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler_positive),
        'strict_rank4_boundary_or_interval_impossible': len(boundary),
        'shadow_flow_nonminimal': len(shadow_ids),
        'remaining_algebraic_survivors': len(remaining_ids),
    }
    assert sum(disjoint.values()) == 2395
    survivor = {
        'initial': 121,
        'facet_containment': 26,
        'additional_segment_loss': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler_positive),
        'strict_rank4_boundary_or_interval_impossible': len(boundary),
        'shadow_flow_nonminimal': len(shadow_ids),
        'remaining': len(remaining_ids),
    }
    assert sum(value for key, value in survivor.items() if key != 'initial') == 121

    certificate = {
        'status': 'PASS',
        'scope': '4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17',
        'scope_warning': (
            'The 25 exact families have pointwise Mahler certificates. '
            'The 31 shadow-flow families are theorem-dependent exclusions '
            'from the location of a bounded-class local minimum, not '
            'pointwise Mahler inequalities. All claims remain '
            'computer-assisted analytic proof candidates without external '
            'peer review.'
        ),
        'total_pairing_templates': 2395,
        'disjoint_classification': disjoint,
        'survivor_level_accounting': survivor,
        'Mahler_positive_exact_families': mahler_positive,
        'strict_rank4_boundary_or_interval_impossible': boundary,
        'shadow_flow_nonminimal_families': shadow_ids,
        'remaining_ids': remaining_ids,
        'newly_closed': {
            'Mahler_positive_exact': [FAMILY_ID],
            'shadow_flow_nonminimal': shadow_ids,
        },
        'theorem_interfaces': {
            'shadow_batch': {
                'analytic_lemma': str(SHADOW_LEMMA),
                'analytic_lemma_sha256': sha(SHADOW_LEMMA),
                'combinatorial_certificate': str(SHADOW_CERT),
                'combinatorial_certificate_sha256': sha(SHADOW_CERT),
                'summary': shadow['theorem_interface'],
            },
            'interpretation': (
                'This is a minimizer-based closure of the bounded finite '
                'class, of the same logical kind as the earlier D=19 '
                'structural exclusion. It does not assert pointwise '
                'positivity for the 31 shadow families.'
            ),
        },
        'rerun_results': {
            'shadow_batch': {
                'status': 'PASS',
                'count': len(shadow_ids),
                'script_sha256': sha(SHADOW_SCRIPT),
                'certificate_sha256': sha(SHADOW_CERT),
                'output_sha256': sha(SHADOW_OUT),
                'lemma_sha256': sha(SHADOW_LEMMA),
            },
            str(FAMILY_ID): {
                'status': 'PASS',
                'rank': 4,
                'strict_defects': 17,
                'primal_vertices': 12,
                'polar_vertices': 22,
                'tetrahedra_primal': 36,
                'tetrahedra_polar': 77,
                'margin_certificate': family['margin_certificate'],
                'script_sha256': sha(FAMILY_SCRIPT),
                'certificate_sha256': sha(FAMILY_CERT),
                'output_sha256': sha(FAMILY_OUT),
            },
        },
        'source_hashes': {
            str(OLD): sha(OLD),
            str(OLD_STATUS): sha(OLD_STATUS),
            str(PRE): sha(PRE),
        },
        'conclusion': (
            'No D=17 pairing template remains as a possible minimizer in '
            'the bounded-12 class; the D=17 layer is closed as a '
            'computer-assisted analytic proof candidate.'
        ),
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    result = {
        'status': 'PASS',
        'new_exact_family': [FAMILY_ID],
        'new_shadow_nonminimal': shadow_ids,
        'Mahler_positive_exact_total': len(mahler_positive),
        'shadow_nonminimal_total': len(shadow_ids),
        'remaining': 0,
        'total_pairing_templates': 2395,
        'survivor_level_total': 121,
        'certificate': str(CERT),
        'certificate_sha256': sha(CERT),
        'conclusion': certificate['conclusion'],
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
