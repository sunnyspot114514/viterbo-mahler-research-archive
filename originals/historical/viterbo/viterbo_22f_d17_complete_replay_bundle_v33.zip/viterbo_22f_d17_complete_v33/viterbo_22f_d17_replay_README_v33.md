# D=17 complete replay bundle v33

This bundle closes the remaining `12V/22F,c=0,D=17` frontier as a
**computer-assisted analytic proof candidate**.

It contains two new proof components:

1. a combinatorial/circuit verifier certifying that 31 of the 32 v32
   survivors satisfy the hypotheses of the accompanying shadow-flow
   local-minimizer exclusion lemma;
2. a standalone exact verifier proving Family 1656 has Mahler product
   strictly greater than `32/3` throughout its full strict realization cube.

The aggregate v16 verifier checks both components against the v15/v32 chain,
checks category disjointness, and proves that the D=17 remaining count is zero.

## Integrity replay

After extraction, run:

```bash
python viterbo_22f_d17_replay_v33.py
```

This checks every payload byte against the v33 manifest and checks the stored
PASS outputs semantically.

## Full rebuild

The exact verifiers currently use `/mnt/data` as their artifact root. Extract
or copy the bundle contents into `/mnt/data`, then run:

```bash
cd /mnt/data
python viterbo_22f_d17_replay_v33.py --rebuild
```

The rebuild reruns the preclassification verifier and the v16 aggregate
verifier. The aggregate verifier itself reruns the shadow-batch and Family
1656 standalone verifiers. It then repeats the manifest and semantic checks.

The nested v32 replay ZIP is included as the immediately preceding hash-chain
checkpoint.

## Scope

The 31 shadow classifications are **bounded-class local-minimizer exclusions**,
not pointwise Mahler inequalities for every realization in those families.
Family 1656 is a pointwise exact Mahler-positive closure. External peer review
and an independent implementation are still absent. Closing bounded-12 does
not by itself prove the unrestricted four-dimensional symmetric Mahler
conjecture; a complexity-independent finite-core/bi-shadow-rigidity bridge is
still required.
