# Family 1656：唯一 full-cube rank-4 分支及严格 Mahler 余量

**层级：** 四维中心对称 Mahler 猜想的 bounded-12 有限核心，`12V/22F, c=0, D=17`  
**canonical family：** `1656`  
**source local matching：** `2479`  
**状态：** `PASS`（computer-assisted analytic proof candidate；尚未经过外部同行审阅）

## 1. 严格 rank-4 分支

从原始 preclassification certificate 读取 Family 1656 的 `11×6` pairing matrix。选取 zero-indexed rows

\[
(2,4,5,7)
\]

与 columns

\[
(1,2,4,5)
\]

构成 pivot。该 pivot 含有 defect entries，但 determinant 恒等于非零常数

\[
\boxed{\det P=8}.
\]

Schur complement 与八步常系数消元以后，剩余 rank 方程包含

\[
(x_{7,3}-1)
\bigl(2x_{3,4}+x_{5,4}x_{6,2}-x_{5,4}-x_{6,2}-1\bigr)=0.
\]

因为 `x_{7,3}` 是严格 defect，故 `x_{7,3}<1`。因此严格分支必须满足

\[
2x_{3,4}+x_{5,4}x_{6,2}-x_{5,4}-x_{6,2}-1=0.
\]

令

\[
a=x_{5,4},\qquad b=x_{6,2},\qquad c=x_{7,3}.
\]

则

\[
\boxed{x_{3,4}=\frac{-ab+a+b+1}{2}}.
\]

剩余 determinantal ideal 在 \(\mathbb Q(a,b,c)\) 上零维，lex Gröbner basis 长度为 `7`。它给出唯一的三参数有理 completion：

\[
x_{0,1}
=
\frac{abc-ab-3ac+3a-bc+b+3c+5}
{abc-ab+ac-a-bc+b-c+9},
\]

\[
x_{10,1}
=
-\frac{abc^2-abc+ac^2-ac+bc^2+bc-2b+c^2+c+6}
{abc-ab+ac-a-bc+b-c+9},
\]

\[
x_{10,4}
=
\frac{abc+ab+ac+a+bc+b+c-3}{4},
\]

\[
x_{1,1}
=
-\frac{abc-ab+ac-a-bc+b-9c+1}
{abc-ab+ac-a-bc+b-c+9},
\]

\[
x_{2,0}
=
-\frac{abc+ab+3ac-5a+bc+b+3c+3}
{abc+ab-ac-a+bc+b-c-9},
\]

\[
x_{8,1}
=
-\frac{abc-ab-3ac+3a-bc+b-5c-3}
{abc-ab+ac-a-bc+b-c+9},
\]

\[
x_{9,1}
=
\frac{abc-ab+ac-a+3bc+5b+3c-3}
{abc-ab+ac-a-bc+b-c+9}.
\]

其余六个 dependent defects 由常系数消元轨迹唯一恢复。完整解代回所有原始 Schur equations 后均恒等于零。

## 2. 完整严格 realization space

Family 1656 的三个自由参数本身就是原始 defects，所以任何严格 realization 必须满足

\[
-1<a,b,c<1.
\]

反向包含也成立。使用单位开立方体 chart

\[
a=2A-1,\qquad b=2B-1,\qquad c=2C-1,
\qquad0<A,B,C<1,
\]

verifier 对全部 `17` 个原始 defects 逐项证明

\[
1-x_{ij}^{\,2}>0.
\]

每一项均使用因子化 rational tensor-Bernstein 定号证书。completion 中两个非平凡公共分母

\[
D_+=abc-ab+ac-a-bc+b-c+9
\]

与

\[
D_-=abc+ab-ac-a+bc+b-c-9
\]

也分别获得

\[
D_+>0,\qquad -D_->0
\]

的全立方体证书。因此 Gröbner solve 没有在严格域内丢失 denominator-zero 分支。

于是完整参数域精确为

\[
\boxed{-1<a,b,c<1}.
\]

## 3. 组合闭包

由 pivot 得到 exact rank factorization \(X=FV\)。六个正向 primal representatives 均有四条 incident facet normals 形成的固定符号非零 determinant witness，因此

\[
\boxed{f_0(P)=12}.
\]

从 pairing template 构造 22 个 primal facets 与 12 个 polar facets，并使用 ridge-compatible global pulling triangulation：

- primal facet-size distribution：`12` 个四顶点 facets、`10` 个五顶点 facets；
- polar facet-size distribution：`4` 个六顶点、`4` 个八顶点、`4` 个十顶点 facets；
- primal boundary：`36` 个 tetrahedra；
- polar boundary：`77` 个 tetrahedra。

边界复形分别满足

\[
(f_0,f_1,f_2,f_3)(P)=(12,48,72,36),
\]

\[
(f_0,f_1,f_2,f_3)(P^\circ)=(22,99,154,77).
\]

所有 `36+77` 个 simplex determinants 都在整个参数立方体上得到严格定号证书；closed-sphere、facet-ball 与 ridge compatibility 检查均通过。故不存在隐藏的 facet 增减或 oriented-matroid chamber switch，并且

\[
\boxed{f_0(P^\circ)=22}.
\]

## 4. Mahler 余量

固定边界 triangulation 给出精确体积。令

\[
q_0=ABC-AB-AC+A-BC+B+C+1,
\]

\[
q_1=ABC-AB+AC-A-BC+B-C+2,
\]

\[
q_2=ABC+AB-AC-A+BC+B-C-2.
\]

verifier 得到

\[
|P|
=
-\frac{8P_0(A,B,C)}{3q_0q_1q_2},
\]

\[
|P^\circ|
=
-\frac{8P_1(A,B,C)}{3q_1},
\]

其中完整多项式 \(P_0,P_1\) 记录在机器证书中。最终

\[
|P|\,|P^\circ|-\frac{32}{3}
=
\frac{N(A,B,C)}{Q(A,B,C)}.
\]

分子 tensor-Bernstein degree 为

\[
\boxed{(4,5,4)}.
\]

全部 `150` 个 coefficients 满足

\[
\boxed{136>0,\qquad14=0,\qquad0<0},
\]

最小正系数为

\[
\boxed{4}.
\]

分母 degree 为

\[
\boxed{(2,2,2)}.
\]

全部 `27` 个 coefficients 都严格为正：

\[
\boxed{27>0,\qquad0=0,\qquad0<0},
\]

最小系数为

\[
\boxed{9}.
\]

因此整个严格 realization space 中

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

## 5. 结论

\[
\boxed{\text{Family }1656\quad\checkmark}
\]

这是一项 pointwise exact closure：严格 realization space 中的每个 polytope 都被证明具有严格正 Mahler 余量。该结论与另外 31 个 families 的 shadow-flow local-minimizer exclusion 合并后，将 `D=17` 的剩余数从 `32` 降为 `0`。
