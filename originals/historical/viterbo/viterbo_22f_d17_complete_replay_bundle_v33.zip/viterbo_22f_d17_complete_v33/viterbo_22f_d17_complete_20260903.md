# `12V/22F,c=0,D=17` 完整关闭：统一 shadow 排除与 Family 1656 exact closure

**日期：** 2026-09-03  
**状态：** `PASS`（computer-assisted analytic proof candidate；尚未经过外部同行审阅）

# 一、本轮结果

这轮没有继续逐个计算剩余 32 个 family 的体积，而是建立了一个统一的

\[
\boxed{\text{circuit-collinearity shadow exclusion}}
\]

引理。它一次性排除 `31` 个 family 作为 bounded-12 类内的局部 Mahler 极小者。唯一未被统一图判据捕获的 Family `1656` 又获得完整 pointwise exact certificate：

\[
\boxed{\text{Family }1656\quad\checkmark}.
\]

因此

\[
\boxed{
12V/22F,\qquad c=0,\qquad D=17:
\qquad32\longrightarrow0.
}
\]

结合已经关闭的 `D=19` 与 `D=18`，整个 `12V/22F` 层关闭。进一步结合此前的 `12F,14F,16F,18F,20F` 层，当前 bounded-12 finite core 完整关闭为一个计算机辅助解析证明候选。

# 二、统一 circuit-collinearity shadow 引理

设一个 genuine strict realization 写成

\[
P=\operatorname{conv}\{\pm v_1,\ldots,\pm v_6\}\subset\mathbb R^4,
\qquad \operatorname{rank}(v_1,\ldots,v_6)=4.
\]

`D=17` 的模板含五对五顶点 facets 与六对 tetrahedral facets。对一条五顶点 facet pair，设其正向 facet 缺失顶点对 `j`。该 facet 的唯一 affine circuit 诱导一个非零向量

\[
r_F\in\ker V,\qquad (r_F)_j=0,
\]

其中 \(V=(v_1\ \cdots\ v_6)\)。由于其余五个顶点向量张成 \(\mathbb R^4\)，有

\[
\ker V\cap\{z_j=0\}=\mathbb R r_F.
\]

于是两种离散关系都会迫使两条 facet-circuit 共线：

1. 两条五顶点 facets 缺失同一个顶点对；
2. 两条五顶点 facets 共享一个四边形 ridge。此时 ridge circuit 同时在两个相应 coordinate-zero lines 中，所以两条 facet-circuit 仍共线。

在五条 single-defect rows 上建立图：出现上述任一关系便连边。若图中有边，选取同一非平凡连通分量中的两条 facets，并让 shadow direction \(\theta\) 平行于其余三条五顶点 facets。三个 facet-direction hyperplanes 在 \(\mathbb R^4\) 中的交维数至少为 `1`，所以存在非零 \(\theta\)。

沿 \(\theta\) 的对称速度写作

\[
\alpha(v_j)=s_j,
\qquad
\alpha(-v_j)=-s_j.
\]

平行于 \(\theta\) 的 facets 不产生 planarity constraint；剩余 facet constraints 与可能留下的 quadrilateral-ridge constraints 全落在同一条 circuit line 上。因此六个速度变量至多受到一条独立线性约束：

\[
\dim A^s_\theta(P)\ge5.
\]

仿射平凡速度为

\[
s_j=w\cdot v_j,
\qquad w\in\mathbb R^4,
\]

其空间维数恰为 `4`。故存在非平凡 admissible speed。

## 常体积选择

在固定、与所有 facets 和 quadrilateral ridges 相容的边界 triangulation 上，每个 oriented 四维 simplex determinant 至多线性依赖参数 `t`，因为所有顶点都沿同一方向 \(\theta\) 移动。由小扰动下的支撑严格性、extremality 与非关联不等式保持，足够小的正负参数区间内同一 triangulation 仍给出边界，因此

\[
|P_t|=|P|+tL(s)
\]

是速度 \(s\) 的线性泛函。

仿射 shear

\[
P_t=(I+t\theta w^T)P
\]

对应平凡速度 \(s_j=w\cdot v_j\)，且

\[
L(s_w)=|P|\,w\cdot\theta.
\]

所以平凡常体积速度只有三维，而

\[
\dim(A^s_\theta(P)\cap\ker L)\ge4.
\]

从而可选取一个非平凡、常体积的 symmetric shadow flow。

Meyer--Reisner 的 shadow-system theorem 给出

\[
t\longmapsto |P_t^\circ|^{-1}
\]

为凸函数。若 \(P=P_0\) 是局部 Mahler 极小者，而 \(|P_t|\) 恒定，则这个凸函数在内点取得局部最大值，只能在一个邻域内为常数。其 equality-rigidity 又迫使整个 shadow 是仿射 shear，与速度的非平凡性矛盾。

因此：

\[
\boxed{
\text{只要五条 single-facet circuit 图含边，该模板便不可能承载 bounded-class 局部极小者。}
}
\]

# 三、31 个 family 的统一离散证书

对 v32 的 32 个剩余 canonical templates，exact combinatorial verifier 重建：

- 五条 single-defect rows；
- 每条 single row 缺失的 vertex-pair column；
- 22 个实际 facets；
- 所有由两 facets 的四顶点交得到的 quadrilateral ridges；
- circuit-collinearity 图的连通分量。

结果为：

- `30` 个 family 具有重复 missing column；
- Family `961` 的 missing columns 虽互异，但 rows `5,6` 共享 quadrilateral ridge，该 ridge 缺失 columns `4,5`（均为 zero-indexed）；
- Family `1656` 是唯一 graph-edgeless 例外。

统一排除的 31 个 canonical IDs 为：

```text
131, 961, 1260, 1623, 1654, 1759, 1770, 1943,
2055, 2056, 2070, 2080, 2120, 2191, 2199, 2234,
2236, 2249, 2257, 2263, 2269, 2272, 2274, 2344,
2358, 2364, 2368, 2382, 2387, 2391, 2394
```

combinatorial verifier 与 certificate 均返回 `PASS`。

# 四、Family 1656 的 pointwise exact closure

Family 1656 有一个 determinant 恒为 `8` 的含-defect pivot。strict rank equation 首先给出

\[
(x_{7,3}-1)
\bigl(2x_{3,4}+x_{5,4}x_{6,2}-x_{5,4}-x_{6,2}-1\bigr)=0.
\]

故严格分支满足

\[
x_{3,4}=\frac{-ab+a+b+1}{2},
\qquad
(a,b,c)=(x_{5,4},x_{6,2},x_{7,3}).
\]

lex Gröbner basis 长度为 `7`，其余 defects 唯一成为 \(a,b,c\) 的有理函数。完整 strict realization space 恰为

\[
\boxed{-1<a,b,c<1}.
\]

全部 `17` 个 defects、所有 completion denominators、六对 primal extremality witnesses，以及 `36` 个 primal 与 `77` 个 polar simplex determinants，均得到全立方体严格定号证书。因此

\[
f_0(P)=12,
\qquad
f_0(P^\circ)=22.
\]

Mahler margin 的 numerator tensor-Bernstein degree 为

\[
\boxed{(4,5,4)}.
\]

其 `150` 个 coefficients 满足

\[
\boxed{136>0,\qquad14=0,\qquad0<0},
\]

最小正系数为 `4`。denominator degree 为 `(2,2,2)`，全部 `27` 个 coefficients 严格为正，最小值为 `9`。故

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

贯穿 Family 1656 的完整严格域。

# 五、D=17 最终不重叠 accounting

全部 `2395` 个 canonical pairing templates 现在精确分为

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ 个 facet containment}\\
&+1070\text{ 个 antichain 内 rank}\ge5\\
&+22\text{ 个 segment vertex-loss}\\
&+4\text{ 个 duplicate/antipodal primal pair}\\
&+25\text{ 个 exact Mahler-positive families}\\
&+13\text{ 个 strict boundary/interval-impossible}\\
&+31\text{ 个 shadow-flow nonminimal}\\
&+0\text{ 个 remaining}.
\end{aligned}
}
\]

在最初 `121` 个 algebraic survivors 层面：

\[
\boxed{121=26+22+4+25+13+31+0}.
\]

aggregate verifier v16 重新运行 shadow batch verifier 与 Family 1656 standalone verifier，并核对类别互斥、输入/输出哈希以及两级总数。结果为

```json
{
  "status": "PASS",
  "Mahler_positive_exact_total": 25,
  "shadow_nonminimal_total": 31,
  "remaining": 0,
  "total_pairing_templates": 2395,
  "survivor_level_total": 121
}
```

# 六、方法意义与剩余全局缺口

统一 shadow 引理将 `31` 个连续 family 从逐族体积计算转化为一个离散 graph test。它给出的结论是“不能成为 bounded-class 局部极小者”，并非这 31 个 family 中每个 polytope 都已有 pointwise Mahler certificate。逻辑上它与此前 `D=19` 的局部极小者结构排除同型。

当前 bounded-12 finite core 因此已经完全关闭。但完整四维中心对称 Mahler 猜想仍缺一条 complexity-independent bridge：必须证明任意四维局部极小者都可约化到这个有限核心，或者直接证明任意高维交叉多胞体投影到四维都满足所需 Mahler 下界。

后者是目前最强的全局“一口气”路线。任意有限顶点的中心对称四维多胞体都是某个高维交叉多胞体的线性像；其极体等价于高维 cube 的四维 section。若能建立任意余维的 projection/section Mahler 不等式，再取 Hausdorff 极限即可覆盖任意中心对称凸体。现有一维 reduction 思路的关键缺口仍是高余维下所需的体积比较与 equality propagation。
