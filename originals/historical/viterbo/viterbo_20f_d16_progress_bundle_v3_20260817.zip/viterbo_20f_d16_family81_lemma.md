# Survivor 81 in the 12V/20F, c=0, D=16 layer

**Status.** Computer-assisted analytic proof candidate.

## Statement

Let the ten positive facet-pair rows of the pairing matrix be

\[
X=
\begin{pmatrix}
p-q-1&-r&1&-1&-1&-1\\
p&-r+s+1&1&-1&-1&1\\
q&1&-1&-1&-1&-1\\
\dfrac{pr+ps+qr-q+r-s-2}{r-1}&1&-1&-1&-\dfrac{r+2s+1}{r-1}&1\\
q&1&-1&1&-1&1\\
\dfrac{pr+p+qr-qs+r-s}{r+1}&1&-\dfrac{r-2s-1}{r+1}&-1&-1&1\\
1&\dfrac{pr+ps+p+qr-q-s-2}{p-1}&-1&-1&\dfrac{p+2q+1}{p-1}&1\\
1&r&-1&-1&1&-1\\
1&\dfrac{pr+ps+p-qs-q+r}{p+1}&-1&-\dfrac{p-2q-1}{p+1}&1&1\\
1&s&1&-1&1&1
\end{pmatrix}.
\]

On its complete strict realization domain, the associated centrally symmetric
4-polytope satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

## 1. Exact strict domain

Introduce barycentric variables

\[
A_0=\frac{p-q}{2},\quad B_0=-\frac{p+q}{2},\quad E=1+q,
\]

\[
C_0=\frac{r-s}{2},\quad D_0=-\frac{r+s}{2},\quad F=1+s.
\]

The basic strict inequalities say that

\[
A_0,B_0,E>0,\quad A_0+B_0+E=1,
\]

\[
C_0,D_0,F>0,\quad C_0+D_0+F=1.
\]

All remaining defect inequalities are automatic except

\[
EF<4B_0D_0.
\]

The entire domain is mapped bijectively to the open unit 4-cube by

\[
B_0=(1-A)U,\qquad E=(1-A)(1-U),
\]

\[
V=\frac{1-U+4UT}{1+3U},\qquad
D_0=(1-C)V,\qquad F=(1-C)(1-V),
\]

with

\[
0<A,C,U,T<1.
\]

Equivalently,

\[
p=A-(1-A)U,\qquad q=-A-(1-A)U,
\]

\[
r=C-(1-C)V,\qquad s=-C-(1-C)V.
\]

The only nontrivial inequality becomes

\[
EF-4B_0D_0=-4TU(A-1)(C-1)<0.
\]

All sixteen quantities \(1-x_{ij}^2\) have nonnegative tensor-Bernstein
coefficients on this cube and at least one positive coefficient.

## 2. Rank and primal extremality

Using rows \(2,4,7,9\) and columns \(2,3,4,5\) as a pivot gives

\[
\det X_{\{2,4,7,9\},\{2,3,4,5\}}=-8.
\]

The remaining rows reconstruct exactly from this pivot, so
\(\operatorname{rank}X=4\).

After the corresponding \(GL(4)\) normalization, columns \(2,3,4,5\) are the
standard basis. Supporting-normal determinants for the two nonfixed columns are

\[
\frac{2(U-1)}{(U+1)(AU+A-U+1)}
\]

and

\[
\frac{2U(T-1)(3U+1)}
{(2TU+U+1)(2CTU+CU+C-2TU+2U)}.
\]

Both are nonzero throughout the open cube. Hence all six antipodal vertex-pairs
remain genuine extreme points.

## 3. Exact section closure

All

\[
\binom64 2^4=240
\]

active-face charts were regenerated with exact rational functions. Their
classification is

\[
52\text{ expected occurrences}
+184\text{ strict cube violations}
+4\text{ special charts}.
\]

The 52 occurrences reduce to exactly twenty section vertices, namely the ten
listed rows and their antipodes.

For each of the 184 excluded charts, one inactive coordinate \(z\) has
\(1-z^2<0\); the opposite numerator has a nonnegative tensor-Bernstein
certificate. There are 88 distinct such numerator polynomials.

For the four exceptional charts, the two inactive coordinates differ in
absolute value by one of

\[
\frac{2(r+1)}{s+1}>2,
\qquad
\frac{2(p+1)}{q+1}>2.
\]

They therefore cannot both lie in \([-1,1]\). No extra section vertex exists.

## 4. Exact volumes and chamber certificate

A fixed sample triangulation consists of 31 primal and 68 polar tetrahedra.
There are 42 distinct nonzero determinant expressions. Every numerator and
denominator has a fixed tensor-Bernstein sign on the full parameter cube, and
each tetrahedron remains in its certified supporting facet. Consequently the
triangulations remain valid throughout the domain.

The resulting volumes are

\[
|P|=\frac{2(q+s+10)}{3},
\]

and

\[
|P^\circ|=
\frac{
12p^2r^2+p^2s^2+2p^2s-11p^2+q^2r^2-q^2+2qr^2-2q
-11r^2-s^2-2s+10
}{6(p^2-1)(r^2-1)}.
\]

## 5. Mahler positivity

After substitution of the unit-cube parametrization,

\[
|P||P^\circ|-\frac{32}{3}=\frac{H(A,C,T,U)}{D(A,C,T,U)},
\]

where

\[
\begin{aligned}
D={}&9(U+1)(3U+1)(2TU+U+1)\\
&\cdot\bigl((1-U)+A(1+U)\bigr)\\
&\cdot\bigl(C(2TU+U+1)+2U(1-T)\bigr)>0.
\end{aligned}
\]

The numerator \(H\) has tensor degree

\[
(2,2,3,6).
\]

Its 252 tensor-Bernstein coefficients satisfy

\[
153>0,\qquad99=0,\qquad0<0,
\]

with smallest positive coefficient

\[
\frac13.
\]

Every Bernstein basis function is positive in the open cube, hence
\(H>0\), proving

\[
\boxed{|P||P^\circ|>\frac{32}{3}}.
\]

## Verification artifacts

The master verifier checks rank, domain, all strict defects, primal extremality,
volume formulas and Mahler positivity. The 240 closure charts are independently
regenerated in three exact chunks and then aggregated by the master verifier.
All four verifier runs return `PASS`.
