# 12V/20F, c=0, D=16：survivor 81 关闭与 survivor 82 前置压缩

日期：2026-08-17

## 当前结论

20F、D=16 的预分类为

\[
92=72\text{ 个 rank}\ge5+6\text{ 个重复 facet-row}+14\text{ 个连续 survivors}.
\]

此前已经关闭 survivor 90 与 91。本轮又完整关闭 survivor 81，因此

\[
\boxed{3/14\text{ continuous survivors 已关闭}}
\]

并剩余 11 个 family。

所有“关闭”仍表示 **computer-assisted analytic proof candidate**，不是已经经过外部同行审阅的完整证明。

---

## Survivor 81

### 严格参数域

在两个开二维单纯形的 barycentric coordinates 中，唯一额外条件为

\[
EF<4BD.
\]

它可以有理且双射地映到单位开四维立方体

\[
0<A,C,U,T<1.
\]

全部 16 条 defect strict inequalities 都有 tensor-Bernstein 正证书。

### Section closure

全部 240 个 active-face charts 被拆成三个独立 exact chunks 重放：

\[
52\text{ expected}+184\text{ strict violations}+4\text{ special}=240.
\]

52 次出现去重为恰好 20 个 section vertices。四个特殊 chart 中，两个 inactive coordinates 的绝对差严格大于 2，所以不能同时位于 cube 内。

### 体积

\[
|P|=\frac{2(q+s+10)}{3},
\]

\[
|P^\circ|=
\frac{
12p^2r^2+p^2s^2+2p^2s-11p^2+q^2r^2-q^2+2qr^2-2q
-11r^2-s^2-2s+10
}{6(p^2-1)(r^2-1)}.
\]

固定 triangulation 包含 31 个 primal tetrahedra 和 68 个 polar tetrahedra；42 组非零 determinant 全部保持固定符号。

### Mahler 余量

单位立方体上的正分子 tensor degree 为

\[
(2,2,3,6).
\]

252 个 Bernstein coefficients 满足

\[
\boxed{153>0,\quad99=0,\quad0<0},
\]

最小正系数为

\[
\frac13.
\]

因此

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

遍历整个严格参数域。

主验证器和三个 closure chunk 验证器均返回 `PASS`。

---

## Survivor 82 的前置进展

Survivor 82 尚未关闭，但其连续主层已经大幅简化。令自由参数为

\[
a=x_{3,5},\quad b=x_{5,0},\quad c=x_{6,1},\quad d=x_{7,5}.
\]

整个 strict domain 可以由

\[
0<A,D,B,C<1
\]

参数化：

\[
a=2A-1,
\]

\[
d=2A+2(1-A)D-1,
\]

\[
c=\frac{A+2C-1}{A+1},
\]

\[
b=\frac{AD-A+2B-D}{AD-A-D+2}.
\]

它等价于

\[
-1<a<d<1,
\]

\[
\frac{a-1}{a+3}<c<1,
\]

\[
-\frac{d+1}{3-d}<b<1.
\]

16 条 strict defect inequalities 全部在该单位立方体上具有非负 Bernstein coefficients。rank pivot 恒为

\[
8.
\]

两个非固定 primal columns 的 supporting determinants 为

\[
\frac{(A-1)(D-1)(AD-A-D+2)}{AD-A+B-D+1}
\]

和

\[
-\frac{A(A+1)}{A+C},
\]

所以 12 个 primal vertices 保持 extreme。

一个精确 sample triangulation 给出候选体积公式

\[
|P|=-\frac{ac-a-bd+b+c+d-18}{3},
\]

\[
|P^\circ|=
\frac{
 a^2bc-a^2b+a^2c-a^2+2abc-2ab+2ac-2a
 +bcd^2-2bcd+50bc+bd^2-2bd+48b
 -cd^2+2cd+48c-d^2+2d+46
}{24(b+1)(c+1)}.
\]

在假定该 triangulation 全域有效的条件下，Mahler 余量正分子的 degree 为

\[
(5,3,2,2),
\]

216 个 Bernstein coefficients 满足

\[
\boxed{126>0,\quad90=0,\quad0<0},
\]

最小正系数为

\[
\frac25.
\]

这一结果目前是**条件性正余量证书**。还缺：

1. 240-chart section closure；
2. triangulation / oriented-matroid 的全域证书；
3. 独立 master verifier。

因此 survivor 82 尚不能标记为关闭。
