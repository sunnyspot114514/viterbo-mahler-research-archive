#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor family 76.

Checks with exact SymPy arithmetic:
  * rational rank-four completion;
  * exact unit-four-cube parametrization of the strict component;
  * all 16 defect inequalities by tensor Bernstein certificates;
  * all 12 primal vertices are genuine;
  * exact 20-vertex cube-section closure from two limiting simplex-cap pairs;
  * same-sign cap separation and one antipodal opposite-sign tangency pair;
  * global primal volume from fixed-sign facet circuits;
  * global polar volume from disjoint/tangent cap volumes;
  * strict Mahler margin, both by a short cap bound and by an independent
    tensor Bernstein certificate.

This is a computer-assisted analytic proof candidate, not an externally
reviewed theorem.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family76_verifier_output.json"
CERT = HERE / "viterbo_20f_d16_family76_certificate.json"


def same(x, y):
    return sp.cancel(x-y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees=None):
    poly = sp.expand(poly)
    P = sp.Poly(poly, *variables)
    if degrees is None:
        degrees = tuple(P.degree(x) for x in variables)
    terms = {m: sp.Rational(c) for m, c in P.terms()}
    out = {}
    for index in itertools.product(*[range(n+1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in terms.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff*factor
        out[index] = sp.factor(value)
    return degrees, out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def canonical_point(point):
    return tuple(sp.srepr(sp.factor(sp.cancel(x))) for x in point)


def main():
    started = time.time()
    checks = []

    # Unit-cube variables.  In original free coordinates A=(a+1)/2,
    # B=(b+1)/2, C=(c+1)/2, T=(d+1)/2, the strict domain is
    # A(1+C)<1 and T < (1-C+BC)/(1+B-C).  The substitution below is
    # an exact bijection from (0,1)^4.
    X, B, C, R = sp.symbols("X B C R", positive=True)
    K = 1-C+B*C
    L = 1+B-C
    A = X/(1+C)
    T = R*K/L
    a, b, c, d = 2*A-1, 2*B-1, 2*C-1, 2*T-1

    # Exact rank-four completion.
    D0 = b*c+b-c+3
    x00 = (a*c+3*a+c+1)/2
    x01 = (b*c+b+2*c*d+c-2*d+1)/D0
    x10 = a
    x11 = -(b*c*d-b*d-2*b-c*d+d-2)/D0
    x20 = (a*c+a+c-1)/2
    x21 = (b*c-2*b*d-b+2*c*d+c-4*d-1)/D0
    N40 = (
        a*b*c**2*d-a*b*c**2+2*a*b*c*d+2*a*b*c-3*a*b*d-a*b
        -a*c**2*d+a*c**2+6*a*c*d-2*a*c-5*a*d+a+b*c**2*d
        -b*c**2-4*b*c+3*b*d+b-c**2*d+c**2-4*c+5*d-1
    )
    x40 = -N40/(2*(d-1)*D0)
    x43 = (b*c*d+3*b*c-3*b*d-b+3*c*d+c-5*d+1)/((d-1)*D0)
    x50 = (a*b*c+a*b-a*c+3*a+b*c+b-c-1)/4
    N81 = (
        a*b*c**2*d-a*b*c**2+4*a*b*c*d-2*a*b*c+3*a*b*d-a*b
        -a*c**2*d+a*c**2+4*a*c*d+2*a*c+5*a*d-7*a+b*c**2*d
        -b*c**2-2*b*c-b*d-b-c**2*d+c**2-6*c+d+1
    )
    x81 = N81/(2*(a-1)*D0)
    x83 = (a*c+2*a+c)/(a-1)
    x91 = -(b*c-2*b*d-b-c-2*d+1)/D0

    M = sp.Matrix([
        [x00,x01,1,-1,-1,-1],
        [x10,x11,1,-1,-1,1],
        [x20,x21,1,-1,1,-1],
        [a,1,-1,-1,-1,-1],
        [x40,1,-1,x43,-1,1],
        [x50,1,b,-1,-1,1],
        [1,-1,1,1,c,-1],
        [1,d,-1,1,-1,-1],
        [1,x81,1,x83,-1,-1],
        [1,x91,1,1,-1,1],
    ]).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    template = [
        [0,0,1,-1,-1,-1],
        [0,0,1,-1,-1,1],
        [0,0,1,-1,1,-1],
        [0,1,-1,-1,-1,-1],
        [0,1,-1,0,-1,1],
        [0,1,0,-1,-1,1],
        [1,-1,1,1,0,-1],
        [1,0,-1,1,-1,-1],
        [1,0,1,0,-1,-1],
        [1,0,1,1,-1,1],
    ]

    pivot_rows = [2,3,7,9]
    pivot_cols = [2,3,4,5]
    basis = M.extract(pivot_rows, range(6))
    pivot = basis.extract(range(4), pivot_cols)
    assert same(pivot.det(), 8)
    coefficients = M.extract(range(10), pivot_cols)*pivot.inv()
    assert all(same(z, 0) for z in coefficients*basis-M)
    checks.append("exact_rank_four_completion")

    # Strict domain: every defect is strictly inside (-1,1).  Denominators
    # are products of the manifestly nonzero factors 1+C, L, 1+C-X, L-RK.
    assert same(D0, 4*K)
    assert same(1+C-X, (1+C)*(1-A))
    assert same(L-R*K, L*(1-R)+R*(L-K))
    assert same(L-K, B*(1-C))

    defect_positions = [
        (i,j) for i,row in enumerate(template) for j,flag in enumerate(row)
        if flag == 0
    ]
    assert len(defect_positions) == 16
    allowed_denominators = {
        sp.Integer(1),
        sp.expand((1+C)**2),
        sp.expand(L**2),
        sp.expand((L-R*K)**2),
        sp.expand((1+C-X)**2),
        sp.expand((1+C)**2*(L-R*K)**2),
        sp.expand(L**2*(1+C-X)**2),
    }
    defect_certificates = []
    for i,j in defect_positions:
        expr = sp.factor(sp.cancel(1-M[i,j]**2))
        numerator, denominator = map(sp.factor, sp.fraction(expr))
        if denominator.subs({X:sp.Rational(1,2),B:sp.Rational(1,3),
                             C:sp.Rational(2,5),R:sp.Rational(3,5)}) < 0:
            numerator, denominator = -numerator, -denominator
        assert sp.expand(denominator) in allowed_denominators
        degrees, bern = tensor_bernstein_coefficients(numerator, (X,B,C,R))
        stats = bernstein_stats(bern)
        assert stats["negative"] == 0 and stats["positive"] > 0
        defect_certificates.append({
            "position":[i,j], "degrees":list(degrees),
            "positive":stats["positive"], "zero":stats["zero"],
            "minimum_positive":str(stats["minimum_positive"]),
        })
    checks.append("unit_four_cube_is_exact_strict_component_and_all_sixteen_defects")

    # Normalize the four fixed primal columns to e_1,...,e_4.
    normalized = (pivot.inv()*basis).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    x = X*C/(1+C)
    e = B*R*(1-C)/L
    u = sp.Matrix([x, (1+C-X)/(1+C), -X/(1+C), -x])
    v = sp.Matrix([-R*(1-C)/L, -(L-R*K)/L, -B*R/L, e])
    assert all(same(normalized[i,0], u[i]) for i in range(4))
    assert all(same(normalized[i,1], v[i]) for i in range(4))
    assert normalized[:,2:6] == sp.eye(4)
    assert same(sum([u[0],u[1],-u[2],-u[3]]), 1+2*x)
    assert same(sum([-v[0],-v[1],-v[2],v[3]]), 1+2*e)
    # The cap excess is twice a minimum absolute coefficient.
    assert same(u[1]-x, 1-X)
    assert same(-u[2]-x, X*(1-C)/(1+C))
    assert same(-v[0]-e, R*(1-C)*(1-B)/L)
    assert same(-v[1]-e, 1-R)
    assert same(-v[2]-e, B*R*C/L)
    checks.append("normalized_primal_crosspolytope_plus_two_limiting_slab_vertices")

    # All six positive primal columns are genuine vertices.  The following
    # four incident facet normals have nonzero determinant for each column.
    Y = M[:,2:6]
    selections = {
        0:[(6,1),(7,1),(8,1),(9,1)],
        1:[(3,1),(4,1),(5,1),(6,-1)],
        2:[(0,1),(1,1),(2,1),(6,1)],
        3:[(3,-1),(5,-1),(7,1),(9,1)],
        4:[(0,-1),(1,-1),(6,1),(8,-1)],
        5:[(0,-1),(1,1),(5,1),(9,1)],
    }
    expected_dets = {
        0:-8*C*(1+C)/(1+C-X),
        1:8*B*(C-1)*L/(R*K-L),
        2:-8,
        3:-8*(B-1),
        4:-8*C*(1+C)*(X-1)/(1+C-X),
        5:8*(B-1),
    }
    extremality = []
    for j,sel in selections.items():
        normal_matrix = sp.Matrix.hstack(*[
            sp.Matrix([sgn*Y[i,k] for k in range(4)]) for i,sgn in sel
        ])
        det = sp.factor(sp.cancel(normal_matrix.det()))
        assert same(det, expected_dets[j])
        extremality.append({"column":j,"rows":sel,"determinant":str(det)})
    checks.append("all_twelve_primal_vertices_have_full_dimensional_normal_cones")

    # Exact cube-section closure by cap geometry.
    su = (1,1,-1,-1)
    sv = (-1,-1,-1,1)
    yu = (1, sp.factor(1-2*X*C/(1+C-X)), -1, -1)
    ystar = (1,1,2*C-1,-1)
    yv0 = (2*B-1,-1,-1,1)
    yv1 = (-1, sp.factor(-1+2*B*R*(1-C)/(L-R*K)), -1, 1)
    assert all(same(M[8,j+2], yu[j]) for j in range(4))
    assert all(same(M[6,j+2], ystar[j]) for j in range(4))
    assert all(same(M[5,j+2], yv0[j]) for j in range(4))
    assert all(same(M[4,j+2], yv1[j]) for j in range(4))

    # Same-sign caps are strictly separated.  Cancel coordinate 1 in a
    # positive combination; coordinate 2 is manifestly negative.  Whichever
    # signs coordinates 0 and 3 take, the corresponding support gap has a
    # nonnegative Bernstein table with a positive coefficient.
    lam = (1+C)*(L-R*K)
    mu = L*(1+C-X)
    wplus = (lam*u+mu*v).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    assert same(wplus[1], 0)
    assert same(wplus[2], -X*(L-R*K)-B*R*(1+C-X))
    same_sign_gap_certificates = []
    for sign0 in [1,-1]:
        for sign3 in [1,-1]:
            gap = sp.factor(sp.cancel(
                lam+mu-sign0*wplus[0]+wplus[2]-sign3*wplus[3]
            ))
            degrees, bern = tensor_bernstein_coefficients(gap, (X,B,C,R))
            stats = bernstein_stats(bern)
            assert stats["negative"] == 0 and stats["positive"] > 0
            same_sign_gap_certificates.append({
                "sign0":sign0,"sign3":sign3,"degrees":list(degrees),
                "positive":stats["positive"],"zero":stats["zero"],
                "minimum_positive":str(stats["minimum_positive"]),
            })

    # Opposite-sign caps have zero support gap and meet only at ystar.
    lamt = (1+C)*B*R
    mut = X*L
    wminus = (lamt*u-mut*v).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    assert same(wminus[0], R*X*K)
    assert same(wminus[1], B*R*(1+C-X)+X*(L-R*K))
    assert same(wminus[2], 0)
    assert same(wminus[3], -B*R*X)
    assert same(lamt+mut, wminus[0]+wminus[1]-wminus[3])
    ystar_vec = sp.Matrix(ystar)
    assert same(u.dot(ystar_vec), 1)
    assert same(v.dot(ystar_vec), -1)

    all_cube = set(itertools.product([-1,1], repeat=4))
    removed = {su, tuple(-z for z in su), sv, tuple(-z for z in sv)}
    expected = {canonical_point(p) for p in all_cube-removed}
    for p in [yu,ystar,yv0,yv1]:
        expected.add(canonical_point(p))
        expected.add(canonical_point(tuple(-z for z in p)))
    actual = set()
    for i in range(10):
        p = tuple(M[i,j] for j in range(2,6))
        actual.add(canonical_point(p))
        actual.add(canonical_point(tuple(-z for z in p)))
    assert len(expected) == 20 and actual == expected
    checks.append("exact_twenty_vertex_section_closure_with_one_antipodal_tangency_pair")

    # Global primal volume from fixed-sign facet circuits.
    def vertex(j):
        return basis[:,j] if j < 6 else -basis[:,j-6]

    sample = {X:sp.Rational(1,2),B:sp.Rational(1,3),
              C:sp.Rational(2,5),R:sp.Rational(3,5)}
    P_volume = sp.Rational(0)
    determinant_certificates = []
    common_positive = (1+C)*L
    for i,row in enumerate(template):
        ids = [j if flag == 1 else j+6 for j,flag in enumerate(row) if flag]
        signed_sum = sp.Rational(0)
        for subset in itertools.combinations(ids,4):
            det = sp.factor(sp.cancel(
                sp.Matrix.hstack(*[vertex(j) for j in subset]).det()
            ))
            value = det.subs(sample)
            assert value != 0
            sign = 1 if value > 0 else -1
            polynomial = sp.factor(sp.cancel(sign*det*common_positive))
            numerator, denominator = sp.fraction(polynomial)
            assert denominator == 1
            degrees, bern = tensor_bernstein_coefficients(numerator,(X,B,C,R))
            stats = bernstein_stats(bern)
            assert stats["negative"] == 0 and stats["positive"] > 0
            determinant_certificates.append({
                "facet":i,"subset":list(subset),"sign":sign,
                "degrees":list(degrees),"positive":stats["positive"],
                "zero":stats["zero"],
                "minimum_positive":str(stats["minimum_positive"]),
            })
            signed_sum += sign*det
        P_volume += sp.factor(signed_sum/(12 if len(ids)==4 else 24))
    P_volume = sp.factor(sp.cancel(P_volume))
    P_target = sp.factor(sp.Rational(4,3)*(4+x+e))
    assert same(P_volume, P_target)
    checks.append("global_primal_volume_from_twenty_six_fixed_sign_circuit_determinants")

    # Polar volume: each limiting slab removes one antipodal simplex-cap pair.
    # Same-sign interiors are disjoint and opposite-sign closures only touch at
    # +/-ystar, so cap volumes add with no overlap correction.
    cap_u_normalized = sp.factor(4*X*C**2/(3*(1+C-X)))
    cap_v_normalized = sp.factor(4*B**2*R*(1-C)**2/(3*(L-R*K)))
    Ppolar = sp.factor((16-cap_u_normalized-cap_v_normalized)/8)
    sigma_u = sp.factor(X*C**2/(6*(1+C-X)))
    sigma_v = sp.factor(B**2*R*(1-C)**2/(6*(L-R*K)))
    assert same(Ppolar, 2-sigma_u-sigma_v)
    checks.append("global_polar_volume_from_two_tangent_limiting_simplex_cap_pairs")

    # A short analytic margin proof.  Let s=x+e and tau=sigma_u+sigma_v.
    # Exact positive decompositions show sigma_u<x/3, sigma_v<e/3 and s<1.
    ssum = sp.factor(x+e)
    tau = sp.factor(sigma_u+sigma_v)
    assert same(
        x/sp.Integer(3)-sigma_u,
        X*C*(2*(1-X)+C*(1-C))/(6*(1+C)*(1+C-X)),
    )
    assert same(
        e/sp.Integer(3)-sigma_v,
        e*(B*(1-C)*(2-L)+2*(1-R)*K)/(6*(L-R*K)),
    )
    assert same(
        sp.Rational(1,2)-x,
        ((1-C)+2*C*(1-X))/(2*(1+C)),
    )
    assert same(
        sp.Rational(1,2)-B*(1-C)/L,
        (B*C+(1-B)*(1-C))/(2*L),
    )
    assert same(B*(1-C)/L-e, B*(1-C)*(1-R)/L)

    margin = sp.factor(sp.cancel(P_volume*Ppolar-sp.Rational(32,3)))
    assert same(margin, sp.Rational(4,3)*(2*ssum-(4+ssum)*tau))
    lower = sp.factor(4*ssum*(2-ssum)/9)
    assert same(
        margin-lower,
        4*(4+ssum)*(ssum-3*tau)/9,
    )

    # Independent exact cross-check: the exact margin numerator is Bernstein
    # positive on the full unit four-cube.
    positive_denominator = 9*(1+C)*L*(1+C-X)*(L-R*K)
    H = sp.factor(sp.cancel(margin*positive_denominator/2))
    assert sp.fraction(H)[1] == 1
    degrees, bern = tensor_bernstein_coefficients(H,(X,B,C,R))
    margin_stats = bernstein_stats(bern)
    assert degrees == (2,3,5,2)
    assert margin_stats == {
        "positive":111,"zero":105,"negative":0,
        "minimum_positive":sp.Rational(1,10),
    }
    checks.append("strict_mahler_margin_short_cap_bound_and_independent_bernstein_certificate")

    certificate = {
        "schema":"viterbo-20f-d16-family76-certificate-v1",
        "scope":"4D centrally symmetric Mahler; bounded-12; 12V/20F c=0 D=16",
        "family_index":76,
        "domain":"open unit 4-cube X,B,C,R in (0,1)",
        "rank_pivot":"8",
        "defect_certificates":defect_certificates,
        "primal_extremality":extremality,
        "section_vertices":20,
        "cap_geometry":{
            "u_center":list(su),"v_center":list(sv),
            "same_sign":"strictly separated",
            "opposite_sign":"one antipodal tangency pair",
            "tangency_point":[str(z) for z in ystar],
            "same_sign_gap_certificates":same_sign_gap_certificates,
        },
        "volumes":{
            "P":str(P_volume),"polar":str(Ppolar),
            "primal_circuit_determinants":len(determinant_certificates),
        },
        "mahler":{
            "result":"strictly greater than 32/3",
            "conceptual_bound":"sigma_u<x/3, sigma_v<e/3, 0<x+e<1",
            "bernstein_degree":list(degrees),
            "bernstein_positive":margin_stats["positive"],
            "bernstein_zero":margin_stats["zero"],
            "bernstein_negative":margin_stats["negative"],
            "minimum_positive":str(margin_stats["minimum_positive"]),
        },
        "determinant_certificates":determinant_certificates,
    }
    CERT.write_text(json.dumps(certificate,indent=2,ensure_ascii=False),encoding="utf-8")
    cert_sha = hashlib.sha256(CERT.read_bytes()).hexdigest()
    output = {
        "status":"PASS",
        "family_index":76,
        "checks":checks,
        "certificate":CERT.name,
        "certificate_sha256":cert_sha,
        "elapsed_seconds":round(time.time()-started,3),
        "conclusion":"Family 76 has exactly 12 primal vertices and 20 polar vertices and satisfies |P||P^o|>32/3 throughout its strict component.",
        "caveat":"Computer-assisted analytic proof candidate; not externally peer reviewed.",
    }
    OUTPUT.write_text(json.dumps(output,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(output,indent=2,ensure_ascii=False))


if __name__ == "__main__":
    main()
