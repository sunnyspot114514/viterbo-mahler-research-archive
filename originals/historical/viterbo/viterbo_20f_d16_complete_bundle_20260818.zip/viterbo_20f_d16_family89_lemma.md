# Survivor 89 in the bounded-12 four-dimensional symmetric Mahler program

## Statement

Consider the `12V/20F`, `c=0`, `D=16` sign template indexed by 89. Let

\[
p=x_{2,0},\qquad q=x_{4,0},\qquad r=x_{5,0},\qquad s=x_{7,1}.
\]

Define

\[
u=\frac{p-q}{2},\qquad
v=\frac{p-r}{2},\qquad
w=-p+q+r+1,
\]

\[
E=-\frac{q+r}{2},\qquad t=-s.
\]

The strict realization domain is exactly

\[
u,v,w,E>0,
\qquad u+v+w+E=1,
\]

\[
0<t<1,
\qquad4tE>(1-t)w.
\]

It is rationally equivalent to an open three-simplex times an interval, and hence to an open unit four-cube. On the entire domain the associated centrally symmetric four-polytope has exactly 12 vertices and 20 facets and satisfies

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

This is a computer-assisted analytic proof candidate, not an externally reviewed theorem.

---

## 1. Rational cube parameterization and exact rank

Use

\[
u=U,
\qquad v=(1-U)V,
\]

\[
w=(1-U)(1-V)W,
\qquad E=(1-U)(1-V)(1-W),
\]

and

\[
t=\frac{W+4(1-W)T}{4-3W},
\qquad0<U,V,W,T<1.
\]

Then

\[
p=w+2u+2v-1,
\qquad q=w+2v-1,
\]

\[
r=w+2u-1,
\qquad s=-t.
\]

The two nontrivial domain identities are

\[
1-t=\frac{4(1-T)(1-W)}{4-3W}>0,
\]

\[
4tE-(1-t)w=4T(1-U)(1-V)(1-W)>0.
\]

Conversely,

\[
T=\frac{4tE-(1-t)w}{4E},
\]

so the parameterization is bijective on the strict domain.

The selected rank pivot has determinant

\[
\boxed{8}.
\]

All remaining rows are exact rational combinations of the four pivot rows. All 16 defect inequalities have tensor-Bernstein positivity certificates.

The six primal vertex-pairs remain extreme. The two nonfixed supporting determinants include

\[
-\frac{2E^2}{(E+2u)(E+2v)(E+2w)}
\]

in equivalent simplex coordinates, while the remaining supporting determinants are nonzero rational products of positive domain factors.

---

## 2. Exact section closure

All 240 active four-coordinate charts were regenerated exactly:

\[
\boxed{
240
=52\text{ expected occurrences}
+178\text{ one-coordinate violations}
+10\text{ paired exclusions}.
}
\]

The expected occurrences give exactly 20 distinct section vertices.

For 178 charts, an inactive coordinate satisfies \(1-z^2<0\) globally, with tensor-Bernstein certificates.

The ten special charts reduce to exact two-coordinate contradictions. Their sums or differences have absolute value strictly greater than 2 or 4, except for one internal wall. On that wall the active determinant is proportional to \(u-v\), while a three-by-three minor remains nonzero; the active system therefore has rank exactly three and produces no new isolated vertex.

Thus

\[
\boxed{L\cap[-1,1]^6\text{ has exactly the prescribed 20 vertices}.}
\]

---

## 3. Global volumes

Using the facet circuit formula for all five-vertex facets gives

\[
\boxed{
|P|=-\frac{2}{3}(p-q-r-s-10)
=\frac{2}{3}(w+9-t).
}
\]

After normalizing four primal columns to the standard basis, the polar is a four-cube cut by two symmetric slabs. Each slab removes one antipodal pair of four-simplex caps. Their normalized pair volumes are

\[
\frac{4w^3}{3(q+1)(r+1)(1-p)}
\]

and

\[
\frac{4(1+s)}{3(1-s)}.
\]

The same-sign cap-intersection support gap is

\[
\frac{4tE-(1-t)w}{2}>0,
\]

and the opposite-sign gap is

\[
\frac{w(1-t)}{2}>0.
\]

So all cap interiors are disjoint. Undoing the determinant-8 normalization yields

\[
\boxed{
|P^\circ|
=2-
\frac{w^3}{6(q+1)(r+1)(1-p)}
-
\frac{1+s}{6(1-s)}.
}
\]

---

## 4. Strict Mahler margin

In the unit-cube coordinates,

\[
|P|\,|P^\circ|-\frac{32}{3}
=
\frac{H(U,V,W,T)}{D(U,V,W,T)},
\]

where the denominator is strictly positive. The numerator has tensor degree

\[
\boxed{(2,3,6,2)}.
\]

Its 252 Bernstein coefficients satisfy

\[
\boxed{
156>0,
\qquad96=0,
\qquad0<0,
}
\]

with minimum positive coefficient

\[
\boxed{\frac{16}{9}}.
\]

Hence

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout the strict domain.
