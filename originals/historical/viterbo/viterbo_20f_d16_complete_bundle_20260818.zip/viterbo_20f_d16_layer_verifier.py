#!/usr/bin/env python3
"""Aggregate replay checker for the 12V/20F, c=0, D=16 layer.

This script verifies the finite preclassification count and confirms that all
14 algebraic survivor branches are covered by passing exact family verifiers:
13 strict positive-Mahler families and one universal primal-vertex-loss
family.  It is an assembly checker; the mathematical work is performed by
the referenced preclassifier and family verifiers.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
CERT_OUT=HERE/"viterbo_20f_d16_layer_certificate.json"
OUTPUT=HERE/"viterbo_20f_d16_layer_verifier_output.json"


def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    pre_cert=HERE/"viterbo_20f_d16_preclassifier_certificate.json"
    pre_out=HERE/"viterbo_20f_d16_preclassifier_output.json"
    assert pre_cert.exists() and pre_out.exists()
    pc=json.loads(pre_cert.read_text())
    po=json.loads(pre_out.read_text())
    assert po["status"]=="PASS"
    assert pc["raw_global_template_count"]==92
    assert pc["rank_ge_5_count"]==72
    assert pc["duplicate_row_count"]==6
    assert pc["algebraic_survivor_count"]==14

    expected=set(pc["algebraic_survivor_indices"])
    assert expected=={2,17,42,76,80,81,82,85,86,87,88,89,90,91}

    positive=[17,42,76,80,81,82,85,86,87,88,89,90,91]
    vertex_loss=[2]
    records=[]
    for i in positive:
        p=HERE/f"viterbo_20f_d16_family{i}_verifier_output.json"
        assert p.exists(),p
        d=json.loads(p.read_text())
        assert d["status"]=="PASS"
        records.append({"family":i,"classification":"strict_positive_mahler",
                        "output":p.name,"sha256":sha(p)})
    for i in vertex_loss:
        p=HERE/f"viterbo_20f_d16_family{i}_vertex_loss_verifier_output.json"
        assert p.exists(),p
        d=json.loads(p.read_text())
        assert d["status"]=="PASS"
        text=(d.get("conclusion") or "").lower()
        assert "10 vertices" in text
        records.append({"family":i,"classification":"primal_vertex_loss",
                        "output":p.name,"sha256":sha(p)})

    assert {r["family"] for r in records}==expected
    assert 72+6+len(records)==92

    cert={
        "schema":"viterbo-20f-d16-layer-certificate-v1",
        "scope":"4D centrally symmetric Mahler; bounded-12; 12V/20F c=0 D=16",
        "preclassification":{
            "global_templates":92,"rank_ge_5":72,
            "duplicate_facet_rows":6,"algebraic_survivors":14,
            "preclassifier_certificate_sha256":sha(pre_cert),
            "preclassifier_output_sha256":sha(pre_out),
        },
        "survivor_resolution":{
            "strict_positive_mahler_count":13,
            "primal_vertex_loss_count":1,
            "records":sorted(records,key=lambda x:x["family"]),
        },
        "conclusion":"Every D=16 template is excluded or has Mahler product strictly greater than 32/3; the 12V/20F c=0 D=16 layer is closed as a computer-assisted analytic proof candidate.",
        "caveat":"Not externally peer reviewed; this closes one bounded-12 defect layer, not the full four-dimensional conjecture.",
    }
    CERT_OUT.write_text(json.dumps(cert,indent=2,sort_keys=True),encoding="utf-8")
    out={
        "status":"PASS",
        "global_templates":92,
        "rank_ge_5":72,
        "duplicate_facet_rows":6,
        "algebraic_survivors":14,
        "strict_positive_mahler_families":13,
        "primal_vertex_loss_families":1,
        "certificate":CERT_OUT.name,
        "certificate_sha256":sha(CERT_OUT),
        "conclusion":cert["conclusion"],
        "caveat":cert["caveat"],
    }
    OUTPUT.write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))


if __name__=="__main__":main()
