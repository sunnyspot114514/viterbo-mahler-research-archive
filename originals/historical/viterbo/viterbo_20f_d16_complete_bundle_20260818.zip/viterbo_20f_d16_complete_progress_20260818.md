# Four-dimensional symmetric Mahler bounded-12 progress

## Complete closure candidate for the 12V/20F, c=0, D=16 layer

**Date:** 2026-08-18

## Result

The highest-defect layer for a centrally symmetric four-polytope with twelve vertices and twenty facets is now completely resolved as a computer-assisted analytic proof candidate:

\[
\boxed{
12V/20F,\qquad c=0,\qquad D=16\quad\checkmark.
}
\]

The preclassification contains exactly

\[
92
\]

canonical pairing-sign templates. Their complete resolution is

\[
\boxed{
92
=
72\text{ rank-}\ge5
+
6\text{ duplicate-facet-row templates}
+
14\text{ algebraic survivors}.
}
\]

Of the fourteen algebraic survivors:

- thirteen are genuine 12-vertex, 20-facet continuous families and have strict Mahler product greater than \(32/3\) throughout their complete strict realization spaces;
- Family 2 has a universal primal-vertex-loss identity and is actually at most 10-vertex.

The aggregate exact replay checker returns `PASS`.

All checkmarks in this report mean **computer-assisted analytic proof candidate**. They are not externally peer-reviewed theorems.

---

## Previously completed families

Before this round, the following ten genuine families had complete exact certificates:

\[
80,81,82,85,86,87,88,89,90,91.
\]

They cover strict domains built from open cubes, simplexes, products of simplexes and low-degree cuts of these domains. Their polar volumes were obtained from fixed triangulations or from exact two-slab cap formulas, and their Mahler margins were certified by rational inequalities and/or tensor Bernstein positivity.

---

# New completion 1: Family 76

Use \(0<X,B,C,R<1\),

\[
K=1-C+BC,\qquad L=1+B-C,
\]

and define

\[
x=\frac{XC}{1+C},
\qquad
e=\frac{BR(1-C)}{L}.
\]

After rank-four normalization, the polar is a four-cube intersected with two symmetric slabs. Same-sign caps are strictly separated; opposite-sign cap closures meet at exactly one antipodal tangency pair.

The exact volumes reduce to

\[
|P|=\frac43(4+x+e),
\]

\[
|P^\circ|=2-\sigma_u-\sigma_v,
\]

where

\[
\sigma_u=\frac{XC^2}{6(1+C-X)},
\qquad
\sigma_v=\frac{B^2R(1-C)^2}{6(L-RK)}.
\]

The strict component gives

\[
\sigma_u<\frac{x}{3},
\qquad
\sigma_v<\frac{e}{3},
\qquad
0<x+e<1.
\]

Consequently

\[
|P||P^\circ|-\frac{32}{3}
>
\frac{4(x+e)(2-x-e)}{9}>0.
\]

An independent Bernstein cross-check has degree \((2,3,5,2)\), with

\[
111>0,\qquad105=0,\qquad0<0,
\]

and minimum positive coefficient \(1/10\).

---

# New completion 2: Family 17

The complete strict component is

\[
0<P,Q,R,S<1,
\qquad R+S<1.
\]

It is mapped bijectively to the open unit four-cube by

\[
R=U,
\qquad
S=(1-U)V.
\]

After normalization,

\[
u=\frac{(QS,PS,PQS,PQ(1-R))}{PQ(1-R-S)+S(P+Q)},
\]

\[
v=-\frac{(QR,PR,PQ(1-S),PQR)}{PQ(1-R-S)+R(P+Q)}.
\]

At the positive cube corner, the two limiting simplex caps overlap. Their boundary intersection is the triangle

\[
\frac{z_0}{P}+\frac{z_1}{Q}+\frac{z_2}{R}=1,
\qquad
\frac{z_3}{S}=\frac{z_2}{R}.
\]

Its three vertices give the three non-cube section vertices at that corner. Thus the section has

\[
14+3+3=20
\]

vertices.

The cap-pair volumes and their overlap simplify by inclusion-exclusion to

\[
\boxed{
|P^\circ|=16-\frac43PQ(R+S).
}
\]

A fixed-sign facet-circuit computation gives

\[
|P|=rac23+
\frac{PQ\bigl(PQ(1-R-S)(R+S)+(P+Q)RS\bigr)}
{6\bigl(PQ(1-R-S)+R(P+Q)\bigr)
 \bigl(PQ(1-R-S)+S(P+Q)\bigr)}.
\]

The Mahler-margin numerator has tensor degree \((3,3,2,3)\). Its 192 Bernstein coefficients satisfy

\[
64>0,
\qquad128=0,
\qquad0<0,
\]

with minimum positive coefficient \(4/9\).

---

# New completion 3: Family 42

Family 42 was the only survivor for which the first elimination pass did not find a rational parametrization. Its incidence geometry gives one directly.

At a truncated cube corner the two cap-slope vectors must be

\[
\alpha=(k,1,a,c),
\qquad
\beta=(k,b,1,1),
\]

with

\[
k,a,b,c>1.
\]

Set

\[
K=1/k,
\quad A=1/a,
\quad B=1/b,
\quad C=1/c.
\]

Then the complete strict component is exactly the open unit four-cube. With

\[
D_u=AC+KC+KA-KAC,
\]

the two normalized extra primal columns are

\[
u=\frac{(AC,KAC,KC,KA)}{D_u},
\]

\[
v=-\frac{(B,K,KB,KB)}{B+K}.
\]

The two cap boundaries meet in a triangle. Its vertices give precisely three new section vertices per antipodal corner, so again

\[
14+3+3=20.
\]

The overlap base has a fixed decomposition into three tetrahedra. Combining its exact volume with the two cap-pair volumes gives a global rational formula for \(|P^\circ|\), with no triangulation chamber ambiguity.

The primal volume follows from 26 globally fixed-sign circuit determinants. The Mahler-margin numerator has tensor degree

\[
(3,2,3,2).
\]

Its 144 Bernstein coefficients satisfy

\[
52>0,
\qquad92=0,
\qquad0<0,
\]

with minimum positive coefficient \(2/3\). Therefore Family 42 is strictly above \(32/3\) throughout its complete strict component.

---

# New completion 4: Family 2 is not 12-vertex

Use \(0<P,Q,R,S<1\) and

\[
D=QR+QS+RS-QRS>0.
\]

After normalization,

\[
v=\frac{(-RS,-QS,-QR,QRS)}{D}.
\]

The other extra column satisfies the exact identity

\[
\boxed{
u=P(-v)+(1-P)(-e_4).
}
\]

Since \(0<P<1\), \(u\) lies in the relative interior of the edge \([-v,-e_4]\). Hence \(u\) and \(-u\) are not extreme, and the branch has at most ten vertices. It belongs to the lower-vertex recursive layer rather than the genuine 12-vertex layer.

All sixteen formal defects are strict on the open unit cube; the exclusion is specifically primal non-extremality, not an empty realization space.

---

# Complete family table

\[
\begin{array}{c|c}
\text{Family}&\text{Resolution}\\
\hline
2&\text{primal vertex loss; at most 10V}\\
17&|P||P^\circ|>32/3\\
42&|P||P^\circ|>32/3\\
76&|P||P^\circ|>32/3\\
80,81,82,85,86,87,88,89,90,91&|P||P^\circ|>32/3
\end{array}
\]

Thus all fourteen algebraic survivors are resolved.

---

# Updated bounded-12 proof tree

\[
\boxed{
\begin{array}{c|c}
\text{Layer}&\text{Status}\\
\hline
c=1&\checkmark\\
c=0,\ 12V/12F&\checkmark\\
c=0,\ 12V/14F&\checkmark\\
c=0,\ 12V/16F&\checkmark\\
c=0,\ 12V/18F&\checkmark\\
c=0,\ 12V/20F,\ D=16&\checkmark\\
c=0,\ 12V/20F,\ D=15,\ldots,10&\text{open}
\end{array}
}
\]

For \(20F\), the next layer is

\[
D=15,
\qquad g_2=34-2D=4,
\]

with five single-defect rows and five double-defect rows. This is the next finite-core target.

## Global scope caveat

Closing \(20F,D=16\) is a substantial bounded-12 result, but it does not solve the full four-dimensional symmetric Mahler conjecture. A complete proof still needs either all remaining bounded-12 layers plus a complexity-independent reduction theorem, or a direct theorem controlling all four-dimensional bi-shadow-rigid minimizers.
