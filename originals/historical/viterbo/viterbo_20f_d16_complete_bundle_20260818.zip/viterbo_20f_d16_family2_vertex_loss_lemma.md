# Family 2: universal primal vertex loss

## Statement

The algebraic survivor indexed **2** in the \(12V/20F,D=16\) preclassification is not a genuine twelve-vertex family. Throughout its complete strict component, one apparent primal vertex lies in the relative interior of an edge joining two other primal vertices.

## Exact normalization

Use

\[
0<P,Q,R,S<1
\]

and define

\[
D=QR+QS+RS-QRS
=QR(1-S)+S(Q+R)>0.
\]

After normalizing four columns to the coordinate basis, one extra column is

\[
v=\frac1D(-RS,-QS,-QR,QRS).
\]

Let \(e_4=(0,0,0,1)\). The other extra column satisfies the exact identity

\[
\boxed{
u=P(-v)+(1-P)(-e_4).
}
\]

Because \(0<P<1\), both coefficients are strictly positive and sum to one. Therefore \(u\) lies in the relative interior of the edge

\[
[-v,-e_4].
\]

Consequently \(u\) and \(-u\) are not extreme points. The branch has at most five distinct antipodal vertex-pairs, hence at most ten vertices.

All sixteen formal defect entries are strict on the open unit four-cube, so this is a genuine algebraic family; it is excluded specifically by primal non-extremality rather than by an empty parameter domain.
