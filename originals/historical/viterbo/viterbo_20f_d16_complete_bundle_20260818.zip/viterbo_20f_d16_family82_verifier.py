#!/usr/bin/env python3
"""Exact verifier for 12V/20F, c=0, D=16, survivor family 82.

Checks:
  * exact rank-four completion and cube parameterization;
  * all 16 strict defects and 12 primal extreme vertices;
  * all 240 active-face section charts;
  * global primal volume via 4/5-vertex facet circuit formula;
  * global polar volume via a cube-minus-disjoint-simplex-caps argument;
  * tensor-Bernstein positivity of the Mahler remainder.
"""
from __future__ import annotations
import hashlib,itertools,json,time
from pathlib import Path
import sympy as sp

HERE=Path(__file__).resolve().parent
MASTER=HERE/'viterbo_20f_d16_family82_certificate.json'
CLOSURE=HERE/'viterbo_20f_d16_family82_closure_certificate.json'
OUTPUT=HERE/'viterbo_20f_d16_family82_verifier_output.json'

def same(x,y): return sp.cancel(x-y)==0

def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def tensor_coefficients(poly,variables,degrees):
    P=sp.Poly(sp.expand(poly),*variables); mons={m:sp.Rational(c) for m,c in P.terms()}; out={}
    for idx in itertools.product(*[range(n+1) for n in degrees]):
        value=sp.Rational(0)
        for powers,coeff in mons.items():
            if all(k<=i for k,i in zip(powers,idx)):
                factor=sp.Rational(1)
                for i,k,n in zip(idx,powers,degrees):
                    factor*=sp.Rational(sp.binomial(i,k),sp.binomial(n,k))
                value+=coeff*factor
        out[idx]=sp.factor(value)
    return out

def stats(coeffs):
    vals=list(coeffs.values())
    return {'positive':sum(int(bool(x>0)) for x in vals),
            'zero':sum(int(bool(x==0)) for x in vals),
            'negative':sum(int(bool(x<0)) for x in vals),
            'min_positive':min((x for x in vals if bool(x>0)),default=None)}

def parse_matrix(rows,loc): return sp.Matrix([[sp.sympify(x,locals=loc) for x in row] for row in rows])

def vertex(B,j): return B[:,j] if j<6 else -B[:,j-6]

def check_bernstein(poly,vars_,rec):
    coeff=tensor_coefficients(poly,vars_,rec['degree']); s=stats(coeff)
    assert s['positive']==rec['positive'] and s['zero']==rec['zero'] and s['negative']==rec['negative']
    if rec.get('min_positive') is not None and s['positive']:
        assert s['min_positive']==sp.Rational(rec['min_positive'])
    return s

def main():
    started=time.time();
    def mark(x): print(f'[f82] {x} {time.time()-started:.2f}s', flush=True)
    master=json.loads(MASTER.read_text()); closure=json.loads(CLOSURE.read_text()); checks=[]
    A,D,B,C=sp.symbols('A D B C'); a,b,c,d=sp.symbols('x3_5 x5_0 x6_1 x7_5')
    loc={'A':A,'D':D,'B':B,'C':C,'x3_5':a,'x5_0':b,'x6_1':c,'x7_5':d}
    cube={a:sp.sympify(master['cube_parameterization']['a'],locals=loc),
          d:sp.sympify(master['cube_parameterization']['d'],locals=loc),
          c:sp.sympify(master['cube_parameterization']['c'],locals=loc),
          b:sp.sympify(master['cube_parameterization']['b'],locals=loc)}
    vars_=[A,D,B,C]
    M=parse_matrix(master['matrix_entries'],loc); pr=master['pivot_rows'];pc=master['pivot_cols']
    Bas=M.extract(pr,range(6)); pivot=Bas.extract(range(4),pc)
    assert same(pivot.det(),sp.Rational(master['rank_certificate']['pivot_det']))
    coeff=M.extract(range(10),pc)*pivot.inv()
    assert all(same(x,0) for x in coeff*Bas-M)
    checks.append('exact_rank_four_completion');mark('rank')

    # The rational cube map is exactly the stated strict domain.
    domain_id={
      '1+a':1+a,
      'd-a':d-a,
      '1-d':1-d,
      'c-lower':c-(a-1)/(a+3),
      '1-c':1-c,
      'b-lower':b+(d+1)/(3-d),
      '1-b':1-b}
    expected={
      '1+a':2*A,
      'd-a':2*(1-A)*D,
      '1-d':2*(1-A)*(1-D),
      'c-lower':2*C/(A+1),
      '1-c':2*(1-C)/(A+1),
      'b-lower':2*B/(A*D-A-D+2),
      '1-b':2*(1-B)/(A*D-A-D+2)}
    for k,e in domain_id.items(): assert same(e.subs(cube),expected[k])
    checks.append('bijective_open_cube_parameterization');mark('domain')

    Mc=M.subs(cube).applyfunc(lambda x:sp.factor(sp.cancel(x)))
    recs={r['entry']:r for r in master['strict_defect_certificates']}; seen=set()
    for i,row in enumerate(master['template']):
        for j,flag in enumerate(row):
            if flag!=0: continue
            name=f'x{i}_{j}'; rec=recs[name]; expr=Mc[i,j]; q=sp.factor(sp.cancel(1-expr**2)); num,den=sp.fraction(q)
            assert same(expr,sp.sympify(rec['expression'],locals=loc));assert same(q,sp.sympify(rec['one_minus_square'],locals=loc))
            assert same(num,sp.sympify(rec['numerator'],locals=loc));assert same(den,sp.sympify(rec['denominator'],locals=loc))
            check_bernstein(num,vars_,rec['bernstein'])
            co,facs=sp.factor_list(den,A,D,B,C); assert co>0 and all(e%2==0 for _,e in facs)
            seen.add(name)
    assert seen==set(recs);checks.append('sixteen_strict_defects');mark('defects')

    coeffc=coeff.subs(cube).applyfunc(lambda x:sp.factor(sp.cancel(x)))
    pe=master['primal_extremality']
    det0=sp.factor(coeffc.extract(pe['column0_rows'],range(4)).det());det1=sp.factor(coeffc.extract(pe['column1_rows'],range(4)).det())
    assert same(det0,sp.sympify(pe['column0_det'],locals=loc));assert same(det1,sp.sympify(pe['column1_det'],locals=loc))
    checks.append('twelve_primal_vertices');mark('primal')

    # Chunked exact closure replay. Each of the 15 active 4-subsets is regenerated
    # independently by the companion chunk verifier.
    chunk_paths=[HERE/f"viterbo_20f_d16_family82_closure_chunk_{i:02d}_output.json" for i in range(15)]
    chunks=[json.loads(x.read_text()) for x in chunk_paths]
    assert all(x["status"]=="PASS" for x in chunks)
    totals={"expected":0,"global_violation":0,"special":0,"rank3_nonisolated":0};ids=set()
    for x in chunks:
        assert x["master_sha256"]==sha256(MASTER) and x["closure_sha256"]==sha256(CLOSURE)
        for k,v in x["stats"].items(): totals[k]+=v
        ids.update(x["expected_ids"])
    assert totals=={"expected":52,"global_violation":164,"special":8,"rank3_nonisolated":16}
    assert len(ids)==20
    assert closure["stats"]=={"total":240,"expected_occurrences":52,"global_single_coordinate_violations":164,"paired_factor_exclusions":8,"rank3_nonisolated":16}
    checks.append('section_closure_all_240_charts_chunked_exact_replay');mark('closure')

    # Global P volume from each actual facet. Five-vertex facets use the circuit identity
    # vol(cone facet)=sum(|4x4 minors|)/48; antipodal pairing doubles this.
    pvc=master['P_volume_certificate']; ptotal=sp.Integer(0)
    for frec in pvc['facets']:
        i=frec['row'];ids=[]
        for j in range(6):
            if M[i,j]==1:ids.append(j)
            elif M[i,j]==-1:ids.append(j+6)
        assert ids==frec['vertices']
        abs_sum=sp.Integer(0)
        for drec in frec['determinants']:
            subids=drec.get('subvertices',ids);det=sp.factor(sp.Matrix.hstack(*[vertex(Bas,j) for j in subids]).det())
            assert same(det,sp.sympify(drec['original'],locals=loc))
            ec=sp.factor(sp.cancel(det.subs(cube)));num,den=sp.fraction(ec)
            assert same(ec,sp.sympify(drec['cube'],locals=loc));assert same(num,sp.sympify(drec['numerator'],locals=loc));assert same(den,sp.sympify(drec['denominator'],locals=loc))
            ns=check_bernstein(num,vars_,drec['numerator_bernstein']);ds=check_bernstein(den,vars_,drec['denominator_bernstein'])
            assert drec['sign'] in (-1,1) and drec['sign']==drec['numerator_bernstein']['sign']*drec['denominator_bernstein']['sign']
            abs_sum+=drec['sign']*det
        pairvol=abs_sum/(12 if len(ids)==4 else 24)
        assert same(pairvol,sp.sympify(frec['pair_volume'],locals=loc));ptotal+=pairvol
    Pformula=sp.sympify(pvc['target'],locals=loc);assert same(ptotal,Pformula);checks.append('global_primal_volume_by_facet_circuits');mark('P volume')

    # Global Q volume: after a determinant-8 normalization, Q is the 4-cube cut by two slabs.
    pc=master['polar_cube_slab_certificate'];Vp=pivot.inv()*Bas
    alpha=(1-b)*(1-d)/4;beta=(1+b)/2;gamma=(1-b)/2;delta=(1+a)*(1-c)/4;eps=(1+c)/2;zeta=(1-c)/2
    assert all(same(x,y) for x,y in zip(Vp[:,0],[-alpha,-beta,alpha,gamma]))
    assert all(same(x,y) for x,y in zip(Vp[:,1],[-delta,-eps,delta,-zeta]))
    assert same((beta-alpha).subs(cube),B);assert same(gamma-alpha,gamma*(1+d)/2)
    assert same((eps-delta).subs(cube),C);assert same(zeta-delta,zeta*(1-a)/2)
    cap0=sp.sympify(pc['cap_pair_volumes']['column0'],locals=loc);cap1=sp.sympify(pc['cap_pair_volumes']['column1'],locals=loc)
    assert same(cap0,sp.Rational(4,3)*alpha**2/(beta*gamma));assert same(cap1,sp.Rational(4,3)*delta**2/(eps*zeta))
    # Same-sign cap pairs: weighted l1 gap is gamma*zeta*(d-a)>0.
    samegap=(zeta+gamma)-(2*(zeta*alpha+gamma*delta)+zeta*beta+gamma*eps)
    assert same(samegap,gamma*zeta*(d-a)); assert same(samegap,sp.sympify(pc['same_sign_disjoint_weighted_gap'],locals=loc))
    # Opposite-sign cap pairs: triangle inequality gives max <= alpha+delta exactly.
    opp=alpha*eps+delta*beta+delta*gamma+alpha*zeta;assert same(opp,alpha+delta)
    Qformula=sp.sympify(pc['original_polar_volume'],locals=loc);assert same(Qformula,(16-cap0-cap1)/8)
    assert same(Qformula,sp.sympify(pc['target_formula'],locals=loc));checks.append('global_polar_volume_by_disjoint_simplex_caps');mark('Q volume')

    # Mahler remainder.
    mr=master['Mahler_margin_certificate'];margin=sp.factor(sp.cancel(Pformula*Qformula-sp.Rational(32,3)));mc=sp.factor(sp.cancel(margin.subs(cube)))
    assert same(mc,sp.sympify(mr['cube_expression'],locals=loc));num,den=sp.fraction(mc)
    assert same(num,sp.sympify(mr['numerator'],locals=loc));assert same(den,sp.sympify(mr['denominator'],locals=loc))
    s=check_bernstein(num,vars_,mr['bernstein']);assert s['negative']==0 and s['positive']>0
    # Denominator factors are all strictly positive on the open cube.
    assert same(den,9*(A+1)*(A+C)*(A*D-A-D+2)*(A*D-A+B-D+1))
    checks.append('strict_Mahler_margin_tensor_Bernstein');mark('margin')

    out={'status':'PASS','family_index':82,'checks':checks,'closure_stats':closure['stats'],
         'P_volume':str(Pformula),'Q_volume':str(Qformula),'margin_bernstein':mr['bernstein'],
         'certificate_sha256':sha256(MASTER),'closure_sha256':sha256(CLOSURE),'elapsed_seconds':round(time.time()-started,3),
         'scope':'computer-assisted analytic proof candidate; no external review'}
    OUTPUT.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

if __name__=='__main__': main()
