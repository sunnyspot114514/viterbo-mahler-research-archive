# 12V/20F, c=0, D=16：survivor 90 的完整解析证书

日期：2026-08-17

## 1. 结论

对预分类中的 survivor 90（来源 `h2:[3,6,18,19], matching 2`），低秩 completion 给出一个四参数连续族。该族的完整严格参数域是两个开二维单纯形的直积：

\[
\boxed{
A>0,
 B>0,
 A+B<1,
\qquad
C>0,
 D>0,
 C+D<1.
}
\]

在此域内：

1. pairing matrix 精确保持 rank 4；
2. 六对 primal vertices 全部保持极点；
3. 对应的四维 cube section 恰有 20 个顶点，没有额外 section vertex；
4. 四个 oriented-matroid chambers 给出相同的精确体积公式；
5. Mahler 余量在 product-simplex Bernstein basis 中所有系数非负且至少一个严格为正。

因此

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

遍历整个严格参数域。

本结论应记作 **computer-assisted analytic proof candidate**。

---

## 2. 精确参数化

取自由变量

\[
a=x_{2,0},\qquad b=x_{3,0},\qquad c=x_{8,1},\qquad d=x_{9,1}.
\]

使用变换

\[
a=1-2A,
\qquad b=1-2B,
\qquad
c=2C-1,
\qquad d=2D-1.
\]

再记

\[
E=1-A-B,
\qquad F=1-C-D.
\]

所有 defect strict inequalities 精确等价于

\[
A,B,E,C,D,F>0.
\]

因此参数域不是一般半代数集，而是

\[
\Delta_2^\circ\times\Delta_2^\circ.
\]

完整 pairing matrix 和每个 solved defect 的 \(1-x^2\) 因式分解见主证书 JSON。

---

## 3. Rank-four 证书

选取 rows \(2,3,8,9\) 和 columns \(2,3,4,5\) 作为 pivot block。其行列式恒为

\[
\boxed{-16}.
\]

其余六行均由该四行的显式有理线性组合重构；独立 verifier 对所有 60 个矩阵项逐项化简为零。

线性化 Jacobian determinant 为

\[
-\frac{(a-b-2)(a-b+2)(c-d-2)(c-d+2)}{256},
\]

在 product-simplex 严格域内不为零。

---

## 4. Primal extremality

在 chosen rowspace basis 中，六个正向 primal columns 为

\[
\begin{aligned}
v_0&=(a,b,1,1),\\
v_1&=(1,1,c,d),\\
v_2&=(-1,-1,-1,1),\\
v_3&=(-1,-1,1,-1),\\
v_4&=(-1,1,1,1),\\
v_5&=(-1,1,-1,-1).
\end{aligned}
\]

四个固定 sign columns 由 pivot-coordinate facets 暴露。

对 \(v_0\)，四条 supporting normals 的 determinant 为

\[
\frac{A+B-1}{(A-B-1)(A-B+1)}\ne0.
\]

对 \(v_1\)，对应 determinant 为

\[
-\frac{C+D-1}{(C-D-1)(C-D+1)}\ne0.
\]

所以六对 vertices 全部 genuine，未发生降到 10V 的退化。

---

## 5. Section closure

对所有

\[
\binom64 2^4=240
\]

个 active four-face charts 进行 exact 检查，得到：

\[
\boxed{
52\text{ 个预期顶点出现},
\quad176\text{ 个全域 cube-violation},
\quad12\text{ 个分域奇异 charts}.
}
\]

52 个出现去重后恰为

\[
\boxed{20\text{ 个 section vertices}}.
\]

12 个特殊 charts 只与内部墙

\[
A=B,
\qquad C=D
\]

有关。离开墙时至少一个 inactive coordinate 严格越出 \([-1,1]\)；在墙上 active system 降秩，交集不是新的孤立顶点。因而没有额外 section vertex。

---

## 6. 四个 chamber 与体积

内部 oriented-matroid walls 只有

\[
A=B,
\qquad C=D.
\]

四个 chambers 是

\[
A\gtrless B,
\qquad C\gtrless D.
\]

每个 chamber 的 fixed triangulation 均通过 66 条非零 orientation 记录；失败数为 0。四个 chambers 独立重算后得到相同公式：

\[
\boxed{|P|=\frac43(10-A-B-C-D)}.
\]

\(|P^\circ|\) 的完整有理式收录于主证书。四个 chamber 的符号化体积完全一致，因此没有隐藏 triangulation switch。

---

## 7. Mahler 正余量

精确化简得到

\[
|P||P^\circ|-\frac{32}{3}
=
\frac{H(A,B,C,D)}
{9(A-B-1)(A-B+1)(C-D-1)(C-D+1)}.
\]

在严格域中，两个二次因子乘积均为正，因此 denominator 严格为正。

将正分子 \(H\) 写成

\[
\Delta_2\times\Delta_2
\]

上的 product-simplex Bernstein basis，bidegree 为

\[
\boxed{(3,3)}.
\]

100 个系数统计为

\[
\boxed{
48>0,
\qquad52=0,
\qquad0<0,
}
\]

最小严格正系数为

\[
\boxed{2}.
\]

开域中每个 Bernstein basis function 严格为正，故

\[
H(A,B,C,D)>0,
\]

最终得到

\[
\boxed{|P||P^\circ|>\frac{32}{3}}.
\]

---

## 8. 可重放检查

独立 verifier 检查：

- dependency hashes；
- exact rank-four reconstruction；
- strict-domain factorization；
- 12 个 primal vertices 的 extremality；
- 240-chart section closure；
- 四个 chamber 的 orientation 与 exact sample volumes；
- product-simplex Bernstein 系数。

当前输出：`PASS`。
