#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor family 86.

The verifier uses exact SymPy arithmetic. It checks:
  * the rational rank-four completion;
  * the exact strict-domain parametrization Delta_3^o x (0,1);
  * the normalized two-slab geometry, including one antipodal pair of
    tangential cap contacts and the resulting exact 20-vertex closure;
  * global primal and polar volume formulae;
  * a strict Mahler lower margin via a degree-(2,4) Bernstein certificate.

This is a computer-assisted analytic proof candidate, not an externally
reviewed theorem.
"""
from __future__ import annotations

import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family86_verifier_output.json"


def same(x, y):
    return sp.cancel(x - y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees):
    P = sp.Poly(sp.expand(poly), *variables)
    terms = {m: sp.Rational(c) for m, c in P.terms()}
    out = {}
    for index in itertools.product(*[range(n + 1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in terms.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff * factor
        out[index] = sp.factor(value)
    return out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def main():
    started = time.time()
    checks = []

    # Original variables and Delta_3 x interval coordinates.
    a, b, c, t = sp.symbols("a b c t", real=True)
    A, B, C, R = sp.symbols("A B C R", positive=True)
    D = 1 - A - B - C
    K = 2 - R
    H = (1 - R) * A / K
    domain_sub = {
        t: 1 - 2*R,
        a: 2*(A/K + D) - 1,
        b: 2*(A/K + C) - 1,
        c: 2*(A/K + B) - 1,
    }

    # Exact completed pairing matrix.
    M = sp.Matrix([
        [(a*t-a+2*b+2*c+2)/(t-3), (t+1)/(t-3), 1, -1, -1, -1],
        [(2*a+b*t-b+2*c+2)/(t-3), (t+1)/(t-3), 1, -1, 1, 1],
        [(2*a+2*b+c*t-c+2)/(t-3), (t+1)/(t-3), 1, 1, -1, 1],
        [a, 1, -1, -1, -1, -1],
        [b, 1, -1, -1, 1, 1],
        [c, 1, -1, 1, -1, 1],
        [1, -1, t, 1, 1, -1],
        [1,
         -(a*t-a+b*t-b-2*c*t-2*t)/(a*t-a+b*t-b+2*c+2),
         -1,
         -(a*t+3*a+b*t+3*b+2*c*t+2*t)/(a*t-a+b*t-b+2*c+2),
         1, -1],
        [1,
         -(a*t-a-2*b*t+c*t-c-2*t)/(a*t-a+2*b+c*t-c+2),
         -1, 1,
         -(a*t+3*a+2*b*t+c*t+3*c+2*t)/(a*t-a+2*b+c*t-c+2),
         -1],
        [1,
         (2*a*t-b*t+b-c*t+c+2*t)/(2*a+b*t-b+c*t-c+2),
         -1, 1, 1,
         (2*a*t+b*t+3*b+c*t+3*c+2*t)/(2*a+b*t-b+c*t-c+2)],
    ])
    template = [
        [0, 0, 1, -1, -1, -1],
        [0, 0, 1, -1, 1, 1],
        [0, 0, 1, 1, -1, 1],
        [0, 1, -1, -1, -1, -1],
        [0, 1, -1, -1, 1, 1],
        [0, 1, -1, 1, -1, 1],
        [1, -1, 0, 1, 1, -1],
        [1, 0, -1, 0, 1, -1],
        [1, 0, -1, 1, 0, -1],
        [1, 0, -1, 1, 1, 0],
    ]

    pivot_rows = [3, 4, 5, 6]
    pivot_cols = [2, 3, 4, 5]
    basis = M.extract(pivot_rows, range(6))
    pivot = basis.extract(range(4), pivot_cols)
    assert same(pivot.det(), 4*(t - 3))
    assert same(pivot.det().subs(domain_sub), -8*(1 + R))
    coefficients = M.extract(range(10), pivot_cols) * pivot.inv()
    assert all(same(x, 0) for x in coefficients * basis - M)
    checks.append("exact_rank_four_completion")

    # The exact strict domain is Delta_3^o x (0,1).  In original variables,
    # R=(1-t)/2 and the four barycentric coordinates are obtained from
    # S=a+b+c+1 and three short affine forms X_i.
    S = a + b + c + 1
    X1 = R*(c + 1) - a - b
    X2 = R*(b + 1) - a - c
    X3 = R*(a + 1) - b - c
    assert same(A, K*S.subs(domain_sub)/(2*(1 + R)))
    assert same(B, X1.subs(domain_sub)/(2*(1 + R)))
    assert same(C, X2.subs(domain_sub)/(2*(1 + R)))
    assert same(D, X3.subs(domain_sub)/(2*(1 + R)))
    assert same(A + B + C + D, 1)

    Mc = M.subs(domain_sub).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    defect_positions = [
        (i, j) for i, row in enumerate(template) for j, flag in enumerate(row)
        if flag == 0
    ]
    assert len(defect_positions) == 16

    # Recompute and factor 1-x^2 for all defects.  Every factor below has a
    # fixed strict sign under A,B,C,D,R>0, A+B+C+D=1, 0<R<1.
    expected_one_minus_square = {
        (0, 0): 4*D*(1-D),
        (0, 1): 4*R/(1+R)**2,
        (1, 0): 4*C*(1-C),
        (1, 1): 4*R/(1+R)**2,
        (2, 0): 4*B*(1-B),
        (2, 1): 4*R/(1+R)**2,
        (3, 0): 4*(A+K*D)*((1-R)*A+K*(B+C))/K**2,
        (4, 0): 4*((1-R)*A+K*(B+D))*(A+K*C)/K**2,
        (5, 0): 4*(A+K*B)*((1-R)*A+K*(C+D))/K**2,
        (6, 2): 4*R*(1-R),
        (7, 1): 4*R*(1-R)*(A+K*B)*((1-R)*A+2*K*B)/((1+R)**2*((1-R)*A+K*B)**2),
        (7, 3): 4*A*B*K*(1-R)/((1-R)*A+K*B)**2,
        (8, 1): 4*R*(1-R)*(A+K*C)*((1-R)*A+2*K*C)/((1+R)**2*((1-R)*A+K*C)**2),
        (8, 4): 4*A*C*K*(1-R)/((1-R)*A+K*C)**2,
        (9, 1): 4*R*(1-R)*(A+K*D)*((1-R)*A+2*K*D)/((1+R)**2*((1-R)*A+K*D)**2),
        (9, 5): 4*A*D*K*(1-R)/((1-R)*A+K*D)**2,
    }
    for ij in defect_positions:
        value = sp.factor(sp.cancel(1 - Mc[ij]**2))
        assert same(value, expected_one_minus_square[ij])
    checks.append("strict_domain_Delta3_times_interval_and_sixteen_defects")

    # Normalize four primal columns to the standard basis.
    normalized = (pivot.inv() * basis).subs(domain_sub).applyfunc(
        lambda x: sp.factor(sp.cancel(x))
    )
    u = sp.Matrix([-A/K, B+H, C+H, -D-H])
    v = sp.Matrix([-1/(1+R), -R/(1+R), -R/(1+R), R/(1+R)])
    assert all(same(normalized[i, 0], u[i]) for i in range(4))
    assert all(same(normalized[i, 1], v[i]) for i in range(4))
    assert normalized[:, 2:6] == sp.eye(4)
    checks.append("normalized_primal_is_crosspolytope_plus_two_vertex_pairs")

    # Each slab cuts one antipodal pair of simplex caps.
    l1_u = A/K + (B+H) + (C+H) + (D+H)
    l1_v = (1 + 3*R)/(1+R)
    assert same(l1_u, 1 + 2*H)
    assert same(l1_v, 1 + 2*R/(1+R))
    assert same(A/K - H, A*R/K)

    # Same-sign cap closures are strictly disjoint. With
    # lambda=K R and mu=A(1-R^2), the combined normal has a fixed orthant.
    lam_same = K*R
    mu_same = A*(1-R**2)
    z_same = sp.simplify(lam_same*u + mu_same*v)
    expected_same = sp.Matrix([-A, K*R*B, K*R*C, -K*R*D])
    assert all(same(z_same[i], expected_same[i]) for i in range(4))
    support_same = A + K*R*(B+C+D)
    assert same(lam_same + mu_same - support_same, 2*A*R*(1-R))

    # Opposite-sign cap interiors are disjoint, but their closures touch at
    # exactly one cube-edge point.  The support inequality is an equality.
    lam_opp = K
    mu_opp = A*(1+R)
    z_opp = sp.simplify(lam_opp*u - mu_opp*v)
    expected_opp = sp.Matrix([0, A+K*B, A+K*C, -A-K*D])
    assert all(same(z_opp[i], expected_opp[i]) for i in range(4))
    support_opp = 3*A + K*(B+C+D)
    assert same(lam_opp + mu_opp, support_opp)
    y_star = sp.Matrix([1-2*R, 1, 1, -1])
    assert same(u.dot(y_star), 1)
    assert same((-v).dot(y_star), 1)
    checks.append("two_slab_caps_disjoint_except_one_antipodal_tangency_pair")

    # Exact section closure by cap counting. The u-cap pair is generic and
    # adds eight edge vertices. The v-cap pair adds two interior edge points.
    # One antipodal pair is shared at +/-y_star, hence 16-4+8+2-2=20.
    predicted = [
        sp.Matrix([1, -1, -1, -1]),
        sp.Matrix([1, -1, 1, 1]),
        sp.Matrix([1, 1, -1, 1]),
        sp.Matrix([-1, -1, -1, -1]),
        sp.Matrix([-1, -1, 1, 1]),
        sp.Matrix([-1, 1, -1, 1]),
        y_star,
        sp.Matrix([-1, (B-H)/(B+H), 1, -1]),
        sp.Matrix([-1, 1, (C-H)/(C+H), -1]),
        sp.Matrix([-1, 1, 1, (H-D)/(H+D)]),
    ]
    for i, y in enumerate(predicted):
        actual = sp.Matrix([Mc[i, j] for j in range(2, 6)])
        assert all(same(actual[k], y[k]) for k in range(4))
        assert same(u.dot(y), Mc[i, 0])
        assert same(v.dot(y), Mc[i, 1])
    assert 16 - 4 + 8 + 2 - 2 == 20
    checks.append("exact_section_closure_twenty_vertices_by_cap_counting")

    # All twelve primal vertices are genuine. Each coordinate cube facet
    # contains e_i in relative interior; both slab inequalities cut nonempty
    # full-dimensional cap bases. Their cap interiors are not swallowed by
    # the other slab (only one boundary tangency occurs).
    for i in range(4):
        assert sp.factor(1-u[i]**2) != 0
        assert sp.factor(1-v[i]**2) != 0
    checks.append("twelve_primal_vertices_from_nonredundant_cube_and_slab_facets")

    # Global primal volume from the ten positive facets.
    def vertex(j):
        return basis[:, j] if j < 6 else -basis[:, j-6]

    signs = {
        0: [1], 1: [1], 2: [1],
        3: [-1, -1, 1, -1, -1],
        4: [1, 1, 1, -1, -1],
        5: [1, -1, -1, -1, -1],
        6: [-1, 1, -1, -1, 1],
        7: [1], 8: [-1], 9: [1],
    }
    expected_abs = {
        0: [8*(1+R)],
        1: [8*(1+R)],
        2: [8*(1+R)],
        3: [8*R, 8*R, 8*R, 8, 8*(1+R)],
        4: [8*R, 8*R, 8*R, 8, 8*(1+R)],
        5: [8*R, 8*R, 8*R, 8, 8*(1+R)],
        6: [8*(A+K*D)/K, 8*(A+K*C)/K, 8*(A+K*B)/K,
            8*A*(1+R)/K, 8],
        7: [8*(1+R)*(B+H)],
        8: [8*(1+R)*(C+H)],
        9: [8*(1+R)*(D+H)],
    }
    P_volume = sp.Rational(0)
    for i, row in enumerate(template):
        ids = []
        for j, flag in enumerate(row):
            if flag == 1:
                ids.append(j)
            elif flag == -1:
                ids.append(j+6)
        dets = [
            sp.factor(sp.Matrix.hstack(*[vertex(j) for j in subset]).det())
            for subset in itertools.combinations(ids, 4)
        ]
        assert len(dets) == len(signs[i]) == len(expected_abs[i])
        signed_sum = sp.Rational(0)
        for det, sign, expected in zip(dets, signs[i], expected_abs[i]):
            signed = sp.factor(sp.cancel((sign*det).subs(domain_sub)))
            assert same(signed, expected)
            signed_sum += sign*det
        P_volume += sp.factor(signed_sum/(12 if len(ids) == 4 else 24))

    P_target = sp.factor(4*((1-R**2)*A - 5*R**2 + 6*R + 8)/(3*K))
    assert same(P_volume.subs(domain_sub), P_target)
    checks.append("global_primal_volume_by_fixed_sign_facet_circuits")

    # Global polar volume from the cube minus the two cap pairs. The closures
    # only touch at a measure-zero antipodal pair, so cap volumes add.
    cap_u = sp.factor((2*H)**4/(12*(A/K)*(B+H)*(C+H)*(D+H)))
    cap_v = sp.factor((2*R/(1+R))**4 /
                      (12*(1/(1+R))*(R/(1+R))**3))
    assert same(cap_u, 4*H**4/(3*(A/K)*(B+H)*(C+H)*(D+H)))
    assert same(cap_v, 4*R/3)
    Q_target = sp.factor((16-cap_u-cap_v)/(8*(1+R)))
    checks.append("global_polar_volume_by_two_cap_pairs_with_boundary_tangency")

    # Strict Mahler margin. The product inequality
    # (B+H)(C+H)(D+H) > H^2(H+1-A)
    # removes B,C,D and yields a two-variable lower bound.
    product = (B+H)*(C+H)*(D+H)
    product_excess = sp.factor(product - H**2*(H+1-A))
    assert same(product_excess, H*(B*C+B*D+C*D) + B*C*D)
    cap_u_upper = sp.factor(4*(1-R)**2*A/(3*(K-A)))
    Q_lower = sp.factor((16-cap_v-cap_u_upper)/(8*(1+R)))
    exact_margin = sp.factor(P_target*Q_target - sp.Rational(32, 3))
    lower_margin = sp.factor(P_target*Q_lower - sp.Rational(32, 3))

    N = sp.expand(
        A**2*R**4 - 3*A**2*R**3 + 12*A**2*R**2 + 3*A**2*R - 13*A**2
        + 4*A*R**4 - 7*A*R**3 + 4*A*R**2 - 20*A*R + 16*A
        - 5*R**4 + 28*R**3 - 52*R**2 + 32*R
    )
    assert same(lower_margin, 2*N/(9*K*(1+R)*(K-A)))
    assert same(exact_margin-lower_margin,
                P_target*(cap_u_upper-cap_u)/(8*(1+R)))

    bern = tensor_bernstein_coefficients(N, (A, R), (2, 4))
    expected_matrix = [
        [0, 8, sp.Rational(22, 3), 5, 3],
        [8, sp.Rational(27, 2), sp.Rational(32, 3), sp.Rational(45, 8), sp.Rational(3, 2)],
        [3, sp.Rational(27, 4), sp.Rational(9, 2), sp.Rational(3, 4), 0],
    ]
    for i in range(3):
        for j in range(5):
            assert bern[(i, j)] == expected_matrix[i][j]
    stats = bernstein_stats(bern)
    assert stats == {
        "positive": 13,
        "zero": 2,
        "negative": 0,
        "minimum_positive": sp.Rational(3, 4),
    }
    checks.append("strict_Mahler_margin_via_product_bound_and_degree_2_4_Bernstein")

    output = {
        "status": "PASS",
        "family_index": 86,
        "scope": "computer-assisted analytic proof candidate; no external peer review",
        "domain": "Delta_3^o x (0,1): A,B,C,D,R>0, A+B+C+D=1, 0<R<1",
        "rank_pivot_det": "-8*(1+R)",
        "section_vertices": 20,
        "cap_interaction": "same-sign closures disjoint; opposite-sign closures tangent at one antipodal vertex pair",
        "P_volume": str(P_target),
        "Q_volume": str(Q_target),
        "margin_lower_bound_numerator": str(N),
        "margin_bernstein_matrix": [[str(x) for x in row] for row in expected_matrix],
        "checks": checks,
        "elapsed_seconds": round(time.time()-started, 3),
    }
    OUTPUT.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
