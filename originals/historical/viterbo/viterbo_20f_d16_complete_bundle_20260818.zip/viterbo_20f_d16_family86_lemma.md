# Survivor Family 86: exact analytic certificate

## Scope

This note concerns the bounded-12 branch of the four-dimensional centrally symmetric Mahler problem:

\[
12V/20F,\qquad c=0,\qquad D=16.
\]

The conclusion is a **computer-assisted analytic proof candidate**. It has not been externally peer reviewed.

## 1. Exact pairing matrix and rank-four completion

Let

\[
a=x_{3,0},\qquad b=x_{4,0},\qquad c=x_{5,0},\qquad t=x_{6,2}.
\]

The completed pairing matrix is the one encoded in
`viterbo_20f_d16_family86_verifier.py`.  Rows \(3,4,5,6\) and columns \(2,3,4,5\) form a pivot with

\[
\det=4(t-3).
\]

Under the strict-domain parametrization below this becomes

\[
\boxed{\det=-8(1+R)\ne0},
\]

so the matrix has rank exactly four throughout the family.

## 2. Full strict domain

Put

\[
R=\frac{1-t}{2},\qquad K=2-R,
\]

and define four barycentric coordinates \(A,B,C,D\) by

\[
A=\frac{K(a+b+c+1)}{2(1+R)},
\]

\[
B=\frac{R(c+1)-a-b}{2(1+R)},\quad
C=\frac{R(b+1)-a-c}{2(1+R)},\quad
D=\frac{R(a+1)-b-c}{2(1+R)}.
\]

They satisfy

\[
A+B+C+D=1.
\]

The full strict family is exactly

\[
\boxed{A,B,C,D>0,\qquad 0<R<1}.
\]

The inverse map is

\[
a=2\left(\frac{A}{2-R}+D\right)-1,
\]

\[
b=2\left(\frac{A}{2-R}+C\right)-1,
\]

\[
c=2\left(\frac{A}{2-R}+B\right)-1,
\qquad t=1-2R.
\]

Thus the domain is

\[
\boxed{\Delta_3^\circ\times(0,1)}.
\]

The verifier factors \(1-x^2\) for all sixteen defect entries. Every factor is strictly positive on this domain, so no additional strict chamber is omitted.

## 3. Normalized two-slab geometry

After using the pivot to send columns \(2,3,4,5\) to the standard basis, the two remaining positive primal columns are

\[
u=\left(-\frac{A}{K},\ B+H,\ C+H,\ -D-H\right),
\]

\[
v=\frac1{1+R}(-1,-R,-R,R),
\]

where

\[
H=\frac{(1-R)A}{K}.
\]

Therefore

\[
P^\circ=[-1,1]^4
\cap\{|u\cdot y|\le1\}
\cap\{|v\cdot y|\le1\}.
\]

Each slab removes one antipodal pair of simplex caps.

### Same-sign caps

Take

\[
\lambda=KR,\qquad \mu=A(1-R^2).
\]

Then

\[
\lambda u+\mu v=(-A,\ KRB,\ KRC,\ -KRD),
\]

and the cube-support gap is

\[
\lambda+\mu-\|\lambda u+\mu v\|_1
=2AR(1-R)>0.
\]

Hence same-sign cap closures are disjoint.

### Opposite-sign caps

Take

\[
\lambda=K,\qquad \mu=A(1+R).
\]

Then

\[
\lambda u-\mu v=(0,\ A+KB,\ A+KC,\ -A-KD)
\]

and

\[
\lambda+\mu=\|\lambda u-\mu v\|_1.
\]

Thus opposite-sign cap interiors are disjoint, while their closures can touch only on the maximizing cube edge. Solving both cap equations gives the unique contact point

\[
\boxed{y_*=(1-2R,1,1,-1)}
\]

and its antipode.

## 4. Exact section closure

The generic \(u\)-cap pair removes two cube vertices and contributes eight edge-intersection vertices. The degenerate \(v\)-cap pair removes two other cube vertices and contributes two interior edge points. One antipodal pair is shared at \(\pm y_*\). Therefore

\[
16-4+8+2-2=20.
\]

The ten positive representatives are exactly the ten rows of the pairing matrix. In normalized coordinates they are six surviving cube vertices, the shared point \(y_*\), and

\[
\left(-1,\frac{B-H}{B+H},1,-1\right),
\]

\[
\left(-1,1,\frac{C-H}{C+H},-1\right),
\]

\[
\left(-1,1,1,\frac{H-D}{H+D}\right).
\]

Hence

\[
\boxed{P^\circ\text{ has exactly }20\text{ vertices}}
\]

and the primal polytope has all twelve intended vertices.

## 5. Exact volumes

Using fixed-sign facet circuit determinants gives

\[
\boxed{
|P|=
\frac{4\bigl((1-R^2)A-5R^2+6R+8\bigr)}{3(2-R)}.
}
\]

The two antipodal cap-pair volumes in the normalized cube are

\[
C_u=
\frac{4H^4}
{3\,(A/K)(B+H)(C+H)(D+H)},
\]

\[
C_v=\frac{4R}{3}.
\]

Since the only cap contact has measure zero,

\[
\boxed{
|P^\circ|=
\frac{16-C_u-C_v}{8(1+R)}.
}
\]

## 6. Strict Mahler margin

The identity

\[
(B+H)(C+H)(D+H)
-H^2(H+1-A)
=
H(BC+BD+CD)+BCD
>0
\]

implies

\[
C_u<\frac{4(1-R)^2A}{3(2-R-A)}.
\]

Substituting this upper bound into \(|P^\circ|\) gives

\[
|P||P^\circ|-\frac{32}{3}
>
\frac{2N(A,R)}
{9(2-R)(1+R)(2-R-A)},
\]

where

\[
\begin{aligned}
N(A,R)={}&A^2R^4-3A^2R^3+12A^2R^2+3A^2R-13A^2\\
&+4AR^4-7AR^3+4AR^2-20AR+16A\\
&-5R^4+28R^3-52R^2+32R.
\end{aligned}
\]

In tensor Bernstein degree \((2,4)\), the coefficient matrix is

\[
\begin{pmatrix}
0&8&22/3&5&3\\
8&27/2&32/3&45/8&3/2\\
3&27/4&9/2&3/4&0
\end{pmatrix}.
\]

Thus

\[
13>0,\qquad2=0,\qquad0<0,
\]

with minimum positive coefficient \(3/4\). Consequently

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

throughout the complete strict family.

## 7. Conclusion

\[
\boxed{
12V/20F,\ c=0,\ D=16,\ \text{Family }86\quad\checkmark
}
\]

The accompanying verifier recomputes every displayed algebraic identity and the Bernstein certificate using exact arithmetic.
