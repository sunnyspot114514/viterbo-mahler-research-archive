#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor Family 42.

Family 42 was the only preclassified 20F/D=16 survivor for which the
original elimination did not produce a rational parametrization.  The key
reparametrization uses the two normalized cap-slope vectors

    alpha=(k,1,a,c),  beta=(k,b,1,1),  k,a,b,c>1.

Writing K=1/k, A=1/a, B=1/b, C=1/c maps the complete strict component
bijectively to the open unit four-cube.

The verifier checks with exact SymPy arithmetic:
  * the new rational parametrization and rank-four factorization;
  * all sixteen strict defect inequalities by Bernstein certificates;
  * all twelve primal vertices are genuine;
  * exact twenty-vertex section closure from two overlapping cap pairs;
  * exact cap-overlap volume by a fixed tetrahedral decomposition;
  * global primal volume from fixed-sign facet circuits;
  * global polar volume and a strict Bernstein Mahler certificate.

This is a computer-assisted analytic proof candidate, not an externally
reviewed theorem.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family42_verifier_output.json"
CERT = HERE / "viterbo_20f_d16_family42_certificate.json"


def same(x, y):
    return sp.cancel(x-y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees=None):
    poly = sp.expand(poly)
    Ppoly = sp.Poly(poly, *variables)
    if degrees is None:
        degrees = tuple(Ppoly.degree(x) for x in variables)
    terms = {m: sp.Rational(c) for m, c in Ppoly.terms()}
    out = {}
    for index in itertools.product(*[range(n+1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in terms.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff*factor
        out[index] = sp.factor(value)
    return degrees, out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def main():
    started = time.time()
    checks = []

    # Reciprocal slope parameters: k=1/K, a=1/A, b=1/B, c=1/C.
    K,A,B,C = sp.symbols("K A B C", positive=True)
    k,a,b,c = 1/K,1/A,1/B,1/C
    Du = sp.factor(A*C+K*C+K*A-K*A*C)
    assert same(Du, A*C*(1-K)+K*(A+C))

    # Normalized primal columns.  w=-v is written positive at the ++++
    # cube corner.
    u = sp.Matrix([A*C,K*A*C,K*C,K*A])/Du
    w = sp.Matrix([B,K,K*B,K*B])/(B+K)
    v = -w

    # The cap slopes recover the parametrization uniquely.
    hu = sp.factor(sum(u)-1)
    hw = sp.factor(sum(w)-1)
    alpha = [sp.factor(2*x/hu) for x in u]
    beta = [sp.factor(2*x/hw) for x in w]
    assert all(same(x,y) for x,y in zip(alpha,[1/K,1,1/A,1/C]))
    assert all(same(x,y) for x,y in zip(beta,[1/K,1/B,1,1]))

    z7 = (0, B*(1-A)/(1-A*B), A*(1-B)/(1-A*B), 0)
    z8 = (0, B*(1-C)/(1-B*C), 0, C*(1-B)/(1-B*C))
    y_rows = [
        (1,-1,-1,-1),
        (1,-1,-1,1),
        (1,-1,1,-1),
        (1,1,-1,-1),
        (-1,-1,-1,1),
        (-1,-1,1,-1),
        (1-2*K,1,1,1),
        tuple(sp.factor(1-2*z) for z in z7),
        tuple(sp.factor(1-2*z) for z in z8),
        (1,-1,1,1),
    ]
    Y = sp.Matrix(y_rows)
    M = sp.Matrix([
        [sp.factor(u.dot(sp.Matrix(y))),sp.factor(v.dot(sp.Matrix(y))),*y]
        for y in y_rows
    ])
    template = [
        [0,0,1,-1,-1,-1],
        [0,0,1,-1,-1,1],
        [0,0,1,-1,1,-1],
        [0,0,1,1,-1,-1],
        [0,1,-1,-1,-1,1],
        [0,1,-1,-1,1,-1],
        [1,-1,0,1,1,1],
        [1,-1,1,0,0,1],
        [1,-1,1,0,1,0],
        [1,0,1,-1,1,1],
    ]

    for i,row in enumerate(template):
        for j,flag in enumerate(row):
            if flag:
                assert same(M[i,j],flag)
    primal_matrix = sp.Matrix.hstack(u,v,sp.eye(4))
    assert all(same(z,0) for z in M-Y*primal_matrix)
    assert Y.extract([0,1,2,3],range(4)).det() == -8
    checks.append("new_reciprocal_slope_parametrization_and_exact_rank_four_factorization")

    # Strict defects on the complete open unit-cube component.
    sample={K:sp.Rational(1,3),A:sp.Rational(2,5),
            B:sp.Rational(1,2),C:sp.Rational(3,5)}
    defect_positions=[
        (i,j) for i,row in enumerate(template) for j,flag in enumerate(row)
        if flag==0
    ]
    assert len(defect_positions)==16
    defect_certificates=[]
    positive_denominators=[Du**2,(B+K)**2,(1-A*B)**2,(1-B*C)**2,sp.Integer(1)]
    for i,j in defect_positions:
        expr=sp.factor(sp.cancel(1-M[i,j]**2))
        numerator,denominator=map(sp.factor,sp.fraction(expr))
        if denominator.subs(sample)<0:
            numerator,denominator=-numerator,-denominator
        assert any(same(denominator,d) for d in positive_denominators)
        degrees,bern=tensor_bernstein_coefficients(numerator,(K,A,B,C))
        stats=bernstein_stats(bern)
        assert stats["negative"]==0 and stats["positive"]>0
        defect_certificates.append({
            "position":[i,j],"degrees":list(degrees),
            "positive":stats["positive"],"zero":stats["zero"],
            "minimum_positive":str(stats["minimum_positive"]),
        })
    checks.append("open_unit_four_cube_is_exact_strict_component_and_all_sixteen_defects")

    # All six primal columns have full-dimensional normal cones.
    selections={
        0:[(6,1),(7,1),(8,1),(9,1)],
        1:[(4,1),(5,1),(6,-1),(7,-1)],
        2:[(0,1),(1,1),(3,1),(4,-1)],
        3:[(0,-1),(1,-1),(2,-1),(3,1)],
        4:[(0,-1),(1,-1),(2,1),(3,-1)],
        5:[(0,-1),(1,1),(2,-1),(3,-1)],
    }
    expected={
        0:8*(B-1)**2*(A*C*K-A*C-A*K-C*K)/((A*B-1)*(B*C-1)),
        1:8*(A-1)*(B+K)/(A*B-1),
        2:8,3:8,4:8,5:8,
    }
    extremality=[]
    for j,sel in selections.items():
        mat=sp.Matrix.hstack(*[
            sp.Matrix([sgn*Y[i,t] for t in range(4)]) for i,sgn in sel
        ])
        det=sp.factor(sp.cancel(mat.det()))
        assert same(det,expected[j])
        extremality.append({"column":j,"rows":sel,"determinant":str(det)})
    checks.append("all_twelve_primal_vertices_have_full_dimensional_normal_cones")

    # Exact section closure.  At ++++, the two caps are
    #   z0/K+z1+z2/A+z3/C < 1,
    #   z0/K+z1/B+z2+z3 < 1.
    # Their boundary intersection is a triangle with the following vertices.
    z_vertices=[
        (K,0,0,0),
        z7,
        z8,
    ]
    new_y=[tuple(sp.factor(1-2*z) for z in point) for point in z_vertices]
    assert new_y[0]==y_rows[6]
    assert all(same(new_y[1][i],y_rows[7][i]) for i in range(4))
    assert all(same(new_y[2][i],y_rows[8][i]) for i in range(4))

    # The other individual simplex vertices are either surviving adjacent
    # cube vertices or lie strictly inside the other cap.
    assert same(1-A,1-A) and same(1-B,1-B) and same(1-C,1-C)
    cube_vertices=list(itertools.product([-1,1],repeat=4))
    surviving=[x for x in cube_vertices if x not in ((1,1,1,1),(-1,-1,-1,-1))]
    expected_points=set(surviving)
    for point in new_y:
        expected_points.add(tuple(sp.factor(x) for x in point))
        expected_points.add(tuple(sp.factor(-x) for x in point))
    assert len(expected_points)==20
    checks.append("exact_twenty_vertex_section_closure_from_intersection_triangle")

    # Polar cap and overlap volumes.  The one-corner overlap is obtained by
    # integrating a fixed 3D base polytope along the shared z0 coefficient.
    cap_u_pair=sp.factor(hu**4/(12*sp.prod(u)))
    cap_w_pair=sp.factor(hw**4/(12*sp.prod(w)))
    assert same(cap_u_pair,sp.Rational(4,3)*A*C*K)
    assert same(cap_w_pair,sp.Rational(4,3)*B*K)

    # Base vertices in (z1,z2,z3); the base is triangulated into three
    # tetrahedra with the origin.
    X1=sp.Matrix([B,0,0])
    X2=sp.Matrix([0,A,0])
    X3=sp.Matrix([0,0,C])
    Dpt=sp.Matrix([B*(1-A)/(1-A*B),A*(1-B)/(1-A*B),0])
    Ept=sp.Matrix([B*(1-C)/(1-B*C),0,C*(1-B)/(1-B*C)])
    def tet3(x,y,z):
        return sp.factor(sp.Matrix.hstack(x,y,z).det()/6)
    t1=tet3(X1,Dpt,Ept)
    t2=-tet3(X2,Dpt,Ept)
    t3=-tet3(X2,Ept,X3)
    base_volume=sp.factor(t1+t2+t3)
    for tvol in (t1,t2,t3):
        numerator,denominator=map(sp.factor,sp.fraction(tvol))
        if denominator.subs(sample)<0:
            numerator,denominator=-numerator,-denominator
        degrees,bern=tensor_bernstein_coefficients(numerator,(K,A,B,C))
        stats=bernstein_stats(bern)
        assert stats["negative"]==0 and stats["positive"]>0
    overlap_pair=sp.factor(8*K*base_volume)
    polar_volume=sp.factor(16-cap_u_pair-cap_w_pair+overlap_pair)
    checks.append("global_polar_volume_from_exact_three_tetrahedra_overlap_decomposition")

    # Global primal volume from fixed-sign facet circuits.
    columns=[u,v]+[sp.eye(4)[:,i] for i in range(4)]
    def signed_vertex(index):
        return columns[index] if index<6 else -columns[index-6]
    primal_volume=sp.Rational(0)
    determinant_records=[]
    clear_factor=(B+K)*Du*(1-A*B)*(1-B*C)
    for i,row in enumerate(template):
        ids=[j if flag==1 else j+6 for j,flag in enumerate(row) if flag]
        signed_sum=sp.Rational(0)
        for subset in itertools.combinations(ids,4):
            det=sp.factor(sp.cancel(sp.Matrix.hstack(*[
                signed_vertex(j) for j in subset
            ]).det()))
            assert not same(det,0)
            sg=1 if det.subs(sample)>0 else -1
            cleared=sp.factor(sp.cancel(sg*det*clear_factor))
            numerator,denominator=map(sp.factor,sp.fraction(cleared))
            assert same(denominator,1)
            degrees,bern=tensor_bernstein_coefficients(numerator,(K,A,B,C))
            stats=bernstein_stats(bern)
            assert stats["negative"]==0 and stats["positive"]>0
            determinant_records.append({
                "facet":i,"subset":list(subset),"sign":sg,
                "degrees":list(degrees),"positive":stats["positive"],
                "zero":stats["zero"],
                "minimum_positive":str(stats["minimum_positive"]),
            })
            signed_sum+=sg*det
        primal_volume+=sp.factor(signed_sum/(12 if len(ids)==4 else 24))
    primal_volume=sp.factor(sp.cancel(primal_volume))
    target_primal=sp.factor(
        (2*A*B*C*K**2+3*A*B*C*K-4*A*B*C-A*B*K**2-4*A*B*K
         +3*A*C*K**2-4*A*C*K-4*A*K**2-B*C*K**2-4*B*C*K
         -4*C*K**2)/(6*(B+K)*(A*C*K-A*C-A*K-C*K))
    )
    assert same(primal_volume,target_primal)
    assert len(determinant_records)==26
    checks.append("global_primal_volume_from_twenty_six_fixed_sign_facet_circuits")

    # Strict Mahler margin on the full unit cube.
    margin=sp.factor(sp.cancel(primal_volume*polar_volume-sp.Rational(32,3)))
    margin_num,margin_den=map(sp.factor,sp.fraction(margin))
    if margin_den.subs(sample)<0:
        margin_num,margin_den=-margin_num,-margin_den
    assert margin_den.subs(sample)>0
    degrees,margin_bern=tensor_bernstein_coefficients(margin_num,(K,A,B,C))
    margin_stats=bernstein_stats(margin_bern)
    assert degrees==(3,2,3,2)
    assert margin_stats["positive"]==52
    assert margin_stats["zero"]==92
    assert margin_stats["negative"]==0
    assert margin_stats["minimum_positive"]==sp.Rational(2,3)
    checks.append("strict_mahler_margin_tensor_bernstein_certificate")

    certificate={
        "family_index":42,
        "scope":"12V/20F, c=0, D=16",
        "status":"computer-assisted analytic proof candidate",
        "new_parametrization":{
            "domain":"0<K,A,B,C<1",
            "slopes":"k=1/K, a=1/A, b=1/B, c=1/C",
            "alpha":"(k,1,a,c)","beta":"(k,b,1,1)",
        },
        "normalized_columns":{"u":[str(sp.factor(x)) for x in u],
                              "v":[str(sp.factor(x)) for x in v]},
        "defect_certificates":defect_certificates,
        "primal_extremality":extremality,
        "section_closure":{
            "surviving_cube_vertices":14,"new_vertices_per_corner":3,
            "total_vertices":20,
            "new_positive_vertices":[[str(x) for x in y] for y in new_y],
        },
        "cap_volumes":{"u_pair":str(cap_u_pair),"v_pair":str(cap_w_pair),
                       "overlap_pair":str(overlap_pair)},
        "volumes":{"P":str(primal_volume),"P_polar":str(polar_volume),
                   "margin":str(margin)},
        "circuit_certificates":{"count":len(determinant_records),
                                "records":determinant_records},
        "mahler_bernstein":{
            "degrees":list(degrees),"positive":margin_stats["positive"],
            "zero":margin_stats["zero"],"negative":margin_stats["negative"],
            "minimum_positive":str(margin_stats["minimum_positive"]),
        },
        "conclusion":"Family 42 has a complete rational parametrization, exactly 12 primal vertices and 20 polar vertices, and satisfies |P||P^o|>32/3 throughout its strict component.",
        "caveat":"Not externally peer reviewed.",
    }
    CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True),encoding="utf-8")
    cert_hash=hashlib.sha256(CERT.read_bytes()).hexdigest()
    output={
        "status":"PASS","family_index":42,"checks":checks,
        "certificate":CERT.name,"certificate_sha256":cert_hash,
        "elapsed_seconds":round(time.time()-started,3),
        "conclusion":certificate["conclusion"],
        "caveat":"Computer-assisted analytic proof candidate; not externally peer reviewed.",
    }
    OUTPUT.write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps(output,indent=2))


if __name__=="__main__":
    main()
