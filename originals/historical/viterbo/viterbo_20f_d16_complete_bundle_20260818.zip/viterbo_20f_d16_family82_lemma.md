# Survivor 82 in the bounded-12 four-dimensional symmetric Mahler program

## Statement

Consider the `12V/20F`, `c=0`, `D=16` sign template indexed by 82 in the current finite classification. After exact rank-four completion, write

\[
a=x_{3,5},\qquad b=x_{5,0},\qquad c=x_{6,1},\qquad d=x_{7,5}.
\]

The strict realization domain is

\[
-1<a<d<1,
\qquad
\frac{a-1}{a+3}<c<1,
\qquad
-\frac{d+1}{3-d}<b<1.
\]

It is rationally and bijectively parametrized by the open unit four-cube:

\[
a=2A-1,
\]

\[
d=2A+2(1-A)D-1,
\]

\[
c=\frac{A+2C-1}{A+1},
\]

\[
b=\frac{AD-A+2B-D}{AD-A-D+2},
\qquad 0<A,D,B,C<1.
\]

On this entire domain, the associated centrally symmetric four-polytope has exactly 12 vertices and 20 facets and satisfies

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

The result is a computer-assisted analytic proof candidate. It has not undergone external peer review.

---

## 1. Exact domain and rank

The domain identities are

\[
1+a=2A,
\qquad d-a=2(1-A)D,
\qquad 1-d=2(1-A)(1-D),
\]

\[
c-\frac{a-1}{a+3}=\frac{2C}{A+1},
\qquad 1-c=\frac{2(1-C)}{A+1},
\]

\[
b+\frac{d+1}{3-d}=\frac{2B}{AD-A-D+2},
\qquad 1-b=\frac{2(1-B)}{AD-A-D+2}.
\]

The selected rank pivot has determinant

\[
\boxed{8}.
\]

All remaining rows are reconstructed exactly from the four pivot rows. Every one of the 16 defect entries satisfies \(1-x_{ij}^2>0\), certified by tensor-Bernstein coefficients on the unit four-cube.

Two exact supporting-normal determinants certify that the two nonfixed primal columns remain extreme:

\[
\frac{(A-1)(D-1)(AD-A-D+2)}{AD-A+B-D+1},
\]

\[
-\frac{A(A+1)}{A+C}.
\]

Neither vanishes in the strict domain. Hence all six antipodal vertex-pairs remain genuine.

---

## 2. Exact cube-section closure

All

\[
\binom64 2^4=240
\]

active-face charts were regenerated exactly. Their classification is

\[
\boxed{
240
=52\text{ expected occurrences}
+164\text{ one-coordinate violations}
+8\text{ paired-factor exclusions}
+16\text{ nonisolated rank-three charts}.
}
\]

The 52 expected occurrences reduce to exactly 20 distinct section vertices, namely the ten prescribed rows and their antipodes.

For the 164 ordinary exclusions, one inactive coordinate \(z\) has

\[
1-z^2<0
\]

throughout the open four-cube; each claim has a tensor-Bernstein certificate.

The eight exceptional nonsingular charts fall into two exact types. In Type I, the two cube inequalities would imply \(F_1\ge0\) and \(F_2\le0\), while

\[
F_2-F_1
=(C-1)
\bigl(ABD-AB-2AD+2A-BD+2D-2\bigr)>0.
\]

In Type II they would imply \(F_1\le0\) and \(F_2\ge0\), while

\[
F_2-F_1
=-(B-1)(AC-2A-C)<0.
\]

Both are contradictions.

For the singular active set \(\{0,1,3,5\}\), the four-by-four determinant is identically zero, whereas the three-by-three minor

\[
\frac{(b-1)(c-1)(a-d+2)}{2}
\]

is nonzero throughout the strict domain. These charts therefore have rank exactly three and do not generate isolated section vertices.

Consequently

\[
\boxed{L\cap[-1,1]^6\text{ has exactly the prescribed 20 vertices}.}
\]

---

## 3. Global primal volume without chamber assumptions

Six positive facets are tetrahedral and four have five vertices. For a five-vertex three-dimensional facet with vertices \(w_1,\dots,w_5\), the cone-volume circuit identity is

\[
\operatorname{vol}\bigl(\operatorname{conv}(0,w_1,\dots,w_5)\bigr)
=
\frac1{48}
\sum_{i=1}^5
\left|
\det(w_1,\dots,\widehat{w_i},\dots,w_5)
\right|.
\]

All 26 determinant signs are fixed on the strict domain by tensor-Bernstein certificates. Summing the ten antipodal facet-pair contributions gives

\[
\boxed{
|P|
=-\frac{ac-a-bd+b+c+d-18}{3}.
}
\]

This derivation does not require a globally fixed triangulation.

---

## 4. Global polar volume as cube minus disjoint simplex caps

Normalize the four pivot primal columns to the standard basis. The determinant of this map is \(1/8\). The two remaining primal columns become

\[
v_0=(-\alpha,-\beta,\alpha,\gamma),
\]

\[
v_1=(-\delta,-\varepsilon,\delta,-\zeta),
\]

where

\[
\alpha=\frac{(1-b)(1-d)}4,
\quad
\beta=\frac{1+b}{2},
\quad
\gamma=\frac{1-b}{2},
\]

\[
\delta=\frac{(1+a)(1-c)}4,
\quad
\varepsilon=\frac{1+c}{2},
\quad
\zeta=\frac{1-c}{2}.
\]

Thus the normalized polar is

\[
[-1,1]^4
\cap\{|v_0\cdot y|\le1\}
\cap\{|v_1\cdot y|\le1\}.
\]

The domain conditions imply

\[
\alpha<\beta,\gamma,
\qquad
\delta<\varepsilon,\zeta.
\]

Each halfspace therefore removes a pair of antipodal four-simplex caps. Their pair-volumes are

\[
C_0=rac{(1-b)(1-d)^2}{3(1+b)},
\]

\[
C_1=rac{(1+a)^2(1-c)}{3(1+c)}.
\]

The two cap pairs are disjoint. For same-sign caps, use the positive weights \(\zeta,\gamma\). The gap between the weighted threshold and the cube support function is

\[
\gamma\zeta(d-a)>0.
\]

For opposite-sign caps, use weights \(\delta,\alpha\). The relevant cube support function is bounded by

\[
\alpha\varepsilon+\delta\beta+\delta\gamma+\alpha\zeta
=\alpha+\delta,
\]

whereas simultaneous strict cap inequalities would demand a value strictly larger than \(\alpha+\delta\).

Hence the normalized polar volume is exactly

\[
16-C_0-C_1.
\]

Undoing the determinant-eight normalization gives

\[
\boxed{
|P^\circ|
=2
-\frac{(1-b)(1-d)^2}{24(1+b)}
-\frac{(1+a)^2(1-c)}{24(1+c)}.
}
\]

This is algebraically identical to the expanded rational volume formula obtained independently from the sample triangulation, but the cap proof is global and has no oriented-matroid chamber assumption.

---

## 5. Strict Mahler remainder

After substituting the unit-cube parametrization,

\[
|P||P^\circ|-\frac{32}{3}
=
\frac{H(A,D,B,C)}
{9(A+1)(A+C)(AD-A-D+2)(AD-A+B-D+1)}.
\]

Every denominator factor is strictly positive in the open cube. The tensor degree of \(H\) is

\[
(5,3,2,2).
\]

Its 216 tensor-Bernstein coefficients satisfy

\[
\boxed{126>0,\qquad90=0,\qquad0<0,}
\]

with smallest positive coefficient

\[
\boxed{\frac25}.
\]

Since every Bernstein basis function is positive in the open cube,

\[
H(A,D,B,C)>0.
\]

Therefore

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

throughout the complete strict realization domain.
