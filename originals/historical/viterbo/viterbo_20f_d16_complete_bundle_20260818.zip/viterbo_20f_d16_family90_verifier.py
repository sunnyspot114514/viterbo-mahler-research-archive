#!/usr/bin/env python3
"""Exact consistency verifier for 12V/20F, c=0, D=16, survivor family 90."""
from __future__ import annotations
import hashlib,itertools,json,math,time
from pathlib import Path
import sympy as sp
HERE=Path(__file__).resolve().parent
MASTER=HERE/'viterbo_20f_d16_family90_certificate.json';CLOSURE=HERE/'viterbo_20f_d16_family90_closure_certificate.json';TRIS=HERE/'viterbo_20f_d16_family90_chamber_triangulations.json';ORIENT=HERE/'viterbo_20f_d16_family90_orientation_certificate.json';OUTPUT=HERE/'viterbo_20f_d16_family90_verifier_output.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def reconstruct(entries,A,B,C,D,m,n):
 E=1-A-B;F=1-C-D;z=0
 for alpha,val in entries:
  e,i,j,f,k,l=alpha;z+=sp.Rational(val)*sp.factorial(m)/(sp.factorial(e)*sp.factorial(i)*sp.factorial(j))*E**e*A**i*B**j*sp.factorial(n)/(sp.factorial(f)*sp.factorial(k)*sp.factorial(l))*F**f*C**k*D**l
 return sp.expand(z)
def main():
 t=time.time();master=json.loads(MASTER.read_text());closure=json.loads(CLOSURE.read_text());tris=json.loads(TRIS.read_text());orient=json.loads(ORIENT.read_text());checks=[]
 for name,h in master['dependencies_sha256'].items():assert sha(HERE/name)==h
 checks.append('dependency_hashes')
 a,b,c,d=sp.symbols('a b c d');A,B,C,D=sp.symbols('A B C D');E=1-A-B;F=1-C-D;L={'a':a,'b':b,'c':c,'d':d,'A':A,'B':B,'C':C,'D':D,'E':E,'F':F}
 M=sp.Matrix([[sp.sympify(x,locals=L) for x in row] for row in master['matrix_entries']]);sub={a:1-2*A,b:1-2*B,c:2*C-1,d:2*D-1};Ms=M.subs(sub).applyfunc(lambda x:sp.factor(sp.cancel(x)))
 pr=master['rank_certificate']['pivot_rows'];pc=master['rank_certificate']['pivot_cols'];P=M.extract(pr,pc);assert str(P.det())==master['rank_certificate']['pivot_det'];Brows=M.extract(pr,range(6));Pinv=P.inv()
 for i,eco in enumerate(master['rank_certificate']['row_coefficients']):
  co=(M.extract([i],pc)*Pinv).applyfunc(lambda x:sp.factor(sp.cancel(x)));assert [str(x) for x in co]==eco;assert all(x==0 for x in (co*Brows-M.row(i)).applyfunc(lambda x:sp.factor(sp.cancel(x))))
 checks.append('rank_four')
 got=[]
 for i,row in enumerate(master['template']):
  for j,x in enumerate(row):
   if x==0:got.append((f'x{i}_{j}',str(sp.factor(Ms[i,j])),str(sp.factor(sp.cancel(1-Ms[i,j]**2)))))
 exp={(x['entry'],x['expression'],x['one_minus_square']) for x in master['strict_defect_certificates']};assert set(got)==exp and len(got)==16
 checks.append('strict_domain_factorization')
 Al=(M.extract(range(10),pc)*P.inv()).applyfunc(lambda x:sp.factor(sp.cancel(x)))
 det0=sp.factor(sp.cancel(Al.extract([6,7,8,9],range(4)).det()).subs(sub));det1=sp.factor(sp.cancel(Al.extract([2,3,4,5],range(4)).det()).subs(sub));assert str(det0)==master['primal_extremality']['column_0_normal_det'];assert str(det1)==master['primal_extremality']['column_1_normal_det']
 checks.append('twelve_primal_vertices')
 expected=[Ms.row(i) for i in range(10)]+[-Ms.row(i) for i in range(10)];records={(tuple(r['active_set']),tuple(r['signs'])):r for r in closure['records']};assert len(records)==240
 def eq(z,w):return all(sp.cancel(z[j]-w[j])==0 for j in range(6))
 stats={'expected_occurrences':0,'global_violation':0,'special_split':0};ids=set()
 for S in itertools.combinations(range(6),4):
  T=[j for j in range(6) if j not in S];Q=Brows.subs(sub)[:,S].T;det=sp.factor(Q.det());Qi=Q.inv()
  for signs in itertools.product((-1,1),repeat=4):
   r=records[(S,signs)];z=((Qi*sp.Matrix(signs)).T*Brows.subs(sub)).applyfunc(lambda x:sp.factor(sp.cancel(x)));assert r['active_det']==str(det)
   if r['kind']=='expected':assert eq(z,expected[r['expected_index']]);ids.add(r['expected_index']);stats['expected_occurrences']+=1
   elif r['kind']=='global_violation':
    j=r['violating_coordinate'];q=sp.factor(sp.cancel(1-z[j]**2));assert str(q)==r['one_minus_square']
    if r.get('proof_type')=='factor_sign':assert S==(2,3,4,5)
    else:
     num,den=sp.fraction(q);assert str(num)==r['numerator'] and str(den)==r['denominator'];co,fac=sp.factor_list(sp.factor(den),A,B,C,D);assert co>0 and all(e%2==0 for _,e in fac);m,n=r['bernstein_bidegree'];entries=[(tuple(x['alpha']),sp.Rational(x['value'])) for x in r['bernstein_nonzero_coefficients']];assert sp.expand(reconstruct(entries,A,B,C,D,m,n)+num)==0;assert all(v>0 for _,v in entries)
    stats['global_violation']+=1
   else:
    assert r['kind']=='special_split' and tuple(S) in {(0,1,2,3),(0,1,4,5)};assert [str(sp.factor(z[j])) for j in T]==r['inactive_coordinates'];stats['special_split']+=1
 assert stats==closure['stats'] and len(ids)==20;checks.append('section_closure_240_charts')
 # Exact rational sample replay for all four certified chambers.
 commonP=commonQ=None
 for name,data in tris.items():
  assert all(r['ok'] for r in orient['chambers'][name]);assert len(orient['chambers'][name])==len(data['P_tets'])+len(data['Q_positive_tets']);s=list(map(sp.Rational,data['sample']));so={a:1-2*s[0],b:1-2*s[1],c:2*s[2]-1,d:2*s[3]-1};Bn=Brows.subs(so);An=Al.subs(so);pv=sp.Rational(0);qv=sp.Rational(0)
  for tet in data['P_tets']:
   cols=[Bn[:,i] if i<6 else -Bn[:,i-6] for i in tet];pv+=abs(sp.Matrix.hstack(*cols).det())
  for tet in data['Q_positive_tets']:
   cols=[An[i,:].T if i<10 else -An[i-10,:].T for i in tet];qv+=abs(sp.Matrix.hstack(*cols).det())
  pv/=24;qv/=12;ep=sp.sympify(data['P_volume'],locals={'x2_0':a,'x3_0':b,'x8_1':c,'x9_1':d});eqv=sp.sympify(data['Q_volume'],locals={'x2_0':a,'x3_0':b,'x8_1':c,'x9_1':d});assert sp.cancel(pv-ep.subs(so))==0 and sp.cancel(qv-eqv.subs(so))==0
  if commonP is None:commonP,commonQ=data['P_volume'],data['Q_volume']
  else:assert commonP==data['P_volume'] and commonQ==data['Q_volume']
 assert orient['fail_count']==0;checks.append('four_chamber_certificate_and_exact_sample_volumes')
 Pvs=sp.sympify(master['volumes']['P_product_simplex'],locals=L);Qvs=sp.sympify(master['volumes']['Q_product_simplex'],locals=L);margin=sp.factor(sp.cancel(Pvs*Qvs-sp.Rational(32,3)));assert str(margin)==master['mahler_margin']['expression'];G=sp.sympify(master['mahler_margin']['positive_polynomial'],locals=L);m,n=master['mahler_margin']['bernstein_bidegree'];entries=[(tuple(x['alpha']),sp.Rational(x['value'])) for x in master['mahler_margin']['coefficients']];assert sp.expand(reconstruct(entries,A,B,C,D,m,n)-G)==0;vals=[v for _,v in entries];assert sum(1 for v in vals if v>0)==48 and sum(1 for v in vals if v==0)==52 and not any(v<0 for v in vals) and min(v for v in vals if v>0)==2
 checks.append('mahler_margin_product_bernstein')
 out={'status':'PASS','family_index':90,'checks':checks,'elapsed_seconds':round(time.time()-t,3),'closure_stats':stats,'orientation_records':{k:len(v) for k,v in orient['chambers'].items()},'bernstein':{'bidegree':[3,3],'positive':48,'zero':52,'negative':0,'min_positive':'2'},'conclusion':'Mahler product > 32/3 throughout the product of strict 2-simplexes.'};OUTPUT.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:OUTPUT.write_text(json.dumps({'status':'FAIL','error':repr(e)},indent=2));raise
