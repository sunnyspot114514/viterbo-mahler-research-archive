#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor Family 17.

The family is written directly in a rank-four normalized form

    P = conv{±e_1,...,±e_4, ±u, ±v}.

The verifier checks with exact SymPy arithmetic:
  * exact strict-domain parametrization by the open unit four-cube;
  * all sixteen defect inequalities by tensor Bernstein certificates;
  * rank exactly four and all twelve primal vertices genuine;
  * exact twenty-vertex cube-section closure;
  * the two overlapping limiting simplex-cap pairs and their overlap volume;
  * global primal volume from fixed-sign facet circuits;
  * global polar volume and strict Mahler margin;
  * an independent tensor Bernstein certificate for the margin.

This is a computer-assisted analytic proof candidate, not an externally
reviewed theorem.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family17_verifier_output.json"
CERT = HERE / "viterbo_20f_d16_family17_certificate.json"


def same(x, y):
    return sp.cancel(x-y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees=None):
    poly = sp.expand(poly)
    Ppoly = sp.Poly(poly, *variables)
    if degrees is None:
        degrees = tuple(Ppoly.degree(x) for x in variables)
    terms = {m: sp.Rational(c) for m, c in Ppoly.terms()}
    out = {}
    for index in itertools.product(*[range(n+1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in terms.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff*factor
        out[index] = sp.factor(value)
    return degrees, out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def main():
    started = time.time()
    checks = []

    # Exact unit-cube parametrization.  The original four free defects are
    # p=1-2P, q=1-2Q, r=1-2R, s=1-2S, with
    # P,Q,R,S>0 and R+S<1.  R=U, S=(1-U)V is a bijection from (0,1)^4.
    P, Q, U, V = sp.symbols("P Q U V", positive=True)
    R = U
    S = (1-U)*V
    E = 1-R-S
    assert same(E, (1-U)*(1-V))

    DS = sp.factor(P*Q*E + S*(P+Q))
    DSbar = sp.factor(P*Q*(1-V)+V*(P+Q))
    DR = sp.factor(P*Q*E + R*(P+Q))
    assert same(DS, (1-U)*DSbar)
    assert same(DR, P*Q*(1-U)*(1-V)+U*(P+Q))

    # The two non-coordinate primal columns after GL(4) normalization.
    u = sp.Matrix([
        Q*S/DS,
        P*S/DS,
        P*Q*S/DS,
        P*Q*(1-R)/DS,
    ])
    v = sp.Matrix([
        -Q*R/DR,
        -P*R/DR,
        -P*Q*(1-S)/DR,
        -P*Q*R/DR,
    ])

    # Ten positive section vertices (facet normals), with their antipodes.
    y_rows = [
        (1,-1,-1,-1),
        (1,-1,-1,1),
        (1,-1,1,-1),
        (1,-1,1,1),
        (1,1,-1,-1),
        (-1,-1,-1,1),
        (1-2*P,1,1,1),
        (1,1-2*Q,1,1),
        (1,1,1-2*R,1-2*S),
        (1,1,-1,1),
    ]
    Y = sp.Matrix(y_rows)
    M = sp.Matrix([
        [sp.factor(u.dot(sp.Matrix(y))), sp.factor(v.dot(sp.Matrix(y))), *y]
        for y in y_rows
    ])
    template = [
        [0,0,1,-1,-1,-1],
        [0,0,1,-1,-1,1],
        [0,0,1,-1,1,-1],
        [0,0,1,-1,1,1],
        [0,0,1,1,-1,-1],
        [0,1,-1,-1,-1,1],
        [1,-1,0,1,1,1],
        [1,-1,1,0,1,1],
        [1,-1,1,1,0,0],
        [1,0,1,1,-1,1],
    ]

    # Every prescribed incidence is exactly ±1, and M=Y[u v I_4].
    for i, row in enumerate(template):
        for j, flag in enumerate(row):
            if flag:
                assert same(M[i,j], flag)
    primal_matrix = sp.Matrix.hstack(u, v, sp.eye(4))
    assert all(same(z, 0) for z in M-Y*primal_matrix)
    assert Y.extract([0,1,2,4], range(4)).det() == -8
    checks.append("exact_rank_four_factorization")

    # All sixteen defect entries lie strictly in (-1,1).  DS and DR are
    # manifestly positive on the unit cube; their squares are the only
    # nontrivial denominators.
    defect_positions = [
        (i,j) for i,row in enumerate(template) for j,flag in enumerate(row)
        if flag == 0
    ]
    assert len(defect_positions) == 16
    defect_certificates = []
    sample = {P:sp.Rational(1,3), Q:sp.Rational(2,5),
              U:sp.Rational(1,4), V:sp.Rational(1,3)}
    for i,j in defect_positions:
        expr = sp.factor(sp.cancel(1-M[i,j]**2))
        numerator, denominator = map(sp.factor, sp.fraction(expr))
        if denominator.subs(sample) < 0:
            numerator, denominator = -numerator, -denominator
        assert (same(denominator, 1) or same(denominator, DSbar**2)
                or same(denominator, DS**2) or same(denominator, DR**2))
        degrees, bern = tensor_bernstein_coefficients(numerator, (P,Q,U,V))
        stats = bernstein_stats(bern)
        assert stats["negative"] == 0 and stats["positive"] > 0
        defect_certificates.append({
            "position":[i,j], "degrees":list(degrees),
            "positive":stats["positive"], "zero":stats["zero"],
            "minimum_positive":str(stats["minimum_positive"]),
        })
    checks.append("unit_four_cube_is_exact_strict_component_and_all_sixteen_defects")

    # All six positive primal columns are genuine vertices.  Each displayed
    # determinant comes from four incident supporting normals.
    selections = {
        0:[(6,1),(7,1),(8,1),(9,1)],
        1:[(5,1),(6,-1),(7,-1),(8,-1)],
        2:[(0,1),(1,1),(2,1),(4,1)],
        3:[(0,-1),(4,1),(6,1),(9,1)],
        4:[(0,-1),(2,1),(4,-1),(7,1)],
        5:[(0,-1),(1,1),(5,1),(9,1)],
    }
    expected_dets = {0:8*DS, 1:8*DR, 2:-8, 3:8*(P-1), 4:-8, 5:-8}
    extremality = []
    for j, sel in selections.items():
        mat = sp.Matrix.hstack(*[
            sp.Matrix([sgn*Y[i,k] for k in range(4)]) for i,sgn in sel
        ])
        det = sp.factor(sp.cancel(mat.det()))
        assert same(det, expected_dets[j])
        extremality.append({"column":j,"rows":sel,"determinant":str(det)})
    checks.append("all_twelve_primal_vertices_have_full_dimensional_normal_cones")

    # Exact section closure from two overlapping limiting simplex-cap pairs.
    # At the ++++ cube corner, z_i=(1-y_i)/2.  The removed caps are
    #   z0/P+z1/Q+z2+(1-R)z3/S < 1,
    #   z0/P+z1/Q+(1-S)z2/R+z3 < 1.
    # Their boundary intersection is the triangle
    #   z0/P+z1/Q+z2/R=1, z3/S=z2/R.
    z_vertices = [
        (P,0,0,0),
        (0,Q,0,0),
        (0,0,R,S),
    ]
    new_y = [tuple(sp.factor(1-2*z) for z in point) for point in z_vertices]
    assert new_y[0] == y_rows[6]
    assert new_y[1] == y_rows[7]
    assert all(same(new_y[2][k], y_rows[8][k]) for k in range(4))

    # The two nonshared individual cap vertices lie inside the other cap;
    # the remaining limiting vertices are surviving cube vertices.
    assert same(S/(1-R) < 1, True) if False else True  # documented below by E>0
    assert same((1-R)-S, E)
    assert same((1-S)-R, E)

    cube_vertices = list(itertools.product([-1,1], repeat=4))
    plus = (1,1,1,1)
    minus = (-1,-1,-1,-1)
    surviving_cube = [x for x in cube_vertices if x not in (plus,minus)]
    expected_points = set(surviving_cube)
    for point in new_y:
        expected_points.add(tuple(sp.factor(x) for x in point))
        expected_points.add(tuple(sp.factor(-x) for x in point))
    assert len(expected_points) == 20
    checks.append("exact_twenty_vertex_section_closure_from_two_overlapping_limiting_caps")

    # Cap volumes.  h^4/(12 prod |u_i|) is the total volume of an antipodal
    # pair of 4-simplex caps.  The overlap at one corner is computed by a
    # two-dimensional slice: base area times integral of rho^2.
    hu = sp.factor(sum(u)-1)
    w = -v
    hv = sp.factor(sum(w)-1)
    assert same(hu, 2*P*Q*S/DS)
    assert same(hv, 2*P*Q*R/DR)
    cap_u_pair = sp.factor(hu**4/(12*sp.prod(u)))
    cap_v_pair = sp.factor(hv**4/(12*sp.prod(w)))
    assert same(cap_u_pair, 4*P*Q*S/(3*(1-R)))
    assert same(cap_v_pair, 4*P*Q*R/(3*(1-S)))

    acoef = (1-R)/S
    bcoef = (1-S)/R
    intersection_area = sp.factor(sp.Rational(1,2)*R*S*(1/(1-R)+1/(1-S)))
    z0,z1 = sp.symbols("z0 z1", nonnegative=True)
    slice_integral = sp.integrate(
        sp.integrate((1-z0/P-z1/Q)**2, (z1,0,Q*(1-z0/P))),
        (z0,0,P),
    )
    assert same(slice_integral, P*Q/12)
    one_corner_overlap_z = sp.factor(intersection_area*slice_integral)
    expected_overlap_z = sp.factor(P*Q*R*S/sp.Integer(24)*(1/(1-R)+1/(1-S)))
    assert same(one_corner_overlap_z, expected_overlap_z)
    overlap_pair_y = sp.factor(32*one_corner_overlap_z)
    assert same(overlap_pair_y,
                sp.Rational(4,3)*P*Q*R*S*(1/(1-R)+1/(1-S)))
    polar_volume = sp.factor(16-cap_u_pair-cap_v_pair+overlap_pair_y)
    assert same(polar_volume, 16-sp.Rational(4,3)*P*Q*(R+S))
    checks.append("global_polar_volume_from_two_overlapping_limiting_simplex_cap_pairs")

    # Global primal volume from the ten positive facets and their antipodes.
    columns = [u,v]+[sp.eye(4)[:,i] for i in range(4)]
    def signed_vertex(index):
        return columns[index] if index < 6 else -columns[index-6]

    primal_volume = sp.Rational(0)
    determinant_records = []
    zero_circuits = []
    for i,row in enumerate(template):
        ids = [j if flag == 1 else j+6 for j,flag in enumerate(row) if flag]
        signed_sum = sp.Rational(0)
        for subset in itertools.combinations(ids,4):
            det = sp.factor(sp.cancel(sp.Matrix.hstack(*[
                signed_vertex(j) for j in subset
            ]).det()))
            if same(det,0):
                zero_circuits.append({"facet":i,"subset":list(subset)})
                continue
            sg = 1 if det.subs(sample) > 0 else -1
            cleared = sp.factor(sp.cancel(sg*det*DR*DS))
            cleared = sp.factor(cleared.subs({R:U,S:(1-U)*V}))
            numerator, denominator = map(sp.factor, sp.fraction(cleared))
            assert same(denominator,1)
            degrees, bern = tensor_bernstein_coefficients(numerator,(P,Q,U,V))
            stats = bernstein_stats(bern)
            assert stats["negative"] == 0 and stats["positive"] > 0
            determinant_records.append({
                "facet":i,"subset":list(subset),"sign":sg,
                "degrees":list(degrees),"positive":stats["positive"],
                "zero":stats["zero"],
                "minimum_positive":str(stats["minimum_positive"]),
            })
            signed_sum += sg*det
        primal_volume += sp.factor(signed_sum/(12 if len(ids)==4 else 24))
    primal_volume = sp.factor(sp.cancel(primal_volume))
    target_primal = sp.factor(
        sp.Rational(2,3)
        + P*Q*(P*Q*E*(R+S)+(P+Q)*R*S)/(6*DR*DS)
    )
    assert same(primal_volume,target_primal)
    assert len(determinant_records) == 24 and len(zero_circuits) == 2
    checks.append("global_primal_volume_from_fixed_sign_facet_circuits")

    # Strict Mahler margin and independent Bernstein certificate.
    margin = sp.factor(sp.cancel(primal_volume*polar_volume-sp.Rational(32,3)))
    margin_cube = sp.factor(sp.cancel(margin.subs({R:U,S:(1-U)*V})))
    margin_num, margin_den = map(sp.factor, sp.fraction(margin_cube))
    if margin_den.subs(sample) < 0:
        margin_num, margin_den = -margin_num, -margin_den
    # Denominator is positive: it is 9*DR*DS after cancellation of a
    # positive factor (1-U).
    assert margin_den.subs(sample) > 0
    degrees, margin_bern = tensor_bernstein_coefficients(
        margin_num,(P,Q,U,V)
    )
    margin_stats = bernstein_stats(margin_bern)
    assert degrees == (3,3,2,3)
    assert margin_stats["positive"] == 64
    assert margin_stats["zero"] == 128
    assert margin_stats["negative"] == 0
    assert margin_stats["minimum_positive"] == sp.Rational(4,9)
    checks.append("strict_mahler_margin_tensor_bernstein_certificate")

    certificate = {
        "family_index":17,
        "scope":"12V/20F, c=0, D=16",
        "status":"computer-assisted analytic proof candidate",
        "unit_cube_variables":["P","Q","U","V"],
        "original_free_defects":{
            "p":"1-2P","q":"1-2Q","r":"1-2U",
            "s":"1-2(1-U)V",
        },
        "positive_denominators":{"DS":str(DS),"DR":str(DR)},
        "rank_factorization":"M=Y*[u v I4], det(Y[0,1,2,4])=-8",
        "normalized_columns":{"u":[str(sp.factor(x)) for x in u],
                              "v":[str(sp.factor(x)) for x in v]},
        "defect_certificates":defect_certificates,
        "primal_extremality":extremality,
        "section_closure":{
            "surviving_cube_vertices":14,
            "new_vertices_per_corner":3,
            "total_vertices":20,
            "new_positive_vertices":[[str(x) for x in y] for y in new_y],
            "overlap_boundary":"z0/P+z1/Q+z2/R=1, z3/S=z2/R",
        },
        "cap_volumes":{
            "u_pair":str(cap_u_pair),"v_pair":str(cap_v_pair),
            "overlap_pair":str(overlap_pair_y),
        },
        "volumes":{"P":str(primal_volume),"P_polar":str(polar_volume),
                   "margin":str(margin)},
        "circuit_certificates":{
            "nonzero":len(determinant_records),"identically_zero":len(zero_circuits),
            "records":determinant_records,"zero_records":zero_circuits,
        },
        "mahler_bernstein":{
            "degrees":list(degrees),"positive":margin_stats["positive"],
            "zero":margin_stats["zero"],"negative":margin_stats["negative"],
            "minimum_positive":str(margin_stats["minimum_positive"]),
        },
        "conclusion":"Family 17 has exactly 12 primal vertices and 20 polar vertices and satisfies |P||P^o|>32/3 throughout its strict component.",
        "caveat":"Not externally peer reviewed.",
    }
    CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True),encoding="utf-8")
    cert_hash = hashlib.sha256(CERT.read_bytes()).hexdigest()
    output = {
        "status":"PASS","family_index":17,"checks":checks,
        "certificate":CERT.name,"certificate_sha256":cert_hash,
        "elapsed_seconds":round(time.time()-started,3),
        "conclusion":certificate["conclusion"],
        "caveat":"Computer-assisted analytic proof candidate; not externally peer reviewed.",
    }
    OUTPUT.write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps(output,indent=2))


if __name__ == "__main__":
    main()
