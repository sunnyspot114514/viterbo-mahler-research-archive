# Family 42: rational parametrization and exact exclusion

## Statement

Family **42** was the sole \(12V/20F,D=16\) algebraic survivor for which the first elimination pass did not produce a rational parametrization. It admits a simple parametrization by two cap-slope vectors. Every strict realization has exactly twelve primal vertices and twenty polar vertices and satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

## New slope parametrization

Normalize four primal columns to \(e_1,\ldots,e_4\). At the \((1,1,1,1)\) cube corner, the two active cap slopes are forced by the incidence pattern to be

\[
\alpha=(k,1,a,c),
\qquad
\beta=(k,b,1,1).
\]

Strictness of the four adjacent cube-edge conditions gives

\[
k,a,b,c>1.
\]

Conversely these four inequalities generate every strict realization of the family. Put

\[
K=\frac1k,
\quad A=\frac1a,
\quad B=\frac1b,
\quad C=\frac1c,
\]

so the complete strict component is the open unit four-cube.

Let

\[
D_u=AC+KC+KA-KAC>0.
\]

The two non-coordinate primal columns are

\[
u=\frac1{D_u}(AC,KAC,KC,KA),
\]

\[
v=-\frac1{B+K}(B,K,KB,KB).
\]

The three new positive section vertices are

\[
(1-2K,1,1,1),
\]

\[
\left(
1,
1-\frac{2B(1-A)}{1-AB},
1-\frac{2A(1-B)}{1-AB},
1
\right),
\]

\[
\left(
1,
1-\frac{2B(1-C)}{1-BC},
1,
1-\frac{2C(1-B)}{1-BC}
\right).
\]

All sixteen defect inequalities have Bernstein-positive numerators.

## Section closure

In corner coordinates \(z_i=(1-y_i)/2\), the caps are

\[
\frac{z_0}{K}+z_1+\frac{z_2}{A}+\frac{z_3}{C}<1,
\]

\[
\frac{z_0}{K}+\frac{z_1}{B}+z_2+z_3<1.
\]

Their boundaries meet in a triangle whose three vertices are precisely the points displayed above. Fourteen cube vertices survive, so the section has exactly

\[
14+3+3=20
\]

vertices. Independent normal-cone determinants prove that all twelve primal vertices are extreme.

## Cap overlap and polar volume

After fixing \(z_0\), the three-dimensional overlap base is

\[
\{z\ge0:
 z_1+a z_2+c z_3\le1,
 b z_1+z_2+z_3\le1\}.
\]

It has a fixed three-tetrahedra decomposition. If \(V_{\rm base}\) denotes its volume, the total antipodal overlap is

\[
8K V_{\rm base}.
\]

The individual antipodal cap-pair volumes are

\[
C_u=\frac43ACK,
\qquad
C_v=\frac43BK.
\]

Thus

\[
|P^\circ|=16-C_u-C_v+8K V_{\rm base}.
\]

The verifier checks the tetrahedral signs globally and derives the exact rational formula stored in the certificate.

## Primal volume and Mahler margin

A fixed-sign circuit decomposition with 26 nonzero determinants gives

\[
|P|=
\frac{
2ABCK^2+3ABCK-4ABC-ABK^2-4ABK
+3ACK^2-4ACK-4AK^2-BCK^2-4BCK-4CK^2
}{
6(B+K)(ACK-AC-AK-CK)
}.
\]

After combining this with the polar formula, the Mahler-margin numerator has tensor degree

\[
(3,2,3,2).
\]

Its 144 Bernstein coefficients satisfy

\[
52>0,\qquad92=0,\qquad0<0,
\]

with minimum positive coefficient \(2/3\). Hence

\[
\boxed{|P||P^\circ|>32/3}.
\]
