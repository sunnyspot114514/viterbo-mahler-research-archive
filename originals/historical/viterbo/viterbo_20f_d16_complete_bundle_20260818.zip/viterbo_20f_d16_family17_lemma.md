# Family 17: overlapping limiting caps and strict Mahler margin

## Statement

The algebraic survivor indexed **17** in the bounded-12 layer

\[
12V/20F,\qquad c=0,\qquad D=16
\]

has a complete rational parametrization. Every strict realization has exactly twelve primal vertices and twenty polar vertices and satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

## Strict component

Let

\[
0<P,Q,R,S<1,\qquad R+S<1.
\]

Use the unit-cube substitution

\[
R=U,\qquad S=(1-U)V,
\qquad 0<P,Q,U,V<1.
\]

Define

\[
E=1-R-S,
\]

\[
D_S=PQE+S(P+Q),\qquad
D_R=PQE+R(P+Q).
\]

Both denominators are strictly positive. After normalization,

\[
u=rac1{D_S}igl(QS,PS,PQS,PQ(1-R)\bigr),
\]

\[
v=-\frac1{D_R}igl(QR,PR,PQ(1-S),PQR\bigr).
\]

The pairing matrix factors exactly as

\[
X=Y[\,u\ v\ I_4\,],
\]

where \(Y\) is the matrix of the ten positive section vertices. Its rank is exactly four. All sixteen defect inequalities have nonnegative Bernstein tables with at least one positive coefficient.

## Exact section closure

At the \((1,1,1,1)\) cube corner, put

\[
z_i=\frac{1-y_i}{2}.
\]

The two removed limiting simplex caps are

\[
\frac{z_0}{P}+\frac{z_1}{Q}+z_2+\frac{1-R}{S}z_3<1,
\]

\[
\frac{z_0}{P}+\frac{z_1}{Q}+\frac{1-S}{R}z_2+z_3<1.
\]

Their boundary intersection is the triangle

\[
\frac{z_0}{P}+\frac{z_1}{Q}+\frac{z_2}{R}=1,
\qquad
\frac{z_3}{S}=\frac{z_2}{R},
\]

with vertices

\[
(P,0,0,0),\qquad(0,Q,0,0),\qquad(0,0,R,S).
\]

Thus fourteen cube vertices survive, and three new vertices occur at each of the two antipodal corners:

\[
14+3+3=20.
\]

## Polar volume

The total antipodal cap-pair volumes are

\[
C_u=\frac{4PQS}{3(1-R)},
\qquad
C_v=\frac{4PQR}{3(1-S)}.
\]

For one corner, the overlap volume in \(z\)-coordinates is

\[
\frac{PQRS}{24}
\left(\frac1{1-R}+\frac1{1-S}\right).
\]

After the \(y\)-Jacobian and antipodal doubling, inclusion-exclusion gives the remarkably simple formula

\[
\boxed{
|P^\circ|=16-\frac43PQ(R+S).
}
\]

## Primal volume and positivity

A fixed-sign circuit decomposition of the ten positive facets and their antipodes gives

\[
|P|=rac23+
\frac{PQ\bigl(PQE(R+S)+(P+Q)RS\bigr)}{6D_RD_S}.
\]

After substituting \(R=U\), \(S=(1-U)V\), the Mahler-margin numerator has tensor degree

\[
(3,3,2,3).
\]

Its 192 Bernstein coefficients satisfy

\[
64>0,\qquad128=0,\qquad0<0,
\]

with minimum positive coefficient \(4/9\). Hence

\[
\boxed{|P||P^\circ|>32/3}
\]

throughout the strict component.
