#!/usr/bin/env python3
"""Exact verifier for 12V/20F, c=0, D=16, survivor family 89.

Checks exact rank-four completion, full strict domain, all 16 defects,
12 primal vertices, all 240 cube-section active charts, global primal and
polar volumes, and tensor-Bernstein positivity of the Mahler remainder.
"""
from __future__ import annotations
import hashlib,itertools,json,time
from pathlib import Path
import sympy as sp

HERE=Path(__file__).resolve().parent
CERT=HERE/'viterbo_20f_d16_family89_certificate.json'
OUTPUT=HERE/'viterbo_20f_d16_family89_verifier_output.json'

def same(x,y): return sp.cancel(x-y)==0

def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def tensor_coefficients(poly,variables,degrees):
    P=sp.Poly(sp.expand(poly),*variables)
    mons={m:sp.Rational(c) for m,c in P.terms()}; out={}
    for idx in itertools.product(*[range(n+1) for n in degrees]):
        value=sp.Rational(0)
        for powers,coeff in mons.items():
            if all(k<=i for k,i in zip(powers,idx)):
                factor=sp.Rational(1)
                for i,k,n in zip(idx,powers,degrees):
                    factor*=sp.Rational(sp.binomial(i,k),sp.binomial(n,k))
                value+=coeff*factor
        out[idx]=sp.factor(value)
    return out

def stats(coeffs):
    vals=list(coeffs.values())
    return {'positive':sum(int(bool(x>0)) for x in vals),
            'zero':sum(int(bool(x==0)) for x in vals),
            'negative':sum(int(bool(x<0)) for x in vals),
            'min_positive':min((x for x in vals if bool(x>0)),default=None)}

def check_bernstein(poly,variables,rec):
    coeff=tensor_coefficients(poly,variables,rec['degree']); s=stats(coeff)
    assert s['positive']==rec['positive'] and s['zero']==rec['zero'] and s['negative']==rec['negative']
    if rec.get('min_positive') is not None and s['positive']:
        assert s['min_positive']==sp.Rational(rec['min_positive'])
    return s

def parse_matrix(rows,loc): return sp.Matrix([[sp.sympify(x,locals=loc) for x in row] for row in rows])

def vertex(B,j): return B[:,j] if j<6 else -B[:,j-6]

def main():
    started=time.time()
    def mark(x): print(f'[f89] {x} {time.time()-started:.2f}s',flush=True)
    C=json.loads(CERT.read_text()); checks=[]
    p,q,r,s=sp.symbols('p q r s')
    U,V,W,T=sp.symbols('U V W T')
    u,v,w,E,t=sp.symbols('u v w E t')
    loc={x.name:x for x in [p,q,r,s,U,V,W,T,u,v,w,E,t]}
    cube_rec=C['domain']['cube_parameterization']
    cube={p:sp.sympify(cube_rec['p'],locals=loc),q:sp.sympify(cube_rec['q'],locals=loc),
          r:sp.sympify(cube_rec['r'],locals=loc),s:sp.sympify(cube_rec['s'],locals=loc)}
    uvwt={p:w+2*u+2*v-1,q:w+2*v-1,r:w+2*u-1,s:-t}
    vars_=[U,V,W,T]
    M=parse_matrix(C['matrix_entries'],loc); template=C['template']
    pr=C['pivot_rows'];pc=C['pivot_cols'];Bas=M.extract(pr,range(6));pivot=Bas.extract(range(4),pc)
    assert same(pivot.det(),sp.Rational(C['rank_pivot_det']))
    coeff=M.extract(range(10),pc)*pivot.inv()
    assert all(same(x,0) for x in coeff*Bas-M)
    checks.append('exact_rank_four_completion');mark('rank')

    # Domain and its rational inverse.
    u0=(p-q)/2;v0=(p-r)/2;w0=-p+q+r+1;E0=-(q+r)/2;t0=-s
    assert same(u0+v0+w0+E0,1)
    assert same(u0.subs(cube),U)
    assert same(v0.subs(cube),(1-U)*V)
    assert same(w0.subs(cube),(1-U)*(1-V)*W)
    assert same(E0.subs(cube),(1-U)*(1-V)*(1-W))
    tc=sp.factor(t0.subs(cube))
    assert same(tc,(W+4*(1-W)*T)/(4-3*W))
    assert same((1-t0).subs(cube),sp.sympify(C['domain']['identities']['1_minus_t_cube'],locals=loc))
    gap=4*t0*E0-(1-t0)*w0
    assert same(gap.subs(cube),sp.sympify(C['domain']['identities']['four_tE_minus_gap_cube'],locals=loc))
    # T=(4tE-(1-t)w)/(4E), so the map is bijective on the strict domain.
    assert same(((4*t0*E0-(1-t0)*w0)/(4*E0)).subs(cube),T)
    checks.append('bijective_Delta3_times_interval_parameterization');mark('domain')

    Mc=M.subs(cube).applyfunc(lambda x:sp.factor(sp.cancel(x)))
    strict={(x['row'],x['col']):x for x in C['strict_defects']};seen=set()
    for i,row in enumerate(template):
        for j,flag in enumerate(row):
            if flag!=0: continue
            rec=strict[(i,j)];expr=Mc[i,j];qq=sp.factor(sp.cancel(1-expr**2));num,den=sp.fraction(qq)
            assert same(expr,sp.sympify(rec['cube_expression'],locals=loc))
            assert same(qq,sp.sympify(rec['one_minus_square'],locals=loc))
            assert same(num,sp.sympify(rec['numerator'],locals=loc));assert same(den,sp.sympify(rec['denominator'],locals=loc))
            bs=check_bernstein(num,vars_,rec['bernstein']);assert bs['negative']==0 and bs['positive']>0
            co,facs=sp.factor_list(den,*vars_);assert co>0 and all(e%2==0 for _,e in facs)
            seen.add((i,j))
    assert seen==set(strict);checks.append('sixteen_strict_defects');mark('defects')

    # Every primal column has four independent signed supporting facets.
    for rec in C['primal_extremality']:
        j=rec['column'];rows=rec['rows']
        A=sp.Matrix([list(template[i][j]*coeff.row(i)) for i in rows])
        det=sp.factor(A.det());assert same(det,sp.sympify(rec['det_original'],locals=loc))
        assert same(det.subs(cube),sp.sympify(rec['det_cube'],locals=loc))
        assert det!=0
    checks.append('twelve_primal_vertices');mark('primal')

    # All 240 active four-coordinate charts are independently regenerated
    # by the 15 companion chunk verifiers, one for each active 4-subset.
    clos=C['closure']
    chunk_paths=[HERE/f"viterbo_20f_d16_family89_closure_chunk_{i:02d}_output.json" for i in range(15)]
    chunks=[json.loads(x.read_text()) for x in chunk_paths]
    assert all(x['status']=='PASS' for x in chunks)
    totals={'expected':0,'direct':0,'special':0};ids=set()
    for x in chunks:
        assert x['master_sha256']==sha256(CERT)
        for k,vv in x['stats'].items(): totals[k]+=vv
        ids.update(x['expected_ids'])
    assert totals=={'expected':52,'direct':178,'special':10};assert len(ids)==20
    assert clos['stats']=={'total':240,'expected_occurrences':52,'unique_expected_vertices':20,'single_coordinate_violations':178,'paired_exclusions':10}
    checks.append('section_closure_all_240_charts_chunked_exact_replay');mark('closure')

    # Global primal volume by facet circuits.
    pvc=C['P_volume'];ptotal=sp.Integer(0)
    for frec in pvc['facets']:
        i=frec['row'];ids2=[]
        for j in range(6):
            if M[i,j]==1: ids2.append(j)
            elif M[i,j]==-1: ids2.append(j+6)
        assert ids2==frec['vertices'];abs_sum=sp.Integer(0)
        for drec in frec['determinants']:
            subids=drec['subvertices'];det=sp.factor(sp.Matrix.hstack(*[vertex(Bas,j) for j in subids]).det())
            assert same(det,sp.sympify(drec['det_original'],locals=loc))
            sc=sp.factor(sp.cancel((drec['sign']*det).subs(cube)));num,den=sp.fraction(sc)
            assert same(sc,sp.sympify(drec['signed_cube'],locals=loc))
            pn=sp.sympify(drec['positive_numerator'],locals=loc);pd=sp.sympify(drec['positive_denominator'],locals=loc)
            assert same(pn,drec['denominator_sign']*num);assert same(pd,drec['denominator_sign']*den)
            ns=check_bernstein(pn,vars_,drec['numerator_bernstein']);ds=check_bernstein(pd,vars_,drec['denominator_bernstein'])
            assert ns['negative']==0 and ns['positive']>0 and ds['negative']==0 and ds['positive']>0
            abs_sum+=drec['sign']*det
        pairvol=sp.factor(abs_sum/(12 if len(ids2)==4 else 24));assert same(pairvol,sp.sympify(frec['pair_volume'],locals=loc));ptotal+=pairvol
    Pformula=sp.sympify(pvc['target'],locals=loc);assert same(ptotal,Pformula)
    checks.append('global_primal_volume_by_facet_circuits');mark('P volume')

    # Global polar volume: normalized polar is a cube minus two disjoint antipodal simplex-cap pairs.
    pol=C['polar_volume'];Vp=pivot.inv()*Bas
    assert all(same(Vp[i,0],sp.sympify(pol['normalized_extra_columns']['v0'][i],locals=loc)) for i in range(4))
    assert all(same(Vp[i,1],sp.sympify(pol['normalized_extra_columns']['v1'][i],locals=loc)) for i in range(4))
    ww=-p+q+r+1;A0=(q+1)/2;B0=(r+1)/2;C0=(1-p)/2;D0=ww/2
    alpha=(1+s)/2;beta=(1-s)/2
    cap0=sp.Rational(2)*ww**4/(24*A0*B0*C0*D0)
    cap1=sp.Rational(2)*(1+s)**4/(24*alpha**3*beta)
    assert same(cap0,sp.sympify(pol['cap_pair0_normalized'],locals=loc));assert same(cap1,sp.sympify(pol['cap_pair1_normalized'],locals=loc))
    # Same-sign caps: weights beta and C0 cancel the third coordinate.
    samegap=(beta+C0)-(beta*(A0+B0+D0)+3*C0*alpha)
    assert same(samegap.subs(uvwt),sp.sympify(pol['same_sign_weighted_gap_uvwt'],locals=loc))
    # Opposite-sign caps: weights alpha and D0 cancel the fourth coordinate.
    oppsupport=alpha*((A0-D0)+(B0-D0)+C0)+D0*beta
    oppgap=(alpha+D0)-oppsupport
    assert same(oppgap.subs(uvwt),sp.sympify(pol['opposite_sign_weighted_gap_uvwt'],locals=loc))
    Qformula=sp.sympify(pol['target'],locals=loc);assert same(Qformula,(16-cap0-cap1)/8)
    checks.append('global_polar_volume_by_disjoint_simplex_caps');mark('Q volume')

    # Mahler remainder.
    mr=C['Mahler_margin'];margin=sp.factor(sp.cancel(Pformula*Qformula-sp.Rational(32,3)));mc=sp.factor(sp.cancel(margin.subs(cube)))
    assert same(margin,sp.sympify(mr['expression_original'],locals=loc));assert same(mc,sp.sympify(mr['cube_expression'],locals=loc))
    num,den=sp.fraction(mc);assert same(num,sp.sympify(mr['numerator'],locals=loc));assert same(den,sp.sympify(mr['denominator'],locals=loc))
    ns=check_bernstein(num,vars_,mr['bernstein']);ds=check_bernstein(den,vars_,mr['denominator_bernstein'])
    assert ns['negative']==0 and ns['positive']>0 and ds['negative']==0 and ds['positive']>0
    checks.append('strict_Mahler_margin_tensor_Bernstein');mark('margin')

    out={'status':'PASS','family_index':89,'checks':checks,'closure_stats':clos['stats'],
         'P_volume':str(Pformula),'Q_volume':str(Qformula),'margin_bernstein':mr['bernstein'],
         'certificate_sha256':sha256(CERT),'elapsed_seconds':round(time.time()-started,3),
         'scope':'computer-assisted analytic proof candidate; no external review'}
    OUTPUT.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

if __name__=='__main__': main()
