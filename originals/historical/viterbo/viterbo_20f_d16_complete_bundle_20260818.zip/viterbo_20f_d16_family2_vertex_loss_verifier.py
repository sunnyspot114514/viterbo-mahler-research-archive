#!/usr/bin/env python3
"""Exact vertex-loss verifier for bounded-12 20F/D=16 survivor Family 2.

The full strict algebraic family is parametrized by 0<P,Q,R,S<1.  After
rank-four normalization its first extra primal column satisfies

    u = P(-v) + (1-P)(-e_4).

Since both coefficients are strictly positive and sum to one, u lies in the
relative interior of the edge [-v,-e_4].  Hence the branch has at most ten
primal vertices and is not a genuine 12-vertex survivor.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE=Path(__file__).resolve().parent
OUTPUT=HERE/"viterbo_20f_d16_family2_vertex_loss_verifier_output.json"
CERT=HERE/"viterbo_20f_d16_family2_vertex_loss_certificate.json"


def same(x,y):
    return sp.cancel(x-y)==0


def tensor_bernstein_coefficients(poly,variables):
    Ppoly=sp.Poly(sp.expand(poly),*variables)
    degrees=tuple(Ppoly.degree(x) for x in variables)
    terms={m:sp.Rational(c) for m,c in Ppoly.terms()}
    vals={}
    for idx in itertools.product(*[range(n+1) for n in degrees]):
        value=sp.Rational(0)
        for powers,coef in terms.items():
            if all(k<=i for k,i in zip(powers,idx)):
                fac=sp.Rational(1)
                for i,k,n in zip(idx,powers,degrees):
                    fac*=sp.Rational(sp.binomial(i,k),sp.binomial(n,k))
                value+=coef*fac
        vals[idx]=sp.factor(value)
    return degrees,vals


def stats(vals):
    vs=list(vals.values()); pos=[x for x in vs if bool(x>0)]
    return {"positive":len(pos),"zero":sum(int(bool(x==0)) for x in vs),
            "negative":sum(int(bool(x<0)) for x in vs),
            "minimum_positive":min(pos) if pos else None}


def main():
    started=time.time(); checks=[]
    P,Q,R,S=sp.symbols("P Q R S",positive=True)
    D=sp.factor(Q*R+Q*S+R*S-Q*R*S)
    assert same(D,Q*R*(1-S)+S*(Q+R))

    v=sp.Matrix([-R*S/D,-Q*S/D,-Q*R/D,Q*R*S/D])
    e4=sp.Matrix([0,0,0,1])
    u=(P*(-v)+(1-P)*(-e4)).applyfunc(sp.factor)

    y_rows=[
        (1,-1,-1,-1),(1,-1,-1,1),(1,-1,1,-1),(1,-1,1,1),
        (1,1,-1,-1),(1,1,-1,1),(-1,-1,-1,-1),
        (1-2*Q,1,1,-1),(1,1-2*R,1,-1),(1,1,1-2*S,-1),
    ]
    Y=sp.Matrix(y_rows)
    M=sp.Matrix([[sp.factor(u.dot(sp.Matrix(y))),sp.factor(v.dot(sp.Matrix(y))),*y]
                 for y in y_rows])
    template=[
        [0,0,1,-1,-1,-1],[0,0,1,-1,-1,1],
        [0,0,1,-1,1,-1],[0,0,1,-1,1,1],
        [0,0,1,1,-1,-1],[0,0,1,1,-1,1],
        [0,1,-1,-1,-1,-1],[1,-1,0,1,1,-1],
        [1,-1,1,0,1,-1],[1,-1,1,1,0,-1],
    ]
    for i,row in enumerate(template):
        for j,flag in enumerate(row):
            if flag: assert same(M[i,j],flag)
    assert all(same(z,0) for z in M-Y*sp.Matrix.hstack(u,v,sp.eye(4)))
    assert Y.extract([0,1,2,4],range(4)).det()==-8
    checks.append("exact_rank_four_factorization_and_template_reconstruction")

    # The apparent strict component is indeed the whole open unit cube.
    sample={P:sp.Rational(1,3),Q:sp.Rational(2,5),
            R:sp.Rational(1,4),S:sp.Rational(3,5)}
    defect_certificates=[]
    for i,row in enumerate(template):
        for j,flag in enumerate(row):
            if flag==0:
                expr=sp.factor(sp.cancel(1-M[i,j]**2))
                num,den=map(sp.factor,sp.fraction(expr))
                if den.subs(sample)<0:num,den=-num,-den
                assert same(den,1) or same(den,D**2)
                deg,bern=tensor_bernstein_coefficients(num,(P,Q,R,S))
                st=stats(bern)
                assert st["negative"]==0 and st["positive"]>0
                defect_certificates.append({
                    "position":[i,j],"degrees":list(deg),
                    "positive":st["positive"],"zero":st["zero"],
                    "minimum_positive":str(st["minimum_positive"]),
                })
    assert len(defect_certificates)==16
    checks.append("all_sixteen_defects_are_strict_on_the_open_unit_four_cube")

    # Universal convex-combination obstruction.
    identity=(u-P*(-v)-(1-P)*(-e4)).applyfunc(sp.factor)
    assert all(same(x,0) for x in identity)
    # 0<P<1 makes this a strict convex combination of two other vertices.
    checks.append("u_is_a_strict_convex_combination_of_minus_v_and_minus_e4")

    certificate={
        "family_index":2,
        "scope":"12V/20F, c=0, D=16",
        "status":"excluded_by_primal_vertex_loss",
        "domain":"0<P,Q,R,S<1",
        "positive_denominator":"D=QR(1-S)+S(Q+R)",
        "normalized_columns":{"u":[str(x) for x in u],"v":[str(x) for x in v]},
        "convex_combination":"u=P*(-v)+(1-P)*(-e4)",
        "defect_certificates":defect_certificates,
        "conclusion":"The branch has at most five distinct antipodal vertex-pairs (at most 10 vertices), so it is not a genuine bounded-12 survivor.",
        "caveat":"Computer-assisted exact algebra; not externally peer reviewed.",
    }
    CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True),encoding="utf-8")
    h=hashlib.sha256(CERT.read_bytes()).hexdigest()
    output={
        "status":"PASS","family_index":2,"checks":checks,
        "certificate":CERT.name,"certificate_sha256":h,
        "elapsed_seconds":round(time.time()-started,3),
        "conclusion":certificate["conclusion"],
        "caveat":"Computer-assisted analytic proof candidate; not externally peer reviewed.",
    }
    OUTPUT.write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps(output,indent=2))


if __name__=="__main__":main()
