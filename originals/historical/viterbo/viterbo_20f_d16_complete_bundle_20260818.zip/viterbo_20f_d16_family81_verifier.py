#!/usr/bin/env python3
"""Exact consistency verifier for 12V/20F, c=0, D=16, survivor family 81.

The verifier checks the algebraic rank completion, the exact strict domain,
all 240 active-face section charts, primal extremality, fixed-sign volume
triangulations, and the tensor-Bernstein certificate for the Mahler margin.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
MASTER = HERE / "viterbo_20f_d16_family81_certificate.json"
CLOSURE = HERE / "viterbo_20f_d16_family81_closure_certificate.json"
ORIENTATION = HERE / "viterbo_20f_d16_family81_orientation_certificate.json"
OUTPUT = HERE / "viterbo_20f_d16_family81_verifier_output.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tensor_bernstein(entries, variables, degrees):
    out = sp.Integer(0)
    for item in entries:
        coeff = sp.Rational(item["value"])
        term = coeff
        for x, i, n in zip(variables, item["index"], degrees):
            term *= sp.binomial(n, i) * x**i * (1 - x) ** (n - i)
        out += term
    return sp.expand(out)




def tensor_coefficients(poly, variables, degrees):
    """Return exact tensor-Bernstein coefficients in lexicographic multi-index order."""
    poly = sp.Poly(sp.expand(poly), *variables)
    monoms = {m: c for m, c in poly.terms()}
    out = {}
    for idx in itertools.product(*[range(n + 1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in monoms.items():
            if all(k <= i for k, i in zip(powers, idx)):
                factor = sp.Rational(1)
                for i, k, n in zip(idx, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff * factor
        out[idx] = sp.factor(value)
    return out


def coefficient_stats(coeffs):
    vals = list(coeffs.values())
    nz = [v for v in vals if v != 0]
    return {
        "positive": sum(1 for v in vals if bool(v > 0)),
        "zero": sum(1 for v in vals if bool(v == 0)),
        "negative": sum(1 for v in vals if bool(v < 0)),
        "min_positive": min((v for v in vals if bool(v > 0)), default=None),
        "max_negative": max((v for v in vals if bool(v < 0)), default=None),
        "nonzero": nz,
    }

def same(a, b) -> bool:
    return sp.cancel(a - b) == 0


def parse_matrix(rows, loc):
    return sp.Matrix([[sp.sympify(x, locals=loc) for x in row] for row in rows])


def point_from_index(columns, index):
    if index < 6:
        return columns[:, index]
    return -columns[:, index - 6]


def polar_point_from_index(rows, index):
    if index < 10:
        return rows[index, :].T
    return -rows[index - 10, :].T


def main() -> None:
    started = time.time()
    master = json.loads(MASTER.read_text())
    closure = json.loads(CLOSURE.read_text())
    orient = json.loads(ORIENTATION.read_text())
    checks = []

    # Dependency integrity.
    for name, expected in master["dependencies_sha256"].items():
        path = HERE / name
        assert path.exists(), path
        assert sha256(path) == expected
    checks.append("dependency_hashes")

    p, q, r, s = sp.symbols("x2_0 x4_0 x7_1 x9_1")
    A, C, U, T = sp.symbols("A C U T")
    loc = {
        "x2_0": p,
        "x4_0": q,
        "x7_1": r,
        "x9_1": s,
        "A": A,
        "C": C,
        "U": U,
        "T": T,
    }
    cube = {sp.sympify(k, locals=loc): sp.sympify(v, locals=loc)
            for k, v in master["cube_parameterization"].items()}

    M = parse_matrix(master["matrix_entries"], loc)
    Mcube = M.subs(cube).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    pr = master["pivot_rows"]
    pc = master["pivot_cols"]
    pivot = M.extract(pr, pc)
    basis_rows = M.extract(pr, range(6))
    assert str(sp.factor(pivot.det().subs(cube))) == master["rank_certificate"]["pivot_det_cube"]
    alpha = (M.extract(range(10), pc) * pivot.inv()).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    residual = (alpha * basis_rows - M).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    assert all(x == 0 for x in residual)
    checks.append("exact_rank_four_completion")

    # Exact domain map and its inverse-facing barycentric interpretation.
    A0 = (p - q) / 2
    B0 = -(p + q) / 2
    E = 1 + q
    C0 = (r - s) / 2
    D0 = -(r + s) / 2
    F = 1 + s
    V = (1 - U + 4 * U * T) / (1 + 3 * U)
    expected_bary = [A, (1 - A) * U, (1 - A) * (1 - U),
                     C, (1 - C) * V, (1 - C) * (1 - V)]
    for lhs, rhs in zip([A0, B0, E, C0, D0, F], expected_bary):
        assert same(lhs.subs(cube), rhs)
    assert same((E * F - 4 * B0 * D0).subs(cube), -4 * T * U * (A - 1) * (C - 1))
    checks.append("bijective_cube_parameterization_of_strict_domain")

    # Every one of the 16 defects remains strictly inside (-1,1).
    strict_by_entry = {x["entry"]: x for x in master["strict_defect_certificates"]}
    seen = set()
    for i, row in enumerate(master["template"]):
        for j, flag in enumerate(row):
            if flag != 0:
                continue
            name = f"x{i}_{j}"
            rec = strict_by_entry[name]
            expr = Mcube[i, j]
            one_minus = sp.factor(sp.cancel(1 - expr**2))
            assert same(expr, sp.sympify(rec["expression"], locals=loc))
            assert same(one_minus, sp.sympify(rec["one_minus_square"], locals=loc))
            num, den = sp.fraction(one_minus)
            assert same(num, sp.sympify(rec["numerator"], locals=loc))
            assert same(den, sp.sympify(rec["denominator"], locals=loc))
            coeffs = tensor_coefficients(num, [A, C, T, U], rec["degree"])
            cstats = coefficient_stats(coeffs)
            assert cstats["positive"] == rec["positive"]
            assert cstats["zero"] == rec["zero"]
            assert cstats["negative"] == rec["negative"] == 0
            assert cstats["min_positive"] == sp.Rational(rec["min_positive"])
            co, factors = sp.factor_list(den, A, C, T, U)
            assert co > 0 and all(exp % 2 == 0 for _, exp in factors)
            seen.add(name)
    assert seen == set(strict_by_entry)
    checks.append("sixteen_strict_defect_bernstein_certificates")

    # Twelve primal vertices are genuine extreme points.
    alpha_cube = alpha.subs(cube).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    rows0 = master["primal_extremality"]["column0_rows"]
    rows1 = master["primal_extremality"]["column1_rows"]
    det0 = sp.factor(sp.cancel(alpha_cube.extract(rows0, range(4)).det()))
    det1 = sp.factor(sp.cancel(alpha_cube.extract(rows1, range(4)).det()))
    assert same(det0, sp.sympify(master["primal_extremality"]["column0_det"], locals=loc))
    assert same(det1, sp.sympify(master["primal_extremality"]["column1_det"], locals=loc))
    checks.append("twelve_primal_vertices")

    # Chunked exact 240-chart section-closure replay.  Each chunk independently
    # regenerates its active-face charts and compares every certificate entry.
    chunk_paths = [
        HERE / "viterbo_20f_d16_family81_closure_chunk_0_5_output.json",
        HERE / "viterbo_20f_d16_family81_closure_chunk_5_10_output.json",
        HERE / "viterbo_20f_d16_family81_closure_chunk_10_15_output.json",
    ]
    chunks = [json.loads(x.read_text()) for x in chunk_paths]
    assert all(x["status"] == "PASS" for x in chunks)
    stats = {
        "expected_occurrences": sum(x["stats"]["expected"] for x in chunks),
        "global_violation": sum(x["stats"]["global_violation"] for x in chunks),
        "special": sum(x["stats"]["special"] for x in chunks),
    }
    expected_ids = set().union(*(set(x["unique_expected_indices"]) for x in chunks))
    assert stats == closure["stats"] == {"expected_occurrences": 52, "global_violation": 184, "special": 4}
    assert len(expected_ids) == closure["unique_expected_vertices"] == 20
    assert len(closure["records"]) == 240
    checks.append("section_closure_240_charts_chunked_exact_replay")

    # Fixed triangulations: exact determinant groups, facet incidence and volume sums.
    Pcols = basis_rows
    Qrows = alpha
    groups = {int(k): v for k, v in orient["groups"].items()}
    sample = {sp.sympify(k, locals=loc): sp.Rational(v) for k, v in orient["sample_original"].items()}
    p_volume_sum = sp.Integer(0)
    q_volume_sum = sp.Integer(0)
    group_seen = set()

    for kind, tets in (("P", orient["P_tets"]), ("Q", orient["Q_tets"])):
        for item in tets:
            ids = item["vertices"]
            if kind == "P":
                cols = [point_from_index(Pcols, i) for i in ids]
                normal_index, normal_sign = item["facet"]
                for idx in ids:
                    col = idx if idx < 6 else idx - 6
                    vertex_sign = 1 if idx < 6 else -1
                    assert same(normal_sign * vertex_sign * M[normal_index, col], 1)
            else:
                cols = [polar_point_from_index(Qrows, i) for i in ids]
                normal_index, normal_sign = item["facet"]
                for idx in ids:
                    row = idx if idx < 10 else idx - 10
                    vertex_sign = 1 if idx < 10 else -1
                    assert same(normal_sign * vertex_sign * M[row, normal_index], 1)
            det = sp.factor(sp.Matrix.hstack(*cols).det())
            group = groups[item["group_id"]]
            assert same(det, sp.sympify(group["original_expression"], locals=loc))
            sign_at_sample = sp.sign(det.subs(sample))
            assert int(sign_at_sample) == group["sample_sign"]
            cube_det = sp.factor(sp.cancel(det.subs(cube)))
            assert same(cube_det, sp.sympify(group["cube_expression"], locals=loc))
            if kind == "P":
                p_volume_sum += group["sample_sign"] * det
            else:
                q_volume_sum += group["sample_sign"] * det
            group_seen.add(item["group_id"])

    assert group_seen == set(groups)
    for group in groups.values():
        cube_expr = sp.sympify(group["cube_expression"], locals=loc)
        num, den = sp.fraction(cube_expr)
        assert same(num, sp.sympify(group["numerator"], locals=loc))
        assert same(den, sp.sympify(group["denominator"], locals=loc))
        nb = group["numerator_bernstein"]
        db = group["denominator_bernstein"]
        ncoeff = tensor_coefficients(num, [A, C, T, U], nb["degree"])
        dcoeff = tensor_coefficients(den, [A, C, T, U], db["degree"])
        ns = coefficient_stats(ncoeff); ds = coefficient_stats(dcoeff)
        assert ns["positive"] == nb["positive"] and ns["zero"] == nb["zero"] and ns["negative"] == nb["negative"]
        assert ds["positive"] == db["positive"] and ds["zero"] == db["zero"] and ds["negative"] == db["negative"]
        assert nb["sign"] in (-1, 1) and db["sign"] in (-1, 1)
        assert nb["positive"] == 0 or nb["negative"] == 0
        assert db["positive"] == 0 or db["negative"] == 0
        assert nb["positive"] + nb["negative"] > 0
        assert db["positive"] + db["negative"] > 0

    p_volume_sum = sp.factor(sp.cancel(p_volume_sum / 24))
    q_volume_sum = sp.factor(sp.cancel(q_volume_sum / 24))
    Pformula = sp.sympify(master["volumes"]["P"], locals=loc)
    Qformula = sp.sympify(master["volumes"]["Q"], locals=loc)
    assert same(p_volume_sum, Pformula)
    assert same(q_volume_sum, Qformula)
    assert len(orient["P_tets"]) == orient["stats"]["P_tets"] == 31
    assert len(orient["Q_tets"]) == orient["stats"]["Q_tets"] == 68
    assert len(groups) == orient["stats"]["unique_groups"] == 42
    checks.append("fixed_triangulation_and_exact_volume_formulas")

    # Exact Mahler margin and tensor-Bernstein positivity.
    margin = sp.factor(sp.cancel(Pformula * Qformula - sp.Rational(32, 3)))
    assert same(margin, sp.sympify(master["mahler_margin"]["original_expression"], locals=loc))
    margin_cube = sp.factor(sp.cancel(margin.subs(cube)))
    assert same(margin_cube, sp.sympify(master["mahler_margin"]["cube_expression"], locals=loc))
    num, den = sp.fraction(margin_cube)
    assert same(num, sp.sympify(master["mahler_margin"]["positive_numerator"], locals=loc))
    assert same(den, sp.sympify(master["mahler_margin"]["positive_denominator"], locals=loc))
    positive_poly = tensor_bernstein(
        master["mahler_margin"]["coefficients"], [A, C, T, U], master["mahler_margin"]["bernstein_degree"])
    assert same(positive_poly, num)
    vals = [sp.Rational(x["value"]) for x in master["mahler_margin"]["coefficients"]]
    total = 1
    for dgr in master["mahler_margin"]["bernstein_degree"]:
        total *= dgr + 1
    assert len(vals) == master["mahler_margin"]["positive"] == 153
    assert total - len(vals) == master["mahler_margin"]["zero"] == 99
    assert all(v > 0 for v in vals)
    assert min(vals) == sp.Rational(master["mahler_margin"]["min_positive"]) == sp.Rational(1, 3)
    # Explicit positivity decomposition of all denominator factors.
    denom_target = 9 * (U + 1) * (3 * U + 1) * (2 * T * U + U + 1) * \
        ((1 - U) + A * (1 + U)) * \
        (C * (2 * T * U + U + 1) + 2 * U * (1 - T))
    assert same(den, denom_target)
    checks.append("mahler_margin_tensor_bernstein_positive")

    result = {
        "status": "PASS",
        "family_index": 81,
        "checks": checks,
        "elapsed_seconds": round(time.time() - started, 3),
        "closure_stats": stats,
        "closure_verification_chunks": 3,
        "orientation": {
            "P_tets": len(orient["P_tets"]),
            "Q_tets": len(orient["Q_tets"]),
            "unique_groups": len(groups),
        },
        "mahler_bernstein": {
            "degree": master["mahler_margin"]["bernstein_degree"],
            "positive": 153,
            "zero": 99,
            "negative": 0,
            "min_positive": "1/3",
        },
        "conclusion": "Mahler product is strictly greater than 32/3 throughout the strict survivor-81 domain.",
        "status_scope": "computer-assisted analytic proof candidate",
    }
    OUTPUT.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        OUTPUT.write_text(json.dumps({"status": "FAIL", "error": repr(exc)}, indent=2))
        raise
