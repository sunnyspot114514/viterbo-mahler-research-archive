#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor family 87.

The verifier uses only exact SymPy arithmetic.  It checks:
  * the rational rank-four completion and strict-domain parameterization;
  * the normalized two-slab representation;
  * exact cap-disjointness identities and the resulting 20-vertex closure;
  * the global primal and polar volume formulae;
  * a two-variable Bernstein certificate for the strict Mahler margin.

This is a computer-assisted analytic proof candidate, not an externally reviewed theorem.
"""
from __future__ import annotations

import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family87_verifier_output.json"


def same(x, y):
    return sp.cancel(x - y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees):
    P = sp.Poly(sp.expand(poly), *variables)
    monomials = {m: sp.Rational(c) for m, c in P.terms()}
    out = {}
    for index in itertools.product(*[range(n + 1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in monomials.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff * factor
        out[index] = sp.factor(value)
    return out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def main():
    started = time.time()
    checks = []

    # Original free variables and simplex/interval variables.
    p, q, r, s = sp.symbols("p q r s", real=True)
    T, U, V, W = sp.symbols("T U V W", positive=True)
    E = 1 - U - V - W
    domain_sub = {p: 2 * T - 1, q: 1 - 2 * U, r: 2 * V - 1, s: 2 * W - 1}

    # Exact completed pairing matrix.
    M = sp.Matrix([
        [(p - 1) / 2, -(q + r - s - 1) / 2, 1, -1, -1, -1],
        [-(p - 1) / 2, (q - r + s - 1) / 2, 1, -1, 1, 1],
        [p, 1, -1, -1, -1, -1],
        [(p*q - p - 2*q + r + s + 2)/(q + r + s - 1), 1, -1, -1,
         -(3*q - r - s - 3)/(q + r + s - 1), 1],
        [(p*s + p - q + r)/(q - r + s + 1), 1, -1,
         (q - r - 3*s - 3)/(q - r + s + 1), -1, 1],
        [(p*r + p - q + s)/(q + r - s + 1), 1,
         (q - 3*r - s - 3)/(q + r - s + 1), -1, -1, 1],
        [1, (p*q + p*r + p*s - q - r - s - 2)/(p - 3), -1, -1,
         (3*p - 1)/(p - 3), -1],
        [1, q, -1, -1, 1, 1],
        [1, r, -1, 1, 1, -1],
        [1, s, 1, -1, 1, -1],
    ])
    template = [
        [0, 0, 1, -1, -1, -1],
        [0, 0, 1, -1, 1, 1],
        [0, 1, -1, -1, -1, -1],
        [0, 1, -1, -1, 0, 1],
        [0, 1, -1, 0, -1, 1],
        [0, 1, 0, -1, -1, 1],
        [1, 0, -1, -1, 0, -1],
        [1, 0, -1, -1, 1, 1],
        [1, 0, -1, 1, 1, -1],
        [1, 0, 1, -1, 1, -1],
    ]

    pivot_rows = [2, 7, 8, 9]
    pivot_cols = [2, 3, 4, 5]
    basis = M.extract(pivot_rows, range(6))
    pivot = basis.extract(range(4), pivot_cols)
    assert same(pivot.det(), -16)
    coefficients = M.extract(range(10), pivot_cols) * pivot.inv()
    assert all(same(x, 0) for x in coefficients * basis - M)
    checks.append("exact_rank_four_completion")

    # The strict domain is exactly Delta_3^o x (0,1):
    # T,U,V,W,E>0 and U+V+W+E=1.
    Mc = M.subs(domain_sub).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    expected_defects = {
        (0, 0): T - 1,
        (0, 1): 1 - (E + 2*V),
        (1, 0): 1 - T,
        (1, 1): -1 + (E + 2*W),
        (2, 0): 2*T - 1,
        (3, 0): 1 - 2*U*(2 - T)/(E + 2*U),
        (3, 4): (E - 2*U)/(E + 2*U),
        (4, 0): -1 + 2*W*T/(E + 2*W),
        (4, 3): (E - 2*W)/(E + 2*W),
        (5, 0): -1 + 2*V*T/(E + 2*V),
        (5, 2): (E - 2*V)/(E + 2*V),
        (6, 1): 1 - 2*(1 - T)*(E + 2*U)/(2 - T),
        (6, 4): 1 - 2*T/(2 - T),
        (7, 1): 1 - 2*U,
        (8, 1): -1 + 2*V,
        (9, 1): -1 + 2*W,
    }
    seen = set()
    for i, row in enumerate(template):
        for j, flag in enumerate(row):
            if flag != 0:
                continue
            assert same(Mc[i, j], expected_defects[(i, j)])
            seen.add((i, j))
    assert seen == set(expected_defects)

    # Positive denominator-minus-numerator decompositions for the nontrivial
    # Möbius-form defects.  Together with T,U,V,W,E>0, these prove |x|<1.
    assert same((E + 2*U) - U*(2 - T), E + U*T)
    assert same((E + 2*W) - W*T, E + W*(2 - T))
    assert same((E + 2*V) - V*T, E + V*(2 - T))
    assert same((2 - T) - (1 - T)*(E + 2*U),
                T + (1 - T)*(E + 2*V + 2*W))
    assert same((2 - T) - T, 2*(1 - T))
    checks.append("strict_domain_Delta3_times_interval_and_sixteen_defects")

    # Normalize four primal columns to the standard basis.
    normalized = sp.simplify(pivot.inv() * basis).subs(domain_sub)
    u = sp.Matrix([-T/2, -T/2, (2 - T)/2, -T/2])
    v = sp.Matrix([-(E + 2*V)/2, -(E + 2*W)/2, -(E + 2*U)/2, E/2])
    assert all(same(normalized[i, 0], u[i]) for i in range(4))
    assert all(same(normalized[i, 1], v[i]) for i in range(4))
    assert normalized[:, 2:6] == sp.eye(4)
    checks.append("normalized_primal_is_crosspolytope_plus_two_vertex_pairs")

    # Each slab cuts one antipodal pair of simplex caps.
    l1_u = T/2 + T/2 + (2 - T)/2 + T/2
    l1_v = (E + 2*V)/2 + (E + 2*W)/2 + (E + 2*U)/2 + E/2
    assert same(l1_u, 1 + T)
    assert same(l1_v, 1 + E)
    assert same(T, 2*(T/2))
    assert same(E, 2*(E/2))

    # Same-sign cap closures are disjoint.  With lambda=E+U, mu=1,
    # the last two coordinates coincide and the support gap is
    # 2 min(U,(E+U)(1-T))>0.
    lam_same = E + U
    z_same = sp.simplify(lam_same*u + v)
    X = (E + U)*(1 - T)
    assert same(z_same[2], (X - U)/2)
    assert same(z_same[3], (X - U)/2)
    same_base = -z_same[0] - z_same[1]
    assert same((lam_same + 1) - same_base, X + U)

    # Opposite-sign cap closures are disjoint.  With lambda=1-U, mu=T,
    # the first two coordinates are opposite and the support gap is
    # 2*T*min(V,W)>0.
    lam_opp = 1 - U
    z_opp = sp.simplify(lam_opp*u - T*v)
    assert same(z_opp[0], T*(V - W)/2)
    assert same(z_opp[1], T*(W - V)/2)
    assert same(z_opp[2] - z_opp[3], lam_opp + T*(E + U))
    assert same((lam_opp + T) - (lam_opp + T*(E + U)), T*(V + W))
    checks.append("two_slab_simplex_caps_have_disjoint_closures")

    # Direct geometric section closure.  Four cube vertices (two antipodal
    # pairs) are truncated.  The u-caps add one new edge vertex each, while
    # the v-caps add three each, yielding 16-4+2+6=20 vertices.
    cube_vertices = [
        (1, -1, -1, -1),
        (1, -1, 1, 1),
        (-1, -1, -1, -1),
        (-1, -1, 1, 1),
        (-1, 1, 1, -1),
        (1, -1, 1, -1),
    ]
    predicted = [
        sp.Matrix(cube_vertices[0]),
        sp.Matrix(cube_vertices[1]),
        sp.Matrix(cube_vertices[2]),
        sp.Matrix([-1, -1, (E - 2*U)/(E + 2*U), 1]),
        sp.Matrix([-1, (E - 2*W)/(E + 2*W), -1, 1]),
        sp.Matrix([(E - 2*V)/(E + 2*V), -1, -1, 1]),
        sp.Matrix([-1, -1, (2 - 3*T)/(2 - T), -1]),
        sp.Matrix(cube_vertices[3]),
        sp.Matrix(cube_vertices[4]),
        sp.Matrix(cube_vertices[5]),
    ]
    for i, y in enumerate(predicted):
        actual = sp.Matrix([Mc[i, j] for j in range(2, 6)])
        assert all(same(actual[k], y[k]) for k in range(4))
        assert same((u.dot(y)), Mc[i, 0])
        assert same((v.dot(y)), Mc[i, 1])
    assert 16 - 4 + 2 + 6 == 20
    checks.append("exact_section_closure_twenty_vertices_without_240_chart_scan")

    # All twelve primal vertices are genuine: coordinate facets contain e_i
    # in relative interior, while the two slab facets are 3D simplex-cap bases.
    for i in range(4):
        assert sp.factor(1 - u[i]**2) != 0
        assert sp.factor(1 - v[i]**2) != 0
    checks.append("twelve_primal_vertices_by_nonredundant_cube_and_slab_facets")

    # Global primal volume from the ten positive facets.
    def vertex(j):
        return basis[:, j] if j < 6 else -basis[:, j - 6]

    expected_signed_dets = {
        0: [16],
        1: [16],
        2: [8*E, 8*(E + 2*U), 8*(E + 2*W), 8*(E + 2*V), 16],
        3: [8*(E + 2*U)],
        4: [8*(E + 2*W)],
        5: [8*(E + 2*V)],
        6: [8*(2 - T)],
        7: [8*T, 8*(2 - T), 8*T, 8*T, 16],
        8: [8*T, 8*(2 - T), 8*T, 8*T, 16],
        9: [8*T, 8*(2 - T), 8*T, 8*T, 16],
    }
    signs = {
        0: [1], 1: [1], 2: [-1, -1, 1, -1, -1], 3: [1],
        4: [-1], 5: [1], 6: [1], 7: [-1, -1, 1, -1, -1],
        8: [1, -1, -1, -1, -1], 9: [1, -1, 1, 1, -1],
    }
    P_volume = sp.Rational(0)
    for i, row in enumerate(template):
        ids = []
        for j, flag in enumerate(row):
            if flag == 1:
                ids.append(j)
            elif flag == -1:
                ids.append(j + 6)
        dets = []
        for subset in itertools.combinations(ids, 4):
            dets.append(sp.factor(sp.Matrix.hstack(*[vertex(j) for j in subset]).det()))
        assert len(dets) == len(signs[i]) == len(expected_signed_dets[i])
        signed_sum = sp.Rational(0)
        for det, sign, expected in zip(dets, signs[i], expected_signed_dets[i]):
            signed = sp.factor((sign*det).subs(domain_sub))
            assert same(signed, expected)
            signed_sum += sign*det
        P_volume += sp.factor(signed_sum/(12 if len(ids) == 4 else 24))
    P_target = sp.Rational(4, 3)*(8 + T + E)
    assert same(P_volume.subs(domain_sub), P_target)
    checks.append("global_primal_volume_by_fixed_sign_facet_circuits")

    # Global polar volume by two disjoint antipodal simplex-cap pairs.
    cap_u = sp.factor(T**4/(12*(T/2)**3*((2 - T)/2)))
    cap_v = sp.factor(E**4/(12*(E/2)*((E + 2*U)/2)*((E + 2*V)/2)*((E + 2*W)/2)))
    assert same(cap_u, 4*T/(3*(2 - T)))
    assert same(cap_v, 4*E**3/(3*(E + 2*U)*(E + 2*V)*(E + 2*W)))
    Q_normalized = 16 - cap_u - cap_v
    Q_volume = sp.factor(Q_normalized/16)  # |det(pivot)|=16
    Q_target = 1 - T/(12*(2 - T)) - E**3/(12*(E + 2*U)*(E + 2*V)*(E + 2*W))
    assert same(Q_volume, Q_target)
    checks.append("global_polar_volume_by_two_disjoint_simplex_cap_pairs")

    # Strict Mahler margin.  A product lower bound removes U,V,W:
    # (E+2U)(E+2V)(E+2W) > E^2(2-E).
    product = (E + 2*U)*(E + 2*V)*(E + 2*W)
    product_excess = sp.factor(product - E**2*(2 - E))
    assert same(product_excess, 4*E*(U*V + U*W + V*W) + 8*U*V*W)

    exact_margin = sp.factor(P_target*Q_target - sp.Rational(32, 3))
    lower_Q = 1 - T/(12*(2 - T)) - E/(12*(2 - E))
    lower_margin = sp.factor(P_target*lower_Q - sp.Rational(32, 3))
    N = sp.expand(
        7*T**2*E + 7*T*E**2 - 18*T*E
        - 13*T**2 - 13*E**2 + 16*T + 16*E
    )
    assert same(lower_margin, 2*N/(9*(2 - T)*(2 - E)))
    assert same(exact_margin - lower_margin,
                P_target*(E/(12*(2 - E)) - E**3/(12*product)))

    # Recompute with an independent symbol and then substitute Z=E, avoiding
    # treating E=1-U-V-W as a polynomial variable in SymPy.
    Z = sp.Symbol("Z")
    NZ = sp.expand(
        7*T**2*Z + 7*T*Z**2 - 18*T*Z
        - 13*T**2 - 13*Z**2 + 16*T + 16*Z
    )
    assert same(N, NZ.subs(Z, E))
    bern = tensor_bernstein_coefficients(NZ, (T, Z), (2, 2))
    stats = bernstein_stats(bern)
    expected_matrix = [
        [0, 8, 3],
        [8, sp.Rational(23, 2), sp.Rational(11, 2)],
        [3, sp.Rational(11, 2), 2],
    ]
    for i in range(3):
        for j in range(3):
            assert bern[(i, j)] == expected_matrix[i][j]
    assert stats == {
        "positive": 8,
        "zero": 1,
        "negative": 0,
        "minimum_positive": 2,
    }
    checks.append("strict_Mahler_margin_via_product_bound_and_degree_2_Bernstein")

    output = {
        "status": "PASS",
        "family_index": 87,
        "scope": "computer-assisted analytic proof candidate; no external peer review",
        "domain": "Delta_3^o x (0,1): T,U,V,W,E>0, U+V+W+E=1",
        "rank_pivot_det": "-16",
        "section_vertices": 20,
        "P_volume": str(P_target),
        "Q_volume": str(Q_target),
        "margin_lower_bound_numerator": str(N),
        "margin_bernstein_matrix": [[str(x) for x in row] for row in expected_matrix],
        "checks": checks,
        "elapsed_seconds": round(time.time() - started, 3),
    }
    OUTPUT.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
