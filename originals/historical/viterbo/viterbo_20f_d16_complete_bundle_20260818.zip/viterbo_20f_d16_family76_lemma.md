# Family 76: exact exclusion in the 12V/20F, D=16 layer

## Statement

For the bounded-12 four-dimensional centrally symmetric Mahler problem, the algebraic survivor indexed **76** has a strict realization space rationally equivalent to the open unit four-cube. Every strict realization has exactly twelve primal vertices and twenty polar vertices, and

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

This is a computer-assisted analytic proof candidate.

## Parameter domain

Use \(0<X,B,C,R<1\), and put

\[
K=1-C+BC,\qquad L=1+B-C,
\]

\[
A=\frac{X}{1+C},\qquad T=\frac{RK}{L}.
\]

The original four free defect coordinates are affine functions of \(A,B,C,T\). All sixteen defect inequalities reduce to rational expressions with positive denominators and Bernstein-positive numerators on the unit cube.

## Normalized geometry

After a \(GL(4)\) normalization, four primal columns are \(e_1,\ldots,e_4\), and the other two are

\[
u=
\left(
\frac{XC}{1+C},
\frac{1+C-X}{1+C},
-\frac{X}{1+C},
-\frac{XC}{1+C}
\right),
\]

\[
v=
\left(
-\frac{R(1-C)}{L},
-\frac{L-RK}{L},
-\frac{BR}{L},
\frac{BR(1-C)}{L}
\right).
\]

All six positive primal columns have full-dimensional normal cones. Hence the family is genuinely 12-vertex.

The polar is a four-cube intersected with two symmetric slabs. The same-sign cap pairs are strictly separated. The opposite-sign cap closures meet only at

\[
y_*=(1,1,2C-1,-1)
\]

and its antipode. Direct cap counting gives exactly twenty section vertices.

## Volumes and Mahler margin

Set

\[
x=\frac{XC}{1+C},\qquad e=\frac{BR(1-C)}{L}.
\]

The fixed-sign facet-circuit computation gives

\[
|P|=\frac{4}{3}(4+x+e).
\]

The polar cap volumes can be written as

\[
|P^\circ|=2-\sigma_u-\sigma_v,
\]

where

\[
\sigma_u=\frac{XC^2}{6(1+C-X)},
\qquad
\sigma_v=\frac{B^2R(1-C)^2}{6(L-RK)}.
\]

The strict domain implies

\[
\sigma_u<\frac{x}{3},\qquad
\sigma_v<\frac{e}{3},\qquad
0<x+e<1.
\]

Writing \(s=x+e\) and \(\tau=\sigma_u+\sigma_v\),

\[
|P||P^\circ|-\frac{32}{3}
=\frac43\bigl(2s-(4+s)\tau\bigr)
>\frac{4s(2-s)}{9}>0.
\]

An independent tensor-Bernstein check has degree \((2,3,5,2)\), with

\[
111>0,\qquad105=0,\qquad0<0,
\]

and minimum positive coefficient \(1/10\).

## Verification

The independent exact verifier checks rank, all defects, primal extremality, section closure, cap interaction, circuit-volume signs and both Mahler-margin proofs.
