# 12V/20F, c=0, D=16：survivor 91 的解析关闭候选

日期：2026-08-17

## 1. 结论

在四维中心对称 Mahler / symmetric Viterbo 的 bounded-12 分类中，`20F,D=16` 预分类留下 14 个 rank-four 连续模板。本说明关闭其中编号 91 的高对称模板：

\[
\boxed{\mathcal P(P)=|P|\,|P^\circ|>\frac{32}{3}}
\]

遍历该模板的全部 strict interior。这里的结论仍属于 **computer-assisted analytic proof candidate**，尚未经过外部同行审阅。

---

## 2. 精确 rank-four 参数化

令四个自由参数为

\[
a=x_{2,0},\qquad b=x_{3,0},\qquad c=x_{4,0},\qquad d=x_{5,0}.
\]

pairing matrix 为

\[
X=\begin{pmatrix}
\frac{a-b-c+d}{2}&0&1&-1&-1&-1\\
-\frac{a-b+c-d}{2}&0&1&-1&1&1\\
a&1&-1&-1&-1&-1\\
b&1&-1&-1&1&1\\
c&1&-1&1&-1&1\\
d&1&1&-1&-1&1\\
1&-\frac{a+b-c-d-2}{a-b+c+d}&-1&-1&\frac{3a+b-c-d-4}{a-b+c+d}&-1\\
1&\frac{a+b-c-d-2}{a-b-c-d}&-1&-1&1&\frac{a+3b-c-d-4}{a-b-c-d}\\
1&-\frac{a+b-c-d-2}{a+b-c+d}&-1&\frac{a+b-c-3d-4}{a+b-c+d}&1&-1\\
1&-\frac{a+b-c-d-2}{a+b+c-d}&\frac{a+b-3c-d-4}{a+b+c-d}&-1&1&-1
\end{pmatrix}.
\]

取第 2、3、4、5 行以及第 2、3、4、5 列为 pivot，pivot determinant 恒等于

\[
16.
\]

其余六行都由这四行的显式有理线性组合给出，所以

\[
\operatorname{rank}X=4
\]

遍历所有允许参数。

---

## 3. strict domain 是标准四维单纯形

令

\[
a=1-2A,\qquad b=1-2B,\qquad c=2C-1,\qquad d=2D-1,
\]

并记

\[
E=1-A-B-C-D.
\]

全部 16 个 defect inequalities

\[
|x_{ij}|<1
\]

精确等价于

\[
\boxed{A>0,\quad B>0,\quad C>0,\quad D>0,\quad E>0.}
\]

例如四条代表性恒等式为

\[
1-x_{6,4}^{2}=\frac{8AE}{(E+2A)^2},
\qquad
1-x_{7,5}^{2}=\frac{8BE}{(E+2B)^2},
\]

\[
1-x_{8,3}^{2}=\frac{8DE}{(E+2D)^2},
\qquad
1-x_{9,2}^{2}=\frac{8CE}{(E+2C)^2}.
\]

其余 solved defects 也都分解成正 barycentric factors；两个线性 defect 的绝对值则严格小于

\[
A+B+C+D<1.
\]

因此该 family 的全部 interior 由标准开四维单纯形无遗漏覆盖。

---

## 4. 六对 primal vertices 全部保持 extreme

以四条 pivot rows 为坐标后，六个正向 primal columns 为

\[
\begin{aligned}
v_0&=(a,b,c,d),\\
v_1&=(1,1,1,1),\\
v_2&=(-1,-1,-1,1),\\
v_3&=(-1,-1,1,-1),\\
v_4&=(-1,1,-1,-1),\\
v_5&=(-1,1,1,1).
\end{aligned}
\]

固定的五个 sign columns 由四个坐标 facet normals 直接暴露。对可动点 \(v_0\)，第 6、7、8、9 条 facet normals 的 determinant 为

\[
-\frac{E^3}
{(E+2A)(E+2B)(E+2C)(E+2D)}\neq0.
\]

所以 \(v_0\) 也是四个独立 supporting hyperplanes 的唯一交点。由中心对称性，十二个点

\[
\pm v_0,\ldots,\pm v_5
\]

全部是 genuine vertices。

---

## 5. 完整 cube-section closure

对

\[
L=\operatorname{row}(X)\subset\mathbb R^6
\]

枚举全部

\[
\binom64 2^4=240
\]

个 active-coordinate charts，精确结果为：

\[
\boxed{
52\text{ 次 chart occurrences 对应预期顶点},
\quad176\text{ 个由严格 cube violation 排除},
\quad12\text{ 个 split charts}.
}
\]

52 次 occurrences 去重后恰为 20 个 section vertices，即 10 对 antipodal vertices。

对 176 个普通无效 charts，至少一个 inactive coordinate 满足

\[
1-z_j^2<0,
\]

其相反数分子在四维单纯形 Bernstein basis 中全部非负并至少一项严格为正；分母是正系数乘完全平方。

最后 12 个 charts 只出现在两个 active sets：

\[
\{0,1,2,3\},\qquad\{0,1,4,5\}.
\]

它们分别由内部墙

\[
A=B,
\qquad
C=D
\]

控制。墙外按差值正负分域，总有一个 inactive coordinate 严格落在 \([-1,1]\) 外；墙上 active matrix 降秩，不能产生新的孤立 section vertex，除非被另一个 nonsingular chart 捕获。完整枚举没有发现额外顶点。

因此

\[
\boxed{|\operatorname{vert}(L\cap[-1,1]^6)|=20.}
\]

---

## 6. 四个 triangulation chambers

primal oriented matroid 的内部变化墙只有

\[
A=B,
\qquad
C=D.
\]

所以参数域分成四个 chambers：

\[
A\gtrless B,
\qquad
C\gtrless D.
\]

四个 chamber 分别有 66、64、66、64 个 primal/polar orientation records。所有非零 determinant 都在相应 chamber-simplex 上获得固定符号的 Bernstein certificate，失败数为 0。

四个 chambers 独立求和后得到完全相同的体积公式。因此内部 bistellar switch 不影响最终 Mahler 公式。

---

## 7. 精确体积

primal volume 为

\[
\boxed{
|P|=\frac{2}{3}(a+b-c-d+16)
=\frac{4}{3}(10-A-B-C-D).
}
\]

polar volume 是一个显式四次有理式；完整表达式保存在机器证书中。其分母因子为

\[
6(A-B-C-D+1)(A-B+C+D-1)
(A+B-C+D-1)(A+B+C-D-1).
\]

在开四维单纯形中，这四个因子的符号依次是

\[
+,-,-,-.
\]

---

## 8. Mahler 正余量

精确化简得到

\[
|P||P^\circ|-\frac{32}{3}
=
\frac{-2G(A,B,C,D)}
{9(A-B-C-D+1)(A-B+C+D-1)
(A+B-C+D-1)(A+B+C-D-1)}.
\]

把 \(G\) 写成 degree-5 的四维 simplex Bernstein basis：

\[
G=
\sum_{e+i+j+k+\ell=5}
\gamma_{eijkl}
\frac{5!}{e!i!j!k!\ell!}
E^eA^iB^jC^kD^\ell.
\]

全部 126 个 coefficients 满足

\[
\boxed{48>0,\qquad78=0,\qquad0<0,}
\]

最小严格正 coefficient 是

\[
\boxed{\frac15}.
\]

开单纯形内每个 barycentric basis function 都严格为正，所以

\[
G(A,B,C,D)>0.
\]

余量分母为负，分子 \(-2G\) 也为负，故

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

遍历整个 strict domain。

---

## 9. 当前层的更新

`20F,D=16` 的预分类为

\[
92
=72\text{ 个 rank-}\ge5
+6\text{ 个重复 facet-row}
+14\text{ 个连续 survivors}.
\]

本结果关闭其中 1 个。因此当前前沿更新为：

\[
\boxed{14\longrightarrow13\text{ 个未关闭 survivors}.}
\]

剩余 13 个中，12 个已经有精确四参数有理参数化；编号 42 仍需要不同的非线性消元。下一个优先对象是编号 90，它的 strict domain 已被化为两个标准二维单纯形的直积。
