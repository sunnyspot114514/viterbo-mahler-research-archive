#!/usr/bin/env python3
"""Exact verifier for 12V/20F, c=0, D=16, survivor family 88."""
from __future__ import annotations
import hashlib,itertools,json,time
from pathlib import Path
import sympy as sp
HERE=Path(__file__).resolve().parent
CERT=HERE/'viterbo_20f_d16_family88_certificate.json'
OUTPUT=HERE/'viterbo_20f_d16_family88_verifier_output.json'
def same(x,y): return sp.cancel(x-y)==0
def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def tensor_coefficients(poly,variables,degrees):
    P=sp.Poly(sp.expand(poly),*variables); mons={m:sp.Rational(c) for m,c in P.terms()}; out={}
    for idx in itertools.product(*[range(n+1) for n in degrees]):
        val=sp.Rational(0)
        for powers,coeff in mons.items():
            if all(k<=i for k,i in zip(powers,idx)):
                fac=sp.Rational(1)
                for i,k,n in zip(idx,powers,degrees): fac*=sp.Rational(sp.binomial(i,k),sp.binomial(n,k))
                val+=coeff*fac
        out[idx]=sp.factor(val)
    return out
def stats(c):
    vals=list(c.values()); return {'positive':sum(int(bool(x>0)) for x in vals),'zero':sum(int(bool(x==0)) for x in vals),
        'negative':sum(int(bool(x<0)) for x in vals),'min_positive':min((x for x in vals if bool(x>0)),default=None)}
def check_bern(poly,variables,rec):
    s=stats(tensor_coefficients(poly,variables,rec['degree']))
    assert s['positive']==rec['positive'] and s['zero']==rec['zero'] and s['negative']==rec['negative']
    if rec.get('min_positive') is not None and s['positive']: assert s['min_positive']==sp.Rational(rec['min_positive'])
    return s
def vertex(B,j): return B[:,j] if j<6 else -B[:,j-6]

def main():
    started=time.time(); Cj=json.loads(CERT.read_text()); checks=[]
    def mark(x): print(f'[f88] {x} {time.time()-started:.2f}s',flush=True)
    a,b,c,d=sp.symbols('a b c d'); U,V,W,T=sp.symbols('U V W T'); A,B,E,C,D,F=sp.symbols('A B E C D F')
    loc={x.name:x for x in [a,b,c,d,U,V,W,T,A,B,E,C,D,F]}; vars_=[U,V,W,T]
    cr=Cj['domain']['cube_parameterization']; cube={a:sp.sympify(cr['a'],locals=loc),b:sp.sympify(cr['b'],locals=loc),c:sp.sympify(cr['c'],locals=loc),d:sp.sympify(cr['d'],locals=loc)}
    tri={a:1-2*B,b:2*(1-A-B)-1,c:1-2*D,d:2*(1-C-D)-1}
    M=sp.Matrix([[sp.sympify(x,locals=loc) for x in row] for row in Cj['matrix_entries']]); template=Cj['template']
    pr=Cj['pivot_rows']; pc=Cj['pivot_cols']; Bas=M.extract(pr,range(6)); pivot=Bas.extract(range(4),pc)
    assert same(pivot.det(),sp.Rational(Cj['rank_pivot_det'])); coeff=M.extract(range(10),pc)*pivot.inv(); assert all(same(x,0) for x in coeff*Bas-M)
    checks.append('exact_rank_four_completion'); mark('rank')

    # Product-of-two-open-triangles parametrization and inverse.
    A0=(a-b)/2; B0=(1-a)/2; E0=(1+b)/2; C0=(c-d)/2; D0=(1-c)/2; F0=(1+d)/2
    assert same(A0+B0+E0,1) and same(C0+D0+F0,1)
    assert same(A0.subs(cube),U); assert same(B0.subs(cube),(1-U)*V); assert same(E0.subs(cube),(1-U)*(1-V))
    assert same(C0.subs(cube),W); assert same(D0.subs(cube),(1-W)*T); assert same(F0.subs(cube),(1-W)*(1-T))
    # Rational inverse on the strict domain: U=A, V=B/(1-A), W=C, T=D/(1-C).
    checks.append('bijective_product_of_two_open_triangles_parameterization'); mark('domain')

    Mc=M.subs(cube).applyfunc(lambda x:sp.factor(sp.cancel(x))); strict={(x['row'],x['col']):x for x in Cj['strict_defects']}; seen=set()
    for i,row in enumerate(template):
        for j,flag in enumerate(row):
            if flag!=0: continue
            rec=strict[(i,j)]; expr=Mc[i,j]; qq=sp.factor(sp.cancel(1-expr**2)); num,den=sp.fraction(qq)
            assert same(expr,sp.sympify(rec['cube_expression'],locals=loc)); assert same(qq,sp.sympify(rec['one_minus_square'],locals=loc))
            assert same(num,sp.sympify(rec['numerator'],locals=loc)); assert same(den,sp.sympify(rec['denominator'],locals=loc))
            ns=check_bern(num,vars_,rec['numerator_bernstein']); ds=check_bern(den,vars_,rec['denominator_bernstein'])
            assert ns['negative']==0 and ns['positive']>0 and ds['negative']==0 and ds['positive']>0; seen.add((i,j))
    assert seen==set(strict); checks.append('sixteen_strict_defects'); mark('defects')

    for rec in Cj['primal_extremality']:
        j=rec['column']; rows=rec['rows']; Am=sp.Matrix([list(template[i][j]*coeff.row(i)) for i in rows]); det=sp.factor(Am.det())
        assert same(det,sp.sympify(rec['det_original'],locals=loc)); assert same(det.subs(tri),sp.sympify(rec['det_triangle'],locals=loc))
        assert det!=0
    checks.append('twelve_primal_vertices'); mark('primal')

    clos=Cj['closure']; chunk_paths=[HERE/f'viterbo_20f_d16_family88_closure_chunk_{i:02d}_output.json' for i in range(15)]
    chunks=[json.loads(x.read_text()) for x in chunk_paths]; assert all(x['status']=='PASS' for x in chunks)
    totals={'expected':0,'direct':0,'special':0}; ids=set()
    for x in chunks:
        assert x['master_sha256']==sha256(CERT)
        for k,vv in x['stats'].items(): totals[k]+=vv
        ids.update(x['expected_ids'])
    assert totals=={'expected':52,'direct':180,'special':8}; assert len(ids)==20
    assert clos['stats']=={'total':240,'expected_occurrences':52,'unique_expected_vertices':20,'single_coordinate_violations':180,'paired_exclusions':8}
    checks.append('section_closure_all_240_charts_chunked_exact_replay'); mark('closure')

    pvc=Cj['P_volume']; ptotal=sp.Integer(0)
    for frec in pvc['facets']:
        i=frec['row']; ids=[]
        for j in range(6):
            if M[i,j]==1: ids.append(j)
            elif M[i,j]==-1: ids.append(j+6)
        assert ids==frec['vertices']; abs_sum=sp.Integer(0)
        for dr in frec['determinants']:
            det=sp.factor(sp.Matrix.hstack(*[vertex(Bas,j) for j in dr['subvertices']]).det())
            assert same(det,sp.sympify(dr['det_original'],locals=loc)); sc=sp.factor(sp.cancel((dr['sign']*det).subs(cube))); num,den=sp.fraction(sc)
            assert same(sc,sp.sympify(dr['signed_cube'],locals=loc)); assert same(num,sp.sympify(dr['positive_numerator'],locals=loc)); assert same(den,sp.sympify(dr['positive_denominator'],locals=loc))
            ns=check_bern(num,vars_,dr['numerator_bernstein']); ds=check_bern(den,vars_,dr['denominator_bernstein'])
            assert ns['negative']==0 and ns['positive']>0 and ds['negative']==0 and ds['positive']>0; abs_sum+=dr['sign']*det
        pairvol=sp.factor(abs_sum/(12 if len(ids)==4 else 24)); assert same(pairvol,sp.sympify(frec['pair_volume'],locals=loc)); ptotal+=pairvol
    Pformula=sp.sympify(pvc['target'],locals=loc); assert same(ptotal,Pformula)
    checks.append('global_primal_volume_by_facet_circuits'); mark('P volume')

    pol=Cj['polar_volume']; Vp=pivot.inv()*Bas
    assert all(same(Vp[i,0],sp.sympify(pol['normalized_extra_columns']['v0'][i],locals=loc)) for i in range(4))
    assert all(same(Vp[i,1],sp.sympify(pol['normalized_extra_columns']['v1'][i],locals=loc)) for i in range(4))
    cap0=sp.Rational(4,3)*A0**2/((A0+2*B0)*(A0+2*E0)); cap1=sp.Rational(4,3)*C0**2/((C0+2*D0)*(C0+2*F0))
    assert same(cap0,sp.sympify(pol['cap_pair0_normalized'],locals=loc).subs({A:A0,B:B0,E:E0})); assert same(cap1,sp.sympify(pol['cap_pair1_normalized'],locals=loc).subs({C:C0,D:D0,F:F0}))
    base_same=A0*C0/2+(A0*C0+C0*E0+A0*F0)/2
    assert same((A0+C0)/2-(base_same+(B0*C0-A0*D0)/2),A0*D0)
    assert same((A0+C0)/2-(base_same+(A0*D0-B0*C0)/2),B0*C0)
    base_opp=(A0*C0+B0*C0+A0*D0)/2+A0*C0/2
    assert same((A0+C0)/2-(base_opp+(C0*E0-A0*F0)/2),A0*F0)
    assert same((A0+C0)/2-(base_opp+(A0*F0-C0*E0)/2),C0*E0)
    Qformula=sp.sympify(pol['target'],locals=loc); assert same(Qformula,(16-cap0-cap1)/16)
    checks.append('global_polar_volume_by_disjoint_simplex_caps'); mark('Q volume')

    mr=Cj['Mahler_margin']; margin=sp.factor(sp.cancel(Pformula*Qformula-sp.Rational(32,3))); mc=sp.factor(sp.cancel(margin.subs(cube))); num,den=sp.fraction(mc)
    assert same(margin,sp.sympify(mr['expression_original'],locals=loc)); assert same(mc,sp.sympify(mr['cube_expression'],locals=loc))
    assert same(num,sp.sympify(mr['numerator'],locals=loc)); assert same(den,sp.sympify(mr['denominator'],locals=loc))
    ns=check_bern(num,vars_,mr['bernstein']); ds=check_bern(den,vars_,mr['denominator_bernstein'])
    assert ns['negative']==0 and ns['positive']>0 and ds['negative']==0 and ds['positive']>0
    checks.append('strict_Mahler_margin_tensor_Bernstein'); mark('margin')

    out={'status':'PASS','family_index':88,'checks':checks,'closure_stats':clos['stats'],'P_volume':str(Pformula),'Q_volume':str(Qformula),
         'margin_bernstein':mr['bernstein'],'certificate_sha256':sha256(CERT),'elapsed_seconds':round(time.time()-started,3),
         'scope':'computer-assisted analytic proof candidate; no external review'}
    OUTPUT.write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
