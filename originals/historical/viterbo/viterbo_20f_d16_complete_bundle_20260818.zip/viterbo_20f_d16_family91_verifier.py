#!/usr/bin/env python3
"""Independent exact verifier for 12V/20F, c=0, D=16, survivor family 91.

Requires Python 3.11+ and sympy. Run in the directory containing the companion JSON files.
The verifier checks exact rank four, the strict defect domain, primal extremality,
all 240 cube-section active-face charts, four chamber triangulations, and the
simplex Bernstein certificate for the Mahler margin.
"""
from __future__ import annotations
import hashlib, itertools, json, math, sys, time
from pathlib import Path
import sympy as sp

HERE=Path(__file__).resolve().parent
MASTER=HERE/'viterbo_20f_d16_family91_certificate.json'
CLOSURE=HERE/'viterbo_20f_d16_family91_closure_certificate.json'
TRIS=HERE/'viterbo_20f_d16_family91_chamber_triangulations.json'
ORIENT=HERE/'viterbo_20f_d16_family91_orientation_certificate.json'
OUTPUT=HERE/'viterbo_20f_d16_family91_verifier_output.json'

def sha256(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def simplex_alphas(n:int, dim:int=4):
    # alpha=(e,x1,...,xd), sum=n
    def rec(rem,k,prefix):
        if k==1:
            yield tuple(prefix+[rem]); return
        for x in range(rem+1):
            yield from rec(rem-x,k-1,prefix+[x])
    yield from rec(n,dim+1,[])

def bernstein_coefficients(poly, variables, degree=None):
    P=sp.Poly(sp.expand(poly),*variables)
    n=P.total_degree() if degree is None else degree
    if n<P.total_degree(): raise AssertionError('degree too small')
    def fall(x,k): return math.prod(range(x-k+1,x+1)) if k else 1
    vals=[]
    for alpha in simplex_alphas(n,len(variables)):
        av=alpha[1:]; val=sp.Rational(0)
        for beta,c0 in P.terms():
            if all(av[i]>=beta[i] for i in range(len(variables))):
                val += c0*sp.Rational(
                    math.prod(fall(av[i],beta[i]) for i in range(len(variables))),
                    fall(n,sum(beta)))
        vals.append((alpha,sp.factor(val)))
    return vals

def reconstruct_bernstein(entries, variables, degree):
    E=1-sum(variables)
    out=0
    for alpha,val in entries:
        e,*rest=alpha
        mult=sp.factorial(degree)/sp.factorial(e)
        for r in rest: mult/=sp.factorial(r)
        term=sp.Rational(val)*mult*E**e
        for x,r in zip(variables,rest): term*=x**r
        out+=term
    return sp.expand(out)

def main():
    t0=time.time(); checks=[]
    master=json.loads(MASTER.read_text()); closure=json.loads(CLOSURE.read_text())
    tris=json.loads(TRIS.read_text()); orient=json.loads(ORIENT.read_text())
    # Dependency integrity.
    for name,expected in master['dependencies_sha256'].items():
        got=sha256(HERE/name); assert got==expected,(name,got,expected)
    checks.append('dependency_hashes')
    print('DONE dependency_hashes', round(time.time()-t0,2), flush=True)

    a,b,c,d=sp.symbols('a b c d')
    A,B,C,D=sp.symbols('A B C D'); E=1-A-B-C-D
    oldlocals={'a':a,'b':b,'c':c,'d':d,'A':A,'B':B,'C':C,'D':D,'E':E}
    M=sp.Matrix([[sp.sympify(x,locals=oldlocals) for x in row] for row in master['matrix_entries']])
    sub={a:1-2*A,b:1-2*B,c:2*C-1,d:2*D-1}
    Ms=M.subs(sub).applyfunc(lambda x:sp.factor(sp.cancel(x)))

    # Exact rank-four certificate.
    pr=master['rank_certificate']['pivot_rows']; pc=master['rank_certificate']['pivot_cols']
    P=M.extract(pr,pc); assert P.det()==16
    Brows=M.extract(pr,range(6)); Pinv=P.inv()
    for i,expected_coeff in enumerate(master['rank_certificate']['row_coefficients']):
        coeff=(M.extract([i],pc)*Pinv).applyfunc(lambda x:sp.factor(sp.cancel(x)))
        assert [str(x) for x in coeff]==expected_coeff
        assert all(x==0 for x in (coeff*Brows-M.row(i)).applyfunc(lambda x:sp.factor(sp.cancel(x))))
    checks.append('rank_four')
    print('DONE rank_four', round(time.time()-t0,2), flush=True)

    # Strict-domain identities. Positivity follows from A,B,C,D,E>0.
    strict={(x['entry'],x['expression'],x['one_minus_square']) for x in master['strict_defect_certificates']}
    got=[]
    for i,row in enumerate(master['template']):
        for j,x in enumerate(row):
            if x==0:
                z=sp.factor(Ms[i,j]); q=sp.factor(sp.cancel(1-z**2))
                got.append((f'x{i}_{j}',str(z),str(q)))
    assert set(got)==strict and len(got)==16
    # Check the four nontrivial denominator factors in the linearization are nonzero in the simplex.
    factors=[E+2*A,E+2*B,E+2*C,E+2*D]
    assert all(f.subs({A:sp.Rational(1,10),B:sp.Rational(1,9),C:sp.Rational(1,8),D:sp.Rational(1,7)})>0 for f in factors)
    checks.append('strict_domain_factorization')
    print('DONE strict_domain_factorization', round(time.time()-t0,2), flush=True)

    # Primal extremality: columns 1..5 are exposed by the coordinate facet normals;
    # column 0 is exposed by rows 6..9, whose normal determinant is the expression below.
    # Compact determinant computation after clearing the four positive denominators.
    N=sp.Matrix([[A+E,A,-A,-A],[B,B+E,-B,-B],[D,D,-D,-(D+E)],[C,C,-(C+E),-C]])
    assert sp.factor(N.det()+E**3*(A+B+C+D+E))==0
    det0=sp.factor(N.det()/((E+2*A)*(E+2*B)*(E+2*C)*(E+2*D)))
    expected_det=sp.sympify(master['primal_extremality']['supporting_normal_det_simplex'],locals=oldlocals)
    assert sp.factor(sp.cancel(det0-expected_det))==0
    checks.append('twelve_primal_vertices')
    print('DONE twelve_primal_vertices', round(time.time()-t0,2), flush=True)

    # Full 240-chart cube-section closure certificate.
    expected=[Ms.row(i) for i in range(10)]+[-Ms.row(i) for i in range(10)]
    def equalrow(z,w): return all(sp.cancel(z[j]-w[j])==0 for j in range(6))
    records={(tuple(r['active_set']),tuple(r['signs'])):r for r in closure['records']}
    assert len(records)==240
    stats={'expected_occurrences':0,'global_violation':0,'special_split':0}; expected_ids=set()
    for S in itertools.combinations(range(6),4):
        T=[j for j in range(6) if j not in S]
        Q=Brows.subs(sub)[:,S].T; det=sp.factor(Q.det()); assert det!=0
        Qinv=Q.inv()
        for signs in itertools.product((-1,1),repeat=4):
            r=records[(S,signs)]; assert r['active_det']==str(det)
            alpha=Qinv*sp.Matrix(signs); z=(alpha.T*Brows.subs(sub)).applyfunc(lambda x:sp.factor(sp.cancel(x)))
            if r['kind']=='expected':
                k=r['expected_index']; assert equalrow(z,expected[k]); expected_ids.add(k)
                stats['expected_occurrences']+=1
            elif r['kind']=='global_violation':
                j=r['violating_coordinate']; q=sp.factor(sp.cancel(1-z[j]**2)); assert str(q)==r['one_minus_square']
                num,den=sp.fraction(q); assert str(num)==r['numerator'] and str(den)==r['denominator']
                coeff,fac=sp.factor_list(sp.factor(den),A,B,C,D)
                assert coeff>0 and all(exp%2==0 for _,exp in fac)
                entries=[(tuple(x[0]),sp.Rational(x[1])) for x in r['bernstein_nonzero_coefficients']]
                rec=reconstruct_bernstein(entries,(A,B,C,D),r['bernstein_degree'])
                assert sp.expand(rec+num)==0
                assert all(v>0 for _,v in entries)
                stats['global_violation']+=1
            else:
                assert r['kind']=='special_split'
                assert tuple(S) in {(0,1,2,3),(0,1,4,5)}
                assert [str(sp.factor(z[j])) for j in T]==r['inactive_coordinates']
                # For S=0123 let x=A-B; for S=0145 let x=C-D. If x>0 the first/second
                # listed formula (as encoded by the exact factors) is outside; if x<0 the other is.
                # At x=0 the active determinant vanishes, hence the chart is not an isolated vertex.
                stats['special_split']+=1
    assert stats==closure['stats'] and len(expected_ids)==20
    checks.append('section_closure_240_charts')
    print('DONE section_closure_240_charts', round(time.time()-t0,2), flush=True)

    # Chamber certificate consistency plus exact rational sample-volume replay.
    Al=(M.extract(range(10),pc)*P.inv()).applyfunc(lambda x:sp.factor(sp.cancel(x)))
    commonP=None; commonQ=None
    for name,data in tris.items():
        orecs=orient['chambers'][name]
        assert all(r['ok'] for r in orecs)
        assert len(orecs)==len(data['P_tets'])+len(data['Q_positive_tets'])
        sampleABCD=list(map(sp.Rational,data['sample']))
        sampleold={a:1-2*sampleABCD[0],b:1-2*sampleABCD[1],c:2*sampleABCD[2]-1,d:2*sampleABCD[3]-1}
        Bn=Brows.subs(sampleold); An=Al.subs(sampleold)
        ptotal=sp.Rational(0)
        for tet in data['P_tets']:
            cols=[Bn[:,i] if i<6 else -Bn[:,i-6] for i in tet]
            ptotal += abs(sp.Matrix.hstack(*cols).det())
        qtotal=sp.Rational(0)
        for tet in data['Q_positive_tets']:
            cols=[An[i,:].T if i<10 else -An[i-10,:].T for i in tet]
            qtotal += abs(sp.Matrix.hstack(*cols).det())
        pvalue=ptotal/24; qvalue=qtotal/12
        expectedP=sp.sympify(data['P_volume'],locals={'x2_0':a,'x3_0':b,'x4_0':c,'x5_0':d})
        expectedQ=sp.sympify(data['Q_volume'],locals={'x2_0':a,'x3_0':b,'x4_0':c,'x5_0':d})
        assert sp.cancel(pvalue-expectedP.subs(sampleold))==0
        assert sp.cancel(qvalue-expectedQ.subs(sampleold))==0
        if commonP is None: commonP,commonQ=data['P_volume'],data['Q_volume']
        else: assert data['P_volume']==commonP and data['Q_volume']==commonQ
    assert orient['fail_count']==0
    checks.append('four_chamber_certificate_and_exact_sample_volumes')
    print('DONE four_chamber_certificate_and_exact_sample_volumes', round(time.time()-t0,2), flush=True)

    # Mahler margin and its degree-five simplex Bernstein certificate.
    PvolS=sp.sympify(master['volumes']['P_simplex'],locals=oldlocals)
    QvolS=sp.sympify(master['volumes']['Q_simplex'],locals=oldlocals)
    margin=sp.factor(sp.cancel(PvolS*QvolS-sp.Rational(32,3)))
    assert str(margin)==master['mahler_margin']['expression']
    G=sp.sympify(master['mahler_margin']['positive_polynomial_G'],locals=oldlocals)
    entries=[(tuple(x['alpha']),sp.Rational(x['value'])) for x in master['mahler_margin']['coefficients']]
    rec=reconstruct_bernstein(entries,(A,B,C,D),5)
    assert sp.expand(rec-G)==0
    vals=[x for _,x in entries]
    assert sum(1 for x in vals if x.is_positive)==48 and sum(1 for x in vals if x==0)==78 and not any(x.is_negative for x in vals)
    assert min(x for x in vals if x>0)==sp.Rational(1,5)
    checks.append('mahler_margin_bernstein')
    print('DONE mahler_margin_bernstein', round(time.time()-t0,2), flush=True)

    result={'status':'PASS','family_index':91,'checks':checks,'elapsed_seconds':round(time.time()-t0,3),
            'closure_stats':stats,'orientation_records':{k:len(v) for k,v in orient['chambers'].items()},
            'bernstein':{'degree':5,'positive':48,'zero':78,'negative':0,'min_positive':'1/5'},
            'conclusion':'Mahler product > 32/3 throughout the strict four-simplex domain.'}
    OUTPUT.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    try: main()
    except Exception as exc:
        OUTPUT.write_text(json.dumps({'status':'FAIL','error':repr(exc)},indent=2),encoding='utf-8')
        raise
