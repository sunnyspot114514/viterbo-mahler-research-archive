# Survivor 87 in the bounded-12 four-dimensional symmetric Mahler program

## Statement

Consider the `12V/20F`, `c=0`, `D=16` sign template indexed by 87.  Its exact rank-four completion has four free defect parameters

\[
p=x_{2,0},\qquad q=x_{7,1},\qquad r=x_{8,1},\qquad s=x_{9,1}.
\]

Introduce

\[
p=2T-1,\qquad q=1-2U,\qquad r=2V-1,\qquad s=2W-1,
\]

and

\[
E=1-U-V-W.
\]

The full strict realization domain is exactly

\[
\boxed{0<T<1,\qquad U,V,W,E>0,\qquad U+V+W+E=1.}
\]

Thus the domain is the product

\[
\Delta_3^\circ\times(0,1).
\]

On this entire domain, the associated centrally symmetric four-polytope has exactly 12 vertices and 20 facets and satisfies

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

The result is a computer-assisted analytic proof candidate and has not undergone external peer review.

---

## 1. Exact rank-four completion and strict domain

The completed pairing matrix is

\[
\small
X=
\begin{pmatrix}
\frac{p-1}{2}&-\frac{q+r-s-1}{2}&1&-1&-1&-1\\
-\frac{p-1}{2}&\frac{q-r+s-1}{2}&1&-1&1&1\\
p&1&-1&-1&-1&-1\\
\frac{pq-p-2q+r+s+2}{q+r+s-1}&1&-1&-1&-\frac{3q-r-s-3}{q+r+s-1}&1\\
\frac{ps+p-q+r}{q-r+s+1}&1&-1&\frac{q-r-3s-3}{q-r+s+1}&-1&1\\
\frac{pr+p-q+s}{q+r-s+1}&1&\frac{q-3r-s-3}{q+r-s+1}&-1&-1&1\\
1&\frac{pq+pr+ps-q-r-s-2}{p-3}&-1&-1&\frac{3p-1}{p-3}&-1\\
1&q&-1&-1&1&1\\
1&r&-1&1&1&-1\\
1&s&1&-1&1&-1
\end{pmatrix}.
\]

Rows `2,7,8,9` and columns `2,3,4,5` give a constant pivot

\[
\boxed{\det=-16}.
\]

All other rows are exact rational combinations of these four rows.

After substituting \((T,U,V,W,E)\), the sixteen defect entries become

\[
\begin{aligned}
&T-1,\quad 1-(E+2V),\quad 1-T,\quad -1+(E+2W),\quad 2T-1,\\
&1-\frac{2U(2-T)}{E+2U},\quad \frac{E-2U}{E+2U},\\
&-1+\frac{2WT}{E+2W},\quad \frac{E-2W}{E+2W},\\
&-1+\frac{2VT}{E+2V},\quad \frac{E-2V}{E+2V},\\
&1-\frac{2(1-T)(E+2U)}{2-T},\quad 1-\frac{2T}{2-T},\\
&1-2U,\quad -1+2V,\quad -1+2W.
\end{aligned}
\]

Every entry is strictly between \(-1\) and \(1\).  The only nontrivial denominator-minus-numerator identities needed are

\[
(E+2U)-U(2-T)=E+UT>0,
\]

\[
(E+2W)-WT=E+W(2-T)>0,
\]

\[
(E+2V)-VT=E+V(2-T)>0,
\]

and

\[
(2-T)-(1-T)(E+2U)
=T+(1-T)(E+2V+2W)>0.
\]

Conversely, strictness of the free defects gives \(0<T,U,V,W<1\), while the three repeated-direction defects force \(E>0\).  Hence no additional strict branch is omitted.

---

## 2. Normalized two-slab geometry

After applying the inverse pivot, columns `2,3,4,5` become the standard basis and the remaining two primal columns are

\[
u=
\left(-\frac T2,-\frac T2,\frac{2-T}{2},-\frac T2\right),
\]

\[
v=
\left(-\frac{E+2V}{2},-\frac{E+2W}{2},-\frac{E+2U}{2},\frac E2\right).
\]

Thus the normalized polar is

\[
Q=[-1,1]^4\cap\{|u\cdot y|\le1\}\cap\{|v\cdot y|\le1\}.
\]

Moreover

\[
\|u\|_1=1+T,
\qquad
\|v\|_1=1+E.
\]

For the first slab, the cap height is \(T\), and

\[
T=2\min_i|u_i|.
\]

For the second slab, the cap height is \(E\), and

\[
E=2\min_i|v_i|.
\]

Hence every signed slab removes a four-simplex cap from the cube.

### Same-sign caps

Take positive weights

\[
\lambda=E+U,\qquad \mu=1.
\]

Put

\[
X_0=(E+U)(1-T).
\]

The third and fourth coordinates of \(\lambda u+v\) both equal

\[
\frac{X_0-U}{2}.
\]

A direct \(\ell_1\)-norm calculation gives

\[
\lambda+\mu-\|\lambda u+v\|_1
=2\min\{U,X_0\}>0.
\]

### Opposite-sign caps

Take

\[
\lambda=1-U=E+V+W,
\qquad
\mu=T.
\]

The first two coordinates of \(\lambda u-Tv\) are

\[
\frac{T(V-W)}2,
\qquad
\frac{T(W-V)}2.
\]

The support gap is

\[
\lambda+rac{\mu}{T}T-\|\lambda u-Tv\|_1
=2T\min\{V,W\}>0.
\]

Therefore all four cap closures are pairwise disjoint.

---

## 3. Exact section closure without a 240-chart scan

The \(u\)-slab truncates the two antipodal cube vertices with sign pattern

\[
(-,-,+,-).
\]

At each cap, three edge intersections occur at pre-existing adjacent cube vertices and one occurs in an edge interior.  Thus the antipodal \(u\)-cap pair removes two cube vertices and adds two new vertices, for net change zero.

The \(v\)-slab truncates the antipodal pair with sign pattern

\[
(-,-,-,+).
\]

At each cap, one edge intersection is an existing adjacent cube vertex and three are strict edge-interior points.  Hence this cap pair removes two cube vertices and adds six new vertices, for net change four.

Because the cap closures are disjoint, the total number of vertices is

\[
16-4+2+6=20.
\]

One representative from each antipodal pair is precisely

\[
\begin{aligned}
&(1,-1,-1,-1),\quad(1,-1,1,1),\quad(-1,-1,-1,-1),\\
&\left(-1,-1,\frac{E-2U}{E+2U},1\right),\\
&\left(-1,\frac{E-2W}{E+2W},-1,1\right),\\
&\left(\frac{E-2V}{E+2V},-1,-1,1\right),\\
&\left(-1,-1,\frac{2-3T}{2-T},-1\right),\\
&(-1,-1,1,1),\quad(-1,1,1,-1),\quad(1,-1,1,-1).
\end{aligned}
\]

These are exactly the ten rows of the pairing matrix in normalized cube coordinates.  Consequently

\[
\boxed{Q\text{ has exactly 20 vertices}.}
\]

The four coordinate inequalities of the cube are nonredundant because \(e_i\) lies in the relative interior of the corresponding coordinate facet.  The two slab inequalities are nonredundant because their cap bases are three-dimensional.  Therefore all six antipodal primal vertex-pairs are genuine:

\[
\boxed{f_0(P)=12}. 
\]

---

## 4. Exact volumes

Using the facet-circuit identity for the four five-vertex facets and ordinary cone determinants for the six tetrahedral facets gives

\[
\boxed{|P|=\frac{4}{3}(8+T+E)}.
\]

The normalized antipodal \(u\)-cap pair has volume

\[
\frac{T^4}{12\prod_i|u_i|}
=\frac{4T}{3(2-T)}.
\]

The normalized antipodal \(v\)-cap pair has volume

\[
\frac{E^4}{12\prod_i|v_i|}
=
\frac{4E^3}{3(E+2U)(E+2V)(E+2W)}.
\]

Undoing the determinant-16 normalization gives

\[
\boxed{
|P^\circ|
=1-\frac{T}{12(2-T)}
-\frac{E^3}{12(E+2U)(E+2V)(E+2W)}.
}
\]

---

## 5. A two-variable strict Mahler certificate

The denominator product satisfies

\[
\begin{aligned}
&(E+2U)(E+2V)(E+2W)-E^2(2-E)\\
&\qquad=4E(UV+UW+VW)+8UVW>0.
\end{aligned}
\]

Hence

\[
\frac{E^3}{(E+2U)(E+2V)(E+2W)}
<\frac{E}{2-E}.
\]

It is therefore enough to prove positivity of

\[
L(T,E)
=T+E-rac{8+T+E}{12}
\left(\frac{T}{2-T}+\frac{E}{2-E}\right).
\]

Exact simplification gives

\[
L(T,E)=\frac{N(T,E)}{6(2-T)(2-E)},
\]

where

\[
\begin{aligned}
N(T,E)={}&7T^2E+7TE^2-18TE\\
&-13T^2-13E^2+16T+16E.
\end{aligned}
\]

In the tensor Bernstein basis of bidegree \((2,2)\) on \([0,1]^2\), the coefficient matrix is

\[
\boxed{
\begin{pmatrix}
0&8&3\\
8&23/2&11/2\\
3&11/2&2
\end{pmatrix}.
}
\]

All coefficients are nonnegative, eight are strictly positive, and every Bernstein basis function is positive in the open square.  Thus

\[
N(T,E)>0
\qquad(0<T,E<1).
\]

Consequently

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout the full strict realization domain.
