# Survivor 88 in the bounded-12 four-dimensional symmetric Mahler program

## Statement

Consider the `12V/20F`, `c=0`, `D=16` sign template indexed by 88 in the current finite classification. After exact rank-four completion, let the four free defect parameters be

\[
a,b,c,d.
\]

Introduce two triples of barycentric coordinates

\[
A=\frac{a-b}{2},\qquad B=\frac{1-a}{2},\qquad E=\frac{1+b}{2},
\]

\[
C=\frac{c-d}{2},\qquad D=\frac{1-c}{2},\qquad F=\frac{1+d}{2}.
\]

The strict realization domain is exactly

\[
A,B,E,C,D,F>0,
\qquad A+B+E=C+D+F=1.
\]

Thus it is the product of two open two-simplexes. On this entire domain, the associated centrally symmetric four-polytope has exactly 12 vertices and 20 facets and satisfies

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

The result is a computer-assisted analytic proof candidate and has not undergone external peer review.

---

## 1. Exact parameterization and rank

Use the open unit four-cube

\[
0<U,V,W,T<1
\]

with

\[
A=U,\qquad B=(1-U)V,\qquad E=(1-U)(1-V),
\]

\[
C=W,\qquad D=(1-W)T,\qquad F=(1-W)(1-T).
\]

Equivalently,

\[
a=1-2(1-U)V,
\qquad
b=2(1-U)(1-V)-1,
\]

\[
c=1-2(1-W)T,
\qquad
d=2(1-W)(1-T)-1.
\]

The selected four-by-four rank pivot has determinant

\[
\boxed{-16}.
\]

All remaining rows are exact linear combinations of the pivot rows. Every one of the 16 defect entries satisfies

\[
1-x_{ij}^{2}>0
\]

throughout the open cube, with tensor-Bernstein certificates.

The two nonfixed primal columns have supporting-normal determinants

\[
-\frac{A}{(A+2B)(A+2B-2)}
\]

and

\[
\frac{C}{(C+2D)(C+2D-2)}.
\]

They never vanish in the strict product-simplex domain. The remaining four columns have constant supporting determinant 1. Hence all six antipodal vertex-pairs remain genuine.

---

## 2. Exact cube-section closure

All

\[
\binom64 2^4=240
\]

active four-coordinate charts were regenerated exactly. Their classification is

\[
\boxed{
240
=52\text{ expected occurrences}
+180\text{ one-coordinate violations}
+8\text{ paired wall exclusions}.
}
\]

The 52 expected occurrences reduce to exactly 20 distinct section vertices: the ten prescribed rows and their antipodes.

For the 180 ordinary exclusions, an inactive coordinate \(z\) satisfies

\[
1-z^2<0
\]

throughout the open parameter cube, with an exact tensor-Bernstein certificate.

Only two active determinant walls occur in the interior:

\[
\Delta=AD-BC=0
\]

for the active set \(\{0,1,2,3\}\), and

\[
\Delta_2=CE-AF=0
\]

for \(\{0,1,4,5\}\).

Off the first wall, the four exceptional sign patterns satisfy endpoint-offset identities such as

\[
z_0+1=-\frac{2AF}{\Delta},
\qquad
z_1-1=-\frac{2(A+2B)F}{\Delta},
\]

or

\[
z_0+1=\frac{2CE}{\Delta},
\qquad
z_1-1=\frac{2(C+2D)E}{\Delta}.
\]

Depending on the sign of \(\Delta\), one coordinate lies strictly outside \([-1,1]\). The antipodal patterns obey the corresponding reflected identities.

Off the second wall, the analogous identities include

\[
z_0-1=\frac{2D(A+2E)}{\Delta_2},
\qquad
z_1-1=-\frac{2AD}{\Delta_2},
\]

and

\[
z_0-1=-\frac{2B(C+2F)}{\Delta_2},
\qquad
z_1-1=\frac{2BC}{\Delta_2}.
\]

Again, one coordinate must leave the cube.

On \(\Delta=0\), a three-by-three active minor is \(4B\neq0\); on \(\Delta_2=0\), one is \(-4(A+E)\neq0\). Thus the active systems have rank exactly three on the walls and do not create new isolated section vertices.

Consequently

\[
\boxed{L\cap[-1,1]^6\text{ has exactly the prescribed 20 vertices}.}
\]

---

## 3. Global primal volume

The four five-vertex facets are evaluated with the circuit identity

\[
\operatorname{vol}\bigl(\operatorname{conv}(0,w_1,\dots,w_5)\bigr)
=
\frac1{48}
\sum_{i=1}^{5}
\left|
\det(w_1,\dots,\widehat{w_i},\dots,w_5)
\right|.
\]

The remaining six positive facets are tetrahedra. All relevant determinant signs are fixed throughout the strict domain by Bernstein certificates. Summing all antipodal facet-pair contributions gives

\[
\boxed{
|P|=\frac{2}{3}(a-b+c-d+16).
}
\]

In barycentric coordinates this is

\[
|P|=\frac{4}{3}(A+C+8).
\]

---

## 4. Polar volume as a cube with two pairs of simplex caps removed

After the constant rank pivot normalizes four primal columns to the standard basis, the two remaining columns are

\[
v_0=
\left(
-\frac A2,
-\frac{A+2E}{2},
\frac{A+2B}{2},
-\frac A2
\right),
\]

\[
v_1=
\left(
-\frac C2,
-\frac{C+2F}{2},
-\frac{C+2D}{2},
\frac C2
\right).
\]

Hence the normalized polar is the four-cube cut by the two symmetric slabs

\[
|v_0\cdot y|\le1,
\qquad
|v_1\cdot y|\le1.
\]

The two antipodal cap-pair volumes are

\[
\frac{4A^2}{3(A+2B)(A+2E)}
\]

and

\[
\frac{4C^2}{3(C+2D)(C+2F)}.
\]

The cap pairs are disjoint. For same-sign caps, a weighted support comparison gives gap

\[
AD>0\quad\text{if }BC\ge AD,
\]

and

\[
BC>0\quad\text{if }BC\le AD.
\]

For opposite-sign caps, the corresponding gap is

\[
AF>0\quad\text{if }CE\ge AF,
\]

or

\[
CE>0\quad\text{if }CE\le AF.
\]

Undoing the determinant-16 normalization yields the global formula

\[
\boxed{
|P^\circ|
=
1-
\frac{A^2}{12(A+2B)(A+2E)}
-
\frac{C^2}{12(C+2D)(C+2F)}.
}
\]

No polar triangulation chamber assumption is needed.

---

## 5. Strict Mahler margin

Substituting the unit-cube parameterization gives

\[
|P|\,|P^\circ|-\frac{32}{3}
=
\frac{H(U,V,W,T)}{D(U,V,W,T)}.
\]

The denominator has tensor degree \((2,2,2,2)\), with Bernstein statistics

\[
49>0,
\qquad32=0,
\qquad0<0,
\]

and minimum positive coefficient 9.

The numerator has tensor degree

\[
\boxed{(3,2,3,2)}
\]

and its 144 tensor-Bernstein coefficients satisfy

\[
\boxed{
91>0,
\qquad53=0,
\qquad0<0,
}
\]

with minimum positive coefficient

\[
\boxed{2}.
\]

Therefore

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout the strict product-simplex domain.
