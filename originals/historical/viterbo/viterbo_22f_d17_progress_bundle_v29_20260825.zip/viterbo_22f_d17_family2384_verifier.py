#!/usr/bin/env python3
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family2384_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family2384_verifier_output.json')
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
CID=2384

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def affine_dim(points):return np.linalg.matrix_rank(points-points[0],tol=1e-8)
def polygon_tris(ids,coords):
 ids=sorted(ids);pts=coords[ids];delta=pts-pts[0];vh=np.linalg.svd(delta,full_matrices=False)[2];xy=delta@vh[:2].T;h=ConvexHull(xy);order=[ids[i] for i in h.vertices];root=min(order);k=order.index(root);order=order[k:]+order[:k]
 return [tuple(sorted((root,order[i],order[i+1]))) for i in range(1,len(order)-1)]
def global_boundary_triangulation(facets,coords):
 ridges={}
 for i,j in itertools.combinations(range(len(facets)),2):
  inter=tuple(sorted(set(facets[i])&set(facets[j])))
  if len(inter)>=3 and affine_dim(coords[list(inter)])==2:ridges[inter]=polygon_tris(inter,coords)
 out=[]
 for facet in facets:
  root=min(facet)
  for ridge,tris in ridges.items():
   if root not in ridge and set(ridge)<=set(facet):out += [tuple(sorted((root,)+tri)) for tri in tris]
 return sorted(set(out)),ridges

def factorized_positive(expression, chart, eng, sample_original, label):
 expression=sp.factor(sp.cancel(expression));assert sp.N(expression.subs(sample_original))>0,(label,expression.subs(sample_original),expression)
 num,den=map(sp.factor,sp.together(expression).as_numer_denom());records=[];total=sp.Rational(1)
 for side,poly,es in [('numerator',num,1),('denominator',den,-1)]:
  coef,factors=sp.factor_list(poly)
  if coef<0:total*=-1
  for f,m in factors:
   fs=sp.factor(sp.cancel(f.subs(chart)));val=sp.N(fs.subs(eng.sample));assert val!=0,(label,side,f)
   sg=1 if val>0 else -1;ce=eng.positive_rational(sg*fs,label+' '+side+' factor')
   if m%2:total*=sg**es
   records.append({'side':side,'factor':str(f),'multiplicity':int(m),'sign':int(sg),'certificate':ce})
 assert total>0,(label,total,expression)
 return {'factorized':True,'records':records}

def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:
    z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=v
 rr=(0,1,4,9);cc=(2,3,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ);eq=[sp.factor(sp.cancel(e)) for e in S]
 const0,uns0,rem0,trace0=base.constant_eliminate(eq,vs)
 e5=sp.factor(x['x3_2']*x['x5_5']+x['x3_2']-2*x['x5_2']+x['x5_5']-1)
 e6=sp.factor(x['x3_2']*x['x6_3']-x['x3_2']+2*x['x6_2']-x['x6_3']-1)
 assert base.proportional_member(rem0,(x['x7_4']-1)*e5)
 assert base.proportional_member(rem0,-(x['x7_4']-1)*e6)
 init={x['x5_2']:sp.factor((x['x3_2']*x['x5_5']+x['x3_2']+x['x5_5']-1)/2),x['x6_2']:sp.factor((-x['x3_2']*x['x6_3']+x['x3_2']+x['x6_3']+1)/2)}
 const,uns,rem,trace=base.constant_eliminate(eq,vs,init)
 a,b,c=sp.symbols('a b c',real=True);st=dict(const);st.update({x['x1_0']:a,x['x3_2']:b,x['x4_0']:c})
 rem2=[base.apply_all(e,st) for e in rem];rem2=[sp.factor(sp.together(e).as_numer_denom()[0]) for e in rem2 if e!=0];rem2=list(dict.fromkeys(rem2))
 dep=sorted(set(uns)-{x['x1_0'],x['x3_2'],x['x4_0']},key=str);G=sp.groebner(rem2,*dep,order='lex',domain=sp.QQ.frac_field(a,b,c));assert G.is_zero_dimensional and len(G.polys)==4
 solg={}
 for poly in G.polys:
  e=sp.factor(poly.as_expr().subs(solg));vv=[z for z in dep if e.has(z) and z not in solg];assert len(vv)==1 and sp.Poly(e,vv[0]).degree()==1
  solg[vv[0]]=sp.factor(sp.solve(e,vv[0],simplify=False)[0])
 st.update(solg);allsol={z:base.apply_all(z,st) for z in vs};X=M.subs(allsol).applyfunc(lambda z:sp.factor(sp.cancel(z)));assert all(sp.factor(sp.cancel(e.subs(allsol)))==0 for e in eq)
 return rec,rows,M,vs,X,(a,b,c),rr,cc,allsol,trace0+trace,G,(e5,e6)

def main():
 rec,rows,M,vs,X0,free,rr,cc,sol,trace,G,rels=build_branch();a,b,c=free
 A,B,C=sp.symbols('A B C',real=True);chart={c:-C,a:-1+2*A*C,b:2*B-1};cv=(A,B,C);cube={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};sample={k:sp.factor(v.subs(cube)) for k,v in chart.items()};eng=base.SignEngine(cv,cube)
 F=sp.factor(a+2*c+1);Lp=sp.factor(a*b-a+2*b*c+b+1);Lm=sp.factor(a*b+a+2*b*c+b-1)
 coeff={'minus_F':eng.positive_rational((-F).subs(chart),'minus F'),'Lp':eng.positive_rational(Lp.subs(chart),'Lp'),'minus_Lm':eng.positive_rational((-Lm).subs(chart),'minus Lm')}
 invC=-c;invA=sp.factor((a+1)/(-2*c));invB=sp.factor((b+1)/2);assert sp.factor(invC.subs(chart)-C)==0 and sp.factor(invA.subs(chart)-A)==0 and sp.factor(invB.subs(chart)-B)==0
 pivot0=X0.extract(rr,cc);V0=(pivot0.inv()*X0.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F0=X0.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F0*V0-X0)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=factorized_positive(1-X0[i,j]**2,chart,eng,sample,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F0.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=factorized_positive(sg*det,chart,eng,sample,f'extremality {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V0.subs(sample),float);fn=np.array(F0.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP,ridP=global_boundary_triangulation(facP,ptsP);tetQ,ridQ=global_boundary_triangulation(facQ,ptsQ);pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP);qb=base.check_closed_sphere(tetQ);qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V0[:,i] if i<6 else -V0[:,i-6]
 def pointQ(i):return F0[i,:].T if i<11 else -F0[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0,(label,k,ids)
   sg=1 if det.subs(sample)>0 else -1;ce=factorized_positive(sg*det,chart,eng,sample,f'{label} tet {k}')
   terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(det),'sign':sg,'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
 f1=sp.factor(a*b-a+b*c+c-2);f2=sp.factor(a*b+a+b*c-c-2);f3=sp.factor(a*b-a+2*b*c+b-3)
 DP=sp.factor(4*(a+c));DQ=sp.factor((a+c)*f1*f2*f3)
 def accumulate(terms,common,label):
  total=sp.Poly(0,a,b,c,domain='QQ')
  for k,z in enumerate(terms):
   num,den=map(sp.factor,sp.together(z).as_numer_denom());ratio=sp.cancel(common/den);rn,rd=sp.together(ratio).as_numer_denom();assert sp.factor(rd)==1,(label,k,den,common)
   total += sp.Poly(sp.expand(num*rn),a,b,c,domain='QQ')
  return sp.factor(total.as_expr())
 NP=accumulate(pt,DP,'primal');NQ=accumulate(qt,DQ,'polar')
 volP0=sp.factor(NP/(24*DP));volQ0=sp.factor(NQ/(24*DQ))
 margin_num=sp.expand(NP*NQ-6144*DP*DQ);margin_den=sp.expand(576*DP*DQ)
 numc=sp.factor(margin_num.subs(chart));denc=sp.factor(margin_den.subs(chart));sg=1 if sp.N(denc.subs(cube))>0 else -1
 margin=sp.factor((sg*numc)/(sg*denc));mc=eng.positive_rational(margin,'Mahler margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2384','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relations':[str(z) for z in rels],'strict_consequence':'solve x5_2 and x6_2 because x7_4-1<0','constant_elimination_steps':trace,'groebner_basis_length':len(G.polys),'groebner_zero_dimensional':bool(G.is_zero_dimensional),'completion':{str(k):str(v) for k,v in sol.items()}},'parameter_domain':{'original':'-1<b<1, -1<c<0, -1<a<-2c-1','unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse_A':str(invA),'inverse_B':str(invB),'inverse_C':str(invC)},'coefficient_certificates':coeff,'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'polar_boundary':qb,'primal_ridge_sizes':dict(Counter(map(len,ridP))),'polar_ridge_sizes':dict(Counter(map(len,ridQ))),'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P_original':str(volP0),'volume_polar_original':str(volQ0),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 2384 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P_original':str(volP0),'volume_polar_original':str(volQ0),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
