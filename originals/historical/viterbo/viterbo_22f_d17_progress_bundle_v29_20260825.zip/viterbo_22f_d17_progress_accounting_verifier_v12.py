#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,sys
from pathlib import Path
BASE=Path('/mnt/data')
OLD=BASE/'viterbo_22f_d17_progress_accounting_certificate_v11.json'
OLD_STATUS=BASE/'viterbo_bounded12_status_20260825_v28.json'
PRE=BASE/'viterbo_22f_d17_preclassification_certificate.json'
CERT=BASE/'viterbo_22f_d17_progress_accounting_certificate_v12.json'
OUT=BASE/'viterbo_22f_d17_progress_accounting_verifier_output_v12.json'
NEW_IDS=[2270,2384]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(cid):
 script=BASE/f'viterbo_22f_d17_family{cid}_verifier.py';out=BASE/f'viterbo_22f_d17_family{cid}_verifier_output.json';cert=BASE/f'viterbo_22f_d17_family{cid}_certificate.json'
 subprocess.run([sys.executable,str(script)],check=True,timeout=180,stdout=subprocess.DEVNULL)
 o=json.loads(out.read_text());c=json.loads(cert.read_text())
 assert o['status']=='PASS' and c['status']=='PASS' and o['canonical_id']==cid and c['canonical_id']==cid
 assert o['rank']==4 and o['strict_defects']==17 and o['primal_vertices']==12 and o['polar_vertices']==22
 assert c['margin_certificate']['numerator']['positive']>0 and c['margin_certificate']['denominator']['positive']>0
 return {'status':'PASS','rank':4,'strict_defects':17,'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':o['tetrahedra_primal'],'tetrahedra_polar':o['tetrahedra_polar'],'margin_certificate':o['margin_certificate'],'script_sha256':sha(script),'certificate_sha256':sha(cert),'output_sha256':sha(out),'parameter_domain':c['parameter_domain']}

def main():
 old=json.loads(OLD.read_text());status=json.loads(OLD_STATUS.read_text());pre=json.loads(PRE.read_text())
 assert old['status']=='PASS' and old['total_pairing_templates']==2395
 oldrem=old['remaining_ids'];assert oldrem==status['frontier']['remaining_ids'] and len(oldrem)==38
 assert all(i in oldrem for i in NEW_IDS)
 results={str(i):run(i) for i in NEW_IDS}
 remaining=[i for i in oldrem if i not in NEW_IDS]
 positive=sorted(old['Mahler_positive_exact_families']+NEW_IDS)
 assert len(remaining)==36 and len(positive)==20 and not(set(remaining)&set(positive))
 disjoint={'facet_containment':1230,'rank_ge_5_after_antichain':1070,'segment_loss_after_antichain':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':20,'strict_rank4_boundary_or_interval_impossible':13,'remaining_algebraic_survivors':36}
 assert sum(disjoint.values())==2395
 survivor={'initial':121,'facet_containment':26,'additional_segment_loss':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':20,'strict_rank4_boundary_or_interval_impossible':13,'remaining':36}
 assert sum(v for k,v in survivor.items() if k!='initial')==survivor['initial']
 cert={'status':'PASS','scope':old['scope'],'scope_warning':old['scope_warning'],'total_pairing_templates':2395,'disjoint_classification':disjoint,'survivor_level_accounting':survivor,'Mahler_positive_exact_families':positive,'strict_rank4_boundary_or_interval_impossible':old['strict_rank4_boundary_or_interval_impossible'],'newly_closed':{'Mahler_positive_exact':NEW_IDS},'remaining_ids':remaining,'rerun_results':results,'source_hashes':{str(PRE):sha(PRE),str(OLD):sha(OLD),str(OLD_STATUS):sha(OLD_STATUS)}}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 out={'status':'PASS','scope':cert['scope'],'newly_closed':NEW_IDS,'Mahler_positive_exact_total':20,'remaining':36,'total_pairing_templates':2395,'certificate':str(CERT),'certificate_sha256':sha(CERT),'rerun_results':results}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
