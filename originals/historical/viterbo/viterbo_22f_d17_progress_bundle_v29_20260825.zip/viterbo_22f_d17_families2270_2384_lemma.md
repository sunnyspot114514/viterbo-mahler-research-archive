# Two exact Mahler-positive families in 12V/22F, c=0, D=17

Date: 2026-08-25

## Scope

This note closes canonical Families 2270 and 2384 in the four-dimensional centrally symmetric Mahler bounded-12 program.  Every checkmark below means a computer-assisted analytic proof candidate, not an externally peer-reviewed theorem.

The target inequality is

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

Both families are reconstructed from their original 11-by-6 pairing sign templates.  Rank-four completeness, strict parameter domains, primal and polar extremality, global boundary triangulations, exact volumes, and Bernstein positivity are all verified independently.

---

## Family 2270

### Rank-four branch

Use rows \((0,1,2,10)\) and columns \((2,3,4,5)\) as a constant pivot.  Its determinant is \(-8\).

A Schur equation contains

\[
(x_{1,0}+1)(x_{6,2}+1)(x_{7,4}-x_{8,4})=0.
\]

Strictness excludes \(x_{1,0}=-1\) and \(x_{6,2}=-1\), hence

\[
x_{7,4}=x_{8,4}.
\]

Let

\[
a=x_{0,1},\qquad b=x_{3,0},\qquad c=x_{4,5}.
\]

After constant-coefficient elimination, the remaining determinantal ideal has a zero-dimensional lexicographic Gröbner basis of length five over \(\mathbb Q(a,b,c)\).  It uniquely determines every remaining defect.  In particular,

\[
x_{8,4}=c,
\]

\[
x_{5,5}=x_{9,5}=
\frac{bc-3b+c+1}{bc+b+c-3},
\]

\[
x_{6,2}=
\frac{ac+5a-c+3}{(a-1)(c+1)}.
\]

### Complete strict domain

All seventeen strict defect inequalities reduce to

\[
-1<c<1,
\]

\[
-1<a<\frac{c-1}{c+3},
\]

\[
-1<b<\frac{1-c}{c+3}.
\]

The potentially nontrivial residual factor

\[
L_4=2ab-2a-bc^2-2bc+b-c^2+2c+1
\]

is automatically positive on this domain.  With

\[
c=2C-1,
\]

\[
a=-1+\frac{2AC}{C+1},
\]

\[
b=-1+\frac{2B}{C+1},
\qquad 0<A,B,C<1,
\]

it becomes a Bernstein-positive rational function.  The inverse chart is

\[
C=\frac{c+1}{2},\qquad
A=\frac{(a+1)(c+3)}{2(c+1)},\qquad
B=\frac{(b+1)(c+3)}4.
\]

Thus the full strict realization space is rationally equivalent to an open cube.

### Combinatorial closure and volume

The verifier certifies

\[
\operatorname{rank}X=4,\qquad f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

A ridge-compatible global boundary triangulation uses

\[
35\text{ primal tetrahedra},\qquad 79\text{ polar tetrahedra}.
\]

Every selected simplex determinant keeps a fixed strict sign throughout the full parameter cube.

The exact primal volume is

\[
|P|=
\frac{ab c^2-ab+ac^2-4ac+11a-3bc^2+3b-3c^2+28c+47}
{48(c+1)}.
\]

### Mahler margin

After the unit-cube substitution, the positive margin numerator has tensor Bernstein degree

\[
(2,3,7).
\]

Its coefficients satisfy

\[
82>0,\qquad 14=0,\qquad 0<0,
\]

with minimum positive coefficient

\[
\frac{24}{7}.
\]

The denominator has degree \((1,2,5)\), with all 36 coefficients strictly positive and minimum 9.  Therefore

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout Family 2270.

---

## Family 2384

### Rank-four branch

Use rows \((0,1,4,9)\) and columns \((2,3,4,5)\) as a constant pivot.  Its determinant is \(8\).

Two Schur equations factor as

\[
(x_{7,4}-1)
\bigl(x_{3,2}x_{5,5}+x_{3,2}-2x_{5,2}+x_{5,5}-1\bigr)=0,
\]

and

\[
-(x_{7,4}-1)
\bigl(x_{3,2}x_{6,3}-x_{3,2}+2x_{6,2}-x_{6,3}-1\bigr)=0.
\]

Strictness excludes \(x_{7,4}=1\), so these equations uniquely solve \(x_{5,2}\) and \(x_{6,2}\).

Let

\[
a=x_{1,0},\qquad b=x_{3,2},\qquad c=x_{4,0}.
\]

The remaining ideal has a zero-dimensional lexicographic Gröbner basis of length four over \(\mathbb Q(a,b,c)\).  It uniquely determines the other defects.  For example,

\[
x_{0,0}=-c,
\]

\[
x_{0,1}=x_{7,4}=-\frac{a+3c+2}{a+c},
\]

\[
x_{5,5}=-\frac{ab+a+bc+3c+2}{ab+a+bc-c-2},
\]

\[
x_{6,3}=\frac{ab+3a+bc+c+2}{ab-a+bc+c-2}.
\]

### Complete strict domain

All seventeen strict inequalities reduce exactly to

\[
-1<b<1,
\]

\[
-1<c<0,
\]

\[
-1<a<-2c-1.
\]

Equivalently, with

\[
c=-C,
\qquad
b=2B-1,
\qquad
 a=-1+2AC,
\qquad 0<A,B,C<1,
\]

the full realization space is an open cube.  The inverse chart is

\[
C=-c,\qquad
A=-\frac{a+1}{2c},\qquad
B=\frac{b+1}{2}.
\]

The principal strict factor is

\[
a+2c+1=-2C(1-A)<0.
\]

The remaining nontrivial defect factors become Bernstein-positive automatically on the cube.

### Combinatorial closure

The verifier certifies

\[
\operatorname{rank}X=4,\qquad f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

A ridge-compatible boundary decomposition uses

\[
38\text{ primal tetrahedra},\qquad 80\text{ polar tetrahedra}.
\]

All selected determinants retain a fixed strict sign over the full parameter cube.

### Explicit common-denominator volume certificate

Direct generic rational simplification of the 80 polar tetrahedron terms caused expression blow-up.  The verifier instead accumulates the oriented terms over the explicit common denominator

\[
D_Q=(a+c)
(ab-a+bc+c-2)
(ab+a+bc-c-2)
(ab-a+2bc+b-3).
\]

For the primal sum it uses

\[
D_P=4(a+c).
\]

Each individual tetrahedron denominator is verified to divide the corresponding global denominator in \(\mathbb Q[a,b,c]\).  The numerators are then accumulated as polynomial objects before the Mahler margin is formed.  This avoids reliance on a general-purpose simplifier and gives a replayable exact volume certificate.

The exact primal volume is

\[
|P|=-\frac{
 a^2b+a^2+3abc+ab+2ac-12a+2bc^2+bc+c^2-16c-4
}{12(a+c)}.
\]

### Mahler margin

After the unit-cube substitution, the positive margin numerator has tensor Bernstein degree

\[
(6,6,6).
\]

Its 343 coefficients satisfy

\[
260>0,\qquad83=0,\qquad0<0,
\]

with minimum positive coefficient

\[
\frac16.
\]

The denominator has degree \((5,3,5)\), with

\[
102>0,\qquad42=0,\qquad0<0,
\]

and minimum positive coefficient \(18/25\).  Therefore

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout Family 2384.

---

## Consequence for the D=17 accounting

The two canonical IDs 2270 and 2384 move from the unresolved set to the exact Mahler-positive class.  The number of exact Mahler-positive families becomes 20, and the unresolved count decreases from 38 to 36.
