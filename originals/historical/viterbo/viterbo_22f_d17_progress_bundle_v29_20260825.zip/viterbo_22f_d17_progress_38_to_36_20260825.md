# Viterbo/Mahler bounded-12 progress: D=17, 38 to 36

Date: 2026-08-25

## New exact closures

The following two genuine continuous families are now closed as computer-assisted analytic proof candidates:

\[
\boxed{2270,\quad2384}.
\]

Both satisfy, throughout their complete strict realization spaces,

\[
\operatorname{rank}X=4,
\qquad f_0(P)=12,
\qquad f_0(P^\circ)=22,
\]

and

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

### Family 2270

- Parameter domain:
  \[
  -1<c<1,
  \quad -1<a<\frac{c-1}{c+3},
  \quad -1<b<\frac{1-c}{c+3}.
  \]
- Rationally equivalent to an open three-cube.
- Boundary triangulation: 35 primal tetrahedra and 79 polar tetrahedra.
- Margin Bernstein degree: \((2,3,7)\).
- Margin numerator coefficients: 82 positive, 14 zero, no negative.
- Minimum positive coefficient: \(24/7\).

### Family 2384

- Parameter domain:
  \[
  -1<b<1,
  \quad -1<c<0,
  \quad -1<a<-2c-1.
  \]
- Rationally equivalent to an open three-cube.
- Boundary triangulation: 38 primal tetrahedra and 80 polar tetrahedra.
- Margin Bernstein degree: \((6,6,6)\).
- Margin numerator coefficients: 260 positive, 83 zero, no negative.
- Minimum positive coefficient: \(1/6\).
- Polar volume is accumulated with an explicit global polynomial common denominator rather than a generic rational simplifier.

## Updated exact accounting

All 2395 canonical pairing templates are now classified disjointly as

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ facet-containment templates}\\
&+1070\text{ antichain rank-}\ge5\text{ templates}\\
&+22\text{ segment vertex-loss templates}\\
&+4\text{ duplicate/antipodal primal-pair templates}\\
&+20\text{ exact Mahler-positive families}\\
&+13\text{ strict boundary/interval-impossible families}\\
&+36\text{ remaining families}.
\end{aligned}}
\]

At the original 121-survivor level,

\[
\boxed{121=26+22+4+20+13+36}.
\]

The aggregate verifier independently reruns both family verifiers and returns `PASS`.

## Current frontier

\[
\boxed{
12V/22F,\quad c=0,\quad D=17:
\qquad121\longrightarrow36.
}
\]

Of these 36 remaining families, 31 retain a constant pure-sign \(\pm8\) pivot and five require a defect-dependent pivot or the full determinantal ideal:

\[
\boxed{1654,\ 1656,\ 1770,\ 2070,\ 2394}.
\]

Families 131 and 1260 remain the leading candidates for genuinely four-parameter realization spaces.

## Scope warning

All checkmarks remain computer-assisted analytic proof candidates.  This work advances the bounded-12 finite core of the four-dimensional symmetric Mahler conjecture; it does not yet prove the full four-dimensional conjecture.
