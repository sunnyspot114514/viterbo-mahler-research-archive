#!/usr/bin/env python3
from __future__ import annotations
import sys,json,itertools
from pathlib import Path
from itertools import combinations
W=Path(sys.argv[1]); K=int(sys.argv[2]); OUT=Path(sys.argv[3]); TXT=Path(sys.argv[4])

def normrow(a):
 a=tuple(a)
 for x in a:
  if x:return tuple(-y for y in a) if x<0 else a
 return a
facets=[];seen=set()
for mask in range(64):
 if mask.bit_count()!=4:continue
 inds=[i for i in range(6) if mask>>i&1]
 for signs in itertools.product((-1,1),repeat=4):
  a=[0]*6
  for i,s in zip(inds,signs):a[i]=s
  a=normrow(a)
  if a not in seen:seen.add(a);facets.append(a)
facets.sort()
def row_to_F(r):return frozenset((i+1 if x>0 else -(i+1)) for i,x in enumerate(r) if x)
def anti(F):return frozenset(-x for x in F)
def sphere_from_ids(ids):
 out=set()
 for i in ids:
  F=row_to_F(facets[i]);out.add(F);out.add(anti(F))
 return out
sphere_ids=[]
for line in open(W/'sphere_orbits.txt'):sphere_ids.append(tuple(map(int,line.split(':',1)[1].split())))
def dual_data(fs):
 flist=sorted(fs,key=lambda f:tuple(sorted(f)));idx={f:i for i,f in enumerate(flist)};ant=[idx[anti(f)] for f in flist]
 ed=[(i,j) for i,j in combinations(range(len(flist)),2) if len(flist[i]&flist[j])==3]
 seen=set();eps=[]
 for e in ed:
  ae=tuple(sorted((ant[e[0]],ant[e[1]])));key=tuple(sorted((e,ae)))
  if key not in seen:seen.add(key);eps.append(key)
 eps=[pair for pair in eps if not any(i in (flist[pair[0][0]]|flist[pair[0][1]]) and -i in (flist[pair[0][0]]|flist[pair[0][1]]) for i in range(1,7))]
 return flist,idx,ant,eps,[frozenset(e1+e2) for e1,e2 in eps]
def enum_exact(supp,k):
 nfac=max(max(s) for s in supp)+1;by=[[] for _ in range(nfac)]
 for i,S in enumerate(supp):
  for f in S:by[f].append(i)
 full=frozenset(range(nfac));out=[]
 def rec(ch,used):
  if len(ch)==k:
   if used==full:out.append(tuple(sorted(ch)))
   return
  if len(full-used)!=4*(k-len(ch)):return
  f=min(full-used)
  for i in by[f]:
   if supp[i].isdisjoint(used):rec(ch+[i],used|supp[i])
 rec([],frozenset());return sorted(set(out))
def row_from_face(F):return normrow([1 if i in F else -1 if -i in F else 0 for i in range(1,7)])
def sign_template(flist,ant,eps,m):
 cons=set();faces=[]
 for pi in m:
  e1,e2=eps[pi];faces.append(flist[e1[0]]|flist[e1[1]]);cons.update(e1);cons.update(e2)
 for i,F in enumerate(flist):
  if i not in cons and i<ant[i]:faces.append(F)
 rows=tuple(sorted(row_from_face(F) for F in faces));assert len(rows)==10
 expected=[1]*K+[2]*(10-K);assert sorted(sum(x==0 for x in r) for r in rows)==expected
 return rows
records=[];summ=[]
with TXT.open('w') as g:
 rid=0
 for si,ids in enumerate(sphere_ids):
  fs=sphere_from_ids(ids);flist,idx,ant,eps,supp=dual_data(fs);ms=enum_exact(supp,K)
  summ.append({'sphere':si,'good_ridge_pairs':len(eps),'raw_matchings':len(ms)})
  for m in ms:
   rows=sign_template(flist,ant,eps,m);rec={'sphere':si,'matching':list(m),'rows':[list(r) for r in rows]};records.append(rec)
   g.write(str(rid)+' '+''.join(str(x+1) for row in rows for x in row)+'\n');rid+=1
OUT.write_text(json.dumps({'sphere_summary':summ,'raw_matchings':len(records),'records':records},separators=(',',':')))
print(json.dumps({'sphere_orbits':len(sphere_ids),'raw_matchings':len(records),'max_per_sphere':max(x['raw_matchings'] for x in summ)},indent=2))
