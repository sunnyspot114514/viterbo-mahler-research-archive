#!/usr/bin/env python3
import json,sys
from pathlib import Path
CERT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('viterbo_20f_d10_preclassification_certificate.json')
d=json.loads(CERT.read_text())
def det_bareiss(mat):
 a=[list(map(int,r)) for r in mat];n=len(a);sgn=1;prev=1
 for k in range(n-1):
  p=next((i for i in range(k,n) if a[i][k]),None)
  if p is None:return 0
  if p!=k:a[k],a[p]=a[p],a[k];sgn=-sgn
  piv=a[k][k]
  for i in range(k+1,n):
   for j in range(k+1,n):a[i][j]=(a[i][j]*piv-a[i][k]*a[k][j])//prev
  prev=piv
  for i in range(k+1,n):a[i][k]=0
 return sgn*a[-1][-1]
def decode(k):return [[ord(k[6*i+j])-49 for j in range(6)] for i in range(10)]
counts={'rank_ge_5':0,'duplicate_facet_rows':0,'algebraic_survivor':0}
for rec in d['records']:
 A=decode(rec['canonical_key']);assert sorted(sum(x==0 for x in r) for r in A)==[1]*10
 counts[rec['status']]+=1
 if rec['status']=='rank_ge_5':
  rs,cs=rec['minor_rows'],rec['minor_cols'];B0=[[A[i][j] for j in cs] for i in rs];loc=[(i,j) for i in range(5) for j in range(5) if B0[i][j]==0];assert len(loc)==rec['defect_entries_in_minor']
  vals=[]
  for mask in range(1<<len(loc)):
   B=[r[:] for r in B0]
   for k,(i,j) in enumerate(loc):B[i][j]=1 if (mask>>k)&1 else -1
   vals.append(det_bareiss(B))
  assert vals==rec['corner_dets'];assert (all(v>=0 for v in vals) and any(v>0 for v in vals)) or (all(v<=0 for v in vals) and any(v<0 for v in vals))
 else:raise AssertionError('D10 certificate should contain only rank_ge_5')
assert counts==d['minor_classification']=={'rank_ge_5':2602,'duplicate_facet_rows':0,'algebraic_survivor':0}
print(json.dumps({'status':'PASS','sphere_orbits':d['sphere_orbit_count'],'raw_perfect_matchings':d['ridge_merge']['raw_perfect_matchings'],'global_templates':d['global_pairing_templates'],'classification':counts},indent=2,sort_keys=True))
