# 四维中心对称 Mahler：`12V/20F, c=0, D=10` 整层完成报告

日期：2026-08-21

## 1. 组合枚举

`D=10` 对应十条 single-defect rows，没有 double row。所有十对五顶点 facets 三角化后：

\[
f=(12,52,80,40),\qquad g_2=14.
\]

固定一对 antipodal tetrahedra 后，精确回溯访问

\[
90{,}235{,}079
\]

个节点，得到

\[
1{,}612{,}560
\]

个闭合 pseudomanifold candidates。完整 vertex-link 检查留下

\[
\boxed{612{,}800}
\]

个真正的中心对称 simplicial 三维球，并在 `B6/{±I}` 下形成

\[
\boxed{198\text{ 个球轨道}}.
\]

## 2. 十-ridge 完美 matching

每个 admissible ridge-pair support 含四个实际 tetrahedra。选择十对互不相交的 supports 等价于对全部四十个 tetrahedra 做 exact cover。

对 198 个球轨道完整枚举得到

\[
\boxed{7{,}780\text{ 个 raw perfect matchings}}.
\]

完整 signed-coordinate canonicalization 后只剩

\[
\boxed{2{,}602\text{ 个全局 pairing templates}}.
\]

## 3. Exact minor 分类

对全部 2,602 个 templates，均找到一个 `5x5` minor，使其在全部 defect-cube corners 上的整数行列式同号且至少一个严格非零。由多仿射插值，该 minor 在整个开 defect cube 内严格不为零。

因此

\[
\boxed{
2{,}602
=
2{,}602\text{ 个 rank}\ge5
+
0\text{ 个 survivors}.
}
\]

不存在重复 facet-row template，也不存在 genuine rank-four branch。

## 4. 结论

\[
\boxed{12V/20F,\quad c=0,\quad D=10\quad\checkmark}.
\]

勾号表示 **computer-assisted analytic proof candidate**。
