#!/usr/bin/env python3
import sympy as sp,numpy as np,json
from scipy.spatial import ConvexHull
from itertools import product
from pathlib import Path
W=Path(__file__).resolve().parent
A,B,C=sp.symbols('A B C');U,V,R=sp.symbols('U V R')
j=A-B-C;E=(A-B+C+1)/(A-B-C-1);F=(A+B-C+1)/(A-B-C-1);G=-(A-2*C+1)/(A-1);H0=-(A-2*B+1)/(A-1);I=-(3*A-B-C+1)/(A-B-C-1)
L=sp.factor(2/((G+H0+2)/2+(I+1)/(1-I)))
a0=sp.factor(L*(G+H0+2)/2-1);b0=sp.factor(L*(H0+1)/2-1);c0=sp.factor(L*(G+1)/2-1);d0=sp.factor(a0-L)
e0=sp.factor((a0*E-a0-b0*E+b0-c0*E-c0-d0*E+d0)/2);f0=sp.factor((a0*F-a0-b0*F-b0-c0*F+c0-d0*F+d0)/2)
vals={'x0_0':a0,'x0_1':A,'x1_0':b0,'x1_1':B,'x2_0':c0,'x2_1':C,'x3_0':d0,'x4_0':e0,'x4_3':E,'x5_0':f0,'x5_3':F,'x6_2':G,'x7_2':H0,'x8_3':I,'x9_1':j}
key=(W/'unique_templates.txt').read_text().splitlines()[240]
M=[]
for i in range(10):
 row=[]
 for k in range(6):
  z=int(key[6*i+k])-1;row.append(vals[f'x{i}_{k}'] if z==0 else sp.Integer(z))
 M.append(row)
M=sp.Matrix(M);rs=[0,1,2,3];cs=[2,3,4,5];Piv=M.extract(rs,cs)
p=U;q=(1-U)*V;S=sp.factor(p+q);T=sp.factor(p*q)
sub={A:2*R-1,B:2*R-1+2*(1-R)*p,C:2*R-1+2*(1-R)*q}
VM=(Piv.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.cancel(z.subs(sub)));FM=M.extract(range(10),cs).applyfunc(lambda z:sp.cancel(z.subs(sub)))
Acode=np.array([[int(key[6*i+k])-1 for k in range(6)] for i in range(10)],int)
sample={U:sp.Rational(1,4),V:sp.Rational(1,3),R:sp.Rational(2,5)};Vnum=np.array(VM.subs(sample),float);Fnum=np.array(FM.subs(sample),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum])
def project3(x):
 d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);o=set()
 for tri,eq in zip(h.simplices,h.equations):
  if abs(float(eq[:-1]@pr[0]+eq[-1]))<1e-8:continue
  o.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(o)
facP=[]
for i in range(10):
 facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):
 facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)]
def det4mat(X):
 from itertools import permutations
 ans=0
 for pp in permutations(range(4)):
  inv=sum(pp[i]>pp[j] for i in range(4) for j in range(i+1,4));term=-1 if inv%2 else 1
  for i in range(4):term*=X[i][pp[i]]
  ans+=term
 return sp.cancel(ans)
def dp(t):
 cols=[(VM[:,z] if z<6 else -VM[:,z-6]) for z in t];X=[[cols[j][i] for j in range(4)] for i in range(4)];return det4mat(X)
def dq(t):
 rows=[(list(FM[z,:]) if z<10 else list(-FM[z-10,:])) for z in t];return det4mat(rows)
def orient(tets,fn):
 out=[]
 for z,t in enumerate(tets):
  d=fn(t);d=d if d.subs(sample)>0 else -d;out.append(d)
  if z%20==0:print('det',z,'/',len(tets),flush=True)
 return out
print('build P',len(tP),flush=True);termsP=orient(tP,dp);print('build Q',len(tQ),flush=True);termsQ=orient(tQ,dq)
print('sum volumes',flush=True);volP=sp.factor(sp.together(sum(termsP)/24));volQ=sp.factor(sp.together(sum(termsQ)/24))
K=sp.factor(R+(1-R)*S);HH=sp.factor(R+(1-R)*S*(2-S));MP=sp.factor(4*R-2*(1-R)**2*S**3+(3*R**2-2*R-1)*S**2+(9-8*R-R**2)*S)
targetP=sp.factor(MP/(6*HH));targetQ=sp.factor(4*(12*R+(1-R)*(11*S-3*S**2+2*T))/(3*K));assert sp.factor(volP-targetP)==0 and sp.factor(volQ-targetQ)==0
GG=sp.expand(6*S**4*R**2-12*S**4*R+6*S**4-31*S**3*R**2+50*S**3*R-19*S**3+60*S**2*R**2-70*S**2*R+10*S**2-47*S*R**2+32*S*R+3*S+12*R**2+8*R)
Q0=sp.factor(4*(12*R+(1-R)*(11*S-3*S**2))/(3*K));assert sp.factor(targetP*Q0-sp.Rational(32,3)-2*S*(1-R)*GG/(9*K*HH))==0
# oriented numerator polynomials: denominator sign fixed at sample

def positive_numerators(terms):
 o={}
 for t in terms:
  n,d=map(sp.factor,sp.together(t).as_numer_denom());sg=1 if d.subs(sample)>0 else -1;pol=sp.factor(sg*n);o[str(pol)]=str(pol)
 return list(o.values())
defects={}
for n,x in vals.items():
 z=sp.cancel((1-x*x).subs(sub));nn,dd=map(sp.factor,sp.together(z).as_numer_denom());defects[n]={'numerator':str(nn),'denominator':str(dd)}
cert={'template_index':240,'template_key':key,'variables':['U','V','R'],'domain':'0<U,V,R<1; p=U; q=(1-U)V; S=p+q; T=pq','pivot_rows':rs,'pivot_cols':cs,'pivot_det':int(Piv.det()),'completed_matrix':[[str(sp.factor(x.subs(sub))) for x in M.row(i)] for i in range(10)],'defects':defects,'primal_tetrahedra':[list(t) for t in tP],'polar_facet_tetrahedra':[list(t) for t in tQ],'oriented_primal_terms':[str(t) for t in termsP],'oriented_polar_terms':[str(t) for t in termsQ],'positive_primal_numerators':positive_numerators(termsP),'positive_polar_numerators':positive_numerators(termsQ),'volume_P':str(targetP),'volume_polar':str(targetQ),'K':str(K),'H':str(HH),'M_P':str(MP),'G':str(GG),'margin_lower_bound':'2*S*(1-R)*G/(9*K*H)'}
json.dump(cert,open(W/'family240_certificate.json','w'),indent=2)
print('WROTE',len(tP),len(tQ),len(cert['positive_primal_numerators']),len(cert['positive_polar_numerators']),flush=True)
