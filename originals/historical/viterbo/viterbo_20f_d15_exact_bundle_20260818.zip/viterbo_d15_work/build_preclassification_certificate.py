#!/usr/bin/env python3
from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib
W=Path(__file__).resolve().parent
sphere_lines=(W/'sphere_orbits.txt').read_text().splitlines();sphere_reps=[];sphere_sizes=[]
for l in sphere_lines:
 left,right=l.split(':');p=left.split();sphere_sizes.append(int(p[1]));sphere_reps.append(list(map(int,right.split())))
raw=json.load(open(W/'raw_templates.json'));canon={int(a):b for a,b in (l.split() for l in open(W/'canonicalized_templates.txt'))};keys=(W/'unique_templates.txt').read_text().splitlines();idx={k:i for i,k in enumerate(keys)}
src=defaultdict(list)
for rid,r in enumerate(raw['records']):src[idx[canon[rid]]].append(r['sphere'])
classes={};cc=Counter();surv=[]
for l in open(W/'minor_classification.txt'):
 p=l.split();classes[int(p[0])]=p[1];cc[p[1]]+=1
 if p[1]=='SURV':surv.append(int(p[0]))
exclusive5=[i for i,v in src.items() if set(v)=={4}]
move=json.load(open(W/'bistellar_comparison_output.json'))
files=['enumerate_spheres.cpp','sphere_solutions.txt','filter_spheres.py','valid_spheres.txt','canon_spheres.cpp','sphere_orbits.txt','raw_templates.json','unique_templates.txt','minor_classification.txt','family240_certificate.json','family240_verifier_output.json','vertex_loss_verifier_output.json']
def sha(p):return hashlib.sha256((W/p).read_bytes()).hexdigest()
cert={'scope':'12V/20F, c=0, D=15 combinatorial preclassification','closed_pseudomanifolds_fixed_facet':19176,'valid_cs_3_spheres_fixed_facet':4200,'sphere_f_vector':[12,42,60,30],'sphere_orbit_count':5,'sphere_fixed_facet_orbit_sizes':sphere_sizes,'sphere_canonical_representatives':sphere_reps,'bistellar_comparison':move,'merge_summary':raw['sphere_summary'],'local_matching_representatives':raw['local_representatives'],'global_pairing_templates':len(keys),'minor_classification':dict(cc),'survivor_indices':surv,'vertex_loss_indices':[44,342],'closed_positive_indices':[240],'remaining_survivor_indices':[i for i in surv if i not in (44,342,240)],'fifth_sphere_exclusive_templates':len(exclusive5),'fifth_sphere_exclusive_classification':dict(Counter(classes[i] for i in exclusive5)),'fifth_sphere_exclusive_survivors':[i for i in exclusive5 if classes[i]=='SURV'],'hashes':{f:sha(f) for f in files}}
json.dump(cert,open(W/'preclassification_certificate.json','w'),indent=2);print(json.dumps(cert,indent=2))
