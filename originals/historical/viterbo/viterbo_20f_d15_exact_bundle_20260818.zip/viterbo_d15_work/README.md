# Replay instructions

Required: Python 3 with `sympy`, `numpy`, `scipy`; C++17 compiler.

The full pipeline is recorded in the source files in this directory. The principal outputs are:

- `preclassification_certificate.json`
- `preclassification_verifier_output.json`
- `family240_certificate.json`
- `family240_verifier_output.json`
- `vertex_loss_verifier_output.json`

Run the lightweight exact checks:

```bash
python vertex_loss_verifier.py
python family240_verifier.py
python build_preclassification_certificate.py
python preclassification_verifier.py
```

To regenerate the combinatorial search from scratch, compile and run `enumerate_spheres.cpp`, then run `filter_spheres.py`, `canon_spheres.cpp`, `preclass_all5.py`, `canon_templates.cpp`, and `classify_minors.cpp` in that order. `compare_bistellar_generation.py` verifies that one symmetric bistellar-move pair produces only four of the five directly enumerated sphere types.
