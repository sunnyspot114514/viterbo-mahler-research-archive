#!/usr/bin/env python3
import sympy as sp,json
from itertools import product
from math import comb
from pathlib import Path
W=Path(__file__).resolve().parent;C=json.load(open(W/'family240_certificate.json'))
U,V,R=sp.symbols('U V R');loc={'U':U,'V':V,'R':R};vars=(U,V,R)
def parse(x):return sp.sympify(x,locals=loc)
def bern(poly):
 P=sp.Poly(sp.expand(poly),*vars);degs=P.degree_list();co=dict(P.terms());out=[]
 for ii in product(*[range(d+1) for d in degs]):
  z=sp.Rational(0)
  for kk,c in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(degs):f*=sp.Rational(comb(ii[j],kk[j]),comb(d,kk[j]))
    z+=c*f
  out.append(sp.factor(z))
 return degs,out
def positive(poly):
 d,b=bern(poly);return d,b,not any(x<0 for x in b) and any(x>0 for x in b)
# Parse completed pairing matrix and check rank=4 by exact Schur complement.
M=sp.Matrix([[parse(x) for x in row] for row in C['completed_matrix']]);rs=C['pivot_rows'];cs=C['pivot_cols'];P=M.extract(rs,cs)
assert P.det()==C['pivot_det']
ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs]
assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
# The only nonconstant denominator factors are K and H; both are positive in the open cube.
K=parse(C['K']);H=parse(C['H'])
for z in (K,H):assert positive(z)[2]
# Strict defect certificates.
def_stats={}
for name,z in C['defects'].items():
 n=parse(z['numerator']);d=parse(z['denominator']);deg,b,ok=positive(n);assert ok
 # denominator is 1, K^2, or H^2
 assert sp.factor(d) in (1,sp.factor(K*K),sp.factor(H*H))
 def_stats[name]=(deg,sum(1 for x in b if x>0),sum(1 for x in b if x==0),str(min(x for x in b if x>0)))
# Each oriented determinant term is positive throughout the cube.
def check_terms(strings):
 out=[]
 for st in strings:
  z=parse(st);n,d=map(sp.factor,sp.together(z).as_numer_denom());assert positive(n)[2];assert sp.factor(d) in (1,K,H)
  out.append(z)
 return out
pterms=check_terms(C['oriented_primal_terms']);qterms=check_terms(C['oriented_polar_terms'])
volP=parse(C['volume_P']);volQ=parse(C['volume_polar'])
assert sp.factor(sum(pterms)/24-volP)==0
assert sp.factor(sum(qterms)/24-volQ)==0
# Mahler lower bound. The +2T term in |P^o| is positive, so it suffices to prove G>0.
p=U;q=(1-U)*V;S=sp.factor(p+q);T=sp.factor(p*q);G=parse(C['G']);degG,bG,ok=positive(G);assert ok
Q0=sp.factor(4*(12*R+(1-R)*(11*S-3*S**2))/(3*K))
assert sp.factor(volP*Q0-sp.Rational(32,3)-2*S*(1-R)*G/(9*K*H))==0
out={'status':'PASS','template_index':240,'rank':4,'strict_defects':len(def_stats),'primal_tetrahedra':len(C['primal_tetrahedra']),'polar_facet_tetrahedra':len(C['polar_facet_tetrahedra']),'G_degree':degG,'G_positive':sum(1 for x in bG if x>0),'G_zero':sum(1 for x in bG if x==0),'G_min_positive':str(min(x for x in bG if x>0)),'conclusion':'Mahler product > 32/3 on the full strict domain'}
json.dump(out,open(W/'family240_verifier_output.json','w'),indent=2);print(json.dumps(out,indent=2))
