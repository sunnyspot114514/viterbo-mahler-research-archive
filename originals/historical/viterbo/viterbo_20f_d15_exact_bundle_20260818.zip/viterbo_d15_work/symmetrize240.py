import sympy as s
p,q,r,S,T=s.symbols('p q r S T')
# paste numerator inside volP from output
N=2*p**3*r**2-4*p**3*r+2*p**3+6*p**2*q*r**2-12*p**2*q*r+6*p**2*q-3*p**2*r**2+2*p**2*r+p**2+6*p*q**2*r**2-12*p*q**2*r+6*p*q**2-6*p*q*r**2+4*p*q*r+2*p*q+p*r**2+8*p*r-9*p+2*q**3*r**2-4*q**3*r+2*q**3-3*q**2*r**2+2*q**2*r+q**2+q*r**2+8*q*r-9*q-4*r
res=s.symmetrize(N,[p,q], formal=True)
print(res)
print('subst',s.factor(res[0].subs({res[2][0]:S,res[2][1]:T})))
