#!/usr/bin/env python3
import sympy as sp,json
from pathlib import Path
W=Path(__file__).resolve().parent;keys=(W/'unique_templates.txt').read_text().splitlines()
def symbolic_matrix(idx):
 k=keys[idx];M=[]
 for i in range(10):
  row=[]
  for j in range(6):
   z=int(k[6*i+j])-1;row.append(sp.symbols(f'x{i}_{j}') if z==0 else sp.Integer(z))
  M.append(row)
 return sp.Matrix(M)
# Orbit 44: exact rank-four branch with free a=x7_2,b=x8_4,r=x6_0.
a,b,r=sp.symbols('a b r');D=a*b+a+b-3
sol={
sp.symbols('x0_0'):(a*b*r+3*a*r-2*a-b*r+2*b-3*r)/D,
sp.symbols('x0_1'):(a*b+5*a-3*b-3)/D,
sp.symbols('x1_0'):(a*b*r+a*r-b*r+2*b-r-2)/D,
sp.symbols('x1_1'):(a*b+a-3*b+1)/D,
sp.symbols('x2_0'):(a*b*r+a*r-b*r+2*b-r-2)/D,
sp.symbols('x2_1'):(a*b+a-3*b+1)/D,
sp.symbols('x3_0'):-(a*b*r-a*r+2*a+b*r-r-2)/D,
sp.symbols('x3_1'):-(a*b-3*a+b+1)/D,
sp.symbols('x4_0'):r,sp.symbols('x5_0'):r,sp.symbols('x6_0'):r,
sp.symbols('x6_2'):(2*a-b-1)/(b-1),sp.symbols('x7_2'):a,sp.symbols('x8_4'):b,sp.symbols('x9_5'):b}
M44=symbolic_matrix(44).subs(sol);rs=[0,1,2,3];cs=[2,3,4,5];P=M44.extract(rs,cs);assert P.det()==-8
ri=[i for i in range(10) if i not in rs];cj=[0,1];assert all(sp.factor(x)==0 for x in M44.extract(ri,cj)-M44.extract(ri,cs)*P.inv()*M44.extract(rs,cj))
V44=sp.simplify(P.inv()*M44.extract(rs,range(6)));e2=sp.Matrix([0,1,0,0])
assert all(sp.factor(x)==0 for x in V44[:,0]+(1-r)/2*V44[:,1]+(1+r)/2*e2)
# Thus for |r|<1, v0 lies in relint[-v1,-e2].
# Orbit 342: Schur equations force x0_1=x1_1=t.
M342=symbolic_matrix(342);rs2=[0,1,2,4];cs2=[2,3,4,5];P2=M342.extract(rs2,cs2);assert P2.det()==-8
ri2=[i for i in range(10) if i not in rs2];cj2=[0,1];Sch=list(M342.extract(ri2,cj2)-M342.extract(ri2,cs2)*P2.inv()*M342.extract(rs2,cj2))
t0=sp.symbols('x0_1');t1=sp.symbols('x1_1');assert any(sp.factor(x)==t0-t1 or sp.factor(x)==t1-t0 for x in Sch)
t=sp.symbols('t');V342=sp.simplify(P2.inv()*M342.extract(rs2,range(6))).subs({t0:t,t1:t});e1=sp.Matrix([1,0,0,0]);e22=sp.Matrix([0,1,0,0])
assert all(sp.factor(x)==0 for x in V342[:,1]-(1-t)/2*(-e1)-(1+t)/2*(-e22))
out={'status':'PASS','orbit_44':{'relation':'v0=(1-r)/2*(-v1)+(1+r)/2*(-e2)','strict_weight_condition':'-1<r<1','conclusion':'at most 10 primal vertices'},'orbit_342':{'rank_forces':'x0_1=x1_1=t','relation':'v1=(1-t)/2*(-e1)+(1+t)/2*(-e2)','strict_weight_condition':'-1<t<1','conclusion':'at most 10 primal vertices'}}
json.dump(out,open(W/'vertex_loss_verifier_output.json','w'),indent=2);print(json.dumps(out,indent=2))
