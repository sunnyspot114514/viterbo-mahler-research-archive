import sympy as s
from itertools import combinations
from pathlib import Path
W=Path(__file__).resolve().parent;idx=44;k=(W/'unique_templates.txt').read_text().splitlines()[idx]
A=[];vars=[]
for i in range(10):
 row=[]
 for j in range(6):
  z=int(k[6*i+j])-1
  if z==0:v=s.symbols(f'x{i}_{j}');vars.append(v);row.append(v)
  else:row.append(s.Integer(z))
 A.append(row)
A=s.Matrix(A);rs=[0,1,2,3];cs=[2,3,4,5];ri=[i for i in range(10) if i not in rs];cj=[0,1]
eq=list(A.extract(ri,cj)-A.extract(ri,cs)*A.extract(rs,cs).inv()*A.extract(rs,cj))
r=s.symbols('r');a=s.symbols('a');b=s.symbols('b')
free={s.symbols('x6_0'):r,s.symbols('x7_2'):a,s.symbols('x8_4'):b}
eq=[s.factor(e.subs(free)) for e in eq]
deps=[v for v in vars if v not in free]
print('deps',len(deps),deps)
sol=s.solve(eq,deps,dict=True,simplify=False,check=False)
print('n',len(sol))
for ss in sol:
 print('---')
 for v in deps:print(v,s.factor(ss[v]))
