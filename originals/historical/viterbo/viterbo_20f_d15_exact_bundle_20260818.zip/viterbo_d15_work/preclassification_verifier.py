#!/usr/bin/env python3
from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib
W=Path(__file__).resolve().parent;C=json.load(open(W/'preclassification_certificate.json'))
# Exact recorded sets/counts.
assert sum(1 for _ in open(W/'sphere_solutions.txt'))==C['closed_pseudomanifolds_fixed_facet']==19176
assert sum(1 for _ in open(W/'valid_spheres.txt'))==C['valid_cs_3_spheres_fixed_facet']==4200
orbits=(W/'sphere_orbits.txt').read_text().splitlines();assert len(orbits)==5
sizes=[int(l.split(':')[0].split()[1]) for l in orbits];assert sizes==C['sphere_fixed_facet_orbit_sizes'] and sum(sizes)==4200
raw=json.load(open(W/'raw_templates.json'));assert raw['local_representatives']==1044==C['local_matching_representatives'];assert len(raw['sphere_summary'])==5
keys=(W/'unique_templates.txt').read_text().splitlines();assert len(keys)==748==C['global_pairing_templates']
cls=Counter();surv=[]
for l in open(W/'minor_classification.txt'):
 p=l.split();cls[p[1]]+=1
 if p[1]=='SURV':surv.append(int(p[0]))
assert dict(cls)==C['minor_classification']=={'RANK':669,'DUP':51,'SURV':28};assert surv==C['survivor_indices']
# Reconstruct source map and fifth-sphere-exclusive correction.
canon={int(a):b for a,b in (l.split() for l in open(W/'canonicalized_templates.txt'))};idx={k:i for i,k in enumerate(keys)};src=defaultdict(list)
for rid,r in enumerate(raw['records']):src[idx[canon[rid]]].append(r['sphere'])
exclusive=[i for i,v in src.items() if set(v)=={4}];assert len(exclusive)==104
classes={int(l.split()[0]):l.split()[1] for l in open(W/'minor_classification.txt')}
assert Counter(classes[i] for i in exclusive)==Counter({'RANK':90,'DUP':9,'SURV':5})
assert sorted(i for i in exclusive if classes[i]=='SURV')==sorted(C['fifth_sphere_exclusive_survivors'])
# Bistellar comparison and analytic subcertificates.
move=json.load(open(W/'bistellar_comparison_output.json'));assert move['move_generated_global_types']==4 and move['direct_exact_types']==5 and move['missing_direct_type_indices']==[4]
assert json.load(open(W/'vertex_loss_verifier_output.json'))['status']=='PASS'
assert json.load(open(W/'family240_verifier_output.json'))['status']=='PASS'
# Hash integrity.
for f,h in C['hashes'].items():assert hashlib.sha256((W/f).read_bytes()).hexdigest()==h
out={'status':'PASS','sphere_types':5,'pairing_templates':748,'rank_ge_5':669,'duplicate_rows':51,'algebraic_survivors':28,'vertex_loss_closed':2,'positive_family_closed':1,'remaining_survivors':25}
json.dump(out,open(W/'preclassification_verifier_output.json','w'),indent=2);print(json.dumps(out,indent=2))
