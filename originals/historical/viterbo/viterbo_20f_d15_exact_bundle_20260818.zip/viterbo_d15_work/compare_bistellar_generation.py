#!/usr/bin/env python3
import sys,itertools,json
from pathlib import Path
from collections import defaultdict
from itertools import combinations
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W))
import viterbo_20f_d16_preclassifier as d16
def anti(F):return frozenset(-x for x in F)
def tinc(fs):
 d=defaultdict(list)
 for F in fs:
  for T in combinations(F,3):d[frozenset(T)].append(F)
 return d
def edges(fs):return {frozenset(e) for F in fs for e in combinations(F,2)}
def moves(fs):
 inc=tinc(fs);E=edges(fs)
 for T,FF in inc.items():
  if len(FF)!=2:continue
  F1,F2=FF;a=next(iter(F1-T));b=next(iter(F2-T))
  if a!=-b and frozenset((a,b)) not in E:yield T,a,b,F1,F2
def symmove(fs,m):
 T,a,b,F1,F2=m;old={F1,F2,anti(F1),anti(F2)}
 if len(old)<4:return None
 out=set(fs)-old
 for e in combinations(T,2):out.add(frozenset((a,b)+e))
 for e in combinations(anti(T),2):out.add(frozenset((-a,-b)+e))
 return out if len(out)==30 else None
def can(fs,acts):
 best=None
 for mp in acts:
  z=tuple(sorted(tuple(sorted(mp[x] for x in F)) for F in fs))
  if best is None or z<best:best=z
 return best
# reconstruct direct sphere types
def norm(a):
 a=tuple(a)
 for x in a:
  if x:return tuple(-y for y in a) if x<0 else a
 return a
fac=[];seen=set()
for mask in range(64):
 if mask.bit_count()!=4:continue
 inds=[i for i in range(6) if mask>>i&1]
 for ss in itertools.product((-1,1),repeat=4):
  a=[0]*6
  for i,s in zip(inds,ss):a[i]=s
  a=norm(a)
  if a not in seen:seen.add(a);fac.append(a)
fac.sort()
def Frow(r):return frozenset((i+1 if x>0 else -(i+1)) for i,x in enumerate(r) if x)
direct=[]
for line in open(W/'sphere_orbits.txt'):
 ids=map(int,line.split(':',1)[1].split());fs=set()
 for i in ids:
  F=Frow(fac[i]);fs.add(F);fs.add(anti(F))
 direct.append(fs)
acts=list(d16.vertex_actions());direct_can=[can(fs,acts) for fs in direct]
move_types={};raw=0
for kind in ('h1','h2','new'):
 fs=d16.make_complex(kind);seenT=set()
 for m in moves(fs):
  T=m[0];k=tuple(sorted((tuple(sorted(T)),tuple(sorted(anti(T))))))
  if k in seenT:continue
  seenT.add(k);nf=symmove(fs,m)
  if nf is not None:raw+=1;move_types.setdefault(can(nf,acts),[]).append((kind,tuple(sorted(T))))
matched=[i for i,c in enumerate(direct_can) if c in move_types];missing=[i for i,c in enumerate(direct_can) if c not in move_types]
out={'symmetric_move_raw_results':raw,'move_generated_global_types':len(move_types),'direct_exact_types':len(direct),'matched_direct_type_indices':matched,'missing_direct_type_indices':missing}
json.dump(out,open(W/'bistellar_comparison_output.json','w'),indent=2);print(json.dumps(out,indent=2))
