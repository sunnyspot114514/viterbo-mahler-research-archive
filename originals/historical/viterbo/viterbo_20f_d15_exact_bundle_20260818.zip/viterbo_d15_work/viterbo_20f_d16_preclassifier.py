#!/usr/bin/env python3
"""Exact finite preclassifier for the 20-facet, D=16, g2=2 layer.

It reconstructs the three two-symmetric-stacking spheres, enumerates all
admissible antipodal four-ridge matchings, quotients by automorphisms and B6,
and checks exact sign-definite 5x5-minor certificates.  The final 14
algebraic survivors are deliberately left open.
"""
from itertools import product, permutations, combinations
from collections import defaultdict
import json,time

# vertices are +/-1,...,+/-6; facets frozensets of 4 signed ints

def antipode_face(F): return frozenset(-v for v in F)

def cross_facets():
    return {frozenset((s[0]*1,s[1]*2,s[2]*3,s[3]*4)) for s in product((-1,1), repeat=4)}

def stack_pair(facets,F,newidx):
    F=frozenset(F); Fn=antipode_face(F)
    assert F in facets and Fn in facets
    out=set(facets);out.remove(F);out.remove(Fn)
    for v in F: out.add(frozenset((set(F)-{v})|{newidx}))
    for v in Fn: out.add(frozenset((set(Fn)-{v})|{-newidx}))
    assert len(out)==len(facets)+6
    return out

def make_complex(kind):
    fs=cross_facets();F=frozenset((1,2,3,4));fs=stack_pair(fs,F,5)
    if kind=='h1': G=frozenset((-1,2,3,4))
    elif kind=='h2': G=frozenset((-1,-2,3,4))
    elif kind=='new': G=frozenset((5,2,3,4))
    else:raise ValueError
    fs=stack_pair(fs,G,6)
    assert len(fs)==28 and all(antipode_face(f) in fs for f in fs)
    return fs

def vertex_actions():
    for perm in permutations(range(1,7)):
      for flips in product((-1,1),repeat=6):
        mp={}
        for i in range(1,7):
            mp[i]=flips[i-1]*perm[i-1];mp[-i]=-mp[i]
        yield mp

def automorphisms(facets):
    fset=set(facets); out=[]
    for mp in vertex_actions():
        if {frozenset(mp[v] for v in f) for f in fset}==fset:out.append(mp)
    return out

def dual_data(facets):
    flist=sorted(facets,key=lambda f:tuple(sorted(f)))
    idx={f:i for i,f in enumerate(flist)}
    anti=[idx[antipode_face(f)] for f in flist]
    edges=[]
    for i,j in combinations(range(len(flist)),2):
        if len(flist[i]&flist[j])==3:edges.append((i,j))
    assert len(edges)==56
    eindex={e:k for k,e in enumerate(edges)}
    pairseen=set();epairs=[]
    for e in edges:
        ae=tuple(sorted((anti[e[0]],anti[e[1]])))
        key=tuple(sorted((e,ae)))
        if key in pairseen:continue
        pairseen.add(key);epairs.append(key)
    assert len(epairs)==28
    # Only ridge pairs whose merged five-vertex face contains no antipodal
    # vertex pair can be facets of a centrally symmetric polytope.
    good=[]
    for pair in epairs:
        e1,e2=pair
        F=flist[e1[0]]|flist[e1[1]]
        if not any(i in F and -i in F for i in range(1,7)):
            good.append(pair)
    epairs=good
    supports=[frozenset(e1+e2) for e1,e2 in epairs]
    assert all(len(s)==4 for s in supports)
    return flist,idx,anti,edges,epairs,supports

def enumerate_matchings(epairs,supports,k=4):
    # backtracking all k compatible epair indices
    out=[]
    def rec(start,chosen,used):
        if len(chosen)==k:
            out.append(tuple(chosen));return
        # enough remaining
        for i in range(start,len(epairs)):
            if supports[i].isdisjoint(used):
                rec(i+1,chosen+[i],used|supports[i])
    rec(0,[],frozenset())
    return out

def matching_actions(autos,flist,idx,epairs):
    epkey={pair:i for i,pair in enumerate(epairs)}
    acts=[]
    for mp in autos:
        fmap=[idx[frozenset(mp[v] for v in f)] for f in flist]
        arr=[]
        for e1,e2 in epairs:
            ne1=tuple(sorted((fmap[e1[0]],fmap[e1[1]])))
            ne2=tuple(sorted((fmap[e2[0]],fmap[e2[1]])))
            arr.append(epkey[tuple(sorted((ne1,ne2)))])
        acts.append(tuple(arr))
    return acts

def matching_orbits(matchings,acts):
    unseen=set(matchings); reps=[]; sizes=[]
    while unseen:
        m=min(unseen);orb={tuple(sorted(act[i] for i in m)) for act in acts}
        orb &= unseen
        unseen-=orb
        reps.append(m);sizes.append(len(orb))
    return reps,sizes

def row_from_face(F):
    row=[]
    for i in range(1,7):
        if i in F:row.append(1)
        elif -i in F:row.append(-1)
        else:row.append(0)
    # projective normalize first nonzero positive
    first=next(x for x in row if x)
    if first<0:row=[-x for x in row]
    return tuple(row)

def sign_template(flist,anti,epairs,matching):
    consumed=set();faces=[]
    for pi in matching:
        e1,e2=epairs[pi]
        # choose first dual edge and union; antipode is second union
        F=flist[e1[0]]|flist[e1[1]]
        faces.append(frozenset(F)); consumed.update(e1);consumed.update(e2)
    for i,F in enumerate(flist):
        if i in consumed:continue
        if i<anti[i]:faces.append(F)
    assert len(faces)==10
    rows=tuple(sorted(row_from_face(F) for F in faces))
    assert sorted(sum(x==0 for x in r) for r in rows)==[1]*4+[2]*6
    return rows

def B6_row_actions():
    acts=[]
    for perm in permutations(range(6)):
      for flips in product((-1,1),repeat=6):
        acts.append((perm,flips))
    return acts

def canonical_template(rows,acts):
    best=None
    for perm,flips in acts:
        rr=[]
        for row in rows:
            t=[0]*6
            for k in range(6):t[perm[k]]=flips[k]*row[k]
            first=next(x for x in t if x)
            if first<0:t=[-x for x in t]
            rr.append(tuple(t))
        cand=tuple(sorted(rr))
        if best is None or cand<best:best=cand
    return best


def det_bareiss(mat):
    a=[list(map(int,r)) for r in mat];n=len(a);sgn=1;prev=1
    for k in range(n-1):
        p=next((i for i in range(k,n) if a[i][k]),None)
        if p is None:return 0
        if p!=k:a[k],a[p]=a[p],a[k];sgn=-sgn
        piv=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):a[i][j]=(a[i][j]*piv-a[i][k]*a[k][j])//prev
        prev=piv
        for i in range(k+1,n):a[i][k]=0
    return sgn*a[-1][-1]

def verify_minor(rec):
    import numpy as np
    A=np.array(rec['rows'],dtype=int)
    rsel=rec['minor_certificate']['rows'];csel=rec['minor_certificate']['cols']
    B0=A[np.ix_(rsel,csel)].copy()
    loc=[(i,j) for i in range(5) for j in range(5) if B0[i,j]==0]
    vals=[]
    for bits in product((-1,1),repeat=len(loc)):
        B=B0.copy()
        for (i,j),z in zip(loc,bits):B[i,j]=z
        vals.append(det_bareiss(B.tolist()))
    assert vals==rec['minor_certificate']['corner_dets']
    assert ((all(x>=0 for x in vals) and any(x>0 for x in vals)) or
            (all(x<=0 for x in vals) and any(x<0 for x in vals)))

def main():
    import argparse
    from pathlib import Path
    parser=argparse.ArgumentParser()
    parser.add_argument('--certificate',type=Path,default=Path(__file__).with_name('viterbo_20f_d16_preclassifier_certificate.json'))
    args=parser.parse_args()
    cert=json.loads(args.certificate.read_text())
    bacts=B6_row_actions();alltemplates={};summary={}
    for kind in ('h1','h2','new'):
        fs=make_complex(kind);flist,idx,anti,edges,epairs,supports=dual_data(fs)
        autos=automorphisms(fs);ma=matching_actions(autos,flist,idx,epairs)
        ms=enumerate_matchings(epairs,supports,4)
        reps,sizes=matching_orbits(ms,ma)
        cans=[]
        for z,m in enumerate(reps):
            rows=sign_template(flist,anti,epairs,m)
            can=canonical_template(rows,bacts)
            cans.append(can);alltemplates.setdefault(can,[]).append((kind,m,sizes[z]))
        summary[kind]={'automorphisms':len(autos),'raw_matchings':len(ms),'matching_orbits':len(reps),'canonical_templates':len(set(cans))}
    certified={tuple(tuple(r) for r in rec['rows']) for rec in cert['records']}
    assert set(alltemplates)==certified
    assert len(alltemplates)==92==cert['raw_global_template_count']
    counts={'rank_ge_5':0,'duplicate_facet_rows':0,'algebraic_survivor':0}
    for rec in cert['records']:
        counts[rec['status']]+=1
        if rec['status']=='rank_ge_5':verify_minor(rec)
        elif rec['status']=='duplicate_facet_rows':
            from collections import Counter
            c=Counter(tuple(r) for r in rec['rows'])
            assert any(n>1 for n in c.values())
    assert counts=={'rank_ge_5':72,'duplicate_facet_rows':6,'algebraic_survivor':14}
    print(json.dumps({'status':'PASS','sphere_summary':summary,'global_templates':92,'classification':counts,
                      'algebraic_survivor_indices':cert['algebraic_survivor_indices']},indent=2,sort_keys=True))

if __name__=='__main__':main()
