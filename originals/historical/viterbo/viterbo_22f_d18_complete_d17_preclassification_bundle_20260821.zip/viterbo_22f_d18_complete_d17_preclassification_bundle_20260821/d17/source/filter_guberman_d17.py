import json,itertools
from pathlib import Path
from collections import Counter
W=Path('.')
data=json.load(open(W/'raw_templates_d17.json'))

def facets_from_rows(rows):
 out=[]
 for row in rows:
  f=frozenset((j+1 if x>0 else -(j+1)) for j,x in enumerate(row) if x)
  out.extend([f,frozenset(-v for v in f)])
 return list(dict.fromkeys(out))
def comb(rows):
 singles=[r.index(0) for r in rows if r.count(0)==1]
 mult=Counter(singles)
 vertex_ok=all(5-mult.get(j,0)>=3 for j in range(6))
 facets=facets_from_rows(rows);verts=sorted(set().union(*facets));edges=[]
 for a,b in itertools.combinations(verts,2):
  if a==-b:continue
  cont=[f for f in facets if a in f and b in f]
  if not cont:continue
  I=set(cont[0])
  for f in cont[1:]:I&=f
  if I=={a,b}:edges.append((a,b))
 deg={v:0 for v in verts}
 for a,b in edges:deg[a]+=1;deg[b]+=1
 high={v for v,d in deg.items() if d>=5}
 facet_high=[sum(v in high for v in f) for f in facets]
 return vertex_ok,all(x>=3 for x in facet_high),sorted(mult.values(),reverse=True),min(facet_high),deg
out=[];cnt=Counter();part=Counter()
for rec in data['records']:
 rows=rec['rows'];vok,fok,p,mh,deg=comb(rows);part[tuple(p)]+=1
 if not vok:cnt['vertex_fail']+=1
 elif not fok:cnt['facet_fail']+=1
 else:cnt['pass']+=1;out.append(rec)
json.dump({'sphere_summary':data['sphere_summary'],'input':len(data['records']),'classification':dict(cnt),'partition_counts':{str(k):v for k,v in part.items()},'records':out},open(W/'raw_templates_d17_guberman.json','w'),separators=(',',':'))
with open(W/'raw_templates_d17_guberman.txt','w') as f:
 for i,rec in enumerate(out):f.write(str(i)+' '+''.join(str(x+1) for row in rec['rows'] for x in row)+'\n')
print(json.dumps({'input':len(data['records']),'classification':dict(cnt),'passing':len(out),'partitions':{str(k):v for k,v in part.items()}},indent=2))
