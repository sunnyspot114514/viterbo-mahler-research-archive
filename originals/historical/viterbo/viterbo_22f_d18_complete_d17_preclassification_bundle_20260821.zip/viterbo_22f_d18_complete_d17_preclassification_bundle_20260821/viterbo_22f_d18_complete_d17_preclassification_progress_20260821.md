# 四维中心对称 Mahler：22F 的 D=18 整层关闭与 D=17 精确预分类

日期：2026-08-21

## 结论摘要

本轮完成了两项推进：

1. `12V/22F, c=0, D=18` 的最后七个连续 family 全部获得 exact rank、完整严格域、顶点/面闭包、精确体积和 Bernstein 正性证书；因此 D=18 整层关闭为 computer-assisted analytic proof candidate。
2. `12V/22F, c=0, D=17` 复用已经直接枚举并验核的 15 个 `g2=6` 中心对称三维球轨道，完成五对 ridge merges、Guberman 必要条件筛选、全局 `B6` canonicalization 和 exact minor 预分类；最终压缩到 121 个 algebraic survivors。

所有勾号均表示 **computer-assisted analytic proof candidate**。它们尚未经过外部同行审阅，也不等于完整四维 symmetric Mahler 猜想已经解决。

---

# 一、D=18 已整层关闭

D=18 的精确预分类为

\[
62
=
13\text{ 个违反 Guberman facet 条件}
+34\text{ 个 rank}\ge5
+1\text{ 个 primal pair 重复}
+1\text{ 个 incident facets 不足}
+13\text{ 个 algebraic survivors}.
\]

此前已经关闭：

\[
20,\ 27,\ 32,\ 34,\ 67,\ 69.
\]

本轮新关闭：

\[
\boxed{28,\ 29,\ 33,\ 43,\ 49,\ 51,\ 71}.
\]

所以最终 accounting 为

\[
\boxed{
62
=
13+34+1+1+13\text{ 个 Mahler-positive families}
}
\]

且没有剩余分支。

## 七个新 family 的严格参数域

以下均使用自由 defect 的 affine unit variables `A,B,C,D in (0,1)`。

### Family 28

\[
0<B,C<1,
\qquad
0<D<U_D,
\qquad
0<A<U_A,
\]

其中

\[
U_D=\frac{1-C+BC}{2-B-C+BC},
\qquad
U_A=\frac{D(1-B)}{1-BD}.
\]

单一开立方体 chart：

\[
B=X,\quad C=Y,\quad D=U_D Z,\quad A=U_A T.
\]

### Family 29

\[
0<B,C<1,
\qquad
0<D<C,
\qquad
0<A<U(B,C,D),
\]

其中

\[
U=
\frac{(C-1)(BD-B-D)}
{BCD-BC-BD+B-CD+1}.
\]

单一 chart：

\[
B=X,\quad C=Y,\quad D=YZ,\quad A=UT.
\]

### Family 33

严格域由 `B=C` 分成两个对称开 chart 与公共墙。

定义

\[
U_1=
\frac{(1-B)(C+D-CD)}{(1-B)(C+D-CD)+(1-C)(1-D)},
\]

\[
U_2=
\frac{(1-C)(B+D-BD)}{(1-C)(B+D-BD)+(1-B)(1-D)}.
\]

则：

- `B<C`：`0<A<U2`；
- `B>C`：`0<A<U1`；
- `B=C`：两个上界一致。

三个 chart 的 primal/polar volume 公式精确相同。

### Family 43

\[
0<B,C<1,
\qquad
L_D<D<U_D,
\qquad
L_A<A<U_A,
\]

其中

\[
L_D=\frac{B(1-C)}{1-BC},
\qquad
U_D=\frac{B(1-C)+C}{1+C(1-B)},
\]

\[
L_A=\frac{B(1-C)}{1+B(1-C)},
\qquad
U_A=\frac{D(1-B)}{1-BD}.
\]

并且 `U_A(L_D)=L_A`，所以可按先选 `D`、再选 `A` 的 nested interval 双射到开四立方体。

### Family 49

定义

\[
K=1-C+BC,
\quad
J=1+BC,
\quad
L=2-B-C+BC,
\quad
H=2-C+BC,
\]

\[
A_0=\frac KH,
\qquad
U_A=\frac KJ,
\]

\[
L_1(A)=\frac{AC}{1-A+AC},
\quad
U_3(A)=\frac{A}{1-B+AB},
\quad
U_4=\frac KL.
\]

完整域：

\[
0<B,C<1,
\qquad
0<A<U_A,
\qquad
L_1(A)<D<\min\{U_3(A),U_4\}.
\]

两个上界在 `A=A0` 切换，因此使用 low/high 两个 chart 和公共墙。

### Family 51

\[
0<B,C<1,
\qquad
0<D<\frac{C(1-B)}{1+C(1-B)},
\]

\[
0<A<\frac{B(1-C)}{1+B(1-C)}.
\]

这是单一 nested open-cube chart。

### Family 71

\[
0<B,D<1,
\qquad
1-BD<C<1,
\qquad
\frac{D}{C+D}<A<1.
\]

单一 chart：

\[
B=X,\quad D=Y,\quad C=1-XY+XYZ,
\]

\[
A=\frac{D}{C+D}+\left(1-\frac{D}{C+D}\right)T.
\]

## Mahler-margin 证书

| Family | Charts | Primal tets | Polar tets | 最大 numerator degree | 正 / 零 / 负 | 最小正系数 |
|---:|---|---:|---:|---|---:|---:|
| 28 | 1 | 35 | 77 | `(10,9,5,2)` | 973 / 1007 / 0 | `4/675` |
| 29 | 1 | 32 | 74 | `(4,11,6,2)` | 835 / 425 / 0 | `1/550` |
| 33 | 2+wall | 32 | 75 | `(9,6,7,3)` | 856 / 1384 / 0 | `2/11025` |
| 43 | 1 | 35 | 75 | `(15,15,6,3)` | 5112 / 2056 / 0 | `8/4729725` |
| 49 | 2+wall | 35 | 75 | `(18,21,6,3)` | 9569 / 2135 / 0 | `256/305235` |
| 51 | 1 | 34 | 74 | `(10,10,3,3)` | 897 / 1039 / 0 | `4/8505` |
| 71 | 1 | 34 | 77 | `(9,10,6,2)` | 1787 / 523 / 0 | `4/405` |

所有 margin denominators 也都获得无负 Bernstein 系数且至少一项严格为正的证书。每个 family 均保持

\[
f_0(P)=12,
\qquad
f_0(P^\circ)=22,
\]

并严格满足

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

因此：

\[
\boxed{12V/22F,\quad c=0,\quad D=18\quad\checkmark}.
\]

---

# 二、D=17 的完整有限预分类

D=17 对应

\[
5\text{ 条 single-defect rows}
+
6\text{ 条 double-defect rows}.
\]

三角化后仍为

\[
f=(12,44,64,32),
\qquad
g_2=6.
\]

因此可以复用此前通过直接枚举得到的全部 15 个 `g2=6` 中心对称三维球轨道，但重新进行五对 ridge merges。

## Ridge-merge 枚举

15 个球轨道一共产生

\[
\boxed{12,827\text{ 个 local matching representatives}}.
\]

## Guberman 必要条件筛选

对 bounded-class 局部 Mahler 极小者，复核后的四维必要条件为：

- 每个顶点至少属于 3 个非单纯 facets；
- 每个 facet 至少包含 3 个图度数至少 5 的顶点；
- cube/cross-polytope 例外不属于 genuine 12V 层。

12,827 个 local representatives 的精确分类：

\[
\boxed{
9571\text{ 个违反顶点条件}
+
225\text{ 个违反 facet 条件}
+
3031\text{ 个通过结构筛选}.
}
\]

## 全局 canonicalization 与 minor 分类

3031 个 local representatives 经完整 signed-coordinate group canonicalization 后得到

\[
\boxed{2395\text{ 个全局 pairing templates}}.
\]

exact multi-affine `5x5` minor corner certificates 给出：

\[
\boxed{
2395
=
2274\text{ 个 rank}\ge5
+
121\text{ 个 algebraic survivors}.
}
\]

Python/Bareiss 独立 verifier 已重算全部 2274 个 minor certificates，并重新检查 2395 个模板都满足经过审计的 Guberman 两项组合条件。验证结果：`PASS`。

所以 D=17 当前前沿是：

\[
\boxed{121\text{ 个 algebraic survivors}}.
\]

这一层尚未关闭。下一步需要优先扫描：

\[
\text{primal/polar vertex loss},
\quad
\text{forced extra section vertices},
\quad
\text{低维 rank components},
\]

然后只对 genuine continuous families 进入体积与 Bernstein 正性。

---

# 三、最新 bounded-12 证明树

\[
\boxed{
\begin{array}{c|c}
\text{层}&\text{状态}\\
\hline
c=1&\checkmark\\
c=0,\ 12V/12F&\checkmark\\
c=0,\ 12V/14F&\checkmark\\
c=0,\ 12V/16F&\checkmark\\
c=0,\ 12V/18F&\checkmark\\
c=0,\ 12V/20F&\checkmark\\
c=0,\ 12V/22F,\ D=19&\checkmark\ \text{bounded-class minimizer exclusion}\\
c=0,\ 12V/22F,\ D=18&\checkmark\\
c=0,\ 12V/22F,\ D=17&121\text{ survivors}
\end{array}}
\]

完整四维 symmetric Mahler 猜想仍未解决。即使整个 bounded-12 有限核心关闭，仍需证明不依赖 `f0,f3` 的 finite-core / bi-shadow-rigid reduction theorem，才能覆盖任意四维中心对称凸体。
