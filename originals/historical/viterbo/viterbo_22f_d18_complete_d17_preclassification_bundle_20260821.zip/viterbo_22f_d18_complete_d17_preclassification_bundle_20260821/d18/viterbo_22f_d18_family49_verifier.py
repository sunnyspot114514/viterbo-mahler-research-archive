#!/usr/bin/env python3
"""Exact verifier for canonical family 49 in the 12V/22F, c=0, D=18 layer.

The strict realization space has two rational charts separated by a codimension-one wall.
The verifier checks the unique rank-four completion, the exact domain reduction, all strict
defects, primal extremality, fixed facetwise triangulations, exact volumes, and Bernstein
positivity of the Mahler margin on both charts and the wall.
"""
import hashlib, itertools, json, math
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

SRC=Path('/mnt/data/viterbo_d18_work/viterbo_22f_d18_preclassification_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d18_family49_verifier_output.json')
CERT=Path('/mnt/data/viterbo_22f_d18_family49_certificate.json')
CID=49
D0=json.loads(SRC.read_text())
rec=next(r for r in D0['records'] if r['canonical_id']==CID)
rows=rec['rows']; key=rec['key']

# pairing matrix and unique rank-four branch
M0=sp.zeros(11,6); variables=[]
for i,row in enumerate(rows):
    for j,z in enumerate(row):
        if z==0:
            x=sp.symbols(f'x{i}_{j}'); M0[i,j]=x; variables.append(x)
        else: M0[i,j]=z
rr=[2,3,4,9]; cc=[2,3,4,5]
P=M0.extract(rr,cc); assert P.det()==8
orows=[i for i in range(11) if i not in rr]
Smat=M0.extract(orows,[0,1])-M0.extract(orows,cc)*P.inv()*M0.extract(rr,[0,1])
eq=[sp.factor(e) for e in list(Smat)]
free=tuple(M0[i,j] for i,j in [(4,0),(6,2),(8,5),(9,1)])
dep=[x for x in variables if x not in free]
sols=sp.solve(eq,dep,dict=True,simplify=False); assert len(sols)==1
sol={x:sp.factor(v) for x,v in sols[0].items()}
Mf=M0.subs(sol); assert all(sp.factor(e.subs(sol))==0 for e in eq)
Vf=P.inv()*Mf.extract(rr,range(6)); Ff=Mf.extract(range(11),cc)
a,b,c,d=free

# affine unit variables A=(a+1)/2 etc.
A,B,C,D=sp.symbols('A B C D')
base={a:2*A-1,b:2*B-1,c:2*C-1,d:2*D-1}
MAB=sp.simplify(Mf.subs(base)); VAB=sp.simplify(Vf.subs(base)); FAB=sp.simplify(Ff.subs(base))

# Exact domain reduction.
# In affine variables A=(a+1)/2,... the strict domain is
# 0<B,C<1, 0<A<UA, and L1(A)<D<min(U3(A),U4),
# where U3/U4 switch at A=A0.
K=1-C+B*C
J=1+B*C
L=2-B-C+B*C
H=2-C+B*C
A0=sp.factor(K/H)
UA=sp.factor(K/J)
L1=sp.factor(A*C/(1-A+A*C))
U3=sp.factor(A/(1-B+A*B))
U4=sp.factor(K/L)
assert sp.factor(UA-A0)==sp.factor((1-C)*K/(J*H))
assert sp.factor(U3-U4)==sp.factor((1-B)*(A*H-K)/((1-B+A*B)*L))
assert sp.factor(U3-L1)==sp.factor(A*(1-A)*K/((1-B+A*B)*(1-A+A*C)))
assert sp.factor(U4-L1)==sp.factor((K-A)/((1-A+A*C)*L))
# Since A<UA<K, both upper bounds lie strictly above L1.
U,T=sp.symbols('U T')
def ndpair(expr):
    return tuple(map(sp.factor,sp.together(expr).as_numer_denom()))
# low: A=A0*U and active upper U3
Alow=sp.factor(A0*U)
Dlow=sp.factor(L1.subs(A,Alow)+(U3.subs(A,Alow)-L1.subs(A,Alow))*T)
# high: A=A0+(UA-A0)U and active upper U4
Ahigh=sp.factor(A0+(UA-A0)*U)
Dhigh=sp.factor(L1.subs(A,Ahigh)+(U4-L1.subs(A,Ahigh))*T)
# wall
Awall=A0
Dwall=sp.factor(L1.subs(A,Awall)+(U4-L1.subs(A,Awall))*T)
charts={}
for name,Aexpr,Dexpr,vars_,sample_,desc in [
 ('low',Alow,Dlow,(B,C,U,T),{B:sp.Rational(2,5),C:sp.Rational(1,3),U:sp.Rational(1,2),T:sp.Rational(1,2)},'A=A0*U; D=L1+(U3-L1)T'),
 ('high',Ahigh,Dhigh,(B,C,U,T),{B:sp.Rational(2,5),C:sp.Rational(1,3),U:sp.Rational(1,2),T:sp.Rational(1,2)},'A=A0+(UA-A0)U; D=L1+(U4-L1)T'),
 ('wall',Awall,Dwall,(B,C,T),{B:sp.Rational(2,5),C:sp.Rational(1,3),T:sp.Rational(1,2)},'A=A0; D=L1+(U4-L1)T')]:
    NA,DA=ndpair(Aexpr); ND,DD=ndpair(Dexpr)
    charts[name]={'vars':vars_,'NA':NA,'DA':DA,'ND':ND,'DD':DD,'sample':sample_,'description':desc}
for ch in charts.values():
    ch['sub']={A:sp.factor(ch['NA']/ch['DA']),D:sp.factor(ch['ND']/ch['DD'])}

# Bernstein and sparse rational-chart composition.
def bern(poly,vs):
    p=sp.Poly(sp.expand(poly),*vs,domain='QQ')
    deg=tuple(map(int,p.degree_list())); terms=dict(p.terms()); cs=[]
    for beta in itertools.product(*[range(x+1) for x in deg]):
        val=sp.Rational(0)
        for alpha,co in terms.items():
            if all(alpha[j]<=beta[j] for j in range(len(vs))):
                w=sp.Rational(1)
                for j,dg in enumerate(deg):
                    w*=sp.Rational(math.comb(beta[j],alpha[j]),math.comb(dg,alpha[j]))
                val+=co*w
        cs.append(sp.factor(val))
    return deg,cs

compose_cache={}; bern_cache={}
def cleared_sub(poly,ch):
    """Substitute A=NA/DA,D=ND/DD and clear positive chart denominators."""
    poly=sp.Poly(sp.expand(poly),A,B,C,D,domain='QQ')
    cachekey=(sp.srepr(poly.as_expr()), ch['description'])
    if cachekey in compose_cache: return compose_cache[cachekey]
    da,db,dc,dd=map(int,poly.degree_list()); vs=ch['vars']
    NA,DA,ND,DD=ch['NA'],ch['DA'],ch['ND'],ch['DD']
    pNA=[sp.Poly(NA,*vs,domain='QQ')**i for i in range(da+1)]
    pDA=[sp.Poly(DA,*vs,domain='QQ')**i for i in range(da+1)]
    pND=[sp.Poly(ND,*vs,domain='QQ')**i for i in range(dd+1)]
    pDD=[sp.Poly(DD,*vs,domain='QQ')**i for i in range(dd+1)]
    pB=[sp.Poly(B,*vs,domain='QQ')**i for i in range(db+1)]
    pC=[sp.Poly(C,*vs,domain='QQ')**i for i in range(dc+1)]
    out=sp.Poly(0,*vs,domain='QQ')
    for (ia,ib,ic,id_),co in poly.terms():
        out += co*pNA[ia]*pDA[da-ia]*pB[ib]*pC[ic]*pND[id_]*pDD[dd-id_]
    compose_cache[cachekey]=out
    return out

def positive_poly_on_chart(poly,ch,label):
    cp=cleared_sub(sp.factor(poly),ch)
    key=(sp.srepr(cp.as_expr()),ch['vars'])
    if key not in bern_cache: bern_cache[key]=bern(cp.as_expr(),ch['vars'])
    deg,cs=bern_cache[key]; pos=[x for x in cs if x>0]; neg=[x for x in cs if x<0]
    assert not neg and pos,(label,deg,len(neg),str(cp.as_expr())[:300])
    return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos))}

def rational_positive_on_chart(expr,ch,label):
    """Prove a rational function positive by certifying every irreducible factor sign."""
    expr=sp.cancel(expr); num,den=map(sp.factor,sp.together(expr).as_numer_denom())
    sampleAB={A:sp.factor(ch['sub'][A].subs(ch['sample'])),B:ch['sample'][B],C:ch['sample'][C],D:sp.factor(ch['sub'][D].subs(ch['sample']))}
    assert expr.subs(sampleAB)>0
    result={'numerator_factors':[],'denominator_factors':[]}
    for part,name in [(num,'numerator_factors'),(den,'denominator_factors')]:
        coeff,factors=sp.factor_list(part,A,B,C,D)
        for fac,mult in factors:
            val=sp.factor(fac.subs(sampleAB)); assert val!=0
            sg=1 if val>0 else -1
            rec=positive_poly_on_chart(sg*fac,ch,label)
            rec.update({'factor':str(fac),'sign':sg,'multiplicity':mult})
            result[name].append(rec)
    return result

print('stage: rank/domain ready', flush=True)
# Positive chart denominators (required by the cleared-substitution logic).
chart_denominator_certificates={}
for name,ch in charts.items():
    recs=[]
    for label,poly in [('DA',ch['DA']),('DD',ch['DD'])]:
        deg,cs=bern(poly,ch['vars']); pos=[x for x in cs if x>0]; neg=[x for x in cs if x<0]
        assert not neg and pos,(name,label,deg,neg[:3])
        recs.append({'label':label,'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos))})
    chart_denominator_certificates[name]=recs

print('stage: chart denominators ready', flush=True)
# Facets and sample triangulations, separately for each chart.
code=np.array(rows,int); facP=[]; facQ=[]
for i in range(11):
    facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),
             sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
for j in range(6):
    facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),
             sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
def project3(points):
    delta=points-points[0]
    return delta@np.linalg.svd(delta,full_matrices=False)[2][:3].T
def pulling(ids,coords):
    ids=sorted(ids)
    if len(ids)==4:return [tuple(ids)]
    pr=project3(coords[ids]); h=ConvexHull(pr); out=set()
    for tri,e in zip(h.simplices,h.equations):
        if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8: continue
        out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
    return sorted(out)
def sphere(tets):
    tri=Counter(tuple(sorted(q)) for tet in tets for q in itertools.combinations(tet,3))
    assert set(tri.values())=={2}
    verts=set(i for tet in tets for i in tet); edges=set(tuple(sorted(e)) for tet in tets for e in itertools.combinations(tet,2))
    return {'vertices':len(verts),'edges':len(edges),'triangles':len(tri),'tetrahedra':len(tets)}
def balls(tets,facets):
    out=[]
    for fac in facets:
        group=[tet for tet in tets if set(tet)<=set(fac)]
        assert group and set(i for tet in group for i in tet)==set(fac)
        tri=Counter(tuple(sorted(q)) for tet in group for q in itertools.combinations(tet,3))
        bd=[q for q,n in tri.items() if n==1]; bv=set(i for q in bd for i in q); be=set(tuple(sorted(e)) for q in bd for e in itertools.combinations(q,2))
        assert len(bv)-len(be)+len(bd)==2
        out.append(len(group))
    return out

chart_records={}; chart_tets={}
print('stage: starting charts', flush=True)
for name,ch in charts.items():
    print(' chart',name,'start',flush=True)
    sub=ch['sub']; sample=ch['sample']; Mab=MAB.subs(sub); V=VAB.subs(sub); F=FAB.subs(sub)
    # strict defects
    defects={}
    for x in variables:
        i,j=map(int,str(x)[1:].split('_'))
        defects[str(x)]=rational_positive_on_chart(1-MAB[i,j]**2,ch,'defect '+str(x))
    # numerical vertices and triangulations
    vnum=np.array(V.subs(sample),float); fnum=np.array(F.subs(sample),float)
    ptsP=np.vstack([vnum.T,-vnum.T]); ptsQ=np.vstack([fnum,-fnum])
    assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
    tP=[tet for fac in facP for tet in pulling(fac,ptsP)]
    tQ=[tet for fac in facQ for tet in pulling(fac,ptsQ)]
    # extremality
    ext=[]
    for j in range(6):
        incident=[i for i in range(11) if rows[i][j]!=0]; found=None
        for r4 in itertools.combinations(incident,4):
            de=sp.factor(FAB.extract(r4,range(4)).det(method='domain-ge'))
            if de==0: continue
            sampleAB={A:sub[A].subs(sample),B:sample[B],C:sample[C],D:sub[D].subs(sample)}
            sg=1 if de.subs(sampleAB)>0 else -1
            try: cert=rational_positive_on_chart(sg*de,ch,f'ext vertex {j}')
            except AssertionError: continue
            found={'vertex_pair':j,'facet_rows':list(r4),'determinant':str(de),'certificate':cert}; break
        assert found; ext.append(found)
    # orientation certificates using each chart's own pulling triangulation
    def pP(i): return VAB[:,i] if i<6 else -VAB[:,i-6]
    def pQ(i): return FAB[i,:].T if i<11 else -FAB[i-11,:].T
    sampleAB={A:sub[A].subs(sample),B:sample[B],C:sample[C],D:sub[D].subs(sample)}
    orientations=[]
    for lab,tets,point in [('primal',tP,pP),('polar',tQ,pQ)]:
        for k,ids in enumerate(tets):
            de=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'))
            sg=1 if de.subs(sampleAB)>0 else -1
            cert=rational_positive_on_chart(sg*de,ch,f'{lab} tet {k}')
            orientations.append({'type':lab,'tetrahedron':list(ids),'determinant':str(de),'sign':sg,'certificate':cert})
    print(' chart',name,'done',len(tP),len(tQ),flush=True)
    chart_records[name]={'description':ch['description'],'strict_defects':defects,'extremality':ext,'primal_vertices':12,'polar_vertices':22,'primal_boundary':sphere(tP),'primal_facet_tetrahedra':balls(tP,facP),'polar_facet_tetrahedra':balls(tQ,facQ),'tetrahedra_primal':len(tP),'tetrahedra_polar':len(tQ),'orientation_records':orientations}
    chart_tets[name]=(tP,tQ,sampleAB)

print('stage: charts done',flush=True)
# Exact volumes in the original free-variable field; all three charts must agree.
field=sp.QQ.frac_field(*free)
def pPfree(i): return Vf[:,i] if i<6 else -Vf[:,i-6]
def pQfree(i): return Ff[i,:].T if i<11 else -Ff[i-11,:].T
def exact_volume(tets,point,sample_free):
    total=field.zero
    for ids in tets:
        de=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'))
        sg=1 if de.subs(sample_free)>0 else -1
        total += field.from_sympy(sg*de)
    return sp.factor(field.to_sympy(total/24))
volumes={}
print('stage: volumes start',flush=True)
for name,(tP,tQ,sampleAB) in chart_tets.items():
    sample_free={a:2*sampleAB[A]-1,b:2*sampleAB[B]-1,c:2*sampleAB[C]-1,d:2*sampleAB[D]-1}
    volumes[name]=(exact_volume(tP,pPfree,sample_free),exact_volume(tQ,pQfree,sample_free))
assert all(sp.factor(volumes[name][0]-volumes['low'][0])==0 and sp.factor(volumes[name][1]-volumes['low'][1])==0 for name in volumes)
volP,volQ=volumes['low']
marginAB=sp.factor(sp.cancel((volP*volQ-sp.Rational(32,3)).subs(base)))
print('stage: volumes done',flush=True)
# The margin polynomials are much larger than the orientation factors.  Use a
# custom sparse exact composition and a tensor-separable Bernstein transform.
from fractions import Fraction
import numpy as _np
from collections import defaultdict as _defaultdict

def _pdict(expr,vars_):
    pp=sp.Poly(sp.expand(expr),*vars_,domain='QQ')
    return {tuple(map(int,e)):Fraction(int(c.p),int(c.q)) for e,c in pp.terms()}
def _mul(p,q):
    if len(p)>len(q): p,q=q,p
    out=_defaultdict(Fraction)
    for e,c in p.items():
        for f,dv in q.items(): out[tuple(e[i]+f[i] for i in range(len(e)))]+=c*dv
    return {e:c for e,c in out.items() if c}
def _pow(p,n):
    dim=len(next(iter(p))); out={(0,)*dim:Fraction(1)}; base=p
    while n:
        if n&1: out=_mul(out,base)
        n//=2
        if n: base=_mul(base,base)
    return out
def _compose_cleared(poly,ch):
    pp=sp.Poly(sp.expand(poly),A,B,C,D,domain='QQ'); da,db,dc,dd=map(int,pp.degree_list()); tv=ch['vars']
    pNA,pDA,pND,pDD=[_pdict(z,tv) for z in (ch['NA'],ch['DA'],ch['ND'],ch['DD'])]
    NAps=[_pow(pNA,i) for i in range(da+1)]; DAps=[_pow(pDA,i) for i in range(da+1)]
    NDps=[_pow(pND,i) for i in range(dd+1)]; DDps=[_pow(pDD,i) for i in range(dd+1)]
    bases={(ia,id_):_mul(_mul(NAps[ia],DAps[da-ia]),_mul(NDps[id_],DDps[dd-id_])) for ia in range(da+1) for id_ in range(dd+1)}
    out={}
    for (ia,ib,ic,id_),co in pp.terms():
        scale=Fraction(int(co.p),int(co.q)); shift=(ib,ic)+(0,)*(len(tv)-2)
        for e,cv in bases[(ia,id_)].items():
            ee=tuple(e[k]+shift[k] for k in range(len(tv))); val=out.get(ee,Fraction(0))+scale*cv
            if val: out[ee]=val
            elif ee in out: del out[ee]
    return out
def _bern_dict(pd):
    deg=tuple(max(e[i] for e in pd) for i in range(len(next(iter(pd))))); arr=_np.empty(tuple(x+1 for x in deg),dtype=object); arr.fill(Fraction(0))
    for e,c in pd.items(): arr[e]=c
    for axis,n in enumerate(deg):
        aa=_np.moveaxis(arr,axis,0); oo=_np.empty_like(aa); rest=aa.shape[1:]; den=[math.comb(n,i) for i in range(n+1)]
        for idx in _np.ndindex(rest):
            line=[aa[(i,)+idx] for i in range(n+1)]
            for k in range(n+1):
                vv=Fraction(0)
                for i in range(k+1): vv += line[i]*Fraction(math.comb(k,i),den[i])
                oo[(k,)+idx]=vv
        arr=_np.moveaxis(oo,0,axis)
    return deg,arr.ravel().tolist()
def _fast_margin(ch):
    num,den=sp.together(marginAB).as_numer_denom(); result={}
    for lab,poly in [('numerator',num),('denominator',den)]:
        pd=_compose_cleared(poly,ch); center=sum(cv*Fraction(1,2)**sum(e) for e,cv in pd.items())
        if center<0: pd={e:-cv for e,cv in pd.items()}
        deg,cs=_bern_dict(pd); neg=[x for x in cs if x<0]; pos=[x for x in cs if x>0]
        assert not neg and pos,(lab,deg,len(neg))
        result[lab]={'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos)),'terms':len(pd)}
    return result
margin_certs={name:_fast_margin(ch) for name,ch in charts.items()}

print('stage: margin done',flush=True)
certificate={
 'status':'PASS','scope':'4D symmetric Mahler bounded-12, 12V/22F,c=0,D=18, family49','canonical_template':key,
 'rank':{'pivot_rows':rr,'pivot_cols':cc,'pivot_determinant':8,'free_variables':list(map(str,free)),'unique_solution':{str(k):str(v) for k,v in sol.items()}},
 'domain':{'A_B_C_D':'0<B,C<1, 0<A<UA, L1(A)<D<min(U3(A),U4)','threshold':'A0=(1-C+BC)/(2-C+BC)','low':'0<A<A0, upper=U3','high':'A0<A<UA, upper=U4','wall':'A=A0','charts':{k:v['description'] for k,v in charts.items()}},
 'chart_denominator_certificates':chart_denominator_certificates,'charts':chart_records,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(marginAB),'margin_certificates':margin_certs,
 'fixed_sign_polynomials':len(bern_cache),'conclusion':'Mahler product > 32/3 on the full strict realization space.'}
CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True,default=str))
hashv=hashlib.sha256(CERT.read_bytes()).hexdigest()
summary={
 'status':'PASS','canonical_family':49,'charts':['low','high','wall'],'primal_vertices':12,'polar_vertices':22,
 'tetrahedra':{k:{'primal':v['tetrahedra_primal'],'polar':v['tetrahedra_polar']} for k,v in chart_records.items()},
 'margin_certificates':margin_certs,
 'certificate':str(CERT),'certificate_sha256':hashv,'conclusion':certificate['conclusion']}
OUT.write_text(json.dumps(summary,indent=2,sort_keys=True,default=str))
print(json.dumps(summary,indent=2,sort_keys=True,default=str))
