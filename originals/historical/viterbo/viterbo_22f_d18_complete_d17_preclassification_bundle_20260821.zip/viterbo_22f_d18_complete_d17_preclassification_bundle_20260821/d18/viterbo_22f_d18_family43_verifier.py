#!/usr/bin/env python3
"""Exact verifier for canonical family 43 in 12V/22F,c=0,D=18."""
import hashlib,itertools,json,math
from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

SRC=Path('/mnt/data/viterbo_d18_work/viterbo_22f_d18_preclassification_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d18_family43_verifier_output.json')
CERT=Path('/mnt/data/viterbo_22f_d18_family43_certificate.json')
CID=43
D0=json.loads(SRC.read_text());rec=next(r for r in D0['records'] if r['canonical_id']==CID);rows=rec['rows'];key=rec['key']
M0=sp.zeros(11,6);variables=[]
for i,row in enumerate(rows):
 for j,z in enumerate(row):
  if z==0:
   x=sp.symbols(f'x{i}_{j}');M0[i,j]=x;variables.append(x)
  else:M0[i,j]=z
rr=[2,3,4,9];cc=[2,3,4,5];P=M0.extract(rr,cc);assert P.det()==8
orows=[i for i in range(11) if i not in rr];ocols=[j for j in range(6) if j not in cc]
Smat=M0.extract(orows,ocols)-M0.extract(orows,cc)*P.inv()*M0.extract(rr,ocols);eq=[sp.factor(e) for e in list(Smat)]
free=tuple(M0[i,j] for i,j in [(4,0),(6,2),(7,3),(9,1)]);dep=[x for x in variables if x not in free]
sols=sp.solve(eq,dep,dict=True,simplify=False,check=False);assert len(sols)==1
sol={x:sp.factor(v) for x,v in sols[0].items()};Mf=M0.subs(sol);assert all(sp.factor(e.subs(sol))==0 for e in eq)
Vf=P.inv()*Mf.extract(rr,range(6));Ff=Mf.extract(range(11),cc)
a,b,c,d=free;A,B,C,D=sp.symbols('A B C D');base={a:2*A-1,b:2*B-1,c:2*C-1,d:2*D-1}
MAB=sp.simplify(Mf.subs(base));VAB=sp.simplify(Vf.subs(base));FAB=sp.simplify(Ff.subs(base))
# Exact domain nested between rational lower and upper bounds.
LD=sp.factor(B*(1-C)/(1-B*C))
UD=sp.factor((B*(1-C)+C)/(1+C*(1-B)))
LA=sp.factor(B*(1-C)/(1+B*(1-C)))
UA=sp.factor(D*(1-B)/(1-B*D))
assert sp.factor(UD-LD)==sp.factor(-C*(B-1)/((B*C-1)*(B*C-C-1)))
assert sp.factor(UA.subs(D,LD)-LA)==0
X,Y,Z,T=sp.symbols('X Y Z T')
Ds=sp.factor(LD.subs({B:X,C:Y})+(UD-LD).subs({B:X,C:Y})*Z)
As=sp.factor(LA.subs({B:X,C:Y})+(UA.subs({B:X,C:Y,D:Ds})-LA.subs({B:X,C:Y}))*T)
subs={B:X,C:Y,D:Ds,A:As}
sample={X:sp.Rational(1,2),Y:sp.Rational(1,2),Z:sp.Rational(1,2),T:sp.Rational(1,2)}
def make_chart(name,vars_,subs,sample,description):
 data=[]
 for v in (A,B,C,D):
  n,q=map(sp.factor,sp.together(subs[v]).as_numer_denom())
  if q.subs(sample)<0:n,q=-n,-q
  data.append((sp.factor(n),sp.factor(q)))
 return {'name':name,'vars':vars_,'sub':subs,'data':data,'sample':sample,'description':description}
charts={'main':make_chart('main',(X,Y,Z,T),subs,sample,'B=X,C=Y,D=LD+(UD-LD)Z,A=LA+(UA-LA)T')}
# Sparse exact polynomial composition and tensor Bernstein transform.
def pdict(expr,vars_):
 pp=sp.Poly(sp.expand(expr),*vars_,domain='QQ');return {tuple(map(int,e)):Fraction(int(co.p),int(co.q)) for e,co in pp.terms()}
def pmul(p,q):
 if len(p)>len(q):p,q=q,p
 out=defaultdict(Fraction)
 for e,c0 in p.items():
  for f,c1 in q.items():out[tuple(e[i]+f[i] for i in range(len(e)))]+=c0*c1
 return {e:c for e,c in out.items() if c}
def ppow(p,n):
 dim=len(next(iter(p)));out={(0,)*dim:Fraction(1)};basep=p
 while n:
  if n&1:out=pmul(out,basep)
  n//=2
  if n:basep=pmul(basep,basep)
 return out
def compose(poly,ch):
 pp=sp.Poly(sp.expand(poly),A,B,C,D,domain='QQ');degs=tuple(map(int,pp.degree_list()));tv=ch['vars'];nds=ch['data'];powers=[]
 for (n,q),dg in zip(nds,degs):
  pn,pq=pdict(n,tv),pdict(q,tv);powers.append(([ppow(pn,i) for i in range(dg+1)],[ppow(pq,i) for i in range(dg+1)]))
 bases={}
 for alpha in itertools.product(*[range(dg+1) for dg in degs]):
  z={(0,)*len(tv):Fraction(1)}
  for j,k in enumerate(alpha):z=pmul(z,pmul(powers[j][0][k],powers[j][1][degs[j]-k]))
  bases[alpha]=z
 out={}
 for alpha,co in pp.terms():
  sc=Fraction(int(co.p),int(co.q))
  for e,cv in bases[alpha].items():
   val=out.get(e,Fraction(0))+sc*cv
   if val:out[e]=val
   elif e in out:del out[e]
 return out
def bern_dict(pd):
 deg=tuple(max(e[i] for e in pd) for i in range(len(next(iter(pd)))));arr=np.empty(tuple(x+1 for x in deg),dtype=object);arr.fill(Fraction(0))
 for e,c0 in pd.items():arr[e]=c0
 for axis,n in enumerate(deg):
  aa=np.moveaxis(arr,axis,0);oo=np.empty_like(aa);rest=aa.shape[1:];den=[math.comb(n,i) for i in range(n+1)]
  for idx in np.ndindex(rest):
   line=[aa[(i,)+idx] for i in range(n+1)]
   for k in range(n+1):
    vv=Fraction(0)
    for i in range(k+1):vv+=line[i]*Fraction(math.comb(k,i),den[i])
    oo[(k,)+idx]=vv
  arr=np.moveaxis(oo,0,axis)
 return deg,arr.ravel().tolist()
compose_cache={};bern_cache={}
def cert_poly(poly,ch,label):
 key=(sp.srepr(sp.factor(poly)),ch['name'])
 if key not in compose_cache:compose_cache[key]=compose(sp.factor(poly),ch)
 pd=compose_cache[key];bk=(key,'bern')
 if bk not in bern_cache:bern_cache[bk]=bern_dict(pd)
 deg,cs=bern_cache[bk];neg=[x for x in cs if x<0];pos=[x for x in cs if x>0]
 assert not neg and pos,(label,ch['name'],deg,len(neg),str(poly)[:200])
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos)),'terms':len(pd)}

def cert_target_poly(poly,ch,label):
 # The expression is already written in the chart coordinates, so it must
 # not be composed through (A,B,C,D) a second time.
 poly=sp.factor(poly)
 key=('target',sp.srepr(poly),ch['name'])
 if key not in compose_cache:compose_cache[key]=pdict(poly,ch['vars'])
 pd=compose_cache[key];bk=(key,'bern')
 if bk not in bern_cache:bern_cache[bk]=bern_dict(pd)
 deg,cs=bern_cache[bk];neg=[x for x in cs if x<0];pos=[x for x in cs if x>0]
 assert not neg and pos,(label,ch['name'],deg,len(neg),str(poly)[:200])
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos)),'terms':len(pd)}
def sampleAB(ch):return {v:sp.factor(ch['sub'][v].subs(ch['sample'])) for v in (A,B,C,D)}
def cert_rat(expr,ch,label,factorwise=True):
 expr=sp.cancel(expr);sab=sampleAB(ch);assert expr.subs(sab)>0,(label,ch['name'],expr.subs(sab));num,den=map(sp.factor,sp.together(expr).as_numer_denom());res={}
 for part,name in [(num,'numerator'),(den,'denominator')]:
  if factorwise:
   coeff,fl=sp.factor_list(part,A,B,C,D);recs=[]
   for fac,m in fl:
    sg=1 if fac.subs(sab)>0 else -1;rrr=cert_poly(sg*fac,ch,label+' '+name);rrr.update({'factor':str(fac),'sign':sg,'multiplicity':m});recs.append(rrr)
   res[name+'_factors']=recs
  else:
   sg=1 if part.subs(sab)>0 else -1;res[name]=cert_poly(sg*part,ch,label+' '+name)
 return res
# chart denominators
chart_den={}
for name,ch in charts.items():
 recs=[]
 for j,(n,q) in enumerate(ch['data']):
  sg=1 if sp.factor(q).subs(ch['sample'])>0 else -1
  recs.append({'variable':str((A,B,C,D)[j]),'denominator_sign':sg,'denominator':cert_target_poly(sg*q,ch,'chart denominator')})
 chart_den[name]=recs
# facets
code=np.array(rows,int);facP=[];facQ=[]
for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
def project3(points):
 delta=points-points[0];return delta@np.linalg.svd(delta,full_matrices=False)[2][:3].T
def pulling(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
def sphere(tets):
 tri=Counter(tuple(sorted(q)) for t in tets for q in itertools.combinations(t,3));assert set(tri.values())=={2};verts=set(i for t in tets for i in t);edges=set(tuple(sorted(e)) for t in tets for e in itertools.combinations(t,2));return {'vertices':len(verts),'edges':len(edges),'triangles':len(tri),'tetrahedra':len(tets)}
def balls(tets,facets):
 out=[]
 for fac in facets:
  group=[t for t in tets if set(t)<=set(fac)];assert group and set(i for t in group for i in t)==set(fac);tri=Counter(tuple(sorted(q)) for t in group for q in itertools.combinations(t,3));bd=[q for q,n in tri.items() if n==1];bv=set(i for q in bd for i in q);be=set(tuple(sorted(e)) for q in bd for e in itertools.combinations(q,2));assert len(bv)-len(be)+len(bd)==2;out.append(len(group))
 return out
chart_records={};chart_tets={}
for name,ch in charts.items():
 sub=ch['sub'];sample=ch['sample'];V=VAB.subs(sub);F=FAB.subs(sub);M=MAB.subs(sub);sab=sampleAB(ch)
 defects={}
 for x in variables:
  i,j=map(int,str(x)[1:].split('_'));defects[str(x)]=cert_rat(1-MAB[i,j]**2,ch,'defect '+str(x))
 vnum=np.array(V.subs(sample),float);fnum=np.array(F.subs(sample),float);ptsP=np.vstack([vnum.T,-vnum.T]);ptsQ=np.vstack([fnum,-fnum]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tP=[t for fac in facP for t in pulling(fac,ptsP)];tQ=[t for fac in facQ for t in pulling(fac,ptsQ)]
 ext=[]
 for j in range(6):
  incident=[i for i in range(11) if rows[i][j]!=0];found=None
  for r4 in itertools.combinations(incident,4):
   de=sp.factor(FAB.extract(r4,range(4)).det(method='domain-ge'))
   if de==0:continue
   sg=1 if de.subs(sab)>0 else -1
   try:ce=cert_rat(sg*de,ch,f'ext {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(r4),'determinant':str(de),'certificate':ce};break
  assert found,j;ext.append(found)
 def pP(i):return VAB[:,i] if i<6 else -VAB[:,i-6]
 def pQ(i):return FAB[i,:].T if i<11 else -FAB[i-11,:].T
 orientations=[]
 for lab,tets,point in [('primal',tP,pP),('polar',tQ,pQ)]:
  for k,ids in enumerate(tets):
   de=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'));sg=1 if de.subs(sab)>0 else -1;ce=cert_rat(sg*de,ch,f'{lab} tet {k}');orientations.append({'type':lab,'tetrahedron':list(ids),'determinant':str(de),'sign':sg,'certificate':ce})
 chart_records[name]={'description':ch['description'],'strict_defects':defects,'extremality':ext,'primal_vertices':12,'polar_vertices':22,'primal_boundary':sphere(tP),'primal_facet_tetrahedra':balls(tP,facP),'polar_facet_tetrahedra':balls(tQ,facQ),'tetrahedra_primal':len(tP),'tetrahedra_polar':len(tQ),'orientation_records':orientations};chart_tets[name]=(tP,tQ,sab)
 print('chart done',name,len(tP),len(tQ),flush=True)
# exact volumes
field=sp.QQ.frac_field(*free)
def pPfree(i):return Vf[:,i] if i<6 else -Vf[:,i-6]
def pQfree(i):return Ff[i,:].T if i<11 else -Ff[i-11,:].T
def exact_volume(tets,point,sfree):
 total=field.zero
 for ids in tets:
  de=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'));sg=1 if de.subs(sfree)>0 else -1;total+=field.from_sympy(sg*de)
 return sp.factor(field.to_sympy(total/24))
volumes={}
for name,(tP,tQ,sab) in chart_tets.items():
 sfree={a:2*sab[A]-1,b:2*sab[B]-1,c:2*sab[C]-1,d:2*sab[D]-1};volumes[name]=(exact_volume(tP,pPfree,sfree),exact_volume(tQ,pQfree,sfree))
print('volume formula computed',[(x,str(v[0])[:80],str(v[1])[:80]) for x,v in volumes.items()],flush=True)
# certify each chart's own margin formula
margin_certs={};volume_strings={}
for name,ch in charts.items():
 vp,vq=volumes[name];margin=sp.factor(sp.cancel((vp*vq-sp.Rational(32,3)).subs(base)));margin_certs[name]=cert_rat(margin,ch,'Mahler margin',factorwise=False);volume_strings[name]={'P':str(vp),'polar':str(vq),'margin':str(margin)}
certificate={'status':'PASS','scope':'4D symmetric Mahler bounded-12,12V/22F,c=0,D=18,family43','canonical_template':key,'rank':{'pivot_rows':rr,'pivot_cols':cc,'pivot_determinant':8,'free_variables':list(map(str,free)),'unique_solution':{str(k):str(v) for k,v in sol.items()}},'domain':{'description':'0<B,C<1, LD<D<UD, LA<A<UA(D)','LD':str(LD),'UD':str(UD),'LA':str(LA),'UA':str(UA),'chart':'B=X,C=Y,D=LD+(UD-LD)Z,A=LA+(UA-LA)T'},'chart_denominators':chart_den,'charts':chart_records,'volumes':volume_strings,'margin_certificates':margin_certs,'fixed_sign_polynomials':len(bern_cache),'conclusion':'Mahler product > 32/3 on full strict realization space.'}
CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True,default=str));h=hashlib.sha256(CERT.read_bytes()).hexdigest();out={'status':'PASS','canonical_family':CID,'charts':list(charts),'primal_vertices':12,'polar_vertices':22,'tetrahedra':{k:{'primal':v['tetrahedra_primal'],'polar':v['tetrahedra_polar']} for k,v in chart_records.items()},'margin_certificates':margin_certs,'certificate':str(CERT),'certificate_sha256':h,'conclusion':certificate['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True,default=str));print(json.dumps(out,indent=2,sort_keys=True,default=str))
