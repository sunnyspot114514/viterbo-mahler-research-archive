#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
PRE=Path('/mnt/data/viterbo_d18_work/viterbo_22f_d18_preclassification_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d18_layer_accounting_checker_output.json')
ids=[20,27,28,29,32,33,34,43,49,51,67,69,71]
def sha(p):
 h=hashlib.sha256();h.update(Path(p).read_bytes());return h.hexdigest()
def main():
 p=json.loads(PRE.read_text());assert p['global_templates']==62
 assert p['classification']=={'fails_guberman_facet_condition':13,'rank_ge_5':34,'antipodal_duplicate_columns':1,'insufficient_vertex_facets':1,'algebraic_survivor':13}
 surv=sorted(r['canonical_id'] for r in p['records'] if r['status']=='algebraic_survivor');assert surv==ids
 hashes={};margins={}
 for i in ids:
  op=Path(f'/mnt/data/viterbo_22f_d18_family{i}_verifier_output.json');cp=Path(f'/mnt/data/viterbo_22f_d18_family{i}_certificate.json')
  d=json.loads(op.read_text());assert d['status']=='PASS'; pv=d.get('primal_vertices',d.get('open_chamber',{}).get('primal_vertices')); qv=d.get('polar_vertices',d.get('open_chamber',{}).get('polar_vertices')); assert pv==12 and qv==22; assert ('greater than 32/3' in d['conclusion'] or '> 32/3' in d['conclusion'])
  hashes[str(op)]=sha(op)
  if cp.exists(): hashes[str(cp)]=sha(cp)
  margins[str(i)]=d.get('margin_certificates',d.get('margin_certificate',{'open_chamber':d.get('open_chamber',{}).get('margin_certificate'),'wall':d.get('wall',{}).get('margin_certificate')}))
 result={'status':'PASS','scope':'12V/22F,c=0,D=18 complete layer accounting','classification':{'fails_guberman_facet_condition':13,'rank_ge_5':34,'antipodal_duplicate_columns':1,'insufficient_vertex_facets':1,'Mahler_positive_families':13,'remaining':0},'closed_family_ids':ids,'margin_certificates':margins,'source_hashes':hashes,'preclassification_sha256':sha(PRE),'conclusion':'D=18 is closed in the bounded-class minimizer proof architecture as a computer-assisted analytic proof candidate.'}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps({k:result[k] for k in ['status','scope','classification','closed_family_ids','conclusion']},indent=2))
if __name__=='__main__':main()
