# 12V/22F, c=0, D=17：精确预分类

日期：2026-08-21

## 结构

D=17 对应 11 对 facet rows，其中：

\[
5\text{ 条 single-defect rows}+6\text{ 条 double-defect rows}.
\]

将五顶点 facets 三角化后：

\[
f=(12,44,64,32),\qquad g_2=6.
\]

本轮复用此前通过直接穷举得到的全部 15 个 `g2=6` 中心对称三维球轨道，并重新枚举五对相容 antipodal ridge merges。

## 精确计数

五对 ridge merges 经各 sphere 自同构群约化后，共得到：

\[
\boxed{12,827\text{ 个 local matching representatives}}.
\]

应用此前已经逐条验核过适用接口的 Guberman Theorem 3.2 必要条件：

\[
\boxed{
12,827
=
9,571\text{ 个 vertex-condition failures}
+
225\text{ 个 facet-condition failures}
+
3,031\text{ 个 passing locals}.
}
\]

3,031 个 passing locals 经完整 `B_6` signed-coordinate canonicalization：

\[
\boxed{3,031\longrightarrow2,395\text{ 个 global templates}}.
\]

exact multi-affine `5x5` minor corner certificates 给出：

\[
\boxed{
2,395
=
2,274\text{ 个 rank}\ge5
+
121\text{ 个 algebraic survivors}.
}
\]

## 独立验证

Python verifier 使用 Bareiss 整数消元重新计算全部 2,274 个 minor certificates，并对每个 canonical template 重建：

- 22 个实际 facets；
- polytope graph 与 vertex degrees；
- 每个顶点的非单纯 facet incidence；
- 每个 facet 中图度数至少 5 的顶点数。

验证结果：

```json
{
  "status": "PASS",
  "global_templates": 2395,
  "rank_ge_5": 2274,
  "algebraic_survivors": 121
}
```

## 当前状态

\[
\boxed{12V/22F,\ c=0,\ D=17:\ 121\text{ 个 algebraic survivors}}.
\]

这一层尚未关闭。下一阶段应先进行结构扫描：primal/polar vertex loss、额外 section vertices、低维 rank components，然后只对 genuine continuous families 计算 Mahler 余量。
