# Replay notes

Recommended environment: Python 3.13, SymPy, NumPy, SciPy, and a C++17 compiler.

The verifiers use exact SymPy/Fraction/Bareiss arithmetic for rank and positivity certificates. ConvexHull is used only to obtain a candidate facetwise triangulation; every selected simplex determinant is then certified exactly over the full parameter chart.

For the absolute paths embedded in the scripts, extract this bundle under `/mnt/data`, or edit the `SRC`, `CERT`, and `OUT` constants.

Core checks:

```bash
python viterbo_22f_d18_layer_accounting_checker.py
python viterbo_22f_d17_preclassification_verifier.py
```

The D17 `source/` directory includes the five-ridge merge enumerator, Guberman structural filter, global signed-coordinate canonicalizer source, exact minor classifier source, canonical templates, and corner-minor certificates.
