# 12V/22F, c=0, D=18：最后七个 family 的解析关闭

本说明覆盖 canonical families：

\[
28,29,33,43,49,51,71.
\]

每个 family 都由原始 pairing sign template 出发，完成唯一 rank-4 rational completion。完整 strict realization space 被一个开四立方体、两个对称开四立方体加公共墙，或 nested rational intervals 覆盖。

对每个 chart，独立 exact verifier 检查：

1. 所有 18 个 defects 严格位于 `(-1,1)`；
2. pairing matrix rank 恰为 4；
3. 六对 primal vertices 均保持 extreme；
4. cube section 恰有 22 个 vertices；
5. 固定 facetwise triangulations 全域有效；
6. 精确 `|P|`、`|P^circ|` 公式；
7. Mahler margin numerator 与 denominator 的 tensor Bernstein 定号。

最终 margin 证书：

| Family | 主 numerator degree | 正 | 零 | 负 | 最小正系数 |
|---:|---|---:|---:|---:|---:|
| 28 | `(10,9,5,2)` | 973 | 1007 | 0 | `4/675` |
| 29 | `(4,11,6,2)` | 835 | 425 | 0 | `1/550` |
| 33 | `(9,6,7,3)` | 856 | 1384 | 0 | `2/11025` |
| 43 | `(15,15,6,3)` | 5112 | 2056 | 0 | `8/4729725` |
| 49 | `(18,21,6,3)` | 9569 | 2135 | 0 | `256/305235` |
| 51 | `(10,10,3,3)` | 897 | 1039 | 0 | `4/8505` |
| 71 | `(9,10,6,2)` | 1787 | 523 | 0 | `4/405` |

Family 33 的 `B<C` 与 `B>C` 两个 chart 由 exact symmetry 对应，并在 `B=C` 墙上独立认证。Family 49 的两个 upper bounds 在 `A=A0` 切换，low/high/wall 三块分别认证；三块的体积公式在公共墙精确一致。

所以七个 family 的整个 strict realization spaces 上均有：

\[
\boxed{|P|\,|P^\circ|>32/3}.
\]
