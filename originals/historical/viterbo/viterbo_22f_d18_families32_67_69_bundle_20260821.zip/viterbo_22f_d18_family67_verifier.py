#!/usr/bin/env python3
"""Exact verifier for canonical family 67 in the 12V/22F, c=0, D=18 layer.

The strict realization space has two rational charts separated by a codimension-one wall.
The verifier checks the unique rank-four completion, the exact domain reduction, all strict
defects, primal extremality, fixed facetwise triangulations, exact volumes, and Bernstein
positivity of the Mahler margin on both charts and the wall.
"""
import hashlib, itertools, json, math
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

SRC=Path('/mnt/data/viterbo_d18_work/viterbo_22f_d18_preclassification_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d18_family67_verifier_output.json')
CERT=Path('/mnt/data/viterbo_22f_d18_family67_certificate.json')
CID=67
D0=json.loads(SRC.read_text())
rec=next(r for r in D0['records'] if r['canonical_id']==CID)
rows=rec['rows']; key=rec['key']

# pairing matrix and unique rank-four branch
M0=sp.zeros(11,6); variables=[]
for i,row in enumerate(rows):
    for j,z in enumerate(row):
        if z==0:
            x=sp.symbols(f'x{i}_{j}'); M0[i,j]=x; variables.append(x)
        else: M0[i,j]=z
rr=[0,1,2,3]; cc=[2,3,4,5]
P=M0.extract(rr,cc); assert P.det()==8
orows=[i for i in range(11) if i not in rr]
Smat=M0.extract(orows,[0,1])-M0.extract(orows,cc)*P.inv()*M0.extract(rr,[0,1])
eq=[sp.factor(e) for e in list(Smat)]
free=tuple(M0[i,j] for i,j in [(3,0),(7,2),(9,3),(10,1)])
dep=[x for x in variables if x not in free]
sols=sp.solve(eq,dep,dict=True,simplify=False); assert len(sols)==1
sol={x:sp.factor(v) for x,v in sols[0].items()}
Mf=M0.subs(sol); assert all(sp.factor(e.subs(sol))==0 for e in eq)
Vf=P.inv()*Mf.extract(rr,range(6)); Ff=Mf.extract(range(11),cc)
a,b,c,d=free

# affine unit variables A=(a+1)/2 etc.
A,B,C,D=sp.symbols('A B C D')
base={a:2*A-1,b:2*B-1,c:2*C-1,d:2*D-1}
MAB=sp.simplify(Mf.subs(base)); VAB=sp.simplify(Vf.subs(base)); FAB=sp.simplify(Ff.subs(base))

# Exact domain reduction.
H=1+B-B*C
K=1-B*C
Ah=sp.factor(B*(1-C)/H)
U5=sp.factor(B*(1-C)/K)
# Core factor distinguishing the two charts.
core=sp.factor(B*(1-A)*(1-C)-A)
assert sp.factor(core.subs(A,Ah))==0
assert sp.factor(Ah-(1-C)) == sp.factor(-(1-C)*(1-B*C)/H)
# Redundant bounds used in the derivation.
U4=sp.factor(A/(1-B+A*B))
U6=sp.factor(1/(2-A-B+A*B))
UG=sp.factor((B+C-B*C)/(1+C-B*C))
U7=sp.factor(A*(1-C)/(1-A-C))
assert sp.factor(UG-U5)==sp.factor(C*(1-B)/((1-B*C)*(1+C-B*C)))
assert sp.factor(U6-U5)==sp.factor((1-B)*(1-B*(1-A)*(1-C))/((1-B*C)*(2-A-B+A*B)))
# Low chart A<Ah: U7 is the active upper bound. High chart A>Ah: U5 is active.
U,T=sp.symbols('U T')
charts={
 'low':{
   'vars':(B,C,U,T),
   'NA':B*(1-C)*U,'DA':H,
   'ND':B*(1-C)*U*T,'DD':H-B*U,
   'sample':{B:sp.Rational(2,5),C:sp.Rational(1,3),U:sp.Rational(1,2),T:sp.Rational(1,2)},
   'description':'A=Ah*U; D=A(1-C)/(1-A-C)*T'},
 'high':{
   'vars':(B,C,U,T),
   'NA':B*(1-C)+U,'DA':H,
   'ND':B*(1-C)*T,'DD':K,
   'sample':{B:sp.Rational(2,5),C:sp.Rational(1,3),U:sp.Rational(1,2),T:sp.Rational(1,2)},
   'description':'A=Ah+(1-Ah)U; D=U5*T'},
 'wall':{
   'vars':(B,C,T),
   'NA':B*(1-C),'DA':H,
   'ND':B*(1-C)*T,'DD':K,
   'sample':{B:sp.Rational(2,5),C:sp.Rational(1,3),T:sp.Rational(1,2)},
   'description':'A=Ah; D=U5*T'} }
for ch in charts.values():
    ch['sub']={A:sp.factor(ch['NA']/ch['DA']),D:sp.factor(ch['ND']/ch['DD'])}

# Bernstein and sparse rational-chart composition.
def bern(poly,vs):
    p=sp.Poly(sp.expand(poly),*vs,domain='QQ')
    deg=tuple(map(int,p.degree_list())); terms=dict(p.terms()); cs=[]
    for beta in itertools.product(*[range(x+1) for x in deg]):
        val=sp.Rational(0)
        for alpha,co in terms.items():
            if all(alpha[j]<=beta[j] for j in range(len(vs))):
                w=sp.Rational(1)
                for j,dg in enumerate(deg):
                    w*=sp.Rational(math.comb(beta[j],alpha[j]),math.comb(dg,alpha[j]))
                val+=co*w
        cs.append(sp.factor(val))
    return deg,cs

compose_cache={}; bern_cache={}
def cleared_sub(poly,ch):
    """Substitute A=NA/DA,D=ND/DD and clear positive chart denominators."""
    poly=sp.Poly(sp.expand(poly),A,B,C,D,domain='QQ')
    cachekey=(sp.srepr(poly.as_expr()), ch['description'])
    if cachekey in compose_cache: return compose_cache[cachekey]
    da,db,dc,dd=map(int,poly.degree_list()); vs=ch['vars']
    NA,DA,ND,DD=ch['NA'],ch['DA'],ch['ND'],ch['DD']
    pNA=[sp.Poly(NA,*vs,domain='QQ')**i for i in range(da+1)]
    pDA=[sp.Poly(DA,*vs,domain='QQ')**i for i in range(da+1)]
    pND=[sp.Poly(ND,*vs,domain='QQ')**i for i in range(dd+1)]
    pDD=[sp.Poly(DD,*vs,domain='QQ')**i for i in range(dd+1)]
    pB=[sp.Poly(B,*vs,domain='QQ')**i for i in range(db+1)]
    pC=[sp.Poly(C,*vs,domain='QQ')**i for i in range(dc+1)]
    out=sp.Poly(0,*vs,domain='QQ')
    for (ia,ib,ic,id_),co in poly.terms():
        out += co*pNA[ia]*pDA[da-ia]*pB[ib]*pC[ic]*pND[id_]*pDD[dd-id_]
    compose_cache[cachekey]=out
    return out

def positive_poly_on_chart(poly,ch,label):
    cp=cleared_sub(sp.factor(poly),ch)
    key=(sp.srepr(cp.as_expr()),ch['vars'])
    if key not in bern_cache: bern_cache[key]=bern(cp.as_expr(),ch['vars'])
    deg,cs=bern_cache[key]; pos=[x for x in cs if x>0]; neg=[x for x in cs if x<0]
    assert not neg and pos,(label,deg,len(neg),str(cp.as_expr())[:300])
    return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos))}

def rational_positive_on_chart(expr,ch,label):
    """Prove a rational function positive by certifying every irreducible factor sign."""
    expr=sp.cancel(expr); num,den=map(sp.factor,sp.together(expr).as_numer_denom())
    sampleAB={A:sp.factor(ch['sub'][A].subs(ch['sample'])),B:ch['sample'][B],C:ch['sample'][C],D:sp.factor(ch['sub'][D].subs(ch['sample']))}
    assert expr.subs(sampleAB)>0
    result={'numerator_factors':[],'denominator_factors':[]}
    for part,name in [(num,'numerator_factors'),(den,'denominator_factors')]:
        coeff,factors=sp.factor_list(part,A,B,C,D)
        for fac,mult in factors:
            val=sp.factor(fac.subs(sampleAB)); assert val!=0
            sg=1 if val>0 else -1
            rec=positive_poly_on_chart(sg*fac,ch,label)
            rec.update({'factor':str(fac),'sign':sg,'multiplicity':mult})
            result[name].append(rec)
    return result

# Facets and sample triangulations, separately for each chart.
code=np.array(rows,int); facP=[]; facQ=[]
for i in range(11):
    facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),
             sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
for j in range(6):
    facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),
             sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
def project3(points):
    delta=points-points[0]
    return delta@np.linalg.svd(delta,full_matrices=False)[2][:3].T
def pulling(ids,coords):
    ids=sorted(ids)
    if len(ids)==4:return [tuple(ids)]
    pr=project3(coords[ids]); h=ConvexHull(pr); out=set()
    for tri,e in zip(h.simplices,h.equations):
        if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8: continue
        out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
    return sorted(out)
def sphere(tets):
    tri=Counter(tuple(sorted(q)) for tet in tets for q in itertools.combinations(tet,3))
    assert set(tri.values())=={2}
    verts=set(i for tet in tets for i in tet); edges=set(tuple(sorted(e)) for tet in tets for e in itertools.combinations(tet,2))
    return {'vertices':len(verts),'edges':len(edges),'triangles':len(tri),'tetrahedra':len(tets)}
def balls(tets,facets):
    out=[]
    for fac in facets:
        group=[tet for tet in tets if set(tet)<=set(fac)]
        assert group and set(i for tet in group for i in tet)==set(fac)
        tri=Counter(tuple(sorted(q)) for tet in group for q in itertools.combinations(tet,3))
        bd=[q for q,n in tri.items() if n==1]; bv=set(i for q in bd for i in q); be=set(tuple(sorted(e)) for q in bd for e in itertools.combinations(q,2))
        assert len(bv)-len(be)+len(bd)==2
        out.append(len(group))
    return out

chart_records={}; chart_tets={}
for name,ch in charts.items():
    sub=ch['sub']; sample=ch['sample']; Mab=MAB.subs(sub); V=VAB.subs(sub); F=FAB.subs(sub)
    # strict defects
    defects={}
    for x in variables:
        i,j=map(int,str(x)[1:].split('_'))
        defects[str(x)]=rational_positive_on_chart(1-MAB[i,j]**2,ch,'defect '+str(x))
    # numerical vertices and triangulations
    vnum=np.array(V.subs(sample),float); fnum=np.array(F.subs(sample),float)
    ptsP=np.vstack([vnum.T,-vnum.T]); ptsQ=np.vstack([fnum,-fnum])
    assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
    tP=[tet for fac in facP for tet in pulling(fac,ptsP)]
    tQ=[tet for fac in facQ for tet in pulling(fac,ptsQ)]
    # extremality
    ext=[]
    for j in range(6):
        incident=[i for i in range(11) if rows[i][j]!=0]; found=None
        for r4 in itertools.combinations(incident,4):
            de=sp.factor(FAB.extract(r4,range(4)).det(method='domain-ge'))
            if de==0: continue
            sampleAB={A:sub[A].subs(sample),B:sample[B],C:sample[C],D:sub[D].subs(sample)}
            sg=1 if de.subs(sampleAB)>0 else -1
            try: cert=rational_positive_on_chart(sg*de,ch,f'ext vertex {j}')
            except AssertionError: continue
            found={'vertex_pair':j,'facet_rows':list(r4),'determinant':str(de),'certificate':cert}; break
        assert found; ext.append(found)
    # orientation certificates using each chart's own pulling triangulation
    def pP(i): return VAB[:,i] if i<6 else -VAB[:,i-6]
    def pQ(i): return FAB[i,:].T if i<11 else -FAB[i-11,:].T
    sampleAB={A:sub[A].subs(sample),B:sample[B],C:sample[C],D:sub[D].subs(sample)}
    orientations=[]
    for lab,tets,point in [('primal',tP,pP),('polar',tQ,pQ)]:
        for k,ids in enumerate(tets):
            de=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'))
            sg=1 if de.subs(sampleAB)>0 else -1
            cert=rational_positive_on_chart(sg*de,ch,f'{lab} tet {k}')
            orientations.append({'type':lab,'tetrahedron':list(ids),'determinant':str(de),'sign':sg,'certificate':cert})
    chart_records[name]={'description':ch['description'],'strict_defects':defects,'extremality':ext,'primal_vertices':12,'polar_vertices':22,'primal_boundary':sphere(tP),'primal_facet_tetrahedra':balls(tP,facP),'polar_facet_tetrahedra':balls(tQ,facQ),'tetrahedra_primal':len(tP),'tetrahedra_polar':len(tQ),'orientation_records':orientations}
    chart_tets[name]=(tP,tQ,sampleAB)

# Exact volumes in the original free-variable field; all three charts must agree.
field=sp.QQ.frac_field(*free)
def pPfree(i): return Vf[:,i] if i<6 else -Vf[:,i-6]
def pQfree(i): return Ff[i,:].T if i<11 else -Ff[i-11,:].T
def exact_volume(tets,point,sample_free):
    total=field.zero
    for ids in tets:
        de=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'))
        sg=1 if de.subs(sample_free)>0 else -1
        total += field.from_sympy(sg*de)
    return sp.factor(field.to_sympy(total/24))
volumes={}
for name,(tP,tQ,sampleAB) in chart_tets.items():
    sample_free={a:2*sampleAB[A]-1,b:2*sampleAB[B]-1,c:2*sampleAB[C]-1,d:2*sampleAB[D]-1}
    volumes[name]=(exact_volume(tP,pPfree,sample_free),exact_volume(tQ,pQfree,sample_free))
assert all(sp.factor(volumes[name][0]-volumes['low'][0])==0 and sp.factor(volumes[name][1]-volumes['low'][1])==0 for name in volumes)
volP,volQ=volumes['low']
marginAB=sp.factor(sp.cancel((volP*volQ-sp.Rational(32,3)).subs(base)))
margin_certs={name:rational_positive_on_chart(marginAB,ch,'Mahler margin') for name,ch in charts.items()}

certificate={
 'status':'PASS','scope':'4D symmetric Mahler bounded-12, 12V/22F,c=0,D=18, family67','canonical_template':key,
 'rank':{'pivot_rows':rr,'pivot_cols':cc,'pivot_determinant':8,'free_variables':list(map(str,free)),'unique_solution':{str(k):str(v) for k,v in sol.items()}},
 'domain':{'A_B_C_D':'0<A,B,C<1 and 0<D<U(A,B,C)','threshold':'Ah=B(1-C)/(1+B(1-C))','low':'0<A<Ah, U=A(1-C)/(1-A-C)','high':'Ah<A<1, U=B(1-C)/(1-BC)','wall':'A=Ah, U=B(1-C)/(1-BC)','charts':{k:v['description'] for k,v in charts.items()}},
 'charts':chart_records,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(marginAB),'margin_certificates':margin_certs,
 'fixed_sign_polynomials':len(bern_cache),'conclusion':'Mahler product > 32/3 on the full strict realization space.'}
CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True,default=str))
hashv=hashlib.sha256(CERT.read_bytes()).hexdigest()
summary={
 'status':'PASS','canonical_family':67,'charts':['low','high','wall'],'primal_vertices':12,'polar_vertices':22,
 'tetrahedra':{k:{'primal':v['tetrahedra_primal'],'polar':v['tetrahedra_polar']} for k,v in chart_records.items()},
 'margin_certificates':{k:{'numerator':v['numerator_factors'][0] if len(v['numerator_factors'])==1 else v['numerator_factors'],'denominator_factor_count':len(v['denominator_factors'])} for k,v in margin_certs.items()},
 'certificate':str(CERT),'certificate_sha256':hashv,'conclusion':certificate['conclusion']}
OUT.write_text(json.dumps(summary,indent=2,sort_keys=True,default=str))
print(json.dumps(summary,indent=2,sort_keys=True,default=str))
