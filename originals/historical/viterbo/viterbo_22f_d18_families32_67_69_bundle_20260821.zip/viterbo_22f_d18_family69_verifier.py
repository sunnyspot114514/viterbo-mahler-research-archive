# full exact certificate builder for family 69, optimized by summing volumes before chart substitution
import json,itertools,math,time,hashlib
from collections import Counter
from pathlib import Path
import sympy as sp
import numpy as np
from scipy.spatial import ConvexHull
SRC=Path('/mnt/data/viterbo_d18_work/viterbo_22f_d18_preclassification_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d18_family69_verifier_output.json')
CERT=Path('/mnt/data/viterbo_22f_d18_family69_certificate.json')
D0=json.load(open(SRC));rows=next(r['rows'] for r in D0['records'] if r['canonical_id']==69);key=next(r['key'] for r in D0['records'] if r['canonical_id']==69)
M0=sp.zeros(11,6);variables=[]
for i,row in enumerate(rows):
 for j,z in enumerate(row):
  if z==0:x=sp.symbols(f'x{i}_{j}');M0[i,j]=x;variables.append(x)
  else:M0[i,j]=z
rr=[0,1,2,3];cc=[2,3,4,5];P=M0.extract(rr,cc);assert P.det()==8
orows=[i for i in range(11) if i not in rr];Smat=M0.extract(orows,[0,1])-M0.extract(orows,cc)*P.inv()*M0.extract(rr,[0,1]);eq=[sp.factor(e) for e in list(Smat)]
free=tuple(M0[i,j] for i,j in [(3,0),(7,2),(9,3),(10,1)]);dep=[x for x in variables if x not in free]
sols=sp.solve(eq,dep,dict=True,simplify=False);assert len(sols)==1;sol={x:sp.factor(v) for x,v in sols[0].items()};Mfree=M0.subs(sol);assert all(sp.factor(e.subs(sol))==0 for e in eq)
Vfree=P.inv()*Mfree.extract(rr,range(6));Ffree=Mfree.extract(range(11),cc)
a,b,c,d=free;A,B,C,D=sp.symbols('A B C D');lo=B*(1-C)/(1-B*C);up=B+C-B*C;T=sp.factor(lo+(up-lo)*D);chart={a:2*A-1,b:2*B-1,c:2*C-1,d:2*T-1};vs=(A,B,C,D);sampleC={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2),D:sp.Rational(1,2)};sample={x:sp.factor(e.subs(sampleC)) for x,e in chart.items()}
M=Mfree.subs(chart);V=Vfree.subs(chart);F=Ffree.subs(chart)

def bern(poly):
 p=sp.Poly(sp.expand(poly),*vs,domain='QQ');degs=tuple(map(int,p.degree_list()));powers=dict(p.terms());cs=[]
 for beta in itertools.product(*[range(x+1) for x in degs]):
  val=sp.Rational(0)
  for alpha,co in powers.items():
   if all(alpha[j]<=beta[j] for j in range(4)):
    w=sp.Rational(1)
    for j,deg in enumerate(degs):w*=sp.Rational(math.comb(beta[j],alpha[j]),math.comb(deg,alpha[j]))
    val+=co*w
  cs.append(sp.factor(val))
 return degs,cs
cache={}
def pospoly(poly,label):
 poly=sp.factor(poly);k=sp.srepr(poly)
 if k not in cache:cache[k]=bern(poly)
 deg,cs=cache[k];neg=[x for x in cs if x<0];pos=[x for x in cs if x>0];assert not neg and pos,(label,deg,neg[:2])
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in cs),'min_positive':str(min(pos))}
def posrat(expr,label):
 expr=sp.cancel(expr);num,den=map(sp.factor,sp.together(expr).as_numer_denom())
 if den.subs(sampleC)<0:num,den=-num,-den
 return {'numerator':pospoly(num,label+' numerator'),'denominator':pospoly(den,label+' denominator')}
# defects
defects={}
for x in variables:
 i,j=map(int,str(x)[1:].split('_'));defects[str(x)]=posrat(1-M[i,j]**2,'defect '+str(x))
# extremality
ext=[]
for j in range(6):
 incident=[i for i in range(11) if rows[i][j]!=0];found=None
 for r4 in itertools.combinations(incident,4):
  de=sp.factor(sp.cancel(F.extract(r4,range(4)).det(method='domain-ge')))
  if de==0:continue
  sg=1 if de.subs(sampleC)>0 else -1
  try:ce=posrat(sg*de,f'ext vertex {j}')
  except AssertionError:continue
  found={'vertex_pair':j,'facet_rows':list(r4),'determinant':str(de),'certificate':ce};break
 assert found;ext.append(found)
# triangulations
def project3(points):
 delta=points-points[0];return delta@np.linalg.svd(delta,full_matrices=False)[2][:3].T
def pulling(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
vnum=np.array(V.subs(sampleC),float);fnum=np.array(F.subs(sampleC),float);ptsP=np.vstack([vnum.T,-vnum.T]);ptsQ=np.vstack([fnum,-fnum]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
code=np.array(rows,int);facP=[];facQ=[]
for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
tP=[t for f in facP for t in pulling(f,ptsP)];tQ=[t for f in facQ for t in pulling(f,ptsQ)]
def sphere(tets):
 tri=Counter(tuple(sorted(q)) for t in tets for q in itertools.combinations(t,3));assert set(tri.values())=={2};verts=set(i for t in tets for i in t);edges=set(tuple(sorted(e)) for t in tets for e in itertools.combinations(t,2));return {'vertices':len(verts),'edges':len(edges),'triangles':len(tri),'tetrahedra':len(tets)}
def balls(tets,facets):
 out=[]
 for fac in facets:
  group=[t for t in tets if set(t)<=set(fac)];assert group and set(i for t in group for i in t)==set(fac);tri=Counter(tuple(sorted(q)) for t in group for q in itertools.combinations(t,3));bd=[q for q,cnt in tri.items() if cnt==1];bv=set(i for q in bd for i in q);be=set(tuple(sorted(e)) for q in bd for e in itertools.combinations(q,2));assert len(bv)-len(be)+len(bd)==2;out.append(len(group))
 return out
spP=sphere(tP);bp=balls(tP,facP);bq=balls(tQ,facQ)
def pP(i,charted=True):
 VV=V if charted else Vfree;return VV[:,i] if i<6 else -VV[:,i-6]
def pQ(i,charted=True):
 FF=F if charted else Ffree;return FF[i,:].T if i<11 else -FF[i-11,:].T
orients=[]
for lab,tets,point in [('primal',tP,pP),('polar',tQ,pQ)]:
 for k,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));sg=1 if de.subs(sampleC)>0 else -1;posrat(sg*de,f'{lab} tet {k}')
# volumes in original free field
field=sp.QQ.frac_field(*free)
def volume(tets,point):
 total=field.zero
 for ids in tets:
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i,False) for i in ids]).det(method='domain-ge')));sg=1 if de.subs(sample)>0 else -1;total+=field.from_sympy(sg*de)
 return sp.factor(field.to_sympy(total/24))
volP=volume(tP,pP);volQ=volume(tQ,pQ);margin=sp.factor(sp.cancel((volP*volQ-sp.Rational(32,3)).subs(chart)));margin_cert=posrat(margin,'Mahler margin')
certificate={'status':'PASS','scope':'4D symmetric Mahler bounded-12, 12V/22F,c=0,D=18, family69','canonical_template':key,'rank':{'pivot_rows':rr,'pivot_cols':cc,'pivot_determinant':8,'free_variables':list(map(str,free)),'unique_solution':{str(k):str(v) for k,v in sol.items()}},'domain':{'formula':'0<A,B,C,D<1; t=(B(1-C)/(1-BC))+(B+C-BC-B(1-C)/(1-BC))D','original':'-1<a,b,c,d<1 with L((b+1)/2,(c+1)/2)<(d+1)/2<U(...)'},'strict_defects':defects,'extremality':ext,'primal_vertices':12,'polar_vertices':22,'primal_boundary':spP,'primal_facet_tetrahedra':bp,'polar_facet_tetrahedra':bq,'tetrahedra_primal':len(tP),'tetrahedra_polar':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':margin_cert,'fixed_sign_polynomials':len(cache),'conclusion':'Mahler product > 32/3 on the full strict realization space.'}
CERT.write_text(json.dumps(certificate,indent=2,sort_keys=True));h=hashlib.sha256(CERT.read_bytes()).hexdigest();output={'status':'PASS','canonical_family':69,'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tP),'tetrahedra_polar':len(tQ),'margin_certificate':margin_cert,'certificate':str(CERT),'certificate_sha256':h,'conclusion':certificate['conclusion']};OUT.write_text(json.dumps(output,indent=2,sort_keys=True));print(json.dumps(output,indent=2,sort_keys=True))
