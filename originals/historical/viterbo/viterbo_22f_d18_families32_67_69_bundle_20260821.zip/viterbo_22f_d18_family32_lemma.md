# Family 32: exact closure in the 12V/22F, c=0, D=18 layer

## Statement

For canonical pairing template 32, every strict rank-four realization has

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

This is a computer-assisted analytic proof candidate.

## Rank and parameter domain

Choose the four single-defect variables

\[
a=x_{4,0},\quad b=x_{7,2},\quad c=x_{8,3},\quad d=x_{10,1},
\]

and set

\[
A=\frac{a+1}{2},\quad B=\frac{b+1}{2},\quad
C=\frac{c+1}{2},\quad D=\frac{d+1}{2}.
\]

A constant \(4\times4\) pairing pivot has determinant \(-8\), and the Schur equations have one rational solution for every dependent defect. The full strict domain is

\[
0<A,B,C<1,
\qquad
0<D<\frac{C(1-B)}{1-BC}.
\]

It is covered by the unit cube through

\[
D=\frac{C(1-B)}{1-BC}\,T,
\qquad 0<A,B,C,T<1.
\]

## Geometric closure

The exact verifier proves:

- rank exactly four;
- all eighteen defects remain in \((-1,1)\);
- all six antipodal primal vertex-pairs are extreme;
- the polar has exactly eleven antipodal vertex-pairs;
- a fixed boundary decomposition has 35 primal and 75 polar tetrahedra;
- all selected simplex determinants have fixed nonzero sign over the whole parameter cube.

Thus

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

## Mahler margin

After exact volume summation and the unit-cube substitution, the positive numerator certificate has tensor Bernstein degree

\[
(2,6,8,4).
\]

Its coefficients satisfy

\[
555>0,\qquad390=0,\qquad0<0,
\]

with smallest positive coefficient

\[
\frac1{210}.
\]

The denominator certificate has degree \((1,5,7,3)\), with 234 positive coefficients, 150 zero coefficients, and no negative coefficient. Therefore the Mahler margin is strictly positive throughout the open realization space.
