# Family 69: exact closure in the 12V/22F, c=0, D=18 layer

## Statement

For canonical pairing template 69, every strict rank-four realization satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

This is a computer-assisted analytic proof candidate.

## Rank and parameter domain

Use

\[
a=x_{3,0},\quad b=x_{7,2},\quad c=x_{9,3},\quad d=x_{10,1}
\]

and

\[
A=\frac{a+1}{2},\quad B=\frac{b+1}{2},\quad
C=\frac{c+1}{2},\quad E=\frac{d+1}{2}.
\]

A constant pivot has determinant \(8\), and the Schur system gives a unique rational rank-four branch. The complete strict domain is

\[
0<A,B,C<1,
\]

\[
\frac{B(1-C)}{1-BC}
< E <
B+C-BC.
\]

Let

\[
L=\frac{B(1-C)}{1-BC},\qquad U=B+C-BC.
\]

Then the unit-cube parameterization is

\[
E=L+(U-L)D,
\qquad0<A,B,C,D<1.
\]

## Geometric closure

The verifier establishes rank four, all strict defects, all twelve primal vertices, all twenty-two polar vertices, and a fixed boundary decomposition with

\[
35\text{ primal tetrahedra},\qquad75\text{ polar tetrahedra}.
\]

Every selected orientation determinant has a full-domain Bernstein sign certificate.

## Mahler margin

The margin numerator has tensor Bernstein degree

\[
(2,8,10,4),
\]

with

\[
1106>0,\qquad379=0,\qquad0<0,
\]

and smallest positive coefficient

\[
\frac{17}{1890}.
\]

The denominator degree is \((1,6,7,3)\), with 330 positive, 118 zero, and no negative coefficients. Hence the margin is strictly positive on the complete strict realization space.
