# 12V/22F, c=0, D=18: Families 32, 67, and 69 closed

Date: 2026-08-21

## Current layer accounting

The exact preclassification is

\[
62=
13\text{ Guberman-facet failures}
+34\text{ rank-}\ge5
+1\text{ duplicate primal pair}
+1\text{ insufficient incident facets}
+13\text{ algebraic survivors}.
\]

Previously closed survivors were 20, 27, and 34. This round closes 32, 67, and 69. Therefore:

\[
\boxed{6/13\text{ survivors closed}}
\]

and the remaining canonical IDs are

\[
\boxed{28,29,33,43,49,51,71}.
\]

All closed-family statements remain computer-assisted analytic proof candidates, pending external review and a unified public replay package.

## Family 32

The complete domain is

\[
0<A,B,C<1,
\qquad
0<D<\frac{C(1-B)}{1-BC}.
\]

Using \(D=C(1-B)T/(1-BC)\), the verifier proves rank four, 12/22 vertices, fixed triangulations with 35/75 tetrahedra, and a positive Mahler-margin Bernstein numerator of degree \((2,6,8,4)\):

\[
555>0,\quad390=0,\quad0<0,
\qquad \min_+=1/210.
\]

## Family 69

The complete domain is

\[
0<A,B,C<1,
\]

\[
\frac{B(1-C)}{1-BC}<D<B+C-BC.
\]

The verifier proves rank four, 12/22 vertices, 35/75 tetrahedra, and degree \((2,8,10,4)\) margin positivity:

\[
1106>0,\quad379=0,\quad0<0,
\qquad \min_+=17/1890.
\]

## Family 67

This family requires two rational charts, separated by

\[
A_h=\frac{B(1-C)}{1+B(1-C)}.
\]

For \(A<A_h\), the active upper bound is

\[
D<\frac{A(1-C)}{1-A-C};
\]

for \(A>A_h\), it is

\[
D<\frac{B(1-C)}{1-BC}.
\]

The common wall is independently certified. All three regions have 12/22 vertices and 35/76 boundary tetrahedra. Margin Bernstein data:

\[
\begin{array}{c|c|c|c|c}
\text{region}&\text{degree}&>0&=0&\min_+\\
\hline
\text{low}&(8,10,6,4)&1593&1872&1/2205\\
\text{high}&(8,10,2,4)&877&608&1/2100\\
\text{wall}&(8,10,4)&244&251&2/3675
\end{array}
\]

No negative coefficient occurs.

## Next front

Family 49 now has a unique four-parameter rank-four completion and an exact piecewise strict domain. Write

\[
K=1-C+BC,
\quad J=1+BC,
\quad L=2-B-C+BC,
\]

\[
A_0=\frac{K}{2-C+BC},
\quad U_A=\frac{K}{J},
\]

\[
L_1(A)=\frac{AC}{1-A+AC},
\quad U_3(A)=\frac{A}{1-B+AB},
\quad U_4=\frac{K}{L}.
\]

Its complete strict domain has been reduced to

\[
0<B,C<1,
\quad0<A<U_A,
\quad L_1(A)<D<\min\{U_3(A),U_4\},
\]

with the switch at \(A=A_0\). Low, high, and wall sample triangulations produce the same exact volume formulas. The remaining task is an efficient global sign certificate for the orientation factors and Mahler margin; direct fully expanded substitution is too expensive, so the factorwise sparse-composition method used for Family 67 will be applied next.
