#!/usr/bin/env python3
import json
from pathlib import Path
closed=[20,27,32,34,67,69]
for cid in closed:
    p=Path(f'/mnt/data/viterbo_22f_d18_family{cid}_verifier_output.json')
    assert p.exists(), p
    data=json.loads(p.read_text())
    assert data['status']=='PASS', (cid,data.get('status'))
state=json.loads(Path('/mnt/data/viterbo_22f_d18_progress_v17_20260821.json').read_text())
assert state['closed_survivors']==closed
assert state['remaining_survivors']==[28,29,33,43,49,51,71]
assert 13+34+1+1+len(closed)+len(state['remaining_survivors'])==62
out={
    'status':'PASS',
    'closed_survivors':closed,
    'remaining_survivors':state['remaining_survivors'],
    'accounting':'62 = 13 + 34 + 1 + 1 + 6 + 7'
}
Path('/mnt/data/viterbo_22f_d18_six_families_output_checker_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
