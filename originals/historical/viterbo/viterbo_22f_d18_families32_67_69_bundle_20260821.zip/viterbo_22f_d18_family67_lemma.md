# Family 67: two-chart exact closure in the 12V/22F, c=0, D=18 layer

## Statement

For canonical pairing template 67, every strict rank-four realization satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

The strict realization space requires two open rational charts and their common wall. All three pieces are independently certified.

## Rank and domain reduction

Use

\[
a=x_{3,0},\quad b=x_{7,2},\quad c=x_{9,3},\quad d=x_{10,1}
\]

and set

\[
A=\frac{a+1}{2},\quad B=\frac{b+1}{2},\quad
C=\frac{c+1}{2},\quad D=\frac{d+1}{2}.
\]

A constant pivot has determinant \(8\), and the Schur equations have one rational solution for all dependent defects.

Define

\[
A_h=\frac{B(1-C)}{1+B(1-C)},
\qquad
U_5=\frac{B(1-C)}{1-BC}.
\]

The complete strict domain is:

### Low chart

\[
0<A<A_h,
\qquad
0<D<\frac{A(1-C)}{1-A-C}.
\]

It is parameterized by

\[
A=A_hU,
\qquad
D=\frac{B(1-C)UT}{1+B(1-C)-BU},
\qquad0<B,C,U,T<1.
\]

### High chart

\[
A_h<A<1,
\qquad
0<D<U_5.
\]

It is parameterized by

\[
A=A_h+(1-A_h)U,
\qquad
D=U_5T,
\qquad0<B,C,U,T<1.
\]

### Common wall

\[
A=A_h,
\qquad
D=U_5T,
\qquad0<B,C,T<1.
\]

The reduction follows by factoring every expression \(1-x_{ij}^2\). All apparently additional upper bounds are either automatic or dominated by the bound shown above; the sign change is governed by

\[
B(1-A)(1-C)-A.
\]

## Geometric closure

Each chart is checked independently. In all three regions:

- rank is exactly four;
- every defect is strict;
- all twelve primal vertices and all twenty-two polar vertices are genuine;
- the primal boundary uses 35 tetrahedra;
- the polar boundary uses 76 tetrahedra;
- all facet-balls and the total boundary pass exact topological checks;
- every selected orientation factor has a fixed-sign Bernstein certificate.

The low, high, and wall triangulations give exactly the same rational formulas for \(|P|\) and \(|P^\circ|\).

## Mahler margin

After clearing the positive chart denominators, the sign-adjusted margin numerators have the following Bernstein data:

| Region | Degree | Positive | Zero | Negative | Smallest positive |
|---|---:|---:|---:|---:|---:|
| Low | \((8,10,6,4)\) | 1593 | 1872 | 0 | \(1/2205\) |
| High | \((8,10,2,4)\) | 877 | 608 | 0 | \(1/2100\) |
| Wall | \((8,10,4)\) | 244 | 251 | 0 | \(2/3675\) |

The rational denominator factors are independently certified to have fixed sign. Thus the Mahler margin is strictly positive on both open charts and their common wall.
