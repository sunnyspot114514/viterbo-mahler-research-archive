# v43 replay instructions

This package adds a complexity-independent functional-lift reduction for the
four-dimensional centrally symmetric Mahler problem and an exact lambda-one
pressure test.

## Requirements

- Python 3.11+
- SymPy

Install the listed dependency with:

```bash
python -m pip install -r viterbo_global_requirements_v43.txt
```

## Integrity and semantic replay

```bash
python viterbo_global_replay_v43.py
```

This verifies the v43 manifest, replays the inherited v42 bundle as an
integrity/semantic checkpoint, and checks the stored v43 certificates.

## Exact rebuild of new v43 computations

```bash
python viterbo_global_replay_v43.py --rebuild
```

The rebuild reruns:

1. the exact rank-four lambda-one subset-rank and overlap-normal-form analyzer;
2. the symbolic functional-lift/rectangular-prismatic verifier;
3. the complete rational 28V/28F primal/polar vertex enumeration;
4. both 112-tetrahedron boundary reconstructions and determinant volume sums;
5. manifest and semantic consistency checks.

The external Fradelizi--Nakhle functional inequalities and the classical
2D/3D Mahler theorems are theorem interfaces, not re-proved by this Python
package.
