#!/usr/bin/env python3
"""Exact rank-four lambda=1 separation and overlap-normal-form analyzer.

The input contains one or more rational vector configurations.  For every
configuration with at most 20 elements, the script performs a complete subset
rank census, records all exact 2-separations (lambda=1, both sides at least two
items), and constructs a rational 2+3-over-a-line normal form whenever the two
side ranks are {2,3}.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from functools import reduce
from pathlib import Path
from typing import Any

import sympy as sp


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_scalar(value: Any) -> sp.Rational:
    out = sp.sympify(str(value), rational=True)
    if not out.is_Rational:
        raise ValueError(f"Only rational input is supported in v43: {value!r}")
    return sp.Rational(out)


def independent(vectors: list[list[sp.Rational]], indices: list[int]) -> bool:
    if not indices:
        return True
    return sp.polys.matrices.DomainMatrix.from_list_sympy(
        len(indices), 4, [[vectors[i][j] for j in range(4)] for i in indices]
    ).rank() == len(indices)


def all_subset_ranks(vectors: list[list[sp.Rational]]) -> tuple[list[int], list[int]]:
    m = len(vectors)
    ranks = [0] * (1 << m)
    bases = [0] * (1 << m)
    for mask in range(1, 1 << m):
        bit = mask & -mask
        element = bit.bit_length() - 1
        previous = mask ^ bit
        basis_mask = bases[previous]
        basis_indices = [i for i in range(m) if (basis_mask >> i) & 1]
        if len(basis_indices) < 4 and independent(vectors, basis_indices + [element]):
            basis_mask |= bit
        bases[mask] = basis_mask
        ranks[mask] = basis_mask.bit_count()
    return ranks, bases


def independent_row_basis(matrix: sp.Matrix) -> sp.Matrix:
    """Return an independent subset of rows, preserving input order."""
    chosen: list[int] = []
    current_rank = 0
    for i in range(matrix.rows):
        trial = matrix[chosen + [i], :]
        rank = trial.rank()
        if rank > current_rank:
            chosen.append(i)
            current_rank = rank
    return matrix[chosen, :]


def primitive_row(row: sp.Matrix) -> list[str]:
    entries = [sp.Rational(x) for x in list(row)]
    denominators = [x.q for x in entries]
    lcm = sp.ilcm(*denominators) if denominators else 1
    integers = [int(x * lcm) for x in entries]
    nonzero = [abs(x) for x in integers if x]
    gcd = reduce(math.gcd, nonzero) if nonzero else 1
    integers = [x // gcd for x in integers]
    first = next((x for x in integers if x), 0)
    if first < 0:
        integers = [-x for x in integers]
    return [str(x) for x in integers]


def coordinates_in_row_basis(vector: sp.Matrix, basis_rows: sp.Matrix) -> sp.Matrix:
    # vector = coeff^T basis_rows, hence basis_rows.T * coeff = vector.T.
    return basis_rows.T.inv() * vector.T


def build_overlap_normal_form(
    vectors: list[list[sp.Rational]], side_a: list[int], side_b: list[int]
) -> dict[str, Any]:
    full = sp.Matrix(vectors)
    a = independent_row_basis(full[side_a, :])
    b = independent_row_basis(full[side_b, :])
    rank_a, rank_b = a.rows, b.rows
    if sorted((rank_a, rank_b)) != [2, 3]:
        return {
            "available": False,
            "reason": f"side ranks are {rank_a},{rank_b}, not 2 and 3",
        }
    if rank_a == 3:
        side_a, side_b = side_b, side_a
        a, b = b, a
        rank_a, rank_b = rank_b, rank_a

    # Solve alpha^T a = beta^T b.  The nullspace has dimension one because
    # dim(span A intersection span B)=2+3-4=1.
    overlap_system = a.T.row_join(-b.T)
    nullspace = overlap_system.nullspace()
    assert len(nullspace) == 1
    coeff = nullspace[0]
    overlap = (coeff[:2, :].T * a)
    assert overlap != sp.zeros(1, 4)
    overlap_primitive = primitive_row(overlap)
    overlap = sp.Matrix([[sp.Rational(x) for x in overlap_primitive]])

    # Select x in span(A) outside overlap, then two B vectors extending the
    # overlap line.  The resulting ambient row basis is (x,t,y,z).
    x_row = next(a[i, :] for i in range(a.rows) if sp.Matrix.vstack(overlap, a[i, :]).rank() == 2)
    b_extensions: list[sp.Matrix] = []
    running = sp.Matrix.vstack(overlap)
    for i in range(b.rows):
        trial = sp.Matrix.vstack(running, b[i, :])
        if trial.rank() > running.rank():
            b_extensions.append(b[i, :])
            running = trial
        if len(b_extensions) == 2:
            break
    assert len(b_extensions) == 2 and running.rank() == 3
    ambient = sp.Matrix.vstack(x_row, overlap, b_extensions[0], b_extensions[1])
    assert ambient.det() != 0

    coordinate_rows: list[list[str]] = []
    for row in full.tolist():
        c = coordinates_in_row_basis(sp.Matrix([row]), ambient)
        coordinate_rows.append([str(sp.factor(z)) for z in c])

    for i in side_a:
        assert coordinate_rows[i][2] == "0" and coordinate_rows[i][3] == "0"
    for i in side_b:
        assert coordinate_rows[i][0] == "0"

    return {
        "available": True,
        "rank_profile": [2, 3],
        "side_rank2": side_a,
        "side_rank3": side_b,
        "overlap_dimension": 1,
        "overlap_line_primitive": overlap_primitive,
        "ambient_row_basis_x_t_y_z": [
            [str(sp.factor(x)) for x in ambient.row(i)] for i in range(4)
        ],
        "ambient_basis_determinant": str(sp.factor(ambient.det())),
        "coordinates_in_x_t_y_z_basis": coordinate_rows,
        "zero_pattern_verified": {
            "rank2_side_has_zero_y_z": True,
            "rank3_side_has_zero_x": True,
        },
    }


def analyze(rows: list[list[Any]], name: str, cap: int = 20) -> dict[str, Any]:
    vectors = [[parse_scalar(x) for x in row] for row in rows]
    assert vectors and all(len(row) == 4 for row in vectors)
    m = len(vectors)
    if m > cap:
        return {
            "name": name,
            "element_count": m,
            "status": "SKIPPED",
            "reason": f"element count exceeds exact subset-census cap {cap}",
        }
    ranks, _ = all_subset_ranks(vectors)
    full = (1 << m) - 1
    total_rank = ranks[full]
    assert total_rank == 4
    lambda_histogram: dict[str, int] = {}
    exact_two_separations: list[dict[str, Any]] = []
    zero_separations: list[dict[str, Any]] = []
    minimum_two = 99
    minimum_three = 99
    for mask in range(1, full):
        complement = full ^ mask
        if mask > complement:
            continue
        side_a = [i for i in range(m) if (mask >> i) & 1]
        side_b = [i for i in range(m) if (complement >> i) & 1]
        lam = ranks[mask] + ranks[complement] - total_rank
        lambda_histogram[str(lam)] = lambda_histogram.get(str(lam), 0) + 1
        if len(side_a) >= 2 and len(side_b) >= 2:
            minimum_two = min(minimum_two, lam)
            if lam == 1:
                record = {
                    "side_A": side_a,
                    "side_B": side_b,
                    "rank_A": ranks[mask],
                    "rank_B": ranks[complement],
                    "lambda": 1,
                }
                record["overlap_normal_form"] = build_overlap_normal_form(
                    vectors, side_a, side_b
                )
                exact_two_separations.append(record)
        if len(side_a) >= 3 and len(side_b) >= 3:
            minimum_three = min(minimum_three, lam)
        if lam == 0:
            zero_separations.append(
                {
                    "side_A": side_a,
                    "side_B": side_b,
                    "rank_A": ranks[mask],
                    "rank_B": ranks[complement],
                }
            )
    return {
        "name": name,
        "status": "PASS",
        "element_count": m,
        "rank": total_rank,
        "connected": not zero_separations,
        "zero_separation_count": len(zero_separations),
        "minimum_lambda_sides_at_least_2": minimum_two,
        "minimum_lambda_sides_at_least_3": minimum_three,
        "exact_lambda1_two_separation_count": len(exact_two_separations),
        "exact_lambda1_two_separations": exact_two_separations,
        "lambda_histogram_all_unordered_partitions": lambda_histogram,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--certificate", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text())
    certificate = {
        "status": "PASS",
        "scope": "exact rank-four vector-matroid lambda=1 normal forms",
        "name": payload.get("name", "unnamed"),
        "vertex_configuration": analyze(
            payload["vertex_pair_representatives"], "vertex vectors"
        ),
        "normal_configuration": analyze(
            payload["facet_normal_pair_representatives"], "facet-normal vectors"
        ),
        "interpretation": (
            "lambda(S)=r(S)+r(E\\S)-4.  An exact lambda-one split with ranks "
            "2 and 3 is put in a rational 2+3-over-a-line coordinate normal form."
        ),
        "scope_warning": (
            "A vector-matroid 2-separation alone is not a Mahler inequality.  "
            "The v43 functional-lift theorem closes the homothetic-fiber subclass."
        ),
    }
    args.certificate.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    vertex = certificate["vertex_configuration"]
    normal = certificate["normal_configuration"]
    output = {
        "status": "PASS",
        "name": certificate["name"],
        "vertex_connected": vertex["connected"],
        "normal_connected": normal["connected"],
        "vertex_lambda1_two_separations": vertex["exact_lambda1_two_separation_count"],
        "normal_lambda1_two_separations": normal["exact_lambda1_two_separation_count"],
        "certificate": args.certificate.name,
        "certificate_sha256": sha256(args.certificate),
    }
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
