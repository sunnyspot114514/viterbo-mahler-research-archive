# 四维中心对称 Mahler：v43 进展

**日期：** 2026-09-05  
**状态：** `PASS`（外部定理推论 + exact verifier；完整四维猜想仍 open）

## 本轮核心进展

v42 已关闭 \(\lambda=0\) 的直积/free-sum 层。本轮进入 rank-four vector matroid 的 \(\lambda=1\) 层，并找到一个复杂度无关的 functional-lift 闭包。

对

\[
K_{L,m}(f)=\{(x,y):\|y\|_L\le f(x)\}
\]

使用精确因子化

\[
M(K_{L,m}(f))=M(L)P_m(f).
\]

Fradelizi--Nakhle 的一维、二维函数型下界与已知的二维、三维 Mahler 定理给出：

\[
\boxed{n=1,m=3:\quad M(K_{L,3}(f))\ge32/3,}
\]

\[
\boxed{n=2,m=2:\quad M(K_{L,2}(f))\ge32/3.}
\]

因此所有四维同似三维纤维体和同似二维纤维体均被关闭，复杂度不限。

## \(\lambda=1\) 推论

一个 rank \(2+3\) 的 \(\lambda=1\) split 可线性化为

\[
U=\mathbb R_x\oplus\mathbb R_t,
\qquad
W=\mathbb R_t\oplus\mathbb R_y^2.
\]

若 rank-three side 的横向平面 sections 全部是某个固定 \(H\) 的同心同似副本，则整个 gluing 是一个 \(K_{H,2}(f)\)，从而满足 \(32/3\) 下界。若 separation 位于 normal matroid，则对极体应用同一结论。

所以尚未关闭的 \(\lambda=1\) 候选必须具有非同似 transverse fiber-shape variation。

## 显式全参数族

对任意平面中心对称凸体 \(H\) 和 \(r\ge0\)，定义

\[
Q_r(H)=\operatorname{conv}
\left(([-1,1]\times[-r,r])\times\{0\},
\{0\}\times([-1,1]\times H)\right).
\]

完整公式为

\[
M(Q_r(H))=
\begin{cases}
M(H)\dfrac{(3+r)(4-r)}9,&0\le r\le1,\\[2mm]
M(H)\dfrac{2(r+1)(6r^2-4r+1)}{9r^3},&r\ge1.
\end{cases}
\]

两段分别满足

\[
\text{factor}-\frac43
=\frac{r(1-r)}9
\]

和

\[
\text{factor}-\frac43
=\frac{2(2r-1)(r-1)}{9r^3}.
\]

由 \(M(H)\ge8\)，全参数上均有

\[
\boxed{M(Q_r(H))\ge32/3.}
\]

## 越过 bounded-12 的 exact 样本

选取一个 rational centrally symmetric 12-gon \(H\)，并取 \(r=1/2\)。得到

\[
Q:28V/28F,
\qquad
Q^\circ:28V/28F,
\]

\[
|Q|=259/75,
\qquad
|Q^\circ|=34/9,
\]

\[
M(Q)=8806/675,
\qquad
M(Q)-32/3=1606/675.
\]

两侧各有 `112` 个 exact pulling boundary tetrahedra。vertex 与 normal matroids 均连通，且各自恰有一个 rank-\(2+3\) 的 exact \(\lambda=1\) 2-separation。因此该样本不属于 v42 的 \(\lambda=0\) 层，而是真正的高复杂度 \(\lambda=1\) 压力测试。

## 整个 \(\lambda=1\) 层的精确 reformulation

对一般 planar fiber map \(\mathcal F(z)\)，定义

\[
\mathcal F^\star(u)
=
\{v:\langle z,u\rangle+h_{\mathcal F(z)}(v)\le1\ \forall z\}.
\]

则

\[
|Q|=\int|\mathcal F(z)|dz,
\qquad
|Q^\circ|=\int|\mathcal F^\star(u)|du.
\]

所以整个 \(\lambda=1\) 层等价地要求证明

\[
\left(\int|\mathcal F|\right)
\left(\int|\mathcal F^\star|\right)
\ge32/3
\]

对相应的 Minkowski-concave、中心对称 set-valued fibers 成立。homothetic case \(\mathcal F=fH\) 正好退化为本轮已经关闭的 \(M(H)P_2(f)\) 情形。

## 下一缺口

完整 \(\lambda=1\) 层仍未关闭。现在的准确目标是证明上述 planar set-valued functional Mahler inequality，或构造一个 Mahler 不增的 fiber-shape normalization，把非同似 fibers 归约到 fixed-shape 情形。
