#!/usr/bin/env python3
"""Exact verifier for the v43 functional-lift and lambda-one sample package.

The general functional inequalities are external theorem interfaces.  This
script verifies all algebraic constants, polar/volume factorisations used in
the corollary, the complete piecewise rectangular-prismatic formula, and an
exact 28V/28F rational lambda-one pressure test.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path
from typing import Iterable

import sympy as sp

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "viterbo_global_lambda1_H12_sample_input_v43.json"
MATROID_CERT = ROOT / "viterbo_global_lambda1_H12_matroid_certificate_v43.json"
CERT = ROOT / "viterbo_global_functional_lift_mahler_certificate_v43.json"
OUT = ROOT / "viterbo_global_functional_lift_mahler_output_v43.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def F(value: object) -> Fraction:
    return Fraction(str(value))


def s(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def dot(a: Iterable[Fraction], b: Iterable[Fraction]) -> Fraction:
    return sum((x * y for x, y in zip(a, b)), Fraction(0))


def polygon_area(vertices: list[tuple[Fraction, Fraction]]) -> Fraction:
    total = Fraction(0)
    for p, q in zip(vertices, vertices[1:] + vertices[:1]):
        total += p[0] * q[1] - p[1] * q[0]
    return abs(total) / 2


def polar_polygon(vertices: list[tuple[Fraction, Fraction]]) -> list[tuple[Fraction, Fraction]]:
    polar: list[tuple[Fraction, Fraction]] = []
    for p, q in zip(vertices, vertices[1:] + vertices[:1]):
        determinant = p[0] * q[1] - p[1] * q[0]
        assert determinant > 0
        polar.append(((q[1] - p[1]) / determinant, (p[0] - q[0]) / determinant))
    return polar


def solve4(rows: list[tuple[Fraction, ...]]) -> tuple[Fraction, ...] | None:
    augmented = [list(row) + [Fraction(1)] for row in rows]
    for column in range(4):
        pivot = next((i for i in range(column, 4) if augmented[i][column]), None)
        if pivot is None:
            return None
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        pivot_value = augmented[column][column]
        augmented[column] = [x / pivot_value for x in augmented[column]]
        for i in range(4):
            if i == column or not augmented[i][column]:
                continue
            coefficient = augmented[i][column]
            augmented[i] = [
                augmented[i][j] - coefficient * augmented[column][j]
                for j in range(5)
            ]
    return tuple(augmented[i][4] for i in range(4))


def vertices_of_polar(normals: list[tuple[Fraction, ...]]) -> set[tuple[Fraction, ...]]:
    vertices: set[tuple[Fraction, ...]] = set()
    for indices in itertools.combinations(range(len(normals)), 4):
        candidate = solve4([normals[i] for i in indices])
        if candidate is None:
            continue
        if all(dot(normal, candidate) <= 1 for normal in normals):
            vertices.add(candidate)
    return vertices


def exact_rank(rows: list[tuple[Fraction, ...]]) -> int:
    return sp.Matrix([[sp.Rational(x.numerator, x.denominator) for x in row] for row in rows]).rank()


def pulling_boundary_tetrahedra(
    vertices: list[tuple[Fraction, ...]],
    facets: list[tuple[int, ...]],
) -> list[tuple[int, int, int, int]]:
    """Construct the global pulling boundary triangulation from the face lattice.

    In a four-polytope, every facet is three-dimensional.  Pulling first at the
    least vertex of the facet, and then at the least vertex of every opposite
    ridge, reduces the construction to the actual polygon edges.  Ridges and
    edges are recovered exactly as facet intersections of linear ranks three
    and two, respectively.  Proper supporting faces do not contain the origin,
    so linear rank equals affine dimension plus one.
    """
    facet_sets = [frozenset(facet) for facet in facets]
    ridge_sets = sorted(
        {
            intersection
            for i, first in enumerate(facet_sets)
            for second in facet_sets[i + 1 :]
            if len(intersection := first & second) >= 3
            and exact_rank([vertices[j] for j in sorted(intersection)]) == 3
        },
        key=lambda face: (len(face), tuple(sorted(face))),
    )
    edge_sets = sorted(
        {
            intersection
            for ridge in ridge_sets
            for facet in facet_sets
            if len(intersection := ridge & facet) >= 2
            and exact_rank([vertices[j] for j in sorted(intersection)]) == 2
        },
        key=lambda face: (len(face), tuple(sorted(face))),
    )
    assert all(len(edge) == 2 for edge in edge_sets)

    tetrahedra: set[tuple[int, int, int, int]] = set()
    for facet in facet_sets:
        apex = min(facet)
        facet_ridges = [ridge for ridge in ridge_sets if ridge < facet]
        for ridge in facet_ridges:
            if apex in ridge:
                continue
            ridge_apex = min(ridge)
            ridge_edges = [edge for edge in edge_sets if edge < ridge]
            for edge in ridge_edges:
                if ridge_apex in edge:
                    continue
                simplex = tuple(sorted((apex, ridge_apex, *edge)))
                assert len(simplex) == 4
                assert exact_rank([vertices[j] for j in simplex]) == 4
                tetrahedra.add(simplex)

    # Each boundary triangle must occur in exactly two tetrahedra.  This is an
    # exact closed-three-manifold check and catches incompatible local pulls.
    triangle_incidence = Counter(
        triangle
        for tetrahedron in tetrahedra
        for triangle in itertools.combinations(tetrahedron, 3)
    )
    assert triangle_incidence and set(triangle_incidence.values()) == {2}

    # Every tetrahedron belongs to exactly one original facet.
    for tetrahedron in tetrahedra:
        support_count = sum(set(tetrahedron) <= facet for facet in facet_sets)
        assert support_count == 1
    return sorted(tetrahedra)


def coned_boundary_volume(
    vertices: list[tuple[Fraction, ...]],
    tetrahedra: list[tuple[int, int, int, int]],
) -> Fraction:
    """Exact four-volume from cones over a closed boundary triangulation."""
    total = Fraction(0)
    for tetrahedron in tetrahedra:
        matrix = sp.Matrix(
            [
                [sp.Rational(value.numerator, value.denominator) for value in vertices[index]]
                for index in tetrahedron
            ]
        )
        determinant = sp.Rational(matrix.det(method="domain-ge"))
        total += Fraction(abs(int(determinant.p)), int(determinant.q)) / 24
    return total


def main() -> None:
    payload = json.loads(INPUT.read_text())
    matroid = json.loads(MATROID_CERT.read_text())
    assert matroid["status"] == "PASS"

    # ------------------------------------------------------------------
    # Exact constants in the two complexity-independent functional lifts.
    # P_m(f) is the Fradelizi--Nakhle functional factor in base dimension n.
    # ------------------------------------------------------------------
    n1_m3_functional = Fraction(4, 4)  # 4/(m+1)
    mahler_3d = Fraction(32, 3)
    n2_m2_functional = Fraction(16, 3 * 4)
    mahler_2d = Fraction(8)
    assert n1_m3_functional * mahler_3d == Fraction(32, 3)
    assert n2_m2_functional * mahler_2d == Fraction(32, 3)

    # ------------------------------------------------------------------
    # Complete symbolic formula for the rectangular--prismatic one-overlap
    # family.  H is any centrally symmetric planar body and r >= 0.
    # ------------------------------------------------------------------
    r = sp.symbols("r", positive=True)
    low_q = (3 + r) / 3
    low_polar = (4 - r) / 3
    low_factor = sp.factor(low_q * low_polar)
    assert sp.simplify(low_factor - sp.Rational(4, 3) - r * (1 - r) / 9) == 0

    x, t = sp.symbols("x t", nonnegative=True)
    low_q_integral = 4 * sp.integrate(
        (1 - (1 - r) * x) * (1 - x) ** 2,
        (x, 0, 1),
    )
    low_polar_integral = 4 * sp.integrate(
        (1 - r * t) * (1 - t) ** 2,
        (t, 0, 1),
    )
    assert sp.factor(low_q_integral - low_q) == 0
    assert sp.factor(low_polar_integral - low_polar) == 0

    high_q = 2 * (r + 1) / 3
    high_polar = (6 * r**2 - 4 * r + 1) / (3 * r**3)
    high_factor = sp.factor(high_q * high_polar)
    assert sp.simplify(high_factor - sp.Rational(4, 3) - 2 * (2 * r - 1) * (r - 1) / (9 * r**3)) == 0
    assert sp.factor(low_factor.subs(r, 1) - high_factor.subs(r, 1)) == 0

    # The one-dimensional radial integral used in the r >= 1 chamber.
    high_q_integral = 4 * (
        sp.integrate(
            (1 + (r - 1) * x) * (1 - x) ** 2,
            (x, 0, 1),
        )
        + sp.integrate(
            sp.integrate(
                ((r - t) / (r - 1)) ** 2,
                (t, 1 + (r - 1) * x, r),
            ),
            (x, 0, 1),
        )
    )
    assert sp.factor(high_q_integral - high_q) == 0

    radial_moment = sp.integrate((1 - r * t) * (1 - t) ** 2, (t, 0, 1 / r))
    assert sp.factor(radial_moment - (6 * r**2 - 4 * r + 1) / (12 * r**3)) == 0

    # ------------------------------------------------------------------
    # Exact H_12 sample.
    # ------------------------------------------------------------------
    H = [tuple(F(x) for x in row) for row in payload["H_vertices"]]
    H_polar_stored = [tuple(F(x) for x in row) for row in payload["H_polar_vertices"]]
    assert len(H) == len(set(H)) == 12
    assert all(H[(i + 6) % 12] == (-H[i][0], -H[i][1]) for i in range(6))
    cross_products = [
        H[i][0] * H[(i + 1) % 12][1] - H[i][1] * H[(i + 1) % 12][0]
        for i in range(12)
    ]
    assert all(value > 0 for value in cross_products)
    H_polar = polar_polygon(H)
    assert H_polar == H_polar_stored
    for i, w in enumerate(H_polar):
        values = [dot(v, w) for v in H]
        assert max(values) == 1
        assert {j for j, value in enumerate(values) if value == 1} == {i, (i + 1) % 12}

    area_H = polygon_area(H)
    area_H_polar = polygon_area(H_polar)
    product_H = area_H * area_H_polar
    assert area_H == Fraction(74, 25)
    assert area_H_polar == Fraction(68, 21)
    assert product_H == Fraction(5032, 525)
    assert product_H > 8

    sample_r = Fraction(payload["parameter_r"])
    assert sample_r == Fraction(1, 2)
    volume_Q = area_H * (3 + sample_r) / 3
    volume_Q_polar = area_H_polar * (4 - sample_r) / 3
    mahler_Q = volume_Q * volume_Q_polar
    margin_Q = mahler_Q - Fraction(32, 3)
    assert volume_Q == Fraction(259, 75)
    assert volume_Q_polar == Fraction(34, 9)
    assert mahler_Q == Fraction(8806, 675)
    assert margin_Q == Fraction(1606, 675) > 0

    # Full vertex lists of Q and Q^o.
    Q_vertices: list[tuple[Fraction, ...]] = [
        (Fraction(sx), Fraction(st) * sample_r, Fraction(0), Fraction(0))
        for sx in (-1, 1)
        for st in (-1, 1)
    ]
    Q_vertices += [
        (Fraction(0), Fraction(st), x, y)
        for st in (-1, 1)
        for x, y in H
    ]
    P_vertices: list[tuple[Fraction, ...]] = [
        (Fraction(su), Fraction(0), x, y)
        for su in (-1, 1)
        for x, y in H_polar
    ]
    P_vertices += [
        (Fraction(su) * (1 - sample_r), Fraction(st), Fraction(0), Fraction(0))
        for st in (-1, 1)
        for su in (-1, 1)
    ]
    assert len(Q_vertices) == len(set(Q_vertices)) == 28
    assert len(P_vertices) == len(set(P_vertices)) == 28

    # Exhaustively enumerate all intersections of four support inequalities.
    # This certifies that the displayed lists are the complete dual vertex sets.
    enumerated_P = vertices_of_polar(Q_vertices)
    enumerated_Q = vertices_of_polar(P_vertices)
    assert enumerated_P == set(P_vertices)
    assert enumerated_Q == set(Q_vertices)

    # Facet incidence and exact nonredundancy checks.
    Q_facets = [
        tuple(i for i, q in enumerate(Q_vertices) if dot(q, p) == 1)
        for p in P_vertices
    ]
    P_facets = [
        tuple(i for i, p in enumerate(P_vertices) if dot(p, q) == 1)
        for q in Q_vertices
    ]
    assert len(set(Q_facets)) == 28 and len(set(P_facets)) == 28
    assert Counter(map(len, Q_facets)) == Counter({6: 24, 13: 4})
    assert Counter(map(len, P_facets)) == Counter({6: 24, 13: 4})
    for facet in Q_facets:
        assert exact_rank([Q_vertices[i] for i in facet]) == 4
    for facet in P_facets:
        assert exact_rank([P_vertices[i] for i in facet]) == 4

    # Independent face-lattice/volume audit: recover a compatible global
    # pulling triangulation from the exact facet incidences, check that it is a
    # closed boundary, and recompute both four-volumes from cone determinants.
    Q_tetrahedra = pulling_boundary_tetrahedra(Q_vertices, Q_facets)
    P_tetrahedra = pulling_boundary_tetrahedra(P_vertices, P_facets)
    assert len(Q_tetrahedra) == 112
    assert len(P_tetrahedra) == 112
    triangulated_volume_Q = coned_boundary_volume(Q_vertices, Q_tetrahedra)
    triangulated_volume_P = coned_boundary_volume(P_vertices, P_tetrahedra)
    assert triangulated_volume_Q == volume_Q
    assert triangulated_volume_P == volume_Q_polar

    vertex_cfg = matroid["vertex_configuration"]
    normal_cfg = matroid["normal_configuration"]
    assert vertex_cfg["connected"] and normal_cfg["connected"]
    assert vertex_cfg["exact_lambda1_two_separation_count"] == 1
    assert normal_cfg["exact_lambda1_two_separation_count"] == 1
    vertex_sep = vertex_cfg["exact_lambda1_two_separations"][0]
    normal_sep = normal_cfg["exact_lambda1_two_separations"][0]
    assert sorted((vertex_sep["rank_A"], vertex_sep["rank_B"])) == [2, 3]
    assert sorted((normal_sep["rank_A"], normal_sep["rank_B"])) == [2, 3]
    assert vertex_sep["overlap_normal_form"]["overlap_dimension"] == 1
    assert normal_sep["overlap_normal_form"]["overlap_dimension"] == 1

    certificate = {
        "status": "PASS",
        "scope": "4D centrally symmetric Mahler: functional lifts and homothetic-fiber lambda=1 subclass",
        "theorem_interfaces": {
            "functional_factorization": {
                "statement": "M(K_{L,m}(f)) = M(L) P_m(f)",
                "source": "Fradelizi--Nakhle, arXiv:2412.12372v2, equations (2.1) and Section 2.1",
            },
            "base_dimension_1": {
                "statement": "P_m(f) >= 4/(m+1) for even concave f on R and integer m",
                "specialization": {"m": 3, "lower_bound": "1"},
                "source": "Fradelizi--Nakhle, Theorem 3.1",
            },
            "base_dimension_2": {
                "statement": "P_m(f) >= 16/((m+1)(m+2)) for even concave f on R^2 and integer m",
                "specialization": {"m": 2, "lower_bound": "4/3"},
                "source": "Fradelizi--Nakhle, Theorem 1.3 / equation (2.1)",
            },
            "lower_dimensional_geometric_Mahler": {
                "dimension_2": "M(L) >= 8",
                "dimension_3": "M(L) >= 32/3",
            },
        },
        "closed_functional_lift_classes": {
            "one_dimensional_base_three_dimensional_fiber": {
                "body": "K_{L,3}(f)={(x,y): ||y||_L <= f(x)}, x in R, y in R^3",
                "factor_lower_bounds": ["M(L)>=32/3", "P_3(f)>=1"],
                "conclusion": "M(K_{L,3}(f))>=32/3",
            },
            "two_dimensional_base_two_dimensional_fiber": {
                "body": "K_{L,2}(f)={(x,y): ||y||_L <= f(x)}, x,y in R^2",
                "factor_lower_bounds": ["M(L)>=8", "P_2(f)>=4/3"],
                "conclusion": "M(K_{L,2}(f))>=32/3",
            },
        },
        "lambda1_set_valued_reformulation": {
            "fiber_form": "Q={(z,y): y in F(z)}, z,y in R^2",
            "Minkowski_concavity": "F((1-s)z0+s z1) contains (1-s)F(z0)+sF(z1)",
            "central_symmetry": "F(-z)=-F(z)",
            "polar_transform": "F*(u)={v: <z,u>+h_{F(z)}(v)<=1 for every z}",
            "polar_fiber_form": "Q^o={(u,v): v in F*(u)}",
            "target": "(integral area(F(z)) dz)*(integral area(F*(u)) du)>=32/3",
            "homothetic_specialization": "F(z)=f(z)H gives F*(u)=L(f)(u)H^o and M(Q)=M(H)P_2(f)",
            "status": "exact reformulation; general set-valued inequality remains open",
        },
        "rectangular_prismatic_family": {
            "definition": "Q_r(H)=conv(([-1,1]x[-r,r])x{0}, {0}x([-1,1]xH))",
            "parameter_domain": "r>=0, H any centrally symmetric planar convex body",
            "low_chamber_0_le_r_le_1": {
                "volume_over_area_H": str(low_q),
                "polar_volume_over_area_Hpolar": str(low_polar),
                "Mahler_factor_times_MH": str(low_factor),
                "factor_minus_4_over_3": "r*(1-r)/9",
            },
            "high_chamber_r_ge_1": {
                "volume_over_area_H": str(high_q),
                "polar_volume_over_area_Hpolar": str(high_polar),
                "Mahler_factor_times_MH": str(high_factor),
                "factor_minus_4_over_3": "2*(2*r-1)*(r-1)/(9*r^3)",
            },
            "finite_equality_statement": "For r>0, equality can occur only at r=1 and M(H)=8; r=0 is the free-sum endpoint.",
        },
        "exact_H12_pressure_test": {
            "parameter_r": s(sample_r),
            "area_H": s(area_H),
            "area_Hpolar": s(area_H_polar),
            "Mahler_H": s(product_H),
            "vertices_Q": len(Q_vertices),
            "facets_Q": len(Q_facets),
            "vertices_Qpolar": len(P_vertices),
            "facets_Qpolar": len(P_facets),
            "facet_size_histogram_each_side": {str(k): v for k, v in sorted(Counter(map(len, Q_facets)).items())},
            "pulling_boundary_tetrahedra_Q": len(Q_tetrahedra),
            "pulling_boundary_tetrahedra_Qpolar": len(P_tetrahedra),
            "closed_boundary_triangle_incidence_each_side": 2,
            "triangulated_volume_Q": s(triangulated_volume_Q),
            "triangulated_volume_Qpolar": s(triangulated_volume_P),
            "volume_Q": s(volume_Q),
            "volume_Qpolar": s(volume_Q_polar),
            "Mahler_product": s(mahler_Q),
            "Mahler_margin_over_32_3": s(margin_Q),
            "vertex_matroid_connected": True,
            "normal_matroid_connected": True,
            "unique_exact_lambda1_two_separation_each_side": True,
            "vertex_overlap_line": vertex_sep["overlap_normal_form"]["overlap_line_primitive"],
            "normal_overlap_line": normal_sep["overlap_normal_form"]["overlap_line_primitive"],
            "complete_dual_vertex_enumeration": True,
        },
        "source_hashes": {
            INPUT.name: sha256(INPUT),
            MATROID_CERT.name: sha256(MATROID_CERT),
        },
        "scope_warning": (
            "The functional inequalities and the 2D/3D Mahler bounds are external theorem interfaces. "
            "This verifier checks the specializations, exact factorization constants, the full explicit "
            "one-parameter formula, and the finite rational pressure test.  It does not close arbitrary "
            "lambda-one gluings whose transverse planar fibers change shape non-homothetically."
        ),
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    output = {
        "status": "PASS",
        "functional_lift_1_plus_3": "closed by external functional and 3D Mahler theorems",
        "functional_lift_2_plus_2": "closed by external functional and 2D Mahler theorems",
        "rectangular_prismatic_all_r": True,
        "sample_combinatorics": "28V/28F dual to 28V/28F",
        "sample_boundary_tetrahedra_each_side": 112,
        "sample_Mahler_product": s(mahler_Q),
        "sample_margin": s(margin_Q),
        "sample_vertex_normal_matroids": "connected with one exact lambda=1 2-separation each",
        "lambda1_set_valued_target": "exactly formulated; non-homothetic case open",
        "certificate": CERT.name,
        "certificate_sha256": sha256(CERT),
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
