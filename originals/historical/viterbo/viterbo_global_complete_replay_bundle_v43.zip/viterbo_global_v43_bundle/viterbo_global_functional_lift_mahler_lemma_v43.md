# 四维 Mahler 的 functional-lift 归约与 \(\lambda=1\) 同似纤维闭包

**日期：** 2026-09-05  
**状态：** 外部定理推论 + exact symbolic/combinatorial verification  
**解释：** 本文关闭一个复杂度无关的四维凸体类别，并关闭一大类真正的向量拟阵 \(\lambda=1\) gluing。它不是完整四维中心对称 Mahler 猜想的证明。

---

## 1. Functional lift

令 \(L=-L\subset\mathbb R^m\) 为中心对称凸体，\(f:\mathbb R^n\to\mathbb R_+\) 为偶的、在其支集上凹的可积函数。定义

\[
K_{L,m}(f)
=
\{(x,y)\in\mathbb R^n\times\mathbb R^m:
\|y\|_L\le f(x)\}.
\]

定义函数极性

\[
\mathcal L f(u)
=
\inf_x\frac{(1-\langle x,u\rangle)_+}{f(x)}.
\]

Fradelizi--Nakhle 的构造给出

\[
K_{L,m}(f)^\circ
=
K_{L^\circ,m}(\mathcal L f),
\]

\[
|K_{L,m}(f)|
=
|L|\int_{\mathbb R^n}f(x)^m\,dx,
\]

以及精确因子化

\[
\boxed{
M(K_{L,m}(f))
=
M(L)P_m(f),
}
\]

其中

\[
P_m(f)
=
\left(\int f^m\right)
\left(\int(\mathcal L f)^m\right).
\]

当前使用的两个函数型下界是

\[
P_m(f)\ge\frac4{m+1}
\qquad(n=1),
\]

以及

\[
P_m(f)\ge
\frac{16}{(m+1)(m+2)}
\qquad(n=2,\ m\in\mathbb N).
\]

这些是不在本包中重新形式化的外部解析定理。本包验证它们在四维所需的常数代入、极性因子化接口、显式子族和有限压力测试。

---

## 2. 两个复杂度无关的四维闭包

### 2.1 一维底座、三维同似纤维

取 \(n=1,m=3\)。三维中心对称 Mahler 定理给出

\[
M(L)\ge\frac{32}{3},
\]

而函数型定理给出

\[
P_3(f)\ge\frac4{3+1}=1.
\]

所以

\[
\boxed{
M(K_{L,3}(f))\ge\frac{32}{3}.
}
\]

因此，所有沿一条直线具有同心、同似三维截面的四维中心对称凸体都满足猜想；纤维 \(L\) 的组合复杂度完全不受限制。

### 2.2 二维底座、二维同似纤维

取 \(n=2,m=2\)。二维中心对称 Mahler 定理给出

\[
M(L)\ge8,
\]

函数型定理给出

\[
P_2(f)\ge
\frac{16}{3\cdot4}
=
\frac43.
\]

所以

\[
\boxed{
M(K_{L,2}(f))\ge
8\cdot\frac43
=
\frac{32}{3}.
}
\]

这关闭了所有具有同心、同似平面纤维的四维中心对称凸体。

---

## 3. 与向量拟阵 \(\lambda=1\) 分离的接口

设四维向量配置有一个 exact \(2\)-separation：

\[
E=E_2\sqcup E_3,
\qquad
r(E_2)=2,
\qquad
r(E_3)=3,
\]

\[
\lambda(E_2)
=r(E_2)+r(E_3)-4
=1.
\]

则两个 span 的交为一条直线。经过有理线性换元，可取坐标

\[
\mathbb R^4
=
\mathbb R_x\oplus\mathbb R_t\oplus\mathbb R_y^2,
\]

使 rank-two side 位于

\[
U=\mathbb R_x\oplus\mathbb R_t,
\]

rank-three side 位于

\[
W=\mathbb R_t\oplus\mathbb R_y^2,
\]

且

\[
U\cap W=\mathbb R_t.
\]

考虑

\[
Q=\operatorname{conv}(A\cup B),
\]

其中 \(A=-A\subset U\) 是二维凸体，\(B=-B\subset W\) 是三维凸体。

假设 rank-three side 的横向二维截面同似，即存在平面中心对称凸体 \(H\) 和偶凹函数 \(g\)，使

\[
B
=
\{(0,s,y):\|y\|_H\le g(s)\}.
\]

定义 base 上的 roof function

\[
\begin{aligned}
f(x,t)=\sup\{&(1-\alpha)g(s):
0\le\alpha\le1,\ a=(a_x,a_t)\in A,\\
&(x,t)=\alpha(a_x,a_t)+(1-\alpha)(0,s)\}.
\end{aligned}
\]

由凸包定义，\(f\) 是偶函数并在其支集上凹，而且

\[
\boxed{
Q
=
\{(x,t,y):\|y\|_H\le f(x,t)\}
=
K_{H,2}(f).
}
\]

因此

\[
\boxed{M(Q)\ge\frac{32}{3}.}
\]

如果 \(\lambda=1\) 分离出现在 facet-normal configuration 而不是 vertex configuration，则对极体应用同一结论，并利用

\[
M(Q)=M(Q^\circ).
\]

由此得到本轮的 \(\lambda=1\) 闭包：

\[
\boxed{
\begin{aligned}
&\text{所有具有 }2+3\text{ 一维重叠分离，且 rank-three side}\
&\text{具有同心同似二维横截面的四维中心对称凸体，满足 Mahler 下界。}
\end{aligned}
}
\]

剩余的真正 \(\lambda=1\) 障碍被压缩为：rank-three side 的平面截面随共同坐标改变**形状**，而非只改变同似尺度。

---

## 4. 一个全参数、任意平面纤维的显式 \(\lambda=1\) 族

令 \(H=-H\subset\mathbb R^2\) 为任意平面中心对称凸体，并定义

\[
Q_r(H)
=
\operatorname{conv}
\left(
([-1,1]\times[-r,r])\times\{0\},
\{0\}\times([-1,1]\times H)
\right),
\qquad r\ge0.
\]

坐标依次为 \((x,t,y)\in\mathbb R\times\mathbb R\times\mathbb R^2\)。这是一个 rank-two side 与 rank-three side 沿 \(t\)-axis 相交的典型 \(\lambda=1\) gluing。

其极体具有特别简单的描述：

\[
\boxed{
Q_r(H)^\circ
=
\{(u,v,w):
|u|+r|v|\le1,
\ |v|+\|w\|_{H^\circ}\le1\}.
}
\]

### 4.1 区间 \(0\le r\le1\)

roof function 为

\[
f_r(x,t)=1-|x|
\]

在

\[
|x|\le1,
\qquad
|t|\le1-(1-r)|x|
\]

上成立，域外为零。精确积分给出

\[
|Q_r(H)|
=|H|\frac{3+r}{3},
\]

\[
|Q_r(H)^\circ|
=|H^\circ|\frac{4-r}{3}.
\]

因此

\[
M(Q_r(H))
=M(H)\frac{(3+r)(4-r)}9,
\]

并且

\[
\frac{(3+r)(4-r)}9-rac43
=
\frac{r(1-r)}9\ge0.
\]

### 4.2 区间 \(r\ge1\)

此时

\[
f_r(x,t)
=
1-
\max\left
\{
|x|,
\frac{(|t|-1)_+}{r-1}
\right\}
\]

在右侧最大值不超过 \(1\) 的区域上成立。精确积分给出

\[
|Q_r(H)|
=|H|\frac{2(r+1)}3,
\]

\[
|Q_r(H)^\circ|
=|H^\circ|
\frac{6r^2-4r+1}{3r^3}.
\]

于是

\[
M(Q_r(H))
=M(H)
\frac{2(r+1)(6r^2-4r+1)}{9r^3},
\]

并且

\[
\frac{2(r+1)(6r^2-4r+1)}{9r^3}
-
\frac43
=
\frac{2(2r-1)(r-1)}{9r^3}
\ge0.
\]

结合 \(M(H)\ge8\)，得到

\[
\boxed{
M(Q_r(H))\ge\frac{32}{3}
\qquad\forall r\ge0.
}
\]

对有限 \(r>0\)，等号只能出现在

\[
r=1,
\qquad
M(H)=8,
\]

即 \(H\) 为平行四边形的情形。\(r=0\) 是已经由 v42 关闭的 direct/free-sum 端点。

---

## 5. 一个越过 bounded-12 且真正落在 \(\lambda=1\) 层的 exact 样本

取十二边形

\[
\begin{aligned}
H=\operatorname{conv}\{&
(1,0),(4/5,3/5),(3/5,4/5),(0,1),\\
&(-3/5,4/5),(-4/5,3/5),
\text{及其负点}\}.
\end{aligned}
\]

精确得到

\[
|H|=\frac{74}{25},
\qquad
|H^\circ|=\frac{68}{21},
\]

\[
M(H)=\frac{5032}{525}>8.
\]

在

\[
r=\frac12
\]

处：

\[
|Q|=\frac{259}{75},
\qquad
|Q^\circ|=\frac{34}{9},
\]

\[
\boxed{
M(Q)=\frac{8806}{675}
}
\]

以及

\[
\boxed{
M(Q)-\frac{32}{3}
=\frac{1606}{675}>0.
}
\]

### 5.1 完整组合与体积审计

exact four-constraint intersection enumeration 重建两侧的全部极点：

\[
\boxed{Q:28V/28F,\qquad Q^\circ:28V/28F.}
\]

两侧 facet-size histogram 相同：

\[
24\text{ 个六顶点 facets}
+
4\text{ 个十三顶点 facets}.
\]

从精确 face incidences 自动构造 global pulling triangulation，每一侧均得到

\[
\boxed{112\text{ 个 boundary tetrahedra}.}
\]

每个 boundary triangle 恰属于两个 tetrahedra；将 tetrahedra 与原点作锥后，exact determinant volume sums 独立恢复

\[
\frac{259}{75}
\qquad\text{和}\qquad
\frac{34}{9}.
\]

### 5.2 分离审计

vertex vector matroid 与 facet-normal vector matroid 均连通，因此样本不属于 v42 已关闭的 \(\lambda=0\) 直积/free-sum 层。

两侧各自恰有一个 exact \(\lambda=1\) 2-separation：

\[
(\operatorname{rank}2)+(\operatorname{rank}3)-4=1.
\]

normal-form analyzer 精确恢复两个 span 的一维交，并将配置变换到

\[
(x,t,0,0)
\qquad\text{和}\qquad
(0,t,y_1,y_2)
\]

的 \(2+3\)-over-a-line 标准形。

所以这个 `28V/28F` 样本同时满足：

1. 完全越过 bounded-12；
2. primal/dual matroids 都连通；
3. 真正处于 \(\lambda=1\) 层；
4. 被本轮 functional-lift 定理关闭。

---

## 6. 整个 \(\lambda=1\) 层的 set-valued functional reformulation

对一般的 \(2+3\)-over-a-line gluing，不再假设 rank-three side 的横向截面同似。仍取 base 坐标

\[
z=(x,t)\in\mathbb R^2
\]

和 transverse 坐标

\[
y\in\mathbb R^2.
\]

把四维凸体写成 planar-fiber form：

\[
Q=\{(z,y):y\in\mathcal F(z)\},
\]

其中 \(\mathcal F(z)\) 是可能为空的平面凸集。凸性等价地给出 set-valued Minkowski concavity：

\[
\mathcal F((1-s)z_0+sz_1)
\supset
(1-s)\mathcal F(z_0)+s\mathcal F(z_1),
\qquad0\le s\le1.
\]

中心对称性给出

\[
\mathcal F(-z)=-\mathcal F(z).
\]

定义 set-valued polar transform

\[
\boxed{
\mathcal F^\star(u)
=
\left\{
 v\in\mathbb R^2:
 \langle z,u\rangle+h_{\mathcal F(z)}(v)\le1
 \quad\forall z
\right\}.
}
\]

直接由极性定义可得

\[
Q^\circ
=
\{(u,v):v\in\mathcal F^\star(u)\}.
\]

因此

\[
|Q|
=
\int_{\mathbb R^2}|\mathcal F(z)|\,dz,
\]

\[
|Q^\circ|
=
\int_{\mathbb R^2}|\mathcal F^\star(u)|\,du.
\]

整个 \(\lambda=1\) 层于是被精确改写为以下二维 set-valued functional inequality：

\[
\boxed{
\left(\int|\mathcal F(z)|\,dz\right)
\left(\int|\mathcal F^\star(u)|\,du\right)
\ge\frac{32}{3}.
}
\]

在本轮已经关闭的 homothetic case

\[
\mathcal F(z)=f(z)H
\]

中，

\[
\mathcal F^\star(u)
=(\mathcal Lf)(u)H^\circ,
\]

所以 set-valued inequality 精确退化为

\[
M(H)P_2(f)\ge\frac{32}{3}.
\]

这给出了下一阶段非常明确的目标：把 Fradelizi--Nakhle 的标量 functional Mahler 不等式提升为 planar set-valued 版本。若该提升对由 \(\lambda=1\) gluing 产生的 Minkowski-concave fibers 成立，则整个 \(\lambda=1\) 层一次关闭。

本文目前只证明其 fixed-shape scalar slice，不声称已经证明 set-valued 版本。

---

## 7. 本轮闭包与剩余缺口

本轮新关闭的复杂度无关类别为：

\[
\boxed{
\begin{array}{l}
\text{一维底座 + 任意三维固定形状的同似纤维；}\\
\text{二维底座 + 任意二维固定形状的同似纤维；}\\
\text{由此包含的 }\lambda=1\text{ homothetic-fiber gluings；}\\
\text{显式 }Q_r(H)\text{ 全参数族，}H\text{ 可有任意复杂度。}
\end{array}
}
\]

任意尚未排除的 \(\lambda=1\) 反例候选必须逃离这一结构。具体说，在 primal 或 polar 的 \(2+3\) 标准形中，rank-three component 的 transverse planar sections 必须发生非同似形状变化。

这把下一阶段压缩为一个明确问题：

\[
\boxed{
\text{能否通过 Mahler 不增的 shadow、localization 或 set-valued functional inequality，}
}
\]

\[
\boxed{
\text{把任意三维纤维体的非同似平面截面归约到同似截面？}
}
\]

若答案为肯定，则整个 \(\lambda=1\) 层将被关闭。当前包没有证明这一最后一步。

---

## 8. 验证范围

机器部分精确验证：

- 两个四维 functional-lift 常数乘积；
- 显式 \(Q_r(H)\) 两个参数 chamber 的全部积分与因子化；
- 十二边形及极体面积；
- `28V/28F` 的完整 primal/polar vertex enumeration；
- facet incidences 与 facet-size histogram；
- 每侧 `112` 个 tetrahedra 的闭边界检查；
- 两侧 exact determinant volume sums；
- vertex/normal matroid 连通性；
- 两侧唯一 exact \(\lambda=1\) separation 与有理标准形。

外部解析接口是：Fradelizi--Nakhle 的 functional Mahler 不等式、二维中心对称 Mahler 定理和三维中心对称 Mahler 定理。它们没有在 Python 中重新证明。
