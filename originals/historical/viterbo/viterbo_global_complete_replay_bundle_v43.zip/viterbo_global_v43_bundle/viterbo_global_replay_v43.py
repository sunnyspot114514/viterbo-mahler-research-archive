#!/usr/bin/env python3
"""Integrity and optional exact rebuild driver for v43.

v43 adds complexity-independent functional-lift closures, a lambda-one
2+3-over-a-line normal-form analyzer, a complete rectangular-prismatic family,
and an exact 28V/28F pressure test.  v42 is replayed as an inherited integrity
and semantics checkpoint.  All v43 computations are rebuilt with --rebuild.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "viterbo_global_progress_manifest_v43.json"
OUT = ROOT / "viterbo_global_replay_output_v43.json"
INHERITED_BUNDLE = ROOT / "viterbo_global_complete_replay_bundle_v42.zip"
EXPECTED_V42_SHA256 = "d96d78f3a2f2b427d609bd3dd33905e55e8cd59cb04f03c581db8f38466b84db"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def run(arguments: list[str], timeout: int = 1800) -> None:
    completed = subprocess.run(
        [sys.executable, *arguments],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if completed.returncode != 0:
        raise AssertionError(
            {
                "arguments": arguments,
                "returncode": completed.returncode,
                "stdout_tail": completed.stdout[-12000:],
                "stderr_tail": completed.stderr[-12000:],
            }
        )


def replay_inherited_v42() -> dict:
    assert sha256(INHERITED_BUNDLE) == EXPECTED_V42_SHA256
    with tempfile.TemporaryDirectory(prefix="viterbo_v42_replay_") as temporary:
        temporary_path = Path(temporary)
        with zipfile.ZipFile(INHERITED_BUNDLE) as archive:
            archive.extractall(temporary_path)
        candidates = list(temporary_path.rglob("viterbo_global_replay_v42.py"))
        assert len(candidates) == 1
        driver = candidates[0]
        completed = subprocess.run(
            [sys.executable, str(driver)],
            cwd=str(driver.parent),
            capture_output=True,
            text=True,
            timeout=1800,
        )
        if completed.returncode != 0:
            raise AssertionError(
                {
                    "inherited_driver": str(driver),
                    "returncode": completed.returncode,
                    "stdout_tail": completed.stdout[-12000:],
                    "stderr_tail": completed.stderr[-12000:],
                }
            )
        result = json.loads(
            (driver.parent / "viterbo_global_replay_output_v42.json").read_text()
        )
        assert result["status"] == "PASS"
        assert result["bounded12"] == "closed proof candidate"
        assert result["full_4D_symmetric_Mahler"] == "open"
        return {
            "status": "PASS",
            "bounded12": result["bounded12"],
            "lambda0": result["decomposable_4D_direct_products_and_free_sums"],
        }


def rebuild_v43() -> None:
    run(
        [
            str(ROOT / "viterbo_lambda1_normal_form_analyzer_v43.py"),
            str(ROOT / "viterbo_global_lambda1_H12_sample_input_v43.json"),
            "--certificate",
            str(ROOT / "viterbo_global_lambda1_H12_matroid_certificate_v43.json"),
            "--output",
            str(ROOT / "viterbo_global_lambda1_H12_matroid_output_v43.json"),
        ],
        1200,
    )
    run([str(ROOT / "viterbo_global_functional_lift_mahler_verifier_v43.py")], 1800)


def verify_manifest() -> dict:
    manifest = json.loads(MANIFEST.read_text())
    assert manifest["status"] == "PASS"
    checked = 0
    total_bytes = 0
    for name, record in manifest["files"].items():
        path = ROOT / name
        assert path.is_file(), name
        assert path.stat().st_size == record["bytes"], name
        assert sha256(path) == record["sha256"], name
        checked += 1
        total_bytes += path.stat().st_size
    return {
        "manifest_sha256": sha256(MANIFEST),
        "files_checked": checked,
        "bytes_checked": total_bytes,
    }


def verify_semantics() -> dict:
    matroid_output = json.loads(
        (ROOT / "viterbo_global_lambda1_H12_matroid_output_v43.json").read_text()
    )
    matroid_certificate = json.loads(
        (ROOT / "viterbo_global_lambda1_H12_matroid_certificate_v43.json").read_text()
    )
    functional_output = json.loads(
        (ROOT / "viterbo_global_functional_lift_mahler_output_v43.json").read_text()
    )
    functional_certificate = json.loads(
        (ROOT / "viterbo_global_functional_lift_mahler_certificate_v43.json").read_text()
    )
    status = json.loads((ROOT / "viterbo_global_status_20260905_v43.json").read_text())

    assert matroid_output["status"] == "PASS"
    assert matroid_output["vertex_connected"] is True
    assert matroid_output["normal_connected"] is True
    assert matroid_output["vertex_lambda1_two_separations"] == 1
    assert matroid_output["normal_lambda1_two_separations"] == 1
    assert matroid_certificate["vertex_configuration"]["minimum_lambda_sides_at_least_2"] == 1
    assert matroid_certificate["normal_configuration"]["minimum_lambda_sides_at_least_2"] == 1

    assert functional_output["status"] == "PASS"
    assert functional_output["functional_lift_1_plus_3"].startswith("closed")
    assert functional_output["functional_lift_2_plus_2"].startswith("closed")
    assert functional_output["rectangular_prismatic_all_r"] is True
    assert functional_output["sample_combinatorics"] == "28V/28F dual to 28V/28F"
    assert functional_output["sample_boundary_tetrahedra_each_side"] == 112
    assert functional_output["sample_Mahler_product"] == "8806/675"
    assert functional_output["sample_margin"] == "1606/675"
    assert functional_output["lambda1_set_valued_target"].endswith("open")

    sample = functional_certificate["exact_H12_pressure_test"]
    assert sample["vertices_Q"] == sample["facets_Q"] == 28
    assert sample["vertices_Qpolar"] == sample["facets_Qpolar"] == 28
    assert sample["pulling_boundary_tetrahedra_Q"] == 112
    assert sample["pulling_boundary_tetrahedra_Qpolar"] == 112
    assert sample["triangulated_volume_Q"] == sample["volume_Q"] == "259/75"
    assert sample["triangulated_volume_Qpolar"] == sample["volume_Qpolar"] == "34/9"
    assert sample["vertex_matroid_connected"] is True
    assert sample["normal_matroid_connected"] is True
    assert sample["unique_exact_lambda1_two_separation_each_side"] is True
    assert functional_certificate["lambda1_set_valued_reformulation"]["status"].endswith("open")

    assert status["new_results"]["functional_lift_1_plus_3"]["status"] == "closed"
    assert status["new_results"]["functional_lift_2_plus_2"]["status"] == "closed"
    assert status["new_results"]["lambda1_homothetic_fiber_subclass"]["status"] == "closed"
    assert status["full_4D_symmetric_Mahler"] == "open"

    return {
        "functional_lift_1_plus_3": "closed",
        "functional_lift_2_plus_2": "closed",
        "lambda1_homothetic_fiber_subclass": "closed",
        "rectangular_prismatic_all_r": True,
        "H12_pressure_test": "28V/28F dual to 28V/28F",
        "H12_boundary_tetrahedra_each_side": 112,
        "H12_Mahler_product": "8806/675",
        "H12_margin": "1606/675",
        "H12_vertex_normal_matroids": "connected with one exact lambda=1 separation each",
        "remaining_lambda1_obstruction": "non-homothetic transverse planar fiber-shape variation",
        "full_4D_symmetric_Mahler": "open",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()

    inherited = replay_inherited_v42()
    if args.rebuild:
        rebuild_v43()
    manifest = verify_manifest()
    semantics = verify_semantics()
    result = {
        "status": "PASS",
        "rebuild": args.rebuild,
        "inherited_v42_replayed": True,
        "inherited_v42": inherited,
        **manifest,
        **semantics,
        "scope_warning": (
            "The functional inequalities and the 2D/3D Mahler bounds are external theorem "
            "interfaces. v43 closes the homothetic-fiber subclass, not every lambda-one gluing."
        ),
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
