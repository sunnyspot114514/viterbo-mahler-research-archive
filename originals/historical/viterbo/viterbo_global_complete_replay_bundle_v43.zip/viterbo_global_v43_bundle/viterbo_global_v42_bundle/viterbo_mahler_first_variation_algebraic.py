#!/usr/bin/env python3
"""Exact first-variation and Mahler-stress analyzer for centrally symmetric 4-polytopes.

Input JSON schema (shared with viterbo_bishadow_kernel_analyzer.py):

  {
    "name": "...",
    "vertex_pair_representatives": [[...], ...],
    "facet_normal_pair_representatives": [[...], ...]
  }

Entries may lie in a real algebraic number field (tested over Q(sqrt(2))).  Facet normals are normalized so that the positive
facet has equation <n,x>=1.  The analyzer reconstructs the complete signed
boundary, a face-lattice-compatible pulling triangulation, exact primal and
polar volumes, their gradients with respect to arbitrary odd vertex velocities,
and the Jacobian of all facet-coplanarity equations.

At a regular realization-stratum point the exact KKT condition is

    grad Mahler in rowspan(J),

where J is the determinant-equation Jacobian.  Failure gives an exact
compatible descent tangent; if J has full row rank, the implicit function
theorem makes that tangent locally integrable inside the fixed face lattice.

The script is dimension-four specific only in its boundary triangulation and
normalization constants.  All arithmetic after the combinatorial pulling choice
is exact over Q.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Iterable

import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
from sympy.polys.matrices import DomainMatrix

ALGEBRAIC_FIELD = sp.QQ.algebraic_field(sp.sqrt(2))

DIM = 4
FACT = math.factorial(DIM)


def parse_q(value) -> sp.Expr:
    expression = sp.sympify(str(value), locals={"sqrt": sp.sqrt})
    return sp.radsimp(sp.simplify(expression))


def qstr(value: sp.Expr) -> str:
    return str(sp.radsimp(sp.factor(sp.cancel(value))))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dm(matrix: sp.Matrix) -> DomainMatrix:
    return DomainMatrix.from_Matrix(matrix, fmt="dense").convert_to(ALGEBRAIC_FIELD)


def rank_exact(matrix: sp.Matrix) -> int:
    return dm(matrix).rank()


def nullspace_columns(matrix: sp.Matrix) -> list[sp.Matrix]:
    basis_rows = dm(matrix).nullspace().to_Matrix()
    columns=[]
    for row in range(basis_rows.rows):
        vector=basis_rows[row,:].T
        pivot=next(z for z in vector if z!=0)
        vector=(vector/pivot).applyfunc(lambda z: sp.radsimp(sp.cancel(z)))
        columns.append(vector)
    return columns


def rref_exact(matrix: sp.Matrix):
    reduced, pivots = dm(matrix).rref()
    return reduced.to_Matrix(), tuple(pivots)


def primitive_vector(vec: Iterable[sp.Expr]) -> tuple[sp.Expr, ...]:
    """Canonical algebraic scaling: first nonzero entry becomes positive 1."""
    values = [sp.radsimp(sp.simplify(z)) for z in vec]
    pivot = next((z for z in values if z != 0), None)
    if pivot is None:
        return tuple(values)
    values = [sp.radsimp(sp.simplify(z / pivot)) for z in values]
    # The first entry is exactly +1 under this normalization.
    assert next(z for z in values if z != 0) == 1
    return tuple(values)


def signed_rows(representatives: list[tuple[sp.Expr, ...]]):
    rows = list(representatives) + [tuple(-z for z in row) for row in representatives]
    metadata = [(j, 1) for j in range(len(representatives))] + [
        (j, -1) for j in range(len(representatives))
    ]
    return rows, metadata


def antipode(index: int, pairs: int) -> int:
    return index+pairs if index < pairs else index-pairs


def affine_dimension(points: list[tuple[sp.Expr, ...]], ids: Iterable[int]) -> int:
    ids = list(ids)
    if len(ids) <= 1:
        return len(ids)-1
    base = sp.Matrix(points[ids[0]])
    return sp.Matrix.hstack(*[sp.Matrix(points[i])-base for i in ids[1:]]).rank()


def exact_full_facets(vertices, normals):
    points, point_meta = signed_rows(vertices)
    facets = []
    records = []
    for pair, normal in enumerate(normals):
        n = sp.Matrix(normal)
        for side in (1, -1):
            signed_normal = side*n
            support = []
            for index, point in enumerate(points):
                value = sp.factor(signed_normal.dot(sp.Matrix(point)))
                assert value <= 1, (pair, side, index, value)
                if value == 1:
                    support.append(index)
            assert len(support) >= DIM, (pair, side, support)
            assert affine_dimension(points, support) == DIM-1
            facets.append(tuple(sorted(support)))
            records.append({
                'facet_pair': pair,
                'side': side,
                'normal': [qstr(side*z) for z in normal],
                'support': support,
                'vertices': len(support),
            })
    assert len(facets) == len(set(facets))
    for index in range(0, len(facets), 2):
        positive, negative = facets[index], facets[index+1]
        assert tuple(sorted(antipode(i, len(vertices)) for i in positive)) == negative
    return points, point_meta, facets, records


def project_affine(points: list[tuple[sp.Expr, ...]], ids: list[int], dimension: int) -> np.ndarray:
    array = np.array([[float(z) for z in points[i]] for i in ids], dtype=float)
    delta = array-array[0]
    _, singular, vt = np.linalg.svd(delta, full_matrices=False)
    assert sum(value > 1e-10 for value in singular) == dimension, (ids, singular)
    return delta @ vt[:dimension].T


def triangulate_polygon(points, ridge: tuple[int, ...]) -> list[tuple[int, int, int]]:
    ids = list(ridge)
    if len(ids) == 3:
        return [tuple(sorted(ids))]
    projected = project_affine(points, ids, 2)
    hull = ConvexHull(projected)
    order = [ids[int(i)] for i in hull.vertices]
    assert set(order) == set(ids)
    root = min(order)
    pivot = order.index(root)
    order = order[pivot:]+order[:pivot]
    triangles = [tuple(sorted((root, order[i], order[i+1]))) for i in range(1, len(order)-1)]
    assert len(triangles) == len(ids)-2
    assert len(triangles) == len(set(triangles))
    for triangle in triangles:
        assert affine_dimension(points, triangle) == 2
    return triangles


def boundary_triangulation(points, facets):
    ridge_to_facets: dict[tuple[int, ...], set[int]] = defaultdict(set)
    for i, j in itertools.combinations(range(len(facets)), 2):
        intersection = tuple(sorted(set(facets[i]) & set(facets[j])))
        if len(intersection) >= 3 and affine_dimension(points, intersection) == 2:
            ridge_to_facets[intersection].update((i, j))
    assert ridge_to_facets
    assert all(len(incident) == 2 for incident in ridge_to_facets.values())

    ridge_triangles = {
        ridge: triangulate_polygon(points, ridge) for ridge in ridge_to_facets
    }
    facet_ridges: dict[int, list[tuple[int, ...]]] = defaultdict(list)
    for ridge, incident in ridge_to_facets.items():
        for facet in incident:
            facet_ridges[facet].append(ridge)

    facet_tetrahedra = []
    all_tetrahedra = []
    for fi, facet in enumerate(facets):
        root = min(facet)
        local = []
        for ridge in facet_ridges[fi]:
            if root in ridge:
                continue
            for triangle in ridge_triangles[ridge]:
                tetrahedron = tuple(sorted((root,)+triangle))
                assert set(tetrahedron) <= set(facet)
                assert affine_dimension(points, tetrahedron) == 3
                local.append(tetrahedron)
        if len(facet) == 4:
            assert local == [tuple(sorted(facet))]
        assert len(local) == len(set(local))
        facet_tetrahedra.append(sorted(local))
        all_tetrahedra.extend(local)

    assert len(all_tetrahedra) == len(set(all_tetrahedra))
    triangle_count: Counter[tuple[int, ...]] = Counter()
    edge_set = set()
    for tetrahedron in all_tetrahedra:
        triangle_count.update(tuple(sorted(face)) for face in itertools.combinations(tetrahedron, 3))
        edge_set.update(tuple(sorted(edge)) for edge in itertools.combinations(tetrahedron, 2))
    assert set(triangle_count.values()) == {2}
    vertex_set = set().union(*(set(t) for t in all_tetrahedra))
    f_vector = [len(vertex_set), len(edge_set), len(triangle_count), len(all_tetrahedra)]
    assert f_vector[0]-f_vector[1]+f_vector[2]-f_vector[3] == 0

    link_records = []
    for vertex in sorted(vertex_set):
        link_triangles = [tuple(sorted(set(t)-{vertex})) for t in all_tetrahedra if vertex in t]
        link_edges: Counter[tuple[int, int]] = Counter()
        link_vertices = set()
        for triangle in link_triangles:
            link_vertices.update(triangle)
            link_edges.update(tuple(sorted(edge)) for edge in itertools.combinations(triangle, 2))
        assert set(link_edges.values()) == {2}
        adjacency: dict[int, set[int]] = defaultdict(set)
        for a, b in link_edges:
            adjacency[a].add(b)
            adjacency[b].add(a)
        seen = set()
        queue = deque([next(iter(link_vertices))])
        while queue:
            item = queue.popleft()
            if item in seen:
                continue
            seen.add(item)
            queue.extend(adjacency[item]-seen)
        assert seen == link_vertices
        euler = len(link_vertices)-len(link_edges)+len(link_triangles)
        assert euler == 2
        link_records.append({
            'vertex': vertex,
            'vertices': len(link_vertices),
            'edges': len(link_edges),
            'triangles': len(link_triangles),
            'euler': euler,
        })

    return {
        'ridges': [list(ridge) for ridge in sorted(ridge_to_facets)],
        'ridge_count': len(ridge_to_facets),
        'ridge_size_distribution': dict(Counter(map(len, ridge_to_facets))),
        'ridge_triangulations': {
            ','.join(map(str, ridge)): [list(t) for t in ridge_triangles[ridge]]
            for ridge in sorted(ridge_triangles)
        },
        'facet_tetrahedra': [[list(t) for t in local] for local in facet_tetrahedra],
        'tetrahedra': [list(t) for t in all_tetrahedra],
        'tetrahedra_count': len(all_tetrahedra),
        'triangulated_f_vector': f_vector,
        'all_triangles_incidence': 2,
        'all_vertex_links_connected_2_spheres': True,
        'vertex_links': link_records,
    }


def volume_and_gradient(representatives, normals):
    points, point_meta, facets, facet_records = exact_full_facets(representatives, normals)
    boundary = boundary_triangulation(points, facets)
    gradient = [sp.zeros(DIM, 1) for _ in representatives]
    volume = sp.Integer(0)
    determinant_distribution: Counter[str] = Counter()
    orientation_records = []

    for tetrahedron in map(tuple, boundary['tetrahedra']):
        matrix = sp.Matrix.hstack(*[sp.Matrix(points[index]) for index in tetrahedron])
        determinant = sp.factor(matrix.det(method='domain-ge'))
        assert determinant != 0
        sign = 1 if determinant > 0 else -1
        absolute = sign*determinant
        volume += absolute/sp.factorial(DIM)
        determinant_distribution[qstr(absolute)] += 1
        inverse_transpose = matrix.inv().T
        local = []
        for column, point_index in enumerate(tetrahedron):
            pair, epsilon = point_meta[point_index]
            cofactor = determinant*inverse_transpose[:, column]
            contribution = (sp.Rational(sign*epsilon, FACT)*cofactor).applyfunc(sp.factor)
            gradient[pair] += contribution
            local.append({
                'point_index': point_index,
                'vertex_pair': pair,
                'sign': epsilon,
                'gradient_contribution': [qstr(z) for z in contribution],
            })
        orientation_records.append({
            'tetrahedron': list(tetrahedron),
            'determinant': qstr(determinant),
            'absolute_determinant': qstr(absolute),
            'vertex_gradient_contributions': local,
        })

    gradient = [vector.applyfunc(sp.factor) for vector in gradient]
    return sp.radsimp(sp.factor(volume)), gradient, {
        'facet_records': facet_records,
        'facet_size_distribution': dict(Counter(map(len, facets))),
        'boundary': boundary,
        'simplex_absolute_determinant_distribution': dict(sorted(determinant_distribution.items())),
        'orientation_records': orientation_records,
    }


def polar_volume_and_gradient_wrt_primal(vertices, normals):
    # Q=P^o has vertex-pair representatives equal to the normalized facet
    # normals of P, while its facet-pair normals are the vertices of P.
    qpoints, qpoint_meta, qfacets, qfacet_records = exact_full_facets(normals, vertices)
    boundary = boundary_triangulation(qpoints, qfacets)
    gradient = [sp.zeros(DIM, 1) for _ in vertices]
    volume = sp.Integer(0)
    determinant_distribution: Counter[str] = Counter()
    records = []

    for facet_index, local_tetrahedra in enumerate(boundary['facet_tetrahedra']):
        pair = qfacet_records[facet_index]['facet_pair']
        side = qfacet_records[facet_index]['side']
        for raw_tetrahedron in local_tetrahedra:
            tetrahedron = tuple(raw_tetrahedron)
            matrix = sp.Matrix.hstack(*[sp.Matrix(qpoints[index]) for index in tetrahedron])
            determinant = sp.factor(matrix.det(method='domain-ge'))
            assert determinant != 0
            sign = 1 if bool(determinant > 0) else -1
            absolute = sp.radsimp(sp.simplify(sign*determinant))
            assert bool(absolute > 0)
            volume += absolute/sp.factorial(DIM)
            determinant_distribution[qstr(absolute)] += 1
            vertex_sum = sum((sp.Matrix(qpoints[index]) for index in tetrahedron), sp.zeros(DIM, 1))
            contribution = (-sp.Rational(side, FACT)*absolute*vertex_sum).applyfunc(lambda z: sp.radsimp(sp.simplify(z)))
            gradient[pair] = (gradient[pair] + contribution).applyfunc(lambda z: sp.radsimp(sp.simplify(z)))
            records.append({
                'polar_facet_index': facet_index,
                'primal_vertex_pair': pair,
                'facet_side': side,
                'tetrahedron': list(tetrahedron),
                'absolute_determinant': qstr(absolute),
                'gradient_contribution': [qstr(z) for z in contribution],
            })

    gradient = [vector.applyfunc(lambda z: sp.radsimp(sp.simplify(z))) for vector in gradient]
    return sp.radsimp(sp.simplify(volume)), gradient, {
        'facet_records': qfacet_records,
        'facet_size_distribution': dict(Counter(map(len, qfacets))),
        'boundary': boundary,
        'simplex_absolute_determinant_distribution': dict(sorted(determinant_distribution.items())),
        'polar_shape_derivative_records': records,
    }


def facet_circuit_matrix(vertices, normals):
    m = len(vertices)
    V = sp.Matrix.hstack(*[sp.Matrix(vertex) for vertex in vertices])
    rows = []
    records = []
    for fi, normal in enumerate(normals):
        support = []
        points = []
        for j, vertex in enumerate(vertices):
            value = sp.factor(sp.Matrix(normal).dot(sp.Matrix(vertex)))
            if value == 1:
                epsilon = 1
            elif value == -1:
                epsilon = -1
            else:
                continue
            support.append((j, epsilon))
            points.append(epsilon*sp.Matrix(vertex))
        augmented = sp.Matrix.hstack(*[point.col_join(sp.Matrix([1])) for point in points])
        assert augmented.rank() == DIM
        nullspace = augmented.nullspace()
        assert len(nullspace) == len(support)-DIM
        for basis_index, lam in enumerate(nullspace):
            circuit = sp.zeros(m, 1)
            for coefficient, (j, epsilon) in zip(lam, support):
                circuit[j] = sp.factor(coefficient*epsilon)
            residual = (V*circuit).applyfunc(lambda z: sp.radsimp(sp.simplify(z)))
            assert residual == sp.zeros(DIM, 1), residual
            row = [sp.factor(circuit[j]*normal[d]) for j in range(m) for d in range(DIM)]
            rows.append(row)
            records.append({
                'facet_pair': fi,
                'basis_index': basis_index,
                'signed_support': [[j, epsilon] for j, epsilon in support],
                'circuit': [qstr(z) for z in circuit],
                'normal': [qstr(z) for z in normal],
            })
    matrix = sp.Matrix(rows) if rows else sp.zeros(0, DIM*m)
    return matrix, records


def determinant_constraint_matrix(vertices, normals):
    m = len(vertices)
    rows = []
    records = []
    for fi, normal in enumerate(normals):
        support = []
        signed_points_local = {}
        for j, vertex in enumerate(vertices):
            value = sp.factor(sp.Matrix(normal).dot(sp.Matrix(vertex)))
            if value in (1, -1):
                epsilon = int(value)
                support.append((j, epsilon))
                signed_points_local[(j, epsilon)] = epsilon*sp.Matrix(vertex)
        basis = None
        for candidate in itertools.combinations(support, DIM):
            augmented = sp.Matrix.hstack(*[
                signed_points_local[item].col_join(sp.Matrix([1])) for item in candidate
            ])
            if augmented.rank() == DIM:
                basis = candidate
                break
        assert basis is not None
        extras = [item for item in support if item not in basis]
        assert len(extras) == len(support)-DIM
        p0, p1, p2, p3 = [signed_points_local[item] for item in basis]
        for extra_index, extra in enumerate(extras):
            pe = signed_points_local[extra]
            matrix = sp.Matrix.hstack(p1-p0, p2-p0, p3-p0, pe-p0)
            assert matrix.det(method='domain-ge') == 0
            cofactors = [matrix.cofactor_matrix()[:, k] for k in range(DIM)]
            # For det(matrix), the column gradient is the corresponding column
            # of the cofactor matrix.  matrix.cofactor_matrix() satisfies this
            # convention; verify by a one-entry finite symbolic identity below.
            row_vectors = {
                basis[1]: cofactors[0],
                basis[2]: cofactors[1],
                basis[3]: cofactors[2],
                extra: cofactors[3],
                basis[0]: -sum(cofactors, sp.zeros(DIM, 1)),
            }
            row = sp.zeros(1, DIM*m)
            for (pair, epsilon), vector in row_vectors.items():
                for d in range(DIM):
                    row[0, DIM*pair+d] += sp.factor(epsilon*vector[d])
            assert any(row)
            rows.append(list(row))
            records.append({
                'facet_pair': fi,
                'equation_index': extra_index,
                'affine_basis': [[j, epsilon] for j, epsilon in basis],
                'extra_vertex': list(extra),
                'jacobian_row_normalized': [qstr(z) for z in primitive_vector(row)],
            })
    matrix = sp.Matrix(rows) if rows else sp.zeros(0, DIM*m)
    return matrix, records


def gl_motion_matrix(vertices):
    variables = DIM*len(vertices)
    columns = []
    for a in range(DIM):
        for b in range(DIM):
            column = sp.zeros(variables, 1)
            for j, vertex in enumerate(vertices):
                column[DIM*j+a] = vertex[b]
            columns.append(column)
    matrix = sp.Matrix.hstack(*columns)
    assert rank_exact(matrix) == DIM*DIM
    return matrix


def flatten(vectors):
    return sp.Matrix([entry for vector in vectors for entry in vector])


def exact_rank_witness(matrix: sp.Matrix) -> dict:
    rank = rank_exact(matrix)
    if rank == 0:
        return {'rank': 0, 'selected_rows': [], 'selected_columns': [], 'determinant': '1'}
    _, pivot_columns_all = rref_exact(matrix)
    pivot_columns = tuple(pivot_columns_all[:rank])
    column_basis = matrix[:, list(pivot_columns)]
    _, pivot_rows_all = rref_exact(column_basis.T)
    pivot_rows = tuple(pivot_rows_all[:rank])
    determinant = sp.radsimp(sp.simplify(
        matrix.extract(list(pivot_rows), list(pivot_columns)).det(method='domain-ge')
    ))
    assert determinant != 0
    return {
        'rank': rank,
        'selected_rows': list(pivot_rows),
        'selected_columns': list(pivot_columns),
        'determinant': qstr(determinant),
    }


def one_stress_solution(J: sp.Matrix, gradient: sp.Matrix):
    if J.rows == 0:
        assert gradient == sp.zeros(J.cols, 1)
        return {
            'multipliers': [],
            'free_multiplier_dimension': 0,
            'nonzero_multipliers': 0,
            'equilibrium_verified': True,
        }
    A = J.T
    augmented = A.row_join(gradient)
    reduced, pivots = rref_exact(augmented)
    assert A.cols not in pivots, 'inconsistent stress equations'
    pivot_variables = [p for p in pivots if p < A.cols]
    free_variables = [j for j in range(A.cols) if j not in pivot_variables]
    solution = sp.zeros(A.cols, 1)
    for row, pivot in enumerate(pivot_variables):
        solution[pivot] = sp.radsimp(sp.simplify(reduced[row, A.cols]))
    residual = (A * solution - gradient).applyfunc(lambda z: sp.radsimp(sp.simplify(z)))
    assert residual == sp.zeros(A.rows, 1), residual
    return {
        'multipliers': [qstr(z) for z in solution],
        'free_multiplier_dimension': len(free_variables),
        'nonzero_multipliers': sum(z != 0 for z in solution),
        'equilibrium_verified': True,
    }


def descent_witness(J: sp.Matrix, gradient: sp.Matrix):
    for index, vector in enumerate(nullspace_columns(J)):
        derivative = sp.radsimp(sp.simplify((gradient.T * vector)[0]))
        if derivative == 0:
            continue
        normalized = sp.Matrix(primitive_vector(vector))
        derivative = sp.radsimp(sp.simplify((gradient.T * normalized)[0]))
        if bool(derivative > 0):
            normalized = -normalized
            derivative = -derivative
        assert bool(derivative < 0)
        assert J * normalized == sp.zeros(J.rows, 1)
        return {
            'nullspace_basis_index': index,
            'normalized_velocity': [qstr(value) for value in normalized],
            'nonzero_entries': sum(value != 0 for value in normalized),
            'Mahler_directional_derivative': qstr(derivative),
            'compatibility_verified': True,
        }
    raise AssertionError('no descent direction found despite nonstationarity')


def analyze(data: dict) -> dict:
    vertices = [tuple(parse_q(z) for z in row) for row in data['vertex_pair_representatives']]
    normals = [tuple(parse_q(z) for z in row) for row in data['facet_normal_pair_representatives']]
    assert all(len(row) == DIM for row in vertices+normals)
    V = sp.Matrix.hstack(*[sp.Matrix(vertex) for vertex in vertices])
    assert V.rank() == DIM

    primal_volume, primal_gradient_vectors, primal_meta = volume_and_gradient(vertices, normals)
    polar_volume, polar_gradient_vectors, polar_meta = polar_volume_and_gradient_wrt_primal(vertices, normals)
    independent_polar_volume = volume_and_gradient(normals, vertices)[0]
    assert polar_volume == independent_polar_volume

    circuit_matrix, circuit_records = facet_circuit_matrix(vertices, normals)
    determinant_J, determinant_records = determinant_constraint_matrix(vertices, normals)
    assert circuit_matrix.rows == determinant_J.rows
    rank_circuit = rank_exact(circuit_matrix)
    rank_J = rank_exact(determinant_J)
    assert rank_circuit == rank_J
    assert rank_exact(sp.Matrix.vstack(circuit_matrix, determinant_J)) == rank_J

    gl_matrix = gl_motion_matrix(vertices)
    assert determinant_J*gl_matrix == sp.zeros(determinant_J.rows, DIM*DIM)

    grad_primal = flatten(primal_gradient_vectors)
    grad_polar = flatten(polar_gradient_vectors)
    grad_mahler = (polar_volume*grad_primal + primal_volume*grad_polar).applyfunc(sp.factor)

    expected_primal = []
    expected_polar = []
    for a in range(DIM):
        for b in range(DIM):
            expected_primal.append(primal_volume if a == b else 0)
            expected_polar.append(-polar_volume if a == b else 0)
    assert list(grad_primal.T*gl_matrix) == expected_primal
    assert list(grad_polar.T*gl_matrix) == expected_polar
    assert grad_mahler.T*gl_matrix == sp.zeros(1, DIM*DIM)

    augmented = sp.Matrix.vstack(determinant_J, grad_mahler.T)
    augmented_rank = rank_exact(augmented)
    assert augmented_rank in (rank_J, rank_J+1)
    stationary = augmented_rank == rank_J
    full_row_rank = rank_J == determinant_J.rows
    variables = DIM*len(vertices)
    compatible_dimension = variables-rank_J
    quotient_dimension = compatible_dimension-DIM*DIM
    assert quotient_dimension >= 0

    variational = {
        'constraint_equations': determinant_J.rows,
        'constraint_rank': rank_J,
        'constraint_full_row_rank': full_row_rank,
        'velocity_variables': variables,
        'compatible_motion_dimension': compatible_dimension,
        'GL_trivial_dimension': DIM*DIM,
        'projective_compatible_motion_dimension': quotient_dimension,
        'Mahler_augmented_rank': augmented_rank,
        'first_order_stationary_on_linearized_compatible_space': stationary,
        'regular_stratum_KKT_interpretation': bool(full_row_rank),
        'constraint_rank_witness': exact_rank_witness(determinant_J),
        'augmented_rank_witness': exact_rank_witness(augmented),
    }
    if stationary:
        variational['Mahler_stress'] = one_stress_solution(determinant_J, grad_mahler)
        if full_row_rank and quotient_dimension == 0:
            variational['conclusion'] = (
                'The Mahler gradient satisfies the exact facet-coplanarity KKT equilibrium, '
                'and the fixed-face-lattice compatible-motion quotient modulo GL(4) is zero.'
            )
        elif full_row_rank:
            variational['conclusion'] = (
                'The point is a regular first-order Mahler critical point on a positive-dimensional '
                'fixed-face-lattice realization stratum; second variation is required.'
            )
        else:
            variational['conclusion'] = (
                'The Mahler gradient lies in the facet-coplanarity Jacobian row space, but the point '
                'is singular for this constraint presentation; tangent-cone and higher-order analysis are required.'
            )
    else:
        variational['descent_witness'] = descent_witness(determinant_J, grad_mahler)
        variational['conclusion'] = (
            'The Mahler gradient does not lie in the facet-coplanarity Jacobian row space.  '
            + ('Because the determinant constraints have full row rank, the exact compatible descent tangent is locally integrable inside the fixed face lattice.' if full_row_rank else
               'The point is singular for this constraint presentation, so linear nonstationarity alone does not certify integrability.')
        )

    return {
        'status': 'PASS',
        'name': data.get('name', 'unnamed'),
        'dimension': DIM,
        'vertex_pairs': len(vertices),
        'facet_pairs': len(normals),
        'rank_vertex_matrix': DIM,
        'primal_volume': qstr(primal_volume),
        'polar_volume': qstr(polar_volume),
        'Mahler_product': qstr(primal_volume*polar_volume),
        'primal_gradient': [[qstr(z) for z in vector] for vector in primal_gradient_vectors],
        'polar_gradient_with_respect_to_primal_vertices': [[qstr(z) for z in vector] for vector in polar_gradient_vectors],
        'Mahler_gradient': [qstr(z) for z in grad_mahler],
        'GL_covariance_checks': {
            'd_primal_volume_AV': 'tr(A)|P|',
            'd_polar_volume_AV': '-tr(A)|P^polar|',
            'd_Mahler_AV': '0',
            'exactly_verified_on_16_matrix-unit_generators': True,
        },
        'primal_boundary_and_gradient_certificate': primal_meta,
        'polar_boundary_and_gradient_certificate': polar_meta,
        'facet_circuit_records': circuit_records,
        'determinant_constraint_records': determinant_records,
        'circuit_and_determinant_Jacobian_rowspaces_equal': True,
        'variational_certificate': variational,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=Path)
    parser.add_argument('--certificate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    certificate = analyze(data)
    certificate_path = args.certificate or args.input.with_name(args.input.stem+'_mahler_first_variation_certificate.json')
    output_path = args.output or args.input.with_name(args.input.stem+'_mahler_first_variation_output.json')
    certificate_path.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    variational = certificate['variational_certificate']
    output = {
        'status': 'PASS',
        'name': certificate['name'],
        'dimension': DIM,
        'vertex_pairs': certificate['vertex_pairs'],
        'facet_pairs': certificate['facet_pairs'],
        'primal_volume': certificate['primal_volume'],
        'polar_volume': certificate['polar_volume'],
        'Mahler_product': certificate['Mahler_product'],
        'constraint_equations': variational['constraint_equations'],
        'constraint_rank': variational['constraint_rank'],
        'constraint_full_row_rank': variational['constraint_full_row_rank'],
        'projective_compatible_motion_dimension': variational['projective_compatible_motion_dimension'],
        'Mahler_augmented_rank': variational['Mahler_augmented_rank'],
        'first_order_stationary': variational['first_order_stationary_on_linearized_compatible_space'],
        'certificate': certificate_path.name,
        'certificate_sha256': sha256(certificate_path),
        'conclusion': variational['conclusion'],
    }
    output_path.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
