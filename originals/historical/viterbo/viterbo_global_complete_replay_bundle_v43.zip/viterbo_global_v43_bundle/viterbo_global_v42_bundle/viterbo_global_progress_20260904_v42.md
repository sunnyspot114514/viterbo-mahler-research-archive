# 四维中心对称 Mahler 进展 v42

本轮从 v41 的局部 incidence-curvature modules 出发，完成了一条真正不依赖 bounded-12 的全局归约，并用一个 `48V/14F` 对象验证数域上的完整一阶、二阶和结构块分解。

## 本轮结论

1. 对任意中心对称凸体 \(K\subset\mathbb R^p\)、\(L\subset\mathbb R^q\)：
   \[
   M(K\times L)=M(K\oplus_1L)=\frac{p!q!}{(p+q)!}M(K)M(L).
   \]
   结合一、二、三维中心对称 Mahler 下界，所有非平凡四维 direct products 与 free sums 都满足 \(M\ge32/3\)。

2. 对中心对称多胞体：facet-normal vector matroid 不连通等价于线性直积分解；vertex vector matroid 不连通等价于 free-sum 分解。任何反例必须 vertex/normal 两侧同时连通。

3. 校准对象 \(H_6\times O_8\) 有 `48` 个 vertices、`14` 个 facets，Mahler product 为
   \[
   48-24\sqrt2>32/3.
   \]
   其 fixed-face-lattice Jacobian rank 为 `68`，速度空间 `96` 维，模 \(GL(4)\) 后 quotient 为 `12` 维。完整 Mahler gradient 满足唯一 KKT stress。

4. 两套独立 facet-normal extensions 给出相同 reduced Hessian，惯性为
   \[
   (0,12,0).
   \]
   因而该对象是固定组合型内的严格局部 Mahler 最大点。

5. normal-matroid components 自动诱导
   \[
   12=2+4+6
   \]
   的 hexagon-factor、octagon-factor 与 mixed-mode 分解。三块均严格负定，完整曲率只含六个负代数数。

6. 新的 separation census 显示：\(\lambda=0\) 已由分解公式关闭；\(P_3\) normal side 与正则 24-cell 两侧各出现 `16` 个 proper \(\lambda=2\) separations，而没有 proper \(\lambda=1\) separation。下一阶段转向 2-sum/3-separation 的统一变分定理。

## 准确范围

bounded-12 仍是已关闭的计算机辅助解析证明候选。v42 进一步关闭了全部线性 decomposable 四维 bodies，但没有处理所有 bi-indecomposable bodies；完整四维中心对称 Mahler 猜想仍然 open。
