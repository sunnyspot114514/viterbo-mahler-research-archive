# 四维中心对称 Mahler：分解归约、向量拟阵连通性与高复杂度乘积曲率

**版本：** v42  
**日期：** 2026-09-04  
**状态：** computer-assisted analytic proof candidate；完整四维猜想仍未解决。

## 1. 线性直积与 free sum 的 Mahler 因子化

设

\[
K\subset\mathbb R^p,
\qquad
L\subset\mathbb R^q,
\qquad p+q=n,
\]

都是以原点为内部点的中心对称凸体。定义 free sum

\[
K\oplus_1L
=
\operatorname{conv}\bigl((K,0)\cup(0,L)\bigr).
\]

极性给出

\[
(K\times L)^\circ=K^\circ\oplus_1L^\circ,
\qquad
(K\oplus_1L)^\circ=K^\circ\times L^\circ.
\]

free sum 的体积为

\[
|K\oplus_1L|
=
\frac{p!q!}{(p+q)!}|K|\,|L|.
\]

因此

\[
\boxed{
M(K\times L)
=
M(K\oplus_1L)
=
\frac{p!q!}{(p+q)!}M(K)M(L),
}
\]

其中 \(M(K)=|K||K^\circ|\)。

在四维，非平凡维数拆分只有 \(1+3\) 与 \(2+2\)。代入低维中心对称 Mahler 下界

\[
M_d\ge\frac{4^d}{d!}
\]

便得到

\[
\frac{p!q!}{4!}
\frac{4^p}{p!}
\frac{4^q}{q!}
=
\frac{4^4}{4!}
=
\frac{32}{3}.
\]

所以所有非平凡线性直积和 free sum 都满足四维猜想。任何四维反例都必须同时排除这两类分解。

## 2. 多胞体的向量拟阵判据

设一个中心对称四维多胞体有不可约 H-表示

\[
P=
\{x:|\langle u_i,x\rangle|\le1,
\ i\in I\}.
\]

若 facet-normal 向量配置分成两个非空集合

\[
I=I_1\sqcup I_2,
\]

并且

\[
\operatorname{span}\{u_i:i\in I_1\}
\oplus
\operatorname{span}\{u_i:i\in I_2\}
=(\mathbb R^4)^*,
\]

那么选择相应的 primal 互补子空间后，全部不等式分成两组互不耦合的约束，从而

\[
P\cong P_1\times P_2.
\]

反过来，直积的 facet normals 必然分布在互补 dual subspaces 中。因此：

\[
\boxed{
\text{facet-normal 向量拟阵不连通}
\iff
P\text{ 线性等价于非平凡直积}.
}
\]

对 vertices 应用极性，得到

\[
\boxed{
\text{vertex 向量拟阵不连通}
\iff
P\text{ 线性等价于非平凡 free sum}.
}
\]

所以任何反例必须满足

\[
\boxed{
M_V(P)\text{ 与 }M_N(P)
\text{ 都连通}.
}
\]

v42 analyzer 用一个任意 vector-matroid basis 的 fundamental circuits 重建这些 connected components。输出与 basis 选择无关，并对每两个 components 精确检查 span ranks 可加。

## 3. 高复杂度校准对象：六边形乘八边形

取 affine-regular 中心对称六边形

\[
H_6=
\operatorname{conv}\{(1,0),(1,1),(0,1),
(-1,0),(-1,-1),(0,-1)\},
\]

以及令 \(r=\sqrt2-1\) 的正八边形

\[
O_8=
\operatorname{conv}\{(1,r),(r,1),(-r,1),(-1,r),
(-1,-r),(-r,-1),(r,-1),(1,-r)\}.
\]

定义

\[
P=H_6\times O_8\subset\mathbb R^4.
\]

它具有

\[
\boxed{48\text{ 个 vertices},\qquad14\text{ 个 facets}},
\]

而极体具有

\[
\boxed{14\text{ 个 vertices},\qquad48\text{ 个 facets}}.
\]

所以它真正越过 bounded-12。

精确平面数据为

\[
M(H_6)=9,
\qquad
M(O_8)=16(2-\sqrt2).
\]

利用 \(2+2\) 因子化，

\[
M(P)
=
\frac16\cdot9\cdot16(2-\sqrt2)
=
\boxed{48-24\sqrt2}.
\]

相对阈值的余量是

\[
\boxed{
M(P)-\frac{32}{3}
=
\frac{112-72\sqrt2}{3}>0.
}
\]

facet-normal 拟阵的 connected components 精确为两块，大小为 \(3,4\)，秩为 \(2,2\)。这自动恢复了 \(2+2\) 直积分解。

## 4. 完整 fixed-face-lattice 一阶变分

允许 24 对 vertex representatives 独立作 odd 四维运动，共有

\[
4\times24=96
\]

个速度变量。

从所有非单纯 facets 的 determinant equations 得到

\[
J\in\mathbb Q(\sqrt2)^{68\times96}.
\]

exact DomainMatrix 计算给出

\[
\boxed{
\operatorname{rank}J=68.
}
\]

所以 compatible-motion space 的维数为

\[
96-68=28.
\]

模去 \(GL(4)\) 的 16 维平凡运动后，真正的 realization quotient 为

\[
\boxed{\dim\mathcal M(P)=12}.
\]

完整 Mahler gradient 满足

\[
\operatorname{rank}
\begin{pmatrix}
J\\(g^M)^T
\end{pmatrix}
=68,
\]

而且 KKT multiplier solution 唯一。因此 \(P\) 是完整 fixed-face-lattice stratum 上的一阶临界点，不只是直积子族内部的临界点。

## 5. 数域上的完整二阶变分

Primal boundary 的 exact pulling triangulation 有

\[
204
\]

个 tetrahedra；polar boundary 有

\[
48
\]

个 tetrahedra。

为了避免通用符号表达式在 \(\mathbb Q(\sqrt2)\) 上膨胀，v42 使用以下结构化算法：

1. 每个 tetrahedron 的点与速度立即转换为 algebraic-field elements；
2. 利用 determinant 对每一列线性的事实，用六个 column-pair kernels 累加 Hessian；
3. rank-three facet constraints 的基点 determinant 为零，使用无逆 multilinear Hessian，不错误套用 Jacobi inverse formula；
4. 环境 polar gradient 使用 gradient-only 路径，避免构造无用的 \(96\times96\) Hessian；
5. 对每个非单纯 facet 分别使用 first 与 last invertible four-point basis，重新计算各自匹配的 KKT multipliers。

两套 off-stratum extensions 最终给出完全相同的 reduced Lagrangian Hessian。

exact congruence inertia 为

\[
\boxed{
(n_+,n_-,n_0)=(0,12,0).
}
\]

因此

\[
\boxed{
P=H_6\times O_8
\text{ 在其正则 fixed-face-lattice stratum 上，模 }GL(4)
\text{ 是严格局部 Mahler 最大点}.}
\]

这个结论只描述固定组合型的局部曲率。该对象的全局 Mahler 下界已经由直积分解公式独立解决。

## 6. 从 normal-matroid components 自动恢复曲率 sectors

由两块 normal-matroid components 自动构造 factor coordinates，再将 factor-preserving vertex motions 投影到

\[
\ker J/\mathfrak{gl}_4.
\]

得到精确正交分解

\[
\boxed{
\mathcal M(P)
=
W_{H_6}\oplus W_{O_8}\oplus W_{\mathrm{mix}},
}
\]

其中

\[
\boxed{
\dim W_{H_6}=2,
\qquad
\dim W_{O_8}=4,
\qquad
\dim W_{\mathrm{mix}}=6.
}
\]

三个 sectors 对 quotient metric 和 reduced Hessian 都互相正交，并都 invariant under curvature operator。

### 六边形 factor sector

\[
\chi_{H_6}(\lambda)
=
(\lambda-3\sqrt2+6)(\lambda-\sqrt2+2).
\]

曲率为

\[
-6+3\sqrt2,
\qquad
-2+\sqrt2.
\]

### 八边形 factor sector

\[
\chi_{O_8}(\lambda)
=
(\lambda-2+2\sqrt2)^3
(\lambda+2+2\sqrt2).
\]

曲率为

\[
2-2\sqrt2\quad(\times3),
\qquad
-2-2\sqrt2\quad(\times1).
\]

### Mixed sector

\[
\chi_{\mathrm{mix}}(\lambda)
=
\left(\lambda+\frac{5\sqrt2}{18}\right)^4
\left(\lambda-\frac{\sqrt2}{4}+\frac34\right)^2.
\]

曲率为

\[
-\frac{5\sqrt2}{18}\quad(\times4),
\qquad
\frac{\sqrt2-3}{4}\quad(\times2).
\]

全部六个曲率 scalars 都严格为负。原来的 \(12\times12\) 数域 Hessian 因而压缩为 \(2+4+6\) 三个结构块及六个标量。

## 7. 向量拟阵 separation ladder

对 rank-four vector configuration 定义

\[
\lambda(S)
=
r(S)+r(E\setminus S)-4.
\]

v42 的 exact census 给出：

- \(H_6\times O_8\) 的 normal matroid 有 \(\lambda=0\) 分离，即已经解决的直积分解；
- \(P_3\) 的 vertex matroid 在两边至少三个元素时最小 \(\lambda=3\)，但 normal matroid 有恰好 16 个 proper \(\lambda=2\) separations；
- 正则 24-cell 的 vertex 与 normal matroids 各有恰好 16 个 proper \(\lambda=2\) separations；
- \(P_3\) 与正则 24-cell 两侧都没有 proper \(\lambda=1\) 2-separation。

这给出下一条更清楚的全局路线：

\[
\boxed{
\begin{array}{c|c}
\lambda=0&\text{由 direct/free factorization 完整关闭}\\
\lambda=1&\text{建立 2-sum / 一维重叠 gluing 归约}\\
\lambda=2&\text{建立三元 rank-two circuit separator 的 stress-curvature 定理}\\
\text{internally 4-connected}&\text{最终不可分核心}
\end{array}}
\]

正则 24-cell 与 \(P_3\) 已知是 stratified saddles，而它们的低阶分离恰好集中在 \(\lambda=2\)。这不能替代一般定理，但说明三分离层比继续按顶点数枚举更可能形成 complexity-independent bridge。

## 8. 当前边界

本轮真正关闭的是所有线性 decomposable 四维中心对称凸体，并建立了一个可重放的 exact decomposition detector。对于 bi-indecomposable bodies，完整四维猜想仍然开放。

尤其尚未证明：

1. 每个 \(\lambda=1\) separation 都能沿 Mahler 不增方向退化到 \(\lambda=0\)；
2. 每个 proper \(\lambda=2\) separator 都产生负曲率或 coherent mutation descent；
3. internally 4-connected 的四维候选具有 complexity-independent 分类；
4. 任意凸体极小问题必能约化到有限多胞体变分。
