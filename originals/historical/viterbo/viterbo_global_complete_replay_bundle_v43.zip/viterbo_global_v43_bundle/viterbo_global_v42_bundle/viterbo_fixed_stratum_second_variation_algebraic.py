#!/usr/bin/env python3
"""Exact second variation over Q(sqrt(2)) for the v42 product test.

This is a number-field adaptation of viterbo_fixed_stratum_second_variation_analyzer.py.
It consumes a compact first-variation certificate so the expensive geometry and
number-field row reductions can be replayed in separate deterministic stages.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, time
from pathlib import Path
import sympy as sp

ROOT=Path(__file__).resolve().parent

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod); return mod
first=load('first_alg',ROOT/'viterbo_mahler_first_variation_algebraic.py')
sec=load('second_base',ROOT/'viterbo_fixed_stratum_second_variation_analyzer.py')
sec.first=first
sec.parse_q=first.parse_q
DIM=4

def simp(z): return sp.radsimp(sp.factor(sp.cancel(z)))
def canon(z): return first.ALGEBRAIC_FIELD.to_sympy(first.ALGEBRAIC_FIELD.from_sympy(z))
def canon_matrix(M): return first.dm(M).to_Matrix()
def qstr(z): return str(simp(canon(z)))
def sha256(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def mstr(M): return [[qstr(M[i,j]) for j in range(M.cols)] for i in range(M.rows)]
def cstr(v): return [qstr(z) for z in v]
def bcols(M): return [cstr(M[:,j]) for j in range(M.cols)]

def determinant_derivatives_fast(columns, first_derivatives, second_derivatives=None):
    """First/second determinant derivatives via Jacobi's formula.

    For invertible X, d2 det(X)[H,K] = det(X)*(tr(X^-1 H)tr(X^-1 K)
    - tr(X^-1 H X^-1 K)).  This avoids 96 auxiliary 4x4 determinants
    per boundary tetrahedron in the generic implementation.
    """
    p=first_derivatives[0].cols
    X=sp.Matrix.hstack(*columns)
    det=canon(X.det(method="domain-ge")); assert det!=0
    inv=X.inv()
    Ys=[]; traces=[]
    for a in range(p):
        H=sp.Matrix.hstack(*[D[:,a] for D in first_derivatives])
        Y=inv*H
        Ys.append(Y)
        traces.append(sp.trace(Y))
    grad=sp.Matrix([det*t for t in traces])
    Hess=sp.zeros(p)
    for a in range(p):
        for b in range(a,p):
            value=det*(traces[a]*traces[b]-sp.trace(Ys[a]*Ys[b]))
            Hess[a,b]=value; Hess[b,a]=value
    if second_derivatives is not None:
        cof=det*inv.T
        for col in range(DIM):
            for coord in range(DIM):
                if second_derivatives[col][coord] != sp.zeros(p):
                    Hess += cof[coord,col]*second_derivatives[col][coord]
    return grad,Hess

# Use the fast exact formula in the imported base routines.
sec.determinant_derivatives=determinant_derivatives_fast

K = first.ALGEBRAIC_FIELD


def _to_field(value):
    """Convert an exact scalar to QQ(sqrt(2))."""
    if value.__class__.__name__ == "ANP":
        return value
    return K.from_sympy(sp.cancel(value))


def _field_vector_to_matrix(values):
    return sp.Matrix([K.to_sympy(value) for value in values])


def _field_matrix_to_sympy(values):
    rows = len(values)
    cols = len(values[0]) if rows else 0
    return sp.Matrix(rows, cols, lambda i, j: K.to_sympy(values[i][j]))


def _perm_sign(perm):
    inv = sum(perm[i] > perm[j] for i in range(len(perm)) for j in range(i+1, len(perm)))
    return -1 if inv % 2 else 1


_PERM4 = [(perm, _perm_sign(perm)) for perm in __import__('itertools').permutations(range(4))]
_PERM3 = [(perm, _perm_sign(perm)) for perm in __import__('itertools').permutations(range(3))]


def _kdet(matrix):
    n = len(matrix)
    perms = _PERM4 if n == 4 else _PERM3
    total = K.zero
    for perm, sign in perms:
        term = K.one
        for i in range(n):
            term *= matrix[i][perm[i]]
        total += term if sign > 0 else -term
    return total


def _kminor(matrix, row, col):
    return [
        [matrix[i][j] for j in range(4) if j != col]
        for i in range(4) if i != row
    ]


def _kinverse4(matrix, determinant=None):
    det = _kdet(matrix) if determinant is None else determinant
    assert not det.is_zero
    # inverse[col][row] = cofactor[row][col] / det
    inverse = [[K.zero for _ in range(4)] for _ in range(4)]
    for row in range(4):
        for col in range(4):
            cof = _kdet(_kminor(matrix, row, col))
            if (row + col) % 2:
                cof = -cof
            inverse[col][row] = cof / det
    return inverse


def _convert_points(points):
    return [[_to_field(points[j][i]) for i in range(4)] for j in range(len(points))]


def _convert_first(first_derivatives):
    return [
        [[_to_field(D[i, a]) for a in range(D.cols)] for i in range(4)]
        for D in first_derivatives
    ]


def _convert_second(second_derivatives):
    return [
        [
            [[_to_field(M[a, b]) for b in range(M.cols)] for a in range(M.rows)]
            for M in point
        ]
        for point in second_derivatives
    ]


def _field_sign(value):
    expression = K.to_sympy(value)
    sign = sp.sign(expression)
    assert sign in (-1, 1), ('undecided exact field sign', expression, sign)
    return int(sign)


def _accumulate_tetrahedron(volume, gradient, hessian, point_vectors, derivative_matrices,
                            support, second_matrices=None):
    p = len(gradient)
    # X is row-major; its columns are the four tetrahedron vertices.
    X = [[point_vectors[support[col]][row] for col in range(4)] for row in range(4)]
    det = _kdet(X)
    assert not det.is_zero
    inv = _kinverse4(X, det)
    sign = _field_sign(det)
    scale = _to_field(sp.Rational(sign, 24))
    volume += scale * det

    # Cofactor column c, coordinate i: det * inv[c][i].
    cof = [[det * inv[c][i] for i in range(4)] for c in range(4)]
    Ds = [derivative_matrices[support[c]] for c in range(4)]

    for c in range(4):
        Dc = Ds[c]
        for a in range(p):
            value = K.zero
            for i in range(4):
                value += cof[c][i] * Dc[i][a]
            gradient[a] += scale * value

    # Cross-column second derivative.  The determinant is linear in each
    # column, so there are no same-column terms.
    for c in range(4):
        Dc = Ds[c]
        for d in range(c+1, 4):
            Dd = Ds[d]
            kernel = [[
                det * (inv[c][i] * inv[d][j] - inv[c][j] * inv[d][i])
                for j in range(4)
            ] for i in range(4)]
            temp = [[K.zero for _ in range(p)] for _ in range(4)]
            for i in range(4):
                for b in range(p):
                    value = K.zero
                    for j in range(4):
                        value += kernel[i][j] * Dd[j][b]
                    temp[i][b] = value
            # B = Dc^T * kernel * Dd; add B+B^T.
            for a in range(p):
                for b in range(p):
                    value = K.zero
                    for i in range(4):
                        value += Dc[i][a] * temp[i][b]
                    hessian[a][b] += scale * value
                    hessian[b][a] += scale * value

    if second_matrices is not None:
        second = [second_matrices[support[c]] for c in range(4)]
        for c in range(4):
            for i in range(4):
                coefficient = scale * cof[c][i]
                if coefficient.is_zero:
                    continue
                matrix = second[c][i]
                for a in range(p):
                    for b in range(p):
                        if not matrix[a][b].is_zero:
                            hessian[a][b] += coefficient * matrix[a][b]
    return volume


def _volume_derivatives_field(signed_points, signed_first, tetrahedra, signed_second=None):
    p = signed_first[0].cols
    points = _convert_points(signed_points)
    derivatives = _convert_first(signed_first)
    second = _convert_second(signed_second) if signed_second is not None else None
    volume = K.zero
    gradient = [K.zero for _ in range(p)]
    hessian = [[K.zero for _ in range(p)] for _ in range(p)]
    for index, raw in enumerate(tetrahedra, 1):
        volume = _accumulate_tetrahedron(
            volume, gradient, hessian, points, derivatives, tuple(raw), second
        )
        if index % 24 == 0:
            print(f"    field accumulation {index}/{len(tetrahedra)}", flush=True)
    return K.to_sympy(volume), _field_vector_to_matrix(gradient), _field_matrix_to_sympy(hessian)


def volume_derivatives_linear_field(signed_points, signed_first, tetrahedra):
    return _volume_derivatives_field(signed_points, signed_first, tetrahedra)


def volume_derivatives_nonlinear_field(signed_points, signed_first, signed_second, tetrahedra):
    return _volume_derivatives_field(signed_points, signed_first, tetrahedra, signed_second)


def volume_gradient_linear_field(signed_points, signed_first, tetrahedra):
    """Exact field-level volume and gradient only."""
    p = signed_first[0].cols
    points = _convert_points(signed_points)
    derivatives = _convert_first(signed_first)
    volume = K.zero
    gradient = [K.zero for _ in range(p)]
    for raw in tetrahedra:
        support = tuple(raw)
        X = [[points[support[col]][row] for col in range(4)] for row in range(4)]
        det = _kdet(X)
        assert not det.is_zero
        inv = _kinverse4(X, det)
        sign = _field_sign(det)
        scale = _to_field(sp.Rational(sign, 24))
        volume += scale * det
        for c in range(4):
            D = derivatives[support[c]]
            for a in range(p):
                value = K.zero
                for i in range(4):
                    value += det * inv[c][i] * D[i][a]
                gradient[a] += scale * value
    return K.to_sympy(volume), _field_vector_to_matrix(gradient)

sec.volume_derivatives_linear_vertices=volume_derivatives_linear_field
sec.volume_derivatives_nonlinear_vertices=volume_derivatives_nonlinear_field


def _kmatmul(A, B):
    rows, inner, cols = len(A), len(B), len(B[0])
    assert len(A[0]) == inner
    out = [[K.zero for _ in range(cols)] for _ in range(rows)]
    for i in range(rows):
        for k in range(inner):
            aik = A[i][k]
            if aik.is_zero:
                continue
            for j in range(cols):
                if not B[k][j].is_zero:
                    out[i][j] += aik * B[k][j]
    return out


def _kmatvec(A, v):
    return [sum((A[i][j] * v[j] for j in range(len(v))), K.zero) for i in range(len(A))]


def normal_extension_data_field(vertices, normals, points, point_meta, facets,
                                representative_derivatives, policy, compute_second=True):
    """Exact normal extension over QQ(sqrt(2)), without SymPy expression growth."""
    p = representative_derivatives[0].cols
    point_derivatives = [side * representative_derivatives[pair] for pair, side in point_meta]
    point_values = _convert_points(points)
    derivative_values = _convert_first(point_derivatives)
    normal_points = []
    normal_first = []
    normal_second = []
    chosen_bases = []
    for facet_pair, expected_normal in enumerate(normals):
        support = facets[2 * facet_pair]
        basis = sec.choose_facet_basis(points, support, policy)
        chosen_bases.append(basis)
        M = [point_values[index][:] for index in basis]
        det = _kdet(M)
        assert not det.is_zero
        inv = _kinverse4(M, det)
        n = _kmatvec(inv, [K.one] * 4)
        expected = [_to_field(z) for z in expected_normal]
        assert n == expected, (facet_pair, n, expected)
        dMs = []
        products = []
        for a in range(p):
            dM = [[derivative_values[index][coord][a] for coord in range(4)] for index in basis]
            dMs.append(dM)
            products.append(_kmatmul(inv, dM))
        first_values = [[K.zero for _ in range(p)] for _ in range(4)]
        for a in range(p):
            value = _kmatvec(products[a], n)
            for coord in range(4):
                first_values[coord][a] = -value[coord]
        normal_points.append(sp.Matrix([K.to_sympy(z) for z in n]))
        normal_first.append(_field_matrix_to_sympy(first_values))
        if compute_second:
            coordinate_hessians = [
                [[K.zero for _ in range(p)] for _ in range(p)] for _ in range(4)
            ]
            for a in range(p):
                for b in range(a, p):
                    pab = _kmatmul(products[a], products[b])
                    pba = _kmatmul(products[b], products[a])
                    total = [[pab[i][j] + pba[i][j] for j in range(4)] for i in range(4)]
                    value = _kmatvec(total, n)
                    for coord in range(4):
                        coordinate_hessians[coord][a][b] = value[coord]
                        coordinate_hessians[coord][b][a] = value[coord]
            normal_second.append([_field_matrix_to_sympy(H) for H in coordinate_hessians])
        else:
            normal_second.append([])
        print(f"    normal extension {facet_pair+1}/{len(normals)} ({policy})", flush=True)
    return normal_points, normal_first, normal_second, chosen_bases

def matrix_zero(M):
    try:
        return first.dm(M).is_zero_matrix
    except Exception:
        return M.applyfunc(simp)==sp.zeros(M.rows,M.cols)

def solve_particular(A:sp.Matrix,b:sp.Matrix)->tuple[sp.Matrix,int]:
 aug=A.row_join(b)
 reduced,pivots=first.rref_exact(aug)
 assert A.cols not in pivots
 pv=[p for p in pivots if p<A.cols]
 free=[j for j in range(A.cols) if j not in pv]
 x=sp.zeros(A.cols,1)
 for row,p in enumerate(pv): x[p]=simp(reduced[row,A.cols])
 assert matrix_zero(A*x-b)
 return x,len(free)

def quotient_basis(J:sp.Matrix,gl:sp.Matrix)->sp.Matrix:
    # Exact coordinate slice: freeze four independent vertex-pair representatives.
    # For the product input, pairs (0,1,7,8) have determinant 2, so no nonzero
    # infinitesimal GL(4) motion survives this gauge.
    fixed_pairs=(0,1,7,8)
    fixed_columns={DIM*i+d for i in fixed_pairs for d in range(DIM)}
    free_columns=[j for j in range(J.cols) if j not in fixed_columns]
    reduced=J[:,free_columns]
    assert first.rank_exact(reduced)==J.rows
    basis=first.nullspace_columns(reduced)
    Q=sp.zeros(J.cols,len(basis))
    for k,vector in enumerate(basis):
        for i,column in enumerate(free_columns):
            Q[column,k]=vector[i]
    assert Q.cols==J.cols-J.rows-16==12
    assert matrix_zero(J*Q)
    assert first.rank_exact(gl.row_join(Q))==16+Q.cols
    return Q



def constraint_hessians_on_basis_field(records, points, point_derivatives, pairs):
    """Hessians of singular four-column determinant constraints.

    The base determinant vanishes (rank-three facet wall), so Jacobi's inverse
    formula is inapplicable.  Multilinearity gives the Hessian exactly from the
    six unordered column-pair replacement kernels, with no division.
    """
    p = point_derivatives[0].cols
    point_values = _convert_points(points)
    derivative_values = _convert_first(point_derivatives)
    hessians = []
    for record_index, record in enumerate(records, 1):
        basis = [tuple(item) for item in record['affine_basis']]
        extra = tuple(record['extra_vertex'])
        basis_ids = [sec.signed_index(item, pairs) for item in basis]
        extra_id = sec.signed_index(extra, pairs)
        ids = [basis_ids[k] for k in range(1, DIM)] + [extra_id]
        base_id = basis_ids[0]
        columns = [
            [point_values[idx][coord] - point_values[base_id][coord] for coord in range(4)]
            for idx in ids
        ]
        derivatives = [
            [
                [derivative_values[idx][coord][a] - derivative_values[base_id][coord][a]
                 for a in range(p)]
                for coord in range(4)
            ]
            for idx in ids
        ]
        X = [[columns[col][row] for col in range(4)] for row in range(4)]
        assert _kdet(X).is_zero
        H = [[K.zero for _ in range(p)] for _ in range(p)]
        for c in range(4):
            Dc = derivatives[c]
            for d in range(c+1, 4):
                Dd = derivatives[d]
                kernel = [[K.zero for _ in range(4)] for _ in range(4)]
                for i in range(4):
                    for j in range(4):
                        Y = [row[:] for row in X]
                        for row in range(4):
                            Y[row][c] = K.one if row == i else K.zero
                            Y[row][d] = K.one if row == j else K.zero
                        kernel[i][j] = _kdet(Y)
                temp = [[K.zero for _ in range(p)] for _ in range(4)]
                for i in range(4):
                    for b in range(p):
                        value = K.zero
                        for j in range(4):
                            value += kernel[i][j] * Dd[j][b]
                        temp[i][b] = value
                for a in range(p):
                    for b in range(p):
                        value = K.zero
                        for i in range(4):
                            value += Dc[i][a] * temp[i][b]
                        H[a][b] += value
                        H[b][a] += value
        hessians.append(_field_matrix_to_sympy(H))
        if record_index % 12 == 0:
            print(f"    constraint Hessians {record_index}/{len(records)}", flush=True)
    return hessians

def compute_extension(vertices,normals,first_certificate,J,Q,policy):
 t0=time.time(); print(f'  extension {policy}: geometry',flush=True)
 pairs=len(vertices); p=Q.cols
 points_raw,point_meta,facets,_=first.exact_full_facets(vertices,normals)
 points=[sp.Matrix(x) for x in points_raw]
 primal_boundary=first.boundary_triangulation(points_raw,facets)
 polar_raw,polar_meta,polar_facets,_=first.exact_full_facets(normals,vertices)
 polar_points=[sp.Matrix(x) for x in polar_raw]
 polar_boundary=first.boundary_triangulation(polar_raw,polar_facets)
 reps=[Q[DIM*i:DIM*i+DIM,:] for i in range(pairs)]
 point_derivatives=[side*reps[pair] for pair,side in point_meta]
 print(f'  extension {policy}: primal derivatives',flush=True)
 pv,pg,pH=sec.volume_derivatives_linear_vertices(points,point_derivatives,primal_boundary['tetrahedra'])
 print(f'  extension {policy}: normal extension',flush=True)
 _,nfirst,nsecond,bases=normal_extension_data_field(vertices,normals,points,point_meta,facets,reps,policy,True)
 signed_first=[side*nfirst[pair] for pair,side in polar_meta]
 signed_second=[[side*M for M in nsecond[pair]] for pair,side in polar_meta]
 print(f'  extension {policy}: polar derivatives',flush=True)
 qv,qg,qH=sec.volume_derivatives_nonlinear_vertices(polar_points,signed_first,signed_second,polar_boundary['tetrahedra'])
 ep=first.parse_q(first_certificate['primal_volume']); eq=first.parse_q(first_certificate['polar_volume'])
 assert simp(pv-ep)==0 and simp(qv-eq)==0
 mg=(qv*pg+pv*qg).applyfunc(simp)
 assert mg==sp.zeros(p,1),mg
 mH=(qv*pH+pv*qH+pg*qg.T+qg*pg.T).applyfunc(simp)
 print(f'  extension {policy}: ambient extension gradient',flush=True)
 ambient=DIM*pairs
 areps=[sp.zeros(DIM,ambient) for _ in vertices]
 for pair in range(pairs): areps[pair][:,DIM*pair:DIM*pair+DIM]=sp.eye(DIM)
 apoints=[side*areps[pair] for pair,side in point_meta]
 _,anfirst,_,ambient_bases=normal_extension_data_field(vertices,normals,points,point_meta,facets,areps,policy,False)
 assert ambient_bases==bases
 asigned=[side*anfirst[pair] for pair,side in polar_meta]
 _,aqg=volume_gradient_linear_field(polar_points,asigned,polar_boundary['tetrahedra'])
 apg=sp.Matrix([first.parse_q(z) for row in first_certificate['primal_gradient'] for z in row])
 amg=(qv*apg+pv*aqg).applyfunc(simp)
 mult,free=solve_particular(J.T,amg)
 print(f'  extension {policy}: multipliers free={free}',flush=True)
 _,crecords=first.determinant_constraint_matrix(vertices,normals)
 cHs=constraint_hessians_on_basis_field(crecords,points,point_derivatives,pairs)
 red=mH.copy()
 for lam,H in zip(mult,cHs): red-=lam*H
 red=red.applyfunc(simp)
 canonical_g=sp.Matrix([first.parse_q(z) for z in first_certificate['Mahler_gradient']])
 canonical_l=sp.Matrix([first.parse_q(z) for z in first_certificate['variational_certificate']['Mahler_stress']['multipliers']])
 assert matrix_zero(J.T*canonical_l-canonical_g)
 assert matrix_zero(amg-canonical_g-J.T*(mult-canonical_l))
 print(f'  extension {policy}: done {time.time()-t0:.1f}s',flush=True)
 return {'reduced':red,'mahler_hessian':mH,'matching':mult,'canonical':canonical_l,'ambient_gradient':amg,
         'bases':bases,'primal_tets':len(primal_boundary['tetrahedra']),'polar_tets':len(polar_boundary['tetrahedra'])}

def inertia(M):
 # Reuse congruence routine; Q(sqrt2) signs are exactly decidable.
 return sec.exact_inertia_by_congruence(M)

def analyze(data,first_certificate):
 vertices=[tuple(first.parse_q(z) for z in row) for row in data['vertex_pair_representatives']]
 normals=[tuple(first.parse_q(z) for z in row) for row in data['facet_normal_pair_representatives']]
 print('build J/gl',flush=True)
 J,_=first.determinant_constraint_matrix(vertices,normals)
 gl=first.gl_motion_matrix(vertices)
 assert first.rank_exact(J)==J.rows==68
 print('build quotient',flush=True)
 Q=quotient_basis(J,gl); print('quotient dim',Q.cols,flush=True)
 e1=compute_extension(vertices,normals,first_certificate,J,Q,'first')
 e2=compute_extension(vertices,normals,first_certificate,J,Q,'last')
 assert matrix_zero(e1['reduced']-e2['reduced'])
 R=e1['reduced']
 print('inertia',flush=True); iner=inertia(R); print(iner['positive'],iner['negative'],iner['zero'],flush=True)
 # Persist the expensive exact core before optional spectral compression.
 core={'quotient_basis':bcols(Q),'reduced_Lagrangian_Hessian':mstr(R),'inertia':iner,
       'first_matching_multipliers':cstr(e1['matching']),'last_matching_multipliers':cstr(e2['matching'])}
 (ROOT/'viterbo_global_hexagon_octagon_product_second_variation_core_v42.json').write_text(json.dumps(core,indent=2,sort_keys=True))
 print('metric/domain-matrix curvature',flush=True)
 # Natural Euclidean quotient metric, evaluated directly in QQ(sqrt(2)).
 dQ=first.dm(Q); dgl=first.dm(gl); dR=first.dm(R)
 gtg=dgl.transpose()*dgl
 Gd=dQ.transpose()*dQ-dQ.transpose()*dgl*gtg.inv()*dgl.transpose()*dQ
 assert Gd.rank()==Q.cols
 Ad=Gd.inv()*dR
 G=Gd.to_Matrix(); A=Ad.to_Matrix()
 coeff=Ad.charpoly()
 lam=sp.Symbol('lambda')
 char=sp.Add(*[K.to_sympy(c)*lam**(len(coeff)-1-i) for i,c in enumerate(coeff)])
 char=sp.Poly(char,lam,extension=sp.sqrt(2)).as_expr()
 print('spectral data done',flush=True)
 return {
  'status':'PASS','name':data['name'],'number_field':'Q(sqrt(2))','dimension':4,
  'vertex_pairs':len(vertices),'facet_pairs':len(normals),
  'primal_volume':first_certificate['primal_volume'],'polar_volume':first_certificate['polar_volume'],
  'Mahler_product':first_certificate['Mahler_product'],'constraint_rows':J.rows,'constraint_rank':first.rank_exact(J),
  'ambient_velocity_dimension':J.cols,'GL_dimension':16,'quotient_dimension':Q.cols,
  'quotient_basis':bcols(Q),'quotient_metric':mstr(G),'reduced_Lagrangian_Hessian':mstr(R),
  'curvature_operator':mstr(A),'curvature_characteristic_polynomial':str(sp.factor(char,extension=sp.sqrt(2))),'inertia':iner,
  'extension_covariance':{'first_and_last_agree':True,'first_bases':[list(x) for x in e1['bases']],
    'last_bases':[list(x) for x in e2['bases']],
    'first_matching_multipliers':cstr(e1['matching']),'last_matching_multipliers':cstr(e2['matching'])},
  'triangulations':{'primal_tetrahedra':e1['primal_tets'],'polar_tetrahedra':e1['polar_tets']},
  'scope_warning':'Fixed-face-lattice second variation at the affine-regular hexagon times regular octagon product.'
 }

def main():
 ap=argparse.ArgumentParser();ap.add_argument('input',type=Path);ap.add_argument('--first-certificate',required=True,type=Path);ap.add_argument('--certificate',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
 data=json.loads(a.input.read_text());fc=json.loads(a.first_certificate.read_text());cert=analyze(data,fc)
 a.certificate.write_text(json.dumps(cert,indent=2,sort_keys=True))
 I=cert['inertia'];out={'status':'PASS','name':cert['name'],'Mahler_product':cert['Mahler_product'],'constraint_rank':cert['constraint_rank'],'quotient_dimension':cert['quotient_dimension'],'reduced_Hessian_inertia':[I['positive'],I['negative'],I['zero']],'characteristic_polynomial':cert['curvature_characteristic_polynomial'],'certificate':a.certificate.name,'certificate_sha256':sha256(a.certificate)}
 a.output.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
