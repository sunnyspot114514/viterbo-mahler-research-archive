#!/usr/bin/env python3
"""Exact second-variation analyzer on a regular fixed-face-lattice stratum.

The input schema is the same as viterbo_mahler_first_variation_analyzer.py:

  {
    "name": "...",
    "vertex_pair_representatives": [[...], ...],
    "facet_normal_pair_representatives": [[...], ...]
  }

The analyzer:
  * reconstructs exact primal and polar boundary triangulations;
  * builds the facet-coplanarity Jacobian J and a quotient basis ker(J)/gl(4);
  * differentiates primal volume and a chosen smooth polar-normal extension to
    second order;
  * solves for the KKT multipliers matching that SAME off-stratum extension;
  * forms the reduced Lagrangian Hessian on the quotient;
  * repeats the computation with two different facet-basis extensions and
    checks exact extension covariance;
  * provides an exact congruence-inertia certificate.

The matching-multiplier step is essential.  Reusing multipliers belonging to a
second, different off-stratum extension can change the displayed quadratic form
on the tangent space and can create spurious curvature signs.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
from typing import Iterable

import sympy as sp

ROOT = Path(__file__).resolve().parent
FIRST_PATH = ROOT / "viterbo_mahler_first_variation_analyzer.py"
DIM = 4
FACT = 24


def load_first():
    spec = importlib.util.spec_from_file_location("first_variation", FIRST_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


first = load_first()


def parse_q(value) -> sp.Rational:
    return sp.Rational(str(value))


def qstr(value: sp.Expr) -> str:
    return str(sp.factor(sp.cancel(value)))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix_strings(matrix: sp.Matrix) -> list[list[str]]:
    return [[qstr(matrix[i, j]) for j in range(matrix.cols)] for i in range(matrix.rows)]


def column_strings(vector: sp.Matrix) -> list[str]:
    return [qstr(value) for value in vector]


def basis_columns(matrix: sp.Matrix) -> list[list[str]]:
    return [column_strings(matrix[:, j]) for j in range(matrix.cols)]


def determinant4(columns: list[sp.Matrix]) -> sp.Expr:
    return sp.Matrix.hstack(*columns).det(method="domain-ge")


def pair_kernel(columns: list[sp.Matrix], first_index: int, second_index: int) -> sp.Matrix:
    result = sp.zeros(DIM)
    identity = sp.eye(DIM)
    for a in range(DIM):
        for b in range(DIM):
            modified = list(columns)
            modified[first_index] = identity[:, a]
            modified[second_index] = identity[:, b]
            result[a, b] = determinant4(modified)
    return result


def determinant_derivatives(
    columns: list[sp.Matrix],
    first_derivatives: list[sp.Matrix],
    second_derivatives: list[list[sp.Matrix]] | None = None,
) -> tuple[sp.Matrix, sp.Matrix]:
    parameter_dimension = first_derivatives[0].cols
    matrix = sp.Matrix.hstack(*columns)
    cofactor = matrix.cofactor_matrix()
    gradient = sp.zeros(parameter_dimension, 1)
    hessian = sp.zeros(parameter_dimension)
    for column, derivative in enumerate(first_derivatives):
        gradient += derivative.T * cofactor[:, column]
        if second_derivatives is not None:
            for coordinate in range(DIM):
                hessian += cofactor[coordinate, column] * second_derivatives[column][coordinate]
    for a, b in itertools.combinations(range(DIM), 2):
        mixed = (
            first_derivatives[a].T
            * pair_kernel(columns, a, b)
            * first_derivatives[b]
        )
        hessian += mixed + mixed.T
    return gradient.applyfunc(sp.factor), hessian.applyfunc(sp.factor)


def quotient_basis(J: sp.Matrix, gl: sp.Matrix) -> sp.Matrix:
    quotient_dimension = J.cols - J.rank() - gl.rank()
    span = gl.copy()
    extra: list[sp.Matrix] = []
    for vector in J.nullspace():
        if span.row_join(vector).rank() > span.rank():
            primitive = sp.Matrix(first.primitive_vector(vector))
            extra.append(primitive)
            span = span.row_join(primitive)
        if len(extra) == quotient_dimension:
            break
    assert len(extra) == quotient_dimension
    result = sp.Matrix.hstack(*extra) if extra else sp.zeros(J.cols, 0)
    assert J * result == sp.zeros(J.rows, result.cols)
    assert gl.row_join(result).rank() == gl.rank() + result.cols
    return result


def choose_facet_basis(
    points: list[sp.Matrix], support: tuple[int, ...], policy: str
) -> tuple[int, ...]:
    candidates = [
        ids
        for ids in itertools.combinations(support, DIM)
        if sp.Matrix.vstack(*[points[index].T for index in ids]).det(method="domain-ge") != 0
    ]
    assert candidates
    if policy == "first":
        return candidates[0]
    if policy == "last":
        return candidates[-1]
    raise ValueError(policy)


def exact_inertia_by_congruence(matrix: sp.Matrix) -> dict:
    current = sp.Matrix(matrix)
    positive = negative = zero = 0
    pivots: list[dict] = []
    while current.rows:
        n = current.rows
        diagonal_index = next((i for i in range(n) if current[i, i] != 0), None)
        if diagonal_index is not None:
            if diagonal_index != 0:
                order = [diagonal_index] + [i for i in range(n) if i != diagonal_index]
                current = current.extract(order, order)
            pivot = sp.factor(current[0, 0])
            if pivot > 0:
                positive += 1
            else:
                negative += 1
            pivots.append({"size": 1, "pivot": qstr(pivot)})
            if n == 1:
                break
            column = current[1:, 0]
            current = (current[1:, 1:] - column * column.T / pivot).applyfunc(sp.factor)
            continue
        pair = next(
            (
                (i, j)
                for i in range(n)
                for j in range(i + 1, n)
                if current[i, j] != 0
            ),
            None,
        )
        if pair is None:
            zero += n
            break
        i, j = pair
        order = [i, j] + [k for k in range(n) if k not in (i, j)]
        current = current.extract(order, order)
        pivot = current[:2, :2]
        determinant = sp.factor(pivot.det(method="domain-ge"))
        trace = sp.factor(sp.trace(pivot))
        if determinant < 0:
            positive += 1
            negative += 1
        elif determinant > 0 and trace > 0:
            positive += 2
        elif determinant > 0 and trace < 0:
            negative += 2
        else:
            raise AssertionError((pivot, determinant, trace))
        pivots.append({"size": 2, "block": matrix_strings(pivot)})
        if n == 2:
            break
        cross = current[2:, :2]
        current = (current[2:, 2:] - cross * pivot.inv() * cross.T).applyfunc(sp.factor)
    return {
        "positive": positive,
        "negative": negative,
        "zero": zero,
        "congruence_pivots": pivots,
    }


def signed_index(item: tuple[int, int], pairs: int) -> int:
    pair, side = item
    return pair if side == 1 else pair + pairs


def normal_extension_data(
    vertices: list[tuple[sp.Rational, ...]],
    normals: list[tuple[sp.Rational, ...]],
    points: list[sp.Matrix],
    point_meta: list[tuple[int, int]],
    facets: list[tuple[int, ...]],
    representative_derivatives: list[sp.Matrix],
    policy: str,
) -> tuple[
    list[sp.Matrix],
    list[sp.Matrix],
    list[list[sp.Matrix]],
    list[tuple[int, ...]],
]:
    parameter_dimension = representative_derivatives[0].cols
    point_derivatives = [
        side * representative_derivatives[pair] for pair, side in point_meta
    ]
    normal_points: list[sp.Matrix] = []
    normal_first: list[sp.Matrix] = []
    normal_second: list[list[sp.Matrix]] = []
    chosen_bases: list[tuple[int, ...]] = []
    for facet_pair, expected_normal in enumerate(normals):
        support = facets[2 * facet_pair]
        basis = choose_facet_basis(points, support, policy)
        chosen_bases.append(basis)
        matrix = sp.Matrix.vstack(*[points[index].T for index in basis])
        inverse = matrix.inv()
        normal = inverse * sp.ones(DIM, 1)
        assert normal == sp.Matrix(expected_normal)
        matrix_derivatives = [
            sp.Matrix.vstack(*[point_derivatives[index][:, a].T for index in basis])
            for a in range(parameter_dimension)
        ]
        products = [inverse * derivative for derivative in matrix_derivatives]
        first_derivative = sp.zeros(DIM, parameter_dimension)
        for a in range(parameter_dimension):
            first_derivative[:, a] = -products[a] * normal
        coordinate_hessians = [sp.zeros(parameter_dimension) for _ in range(DIM)]
        for a in range(parameter_dimension):
            for b in range(a, parameter_dimension):
                value = (
                    products[a] * products[b] * normal
                    + products[b] * products[a] * normal
                )
                for coordinate in range(DIM):
                    coordinate_hessians[coordinate][a, b] = value[coordinate]
                    coordinate_hessians[coordinate][b, a] = value[coordinate]
        normal_points.append(normal)
        normal_first.append(first_derivative.applyfunc(sp.factor))
        normal_second.append(
            [matrix.applyfunc(sp.factor) for matrix in coordinate_hessians]
        )
    return normal_points, normal_first, normal_second, chosen_bases


def volume_derivatives_linear_vertices(
    signed_points: list[sp.Matrix],
    signed_first: list[sp.Matrix],
    tetrahedra: Iterable[Iterable[int]],
) -> tuple[sp.Expr, sp.Matrix, sp.Matrix]:
    parameter_dimension = signed_first[0].cols
    volume = sp.Integer(0)
    gradient = sp.zeros(parameter_dimension, 1)
    hessian = sp.zeros(parameter_dimension)
    for raw in tetrahedra:
        support = tuple(raw)
        columns = [signed_points[index] for index in support]
        derivatives = [signed_first[index] for index in support]
        determinant = determinant4(columns)
        assert determinant != 0
        sign = 1 if determinant > 0 else -1
        local_gradient, local_hessian = determinant_derivatives(columns, derivatives)
        volume += sp.Rational(sign, FACT) * determinant
        gradient += sp.Rational(sign, FACT) * local_gradient
        hessian += sp.Rational(sign, FACT) * local_hessian
    return (
        sp.factor(volume),
        gradient.applyfunc(sp.factor),
        hessian.applyfunc(sp.factor),
    )


def volume_derivatives_nonlinear_vertices(
    signed_points: list[sp.Matrix],
    signed_first: list[sp.Matrix],
    signed_second: list[list[sp.Matrix]],
    tetrahedra: Iterable[Iterable[int]],
) -> tuple[sp.Expr, sp.Matrix, sp.Matrix]:
    parameter_dimension = signed_first[0].cols
    volume = sp.Integer(0)
    gradient = sp.zeros(parameter_dimension, 1)
    hessian = sp.zeros(parameter_dimension)
    for raw in tetrahedra:
        support = tuple(raw)
        columns = [signed_points[index] for index in support]
        derivatives = [signed_first[index] for index in support]
        second = [signed_second[index] for index in support]
        determinant = determinant4(columns)
        assert determinant != 0
        sign = 1 if determinant > 0 else -1
        local_gradient, local_hessian = determinant_derivatives(
            columns, derivatives, second
        )
        volume += sp.Rational(sign, FACT) * determinant
        gradient += sp.Rational(sign, FACT) * local_gradient
        hessian += sp.Rational(sign, FACT) * local_hessian
    return (
        sp.factor(volume),
        gradient.applyfunc(sp.factor),
        hessian.applyfunc(sp.factor),
    )


def constraint_hessians_on_basis(
    records: list[dict],
    points: list[sp.Matrix],
    point_derivatives: list[sp.Matrix],
    pairs: int,
) -> list[sp.Matrix]:
    hessians: list[sp.Matrix] = []
    for record in records:
        basis = [tuple(item) for item in record["affine_basis"]]
        extra = tuple(record["extra_vertex"])
        basis_ids = [signed_index(item, pairs) for item in basis]
        extra_id = signed_index(extra, pairs)
        columns = [
            points[basis_ids[k]] - points[basis_ids[0]] for k in range(1, DIM)
        ] + [points[extra_id] - points[basis_ids[0]]]
        derivatives = [
            point_derivatives[basis_ids[k]] - point_derivatives[basis_ids[0]]
            for k in range(1, DIM)
        ] + [point_derivatives[extra_id] - point_derivatives[basis_ids[0]]]
        _, hessian = determinant_derivatives(columns, derivatives)
        hessians.append(hessian)
    return hessians


def compute_extension(
    vertices: list[tuple[sp.Rational, ...]],
    normals: list[tuple[sp.Rational, ...]],
    first_certificate: dict,
    J: sp.Matrix,
    quotient: sp.Matrix,
    policy: str,
) -> dict:
    pairs = len(vertices)
    parameter_dimension = quotient.cols
    points_raw, point_meta, facets, _ = first.exact_full_facets(vertices, normals)
    points = [sp.Matrix(point) for point in points_raw]
    primal_boundary = first.boundary_triangulation(points_raw, facets)
    polar_raw, polar_meta, polar_facets, _ = first.exact_full_facets(normals, vertices)
    polar_points = [sp.Matrix(point) for point in polar_raw]
    polar_boundary = first.boundary_triangulation(polar_raw, polar_facets)

    representative_derivatives = [
        quotient[DIM * pair : DIM * pair + DIM, :] for pair in range(pairs)
    ]
    point_derivatives = [
        side * representative_derivatives[pair] for pair, side in point_meta
    ]
    primal_volume, primal_gradient, primal_hessian = volume_derivatives_linear_vertices(
        points, point_derivatives, primal_boundary["tetrahedra"]
    )

    normal_points, normal_first, normal_second, chosen_bases = normal_extension_data(
        vertices,
        normals,
        points,
        point_meta,
        facets,
        representative_derivatives,
        policy,
    )
    del normal_points
    signed_normal_first = [
        side * normal_first[pair] for pair, side in polar_meta
    ]
    signed_normal_second = [
        [side * matrix for matrix in normal_second[pair]]
        for pair, side in polar_meta
    ]
    polar_volume, polar_gradient, polar_hessian = volume_derivatives_nonlinear_vertices(
        polar_points,
        signed_normal_first,
        signed_normal_second,
        polar_boundary["tetrahedra"],
    )

    expected_primal = parse_q(first_certificate["primal_volume"])
    expected_polar = parse_q(first_certificate["polar_volume"])
    assert primal_volume == expected_primal
    assert polar_volume == expected_polar
    mahler_gradient = (
        polar_volume * primal_gradient + primal_volume * polar_gradient
    ).applyfunc(sp.factor)
    assert mahler_gradient == sp.zeros(parameter_dimension, 1)
    mahler_hessian = (
        polar_volume * primal_hessian
        + primal_volume * polar_hessian
        + primal_gradient * polar_gradient.T
        + polar_gradient * primal_gradient.T
    ).applyfunc(sp.factor)

    # Compute the ambient gradient of this same off-stratum extension.  This is
    # the gradient that must be used to solve for its Lagrange multipliers.
    ambient_dimension = DIM * pairs
    ambient_representative_derivatives = [
        sp.zeros(DIM, ambient_dimension) for _ in vertices
    ]
    for pair in range(pairs):
        ambient_representative_derivatives[pair][
            :, DIM * pair : DIM * pair + DIM
        ] = sp.eye(DIM)
    ambient_point_derivatives = [
        side * ambient_representative_derivatives[pair]
        for pair, side in point_meta
    ]
    ambient_normal_first: list[sp.Matrix] = []
    for facet_pair, basis in enumerate(chosen_bases):
        matrix = sp.Matrix.vstack(*[points[index].T for index in basis])
        inverse = matrix.inv()
        normal = inverse * sp.ones(DIM, 1)
        derivative = sp.zeros(DIM, ambient_dimension)
        for coordinate in range(ambient_dimension):
            matrix_derivative = sp.Matrix.vstack(
                *[ambient_point_derivatives[index][:, coordinate].T for index in basis]
            )
            derivative[:, coordinate] = -inverse * matrix_derivative * normal
        ambient_normal_first.append(derivative)
    ambient_signed_normal_first = [
        side * ambient_normal_first[pair] for pair, side in polar_meta
    ]
    _, ambient_polar_gradient, _ = volume_derivatives_linear_vertices(
        polar_points,
        ambient_signed_normal_first,
        polar_boundary["tetrahedra"],
    )
    ambient_primal_gradient = sp.Matrix(
        [parse_q(value) for row in first_certificate["primal_gradient"] for value in row]
    )
    ambient_mahler_gradient = (
        polar_volume * ambient_primal_gradient
        + primal_volume * ambient_polar_gradient
    ).applyfunc(sp.factor)
    solutions = sp.linsolve((J.T, ambient_mahler_gradient))
    assert solutions != sp.EmptySet
    matching_multipliers = sp.Matrix(list(next(iter(solutions))))
    assert not set().union(*(entry.free_symbols for entry in matching_multipliers))
    assert J.T * matching_multipliers == ambient_mahler_gradient

    _, constraint_records = first.determinant_constraint_matrix(vertices, normals)
    constraint_hessians = constraint_hessians_on_basis(
        constraint_records, points, point_derivatives, pairs
    )
    assert len(constraint_hessians) == J.rows == len(matching_multipliers)
    reduced = mahler_hessian.copy()
    for multiplier, hessian in zip(matching_multipliers, constraint_hessians):
        reduced -= multiplier * hessian
    reduced = reduced.applyfunc(sp.factor)

    canonical_gradient = sp.Matrix(
        [parse_q(value) for value in first_certificate["Mahler_gradient"]]
    )
    canonical_multipliers = sp.Matrix(
        [
            parse_q(value)
            for value in first_certificate["variational_certificate"]["Mahler_stress"][
                "multipliers"
            ]
        ]
    )
    assert J.T * canonical_multipliers == canonical_gradient
    assert (
        ambient_mahler_gradient - canonical_gradient
        == J.T * (matching_multipliers - canonical_multipliers)
    )
    naive = mahler_hessian.copy()
    for multiplier, hessian in zip(canonical_multipliers, constraint_hessians):
        naive -= multiplier * hessian
    naive = naive.applyfunc(sp.factor)

    return {
        "policy": policy,
        "primal_volume": primal_volume,
        "polar_volume": polar_volume,
        "primal_gradient": primal_gradient,
        "polar_gradient": polar_gradient,
        "mahler_hessian": mahler_hessian,
        "matching_multipliers": matching_multipliers,
        "canonical_multipliers": canonical_multipliers,
        "ambient_extension_gradient": ambient_mahler_gradient,
        "canonical_gradient": canonical_gradient,
        "reduced_hessian": reduced,
        "naive_mismatched_hessian": naive,
        "chosen_facet_bases": chosen_bases,
        "primal_tetrahedra": len(primal_boundary["tetrahedra"]),
        "polar_tetrahedra": len(polar_boundary["tetrahedra"]),
    }


def analyze(data: dict) -> dict:
    vertices = [tuple(parse_q(value) for value in row) for row in data["vertex_pair_representatives"]]
    normals = [tuple(parse_q(value) for value in row) for row in data["facet_normal_pair_representatives"]]
    first_certificate = first.analyze(data)
    variational = first_certificate["variational_certificate"]
    assert variational["constraint_full_row_rank"] is True
    assert variational["first_order_stationary_on_linearized_compatible_space"] is True

    J, _ = first.determinant_constraint_matrix(vertices, normals)
    gl = first.gl_motion_matrix(vertices)
    quotient = quotient_basis(J, gl)
    first_extension = compute_extension(
        vertices, normals, first_certificate, J, quotient, "first"
    )
    last_extension = compute_extension(
        vertices, normals, first_certificate, J, quotient, "last"
    )
    reduced = first_extension["reduced_hessian"]
    assert reduced == last_extension["reduced_hessian"]
    assert first_extension["naive_mismatched_hessian"] != reduced

    inertia = exact_inertia_by_congruence(reduced)
    negative_ldl = None
    if inertia["positive"] == 0 and inertia["zero"] == 0:
        lower, diagonal = (-reduced).LDLdecomposition(hermitian=True)
        assert lower * diagonal * lower.T == -reduced
        diagonal_values = [sp.factor(diagonal[i, i]) for i in range(diagonal.rows)]
        assert all(value > 0 for value in diagonal_values)
        negative_ldl = {
            "lower": matrix_strings(lower),
            "diagonal": [qstr(value) for value in diagonal_values],
        }

    canonical_metric_projection = (
        sp.eye(J.cols) - gl * (gl.T * gl).inv() * gl.T
    )
    quotient_metric = (
        quotient.T * canonical_metric_projection * quotient
    ).applyfunc(sp.factor)
    assert quotient_metric.rank() == quotient.cols

    return {
        "status": "PASS",
        "name": data.get("name", "unnamed"),
        "dimension": DIM,
        "vertex_pairs": len(vertices),
        "facet_pairs": len(normals),
        "primal_volume": first_certificate["primal_volume"],
        "polar_volume": first_certificate["polar_volume"],
        "Mahler_product": first_certificate["Mahler_product"],
        "constraint_rows": J.rows,
        "constraint_rank": J.rank(),
        "ambient_velocity_dimension": J.cols,
        "GL_dimension": gl.rank(),
        "quotient_dimension": quotient.cols,
        "quotient_basis": basis_columns(quotient),
        "quotient_metric": matrix_strings(quotient_metric),
        "reduced_Lagrangian_Hessian": matrix_strings(reduced),
        "inertia": inertia,
        "negative_LDL": negative_ldl,
        "extension_covariance": {
            "first_and_last_facet_basis_extensions_agree": True,
            "first_policy_bases": [list(ids) for ids in first_extension["chosen_facet_bases"]],
            "last_policy_bases": [list(ids) for ids in last_extension["chosen_facet_bases"]],
            "first_matching_multipliers": column_strings(first_extension["matching_multipliers"]),
            "last_matching_multipliers": column_strings(last_extension["matching_multipliers"]),
            "canonical_shape_gradient_multipliers": column_strings(first_extension["canonical_multipliers"]),
            "first_extension_gradient_shift_is_constraint_combination": True,
            "last_extension_gradient_shift_is_constraint_combination": True,
            "naive_mismatched_Hessian": matrix_strings(
                first_extension["naive_mismatched_hessian"]
            ),
            "naive_mismatched_inertia": exact_inertia_by_congruence(
                first_extension["naive_mismatched_hessian"]
            ),
            "warning": (
                "The naive form uses canonical shape-gradient multipliers with a different "
                "polar-normal off-stratum extension.  Its curvature signs are not invariant."
            ),
        },
        "triangulations": {
            "primal_tetrahedra": first_extension["primal_tetrahedra"],
            "polar_tetrahedra": first_extension["polar_tetrahedra"],
        },
        "first_variation_summary": {
            "stationary": True,
            "constraint_full_row_rank": True,
            "projective_compatible_motion_dimension": variational[
                "projective_compatible_motion_dimension"
            ],
        },
        "scope_warning": (
            "The second-order conclusion is local to the regular fixed-face-lattice "
            "stratum represented by the supplied vertices and normalized facet normals."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--certificate", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    certificate = analyze(data)
    certificate_path = args.certificate or args.input.with_name(
        args.input.stem + "_second_variation_certificate.json"
    )
    output_path = args.output or args.input.with_name(
        args.input.stem + "_second_variation_output.json"
    )
    certificate_path.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    inertia = certificate["inertia"]
    output = {
        "status": "PASS",
        "name": certificate["name"],
        "Mahler_product": certificate["Mahler_product"],
        "constraint_rank": certificate["constraint_rank"],
        "quotient_dimension": certificate["quotient_dimension"],
        "reduced_Hessian_inertia": [
            inertia["positive"],
            inertia["negative"],
            inertia["zero"],
        ],
        "extension_covariance": certificate["extension_covariance"][
            "first_and_last_facet_basis_extensions_agree"
        ],
        "certificate": certificate_path.name,
        "certificate_sha256": sha256(certificate_path),
    }
    output_path.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
