#!/usr/bin/env python3
from __future__ import annotations
import hashlib,importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('first_alg',ROOT/'viterbo_mahler_first_variation_algebraic.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def strings(M):return [[m.qstr(M[i,j]) for j in range(M.cols)] for i in range(M.rows)]
def main():
 inp=ROOT/'viterbo_global_hexagon_octagon_product_input_v42.json';outp=ROOT/'viterbo_global_hexagon_octagon_linear_v42.json';D=json.loads(inp.read_text());V=[tuple(m.parse_q(z) for z in row) for row in D['vertex_pair_representatives']];N=[tuple(m.parse_q(z) for z in row) for row in D['facet_normal_pair_representatives']]
 C,Cr=m.facet_circuit_matrix(V,N);J,Jr=m.determinant_constraint_matrix(V,N)
 out={'status':'PASS','source_input':inp.name,'source_input_sha256':sha(inp),'C':strings(C),'J':strings(J),'C_shape':list(C.shape),'J_shape':list(J.shape)}
 assert C.shape==J.shape==(68,96)
 outp.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps({'status':'PASS','C_shape':list(C.shape),'J_shape':list(J.shape)},indent=2))
if __name__=='__main__':main()
