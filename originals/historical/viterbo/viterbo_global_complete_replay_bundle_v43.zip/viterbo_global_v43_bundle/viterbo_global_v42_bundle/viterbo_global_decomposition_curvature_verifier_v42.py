#!/usr/bin/env python3
"""Aggregate semantic verifier for v42 decomposition/curvature progress."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import sympy as sp
ROOT=Path(__file__).resolve().parent

def load(n):return json.loads((ROOT/n).read_text())
def sha(n):return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
def parse(z):return sp.radsimp(sp.sympify(str(z),locals={'sqrt':sp.sqrt}))
def main():
 inherited=load('viterbo_global_replay_output_v41.json')
 red=load('viterbo_global_decomposable_reduction_certificate_v42.json')
 dec=load('viterbo_global_hexagon_octagon_product_decomposability_certificate_v42.json')
 p3dec=load('viterbo_global_P3_decomposability_certificate_v42.json')
 r24dec=load('viterbo_global_regular24_decomposability_certificate_v42.json')
 first=load('viterbo_global_hexagon_octagon_product_first_variation_compact_v42.json')
 second=load('viterbo_global_hexagon_octagon_product_second_variation_certificate_v42.json')
 modes=load('viterbo_global_hexagon_octagon_product_mode_certificate_v42.json')
 p3conn=load('viterbo_global_P3_connectivity_certificate_v42.json')
 r24conn=load('viterbo_global_regular24_connectivity_certificate_v42.json')
 prodconn=load('viterbo_global_hexagon_octagon_product_connectivity_certificate_v42.json')
 assert inherited['status']=='PASS' and inherited['full_4D_symmetric_Mahler']=='open'
 assert red['status']=='PASS' and red['four_dimensional_splits']['1+3']['lower_dimensional_threshold_product']=='32/3' and red['four_dimensional_splits']['2+2']['lower_dimensional_threshold_product']=='32/3'
 assert dec['direct_product_decomposable'] and dec['direct_product_factor_dimensions']==[2,2] and not dec['free_sum_decomposable']
 assert p3dec['bi_indecomposable'] and r24dec['bi_indecomposable']
 assert first['status']=='PASS' and first['variational_certificate']['constraint_rank']==68 and first['variational_certificate']['projective_compatible_motion_dimension']==12 and first['variational_certificate']['first_order_stationary_on_linearized_compatible_space']
 assert second['status']=='PASS' and [second['inertia'][k] for k in ['positive','negative','zero']]==[0,12,0]
 assert second['extension_covariance']['first_and_last_agree']
 assert modes['status']=='PASS' and modes['sector_dimensions']==[2,4,6] and modes['factor_structure_inferred_from_normal_matroid']
 assert all(modes['sectors'][k]['negative_definite'] for k in ['hexagon_factor','octagon_factor','mixed','full'])
 M=parse(first['Mahler_product']);assert sp.simplify(M-(48-24*sp.sqrt(2)))==0 and bool(M>sp.Rational(32,3))
 assert prodconn['normal_matroid_connectivity']['minimum_lambda_sides_at_least_2']==0
 assert p3conn['vertex_matroid_connectivity']['minimum_lambda_sides_at_least_3']==3
 assert p3conn['normal_matroid_connectivity']['proper_lambda2_separation_count']==16
 assert r24conn['vertex_matroid_connectivity']['proper_lambda2_separation_count']==16 and r24conn['normal_matroid_connectivity']['proper_lambda2_separation_count']==16
 cert={'status':'PASS','scope':'4D symmetric Mahler global reduction v42',
  'inherited_v41':'PASS','bounded12':'closed proof candidate',
  'complexity_independent_reduction':{
    'all_nontrivial_direct_products_and_free_sums':'reduced exactly to lower-dimensional symmetric Mahler inequalities',
    'necessary_counterexample_condition':'vertex and facet-normal vector matroids both connected',
    'hexagon_octagon_normal_components':dec['facet_normal_vector_matroid']['components'],
    'P3_bi_indecomposable':True,'regular24_bi_indecomposable':True},
  'hexagon_octagon_product':{
    'actual_vertices':48,'actual_facets':14,'dual_actual_vertices':14,'dual_actual_facets':48,
    'Mahler_product':first['Mahler_product'],'margin_above_32_over_3':red['hexagon_octagon_test']['margin_above_32_over_3'],
    'constraint_rank':68,'compatible_motion_dimension':28,'quotient_dimension':12,'first_order_stationary':True,
    'reduced_Hessian_inertia':[0,12,0],'fixed_stratum_strict_local_maximum_mod_GL4':True,
    'curvature_sector_dimensions':[2,4,6],'curvature_sectors':modes['sectors']},
  'separation_ladder':{
    'lambda_0':'direct/free decompositions closed by factorization',
    'lambda_1':'next unresolved low-order gluing layer',
    'lambda_2_calibration':{'P3_normal_proper_separations':16,'P3_vertex_proper_separations':0,'regular24_vertex_proper_separations':16,'regular24_normal_proper_separations':16},
    'next_target':'derive a Mahler descent or factorization theorem for exact 2-sums/3-separations, then treat internally 4-connected candidates'},
  'full_4D_symmetric_Mahler':'open',
  'scope_warning':'The decomposable class is globally reduced, and one 48-vertex product calibration is exactly analyzed. No inequality for all bi-indecomposable four-dimensional bodies is claimed.',
  'source_hashes':{n:sha(n) for n in [
    'viterbo_global_replay_output_v41.json','viterbo_global_decomposable_reduction_certificate_v42.json','viterbo_global_hexagon_octagon_product_decomposability_certificate_v42.json','viterbo_global_P3_decomposability_certificate_v42.json','viterbo_global_regular24_decomposability_certificate_v42.json','viterbo_global_hexagon_octagon_product_first_variation_compact_v42.json','viterbo_global_hexagon_octagon_product_second_variation_certificate_v42.json','viterbo_global_hexagon_octagon_product_mode_certificate_v42.json','viterbo_global_P3_connectivity_certificate_v42.json','viterbo_global_regular24_connectivity_certificate_v42.json','viterbo_global_hexagon_octagon_product_connectivity_certificate_v42.json']}}
 cp=ROOT/'viterbo_global_decomposition_curvature_certificate_v42.json';op=ROOT/'viterbo_global_decomposition_curvature_output_v42.json';cp.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','decomposable_4D_closed_by_lower_dimensions':True,'hexagon_octagon_product_M':first['Mahler_product'],'hexagon_octagon_quotient_dimension':12,'hexagon_octagon_reduced_Hessian_inertia':[0,12,0],'curvature_sector_dimensions':[2,4,6],'P3_normal_lambda2_separations':16,'regular24_bilateral_lambda2_separations':[16,16],'full_4D_symmetric_Mahler':'open','certificate':cp.name,'certificate_sha256':sha(cp.name)};op.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
