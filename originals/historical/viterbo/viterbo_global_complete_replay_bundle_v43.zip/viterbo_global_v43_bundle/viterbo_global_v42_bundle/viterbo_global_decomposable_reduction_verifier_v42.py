#!/usr/bin/env python3
"""Exact verifier for the decomposable 4D Mahler reduction and the H6 x O8 test."""
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
import sympy as sp

ROOT=Path(__file__).resolve().parent
CERT=ROOT/'viterbo_global_decomposable_reduction_certificate_v42.json'
OUT=ROOT/'viterbo_global_decomposable_reduction_output_v42.json'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def q(z): return str(sp.radsimp(sp.factor(sp.cancel(z))))

def polygon_area(vertices):
    s=sp.Integer(0)
    for (x,y),(u,v) in zip(vertices,vertices[1:]+vertices[:1]): s+=x*v-y*u
    return sp.factor(abs(s)/2)

def polar_vertices_from_ccw(vertices):
    out=[]
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        M=sp.Matrix([a,b]); z=M.inv()*sp.ones(2,1)
        out.append((sp.radsimp(z[0]),sp.radsimp(z[1])))
    return out

def mahler2(vertices):
    area=polygon_area(vertices); polar=polar_vertices_from_ccw(vertices); pa=polygon_area(polar)
    return area,pa,sp.radsimp(area*pa),polar

def threshold(n): return sp.Rational(4**n,math.factorial(n))

def main():
    # General direct-product/free-sum coefficient in dimensions p+q=4.
    splits={}
    for p,qdim in [(1,3),(2,2),(3,1)]:
        coeff=sp.Rational(math.factorial(p)*math.factorial(qdim),math.factorial(4))
        lower=sp.factor(coeff*threshold(p)*threshold(qdim))
        assert lower==threshold(4)==sp.Rational(32,3)
        splits[f'{p}+{qdim}']={'free_sum_volume_coefficient':q(coeff),'lower_dimensional_threshold_product':q(lower)}

    H=[(sp.Integer(1),0),(1,1),(0,1),(-1,0),(-1,-1),(0,-1)]
    r=sp.sqrt(2)-1
    O=[(1,r),(r,1),(-r,1),(-1,r),(-1,-r),(-r,-1),(r,-1),(1,-r)]
    hA,hPA,hM,hpolar=mahler2(H)
    oA,oPA,oM,opolar=mahler2(O)
    assert (hA,hPA,hM)==(3,3,9)
    assert sp.simplify(oM-16*(2-sp.sqrt(2)))==0
    product_coeff=sp.Rational(2*2,24) # 2!2!/4!
    product_primal=sp.factor(hA*oA)
    product_polar=sp.factor(product_coeff*hPA*oPA)
    product_M=sp.radsimp(product_primal*product_polar)
    assert sp.simplify(product_M-(48-24*sp.sqrt(2)))==0
    assert sp.N(product_M-sp.Rational(32,3))>0
    # Product/freesum dual f0/f3 counts.
    counts={'product_vertices':6*8,'product_facets':6+8,'polar_vertices':6+8,'polar_facets':6*8}
    assert counts=={'product_vertices':48,'product_facets':14,'polar_vertices':14,'polar_facets':48}
    cert={
      'status':'PASS','scope':'4D centrally symmetric Mahler; linearly decomposable direct products and free sums',
      'identity':{
        'direct_product_polar':'(K x L)^o = K^o plus_1 L^o',
        'free_sum_volume':'|A plus_1 B| = p! q!/(p+q)! |A||B|',
        'Mahler_product':'M(K x L)=p!q!/(p+q)! M(K)M(L)',
        'dual_identity':'M(K plus_1 L)=p!q!/(p+q)! M(K)M(L)'
      },
      'four_dimensional_splits':splits,
      'conclusion':'Every nontrivially linearly decomposable centrally symmetric 4D body satisfies M >= 32/3 once the 1D, 2D and 3D symmetric inequalities are supplied; any 4D counterexample must be directly and freely indecomposable.',
      'equality_note':'Equality reduces to equality in every lower-dimensional factor.',
      'hexagon_octagon_test':{
        'hexagon_area':q(hA),'hexagon_polar_area':q(hPA),'hexagon_M':q(hM),
        'octagon_area':q(oA),'octagon_polar_area':q(oPA),'octagon_M':q(oM),
        'product_primal_volume':q(product_primal),'product_polar_volume':q(product_polar),
        'product_M':q(product_M),'margin_above_32_over_3':q(product_M-sp.Rational(32,3)),
        'face_counts':counts
      },
      'scope_warning':'The 3D lower-dimensional input is external. This reduction does not address indecomposable 4D bodies.'
    }
    CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
    out={'status':'PASS','decomposable_4D_reduced_to_lower_dimensions':True,'candidate_product_M':q(product_M),'candidate_product_margin':q(product_M-sp.Rational(32,3)),'certificate':CERT.name,'certificate_sha256':sha(CERT)}
    OUT.write_text(json.dumps(out,indent=2,sort_keys=True)); print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
