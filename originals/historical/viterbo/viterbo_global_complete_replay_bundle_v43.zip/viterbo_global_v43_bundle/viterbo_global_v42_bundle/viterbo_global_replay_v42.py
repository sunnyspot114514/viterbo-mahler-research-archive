#!/usr/bin/env python3
"""Integrity and optional exact rebuild driver for v42.

v42 adds a complexity-independent direct/free decomposition reduction, exact
vector-matroid connectivity filters, and a full Q(sqrt(2)) first/second
variation analysis of H6 x O8.  Historical v41 is replayed as an inherited
integrity checkpoint; all v42 computations are rebuilt when --rebuild is set.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "viterbo_global_progress_manifest_v42.json"
OUT = ROOT / "viterbo_global_replay_output_v42.json"
INHERITED_BUNDLE = ROOT / "viterbo_global_complete_replay_bundle_v41.zip"
INHERITED_OUT = ROOT / "viterbo_global_replay_output_v41.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def run(arguments: list[str], timeout: int = 1800) -> None:
    completed = subprocess.run(
        [sys.executable, *arguments],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if completed.returncode != 0:
        raise AssertionError(
            {
                "arguments": arguments,
                "returncode": completed.returncode,
                "stdout_tail": completed.stdout[-12000:],
                "stderr_tail": completed.stderr[-12000:],
            }
        )


def replay_inherited_v41() -> dict:
    with tempfile.TemporaryDirectory(prefix="viterbo_v41_replay_") as temporary:
        temporary_path = Path(temporary)
        with zipfile.ZipFile(INHERITED_BUNDLE) as archive:
            archive.extractall(temporary_path)
        candidates = list(temporary_path.rglob("viterbo_global_replay_v41.py"))
        assert len(candidates) == 1
        driver = candidates[0]
        completed = subprocess.run(
            [sys.executable, str(driver)],
            cwd=str(driver.parent),
            capture_output=True,
            text=True,
            timeout=1200,
        )
        if completed.returncode != 0:
            raise AssertionError(
                {
                    "inherited_driver": str(driver),
                    "returncode": completed.returncode,
                    "stdout_tail": completed.stdout[-8000:],
                    "stderr_tail": completed.stderr[-8000:],
                }
            )
        result = json.loads(
            (driver.parent / "viterbo_global_replay_output_v41.json").read_text()
        )
        assert result["status"] == "PASS"
        assert result["full_4D_symmetric_Mahler"] == "open"
        return {
            "status": "PASS",
            "P3_local_matrix_module": result["P3_local_matrix_module"],
            "regular24_curvature_identity": result["regular24_curvature_identity"],
        }


def rebuild_v42() -> None:
    # Deterministic split pipeline for the Q(sqrt(2)) first variation.
    run([str(ROOT / "viterbo_global_hexagon_octagon_geometry_stage_v42.py")], 1800)
    run([str(ROOT / "viterbo_global_hexagon_octagon_linear_stage_v42.py")], 1800)
    run([str(ROOT / "viterbo_global_hexagon_octagon_first_variation_verifier_v42.py")], 1800)

    # Full extension-covariant second variation over QQ(sqrt(2)).
    run(
        [
            str(ROOT / "viterbo_fixed_stratum_second_variation_algebraic.py"),
            str(ROOT / "viterbo_global_hexagon_octagon_product_input_v42.json"),
            "--first-certificate",
            str(ROOT / "viterbo_global_hexagon_octagon_product_first_variation_compact_v42.json"),
            "--certificate",
            str(ROOT / "viterbo_global_hexagon_octagon_product_second_variation_certificate_v42.json"),
            "--output",
            str(ROOT / "viterbo_global_hexagon_octagon_product_second_variation_output_v42.json"),
        ],
        3600,
    )

    # Complexity-independent factorization reduction.
    run([str(ROOT / "viterbo_global_decomposable_reduction_verifier_v42.py")], 600)

    # Exact direct/free decomposition analyzers.
    decomposition_jobs = [
        ("viterbo_global_hexagon_octagon_product_input_v42.json", "viterbo_global_hexagon_octagon_product_decomposability_certificate_v42.json", "viterbo_global_hexagon_octagon_product_decomposability_output_v42.json"),
        ("viterbo_global_P3_bishadow_input.json", "viterbo_global_P3_decomposability_certificate_v42.json", "viterbo_global_P3_decomposability_output_v42.json"),
        ("viterbo_global_regular24_decomposability_input_v42.json", "viterbo_global_regular24_decomposability_certificate_v42.json", "viterbo_global_regular24_decomposability_output_v42.json"),
    ]
    for source, certificate, output in decomposition_jobs:
        run(
            [
                str(ROOT / "viterbo_linear_decomposability_analyzer.py"),
                str(ROOT / source),
                "--certificate",
                str(ROOT / certificate),
                "--output",
                str(ROOT / output),
            ],
            600,
        )

    # Exact low-order separation census.
    connectivity_jobs = [
        ("viterbo_global_hexagon_octagon_product_input_v42.json", "viterbo_global_hexagon_octagon_product_connectivity_certificate_v42.json", "viterbo_global_hexagon_octagon_product_connectivity_output_v42.json"),
        ("viterbo_global_P3_bishadow_input.json", "viterbo_global_P3_connectivity_certificate_v42.json", "viterbo_global_P3_connectivity_output_v42.json"),
        ("viterbo_global_regular24_decomposability_input_v42.json", "viterbo_global_regular24_connectivity_certificate_v42.json", "viterbo_global_regular24_connectivity_output_v42.json"),
    ]
    for source, certificate, output in connectivity_jobs:
        run(
            [
                str(ROOT / "viterbo_matroid_connectivity_analyzer.py"),
                str(ROOT / source),
                "--certificate",
                str(ROOT / certificate),
                "--output",
                str(ROOT / output),
            ],
            900,
        )

    # Product-induced 2+4+6 curvature decomposition, then aggregate semantics.
    run([str(ROOT / "viterbo_global_hexagon_octagon_product_mode_verifier_v42.py")], 1200)
    run([str(ROOT / "viterbo_global_decomposition_curvature_verifier_v42.py")], 600)


def verify_manifest() -> dict:
    manifest = json.loads(MANIFEST.read_text())
    assert manifest["status"] == "PASS"
    checked = 0
    total_bytes = 0
    for name, record in manifest["files"].items():
        path = ROOT / name
        assert path.is_file(), name
        assert path.stat().st_size == record["bytes"], name
        assert sha256(path) == record["sha256"], name
        checked += 1
        total_bytes += path.stat().st_size
    return {
        "manifest_sha256": sha256(MANIFEST),
        "files_checked": checked,
        "bytes_checked": total_bytes,
    }


def verify_semantics() -> dict:
    inherited = json.loads(INHERITED_OUT.read_text())
    reduction = json.loads((ROOT / "viterbo_global_decomposable_reduction_output_v42.json").read_text())
    first = json.loads((ROOT / "viterbo_global_hexagon_octagon_product_first_variation_output_v42.json").read_text())
    second = json.loads((ROOT / "viterbo_global_hexagon_octagon_product_second_variation_output_v42.json").read_text())
    modes = json.loads((ROOT / "viterbo_global_hexagon_octagon_product_mode_output_v42.json").read_text())
    product_dec = json.loads((ROOT / "viterbo_global_hexagon_octagon_product_decomposability_output_v42.json").read_text())
    p3_dec = json.loads((ROOT / "viterbo_global_P3_decomposability_output_v42.json").read_text())
    r24_dec = json.loads((ROOT / "viterbo_global_regular24_decomposability_output_v42.json").read_text())
    p3_conn = json.loads((ROOT / "viterbo_global_P3_connectivity_certificate_v42.json").read_text())
    r24_conn = json.loads((ROOT / "viterbo_global_regular24_connectivity_certificate_v42.json").read_text())
    aggregate = json.loads((ROOT / "viterbo_global_decomposition_curvature_output_v42.json").read_text())
    status = json.loads((ROOT / "viterbo_global_status_20260904_v42.json").read_text())

    assert inherited["status"] == "PASS"
    assert inherited["full_4D_symmetric_Mahler"] == "open"
    assert reduction["status"] == "PASS"
    assert reduction["decomposable_4D_reduced_to_lower_dimensions"] is True
    assert first["status"] == "PASS"
    assert first["constraint_rank"] == 68
    assert first["quotient_dimension"] == 12
    assert first["first_order_stationary"] is True
    assert second["status"] == "PASS"
    assert second["reduced_Hessian_inertia"] == [0, 12, 0]
    assert modes["status"] == "PASS"
    assert modes["sector_dimensions"] == [2, 4, 6]
    assert modes["all_sectors_negative"] is True
    assert product_dec["direct_product_decomposable"] is True
    assert product_dec["direct_product_factor_dimensions"] == [2, 2]
    assert product_dec["free_sum_decomposable"] is False
    assert p3_dec["bi_indecomposable"] is True
    assert r24_dec["bi_indecomposable"] is True
    assert p3_conn["normal_matroid_connectivity"]["proper_lambda2_separation_count"] == 16
    assert r24_conn["vertex_matroid_connectivity"]["proper_lambda2_separation_count"] == 16
    assert r24_conn["normal_matroid_connectivity"]["proper_lambda2_separation_count"] == 16
    assert aggregate["status"] == "PASS"
    assert aggregate["decomposable_4D_closed_by_lower_dimensions"] is True
    assert aggregate["hexagon_octagon_product_M"] == "48 - 24*sqrt(2)"
    assert aggregate["hexagon_octagon_reduced_Hessian_inertia"] == [0, 12, 0]
    assert aggregate["curvature_sector_dimensions"] == [2, 4, 6]
    assert aggregate["full_4D_symmetric_Mahler"] == "open"
    assert status["full_4D_symmetric_Mahler"] == "open"

    return {
        "bounded12": "closed proof candidate",
        "decomposable_4D_direct_products_and_free_sums": "closed by lower-dimensional factorization",
        "necessary_counterexample_matroid_condition": "vertex and facet-normal matroids both connected",
        "hexagon_octagon_product_combinatorics": "48V/14F dual to 14V/48F",
        "hexagon_octagon_Mahler_product": aggregate["hexagon_octagon_product_M"],
        "hexagon_octagon_constraint_rank": 68,
        "hexagon_octagon_quotient_dimension": 12,
        "hexagon_octagon_first_order_stationary": True,
        "hexagon_octagon_reduced_Hessian_inertia": [0, 12, 0],
        "hexagon_octagon_curvature_sector_dimensions": [2, 4, 6],
        "P3_normal_proper_lambda2_separations": 16,
        "regular24_vertex_normal_proper_lambda2_separations": [16, 16],
        "full_4D_symmetric_Mahler": "open",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()

    inherited_replayed = False
    if args.rebuild:
        replay_inherited_v41()
        inherited_replayed = True
        rebuild_v42()

    integrity = verify_manifest()
    semantics = verify_semantics()
    output = {
        "status": "PASS",
        "rebuild": bool(args.rebuild),
        "inherited_v41_replayed": inherited_replayed,
        **integrity,
        **semantics,
        "scope_warning": (
            "v42 closes the decomposable four-dimensional class and exactly analyzes "
            "one 48-vertex product stratum. It does not prove the conjecture for all "
            "bi-indecomposable four-dimensional centrally symmetric bodies."
        ),
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
