#!/usr/bin/env python3
from __future__ import annotations
import hashlib,importlib.util,json,time
from pathlib import Path
import sympy as sp
ROOT=Path(__file__).resolve().parent
def load(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('first_alg',ROOT/'viterbo_mahler_first_variation_algebraic.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parseM(rows):return sp.Matrix([[m.parse_q(z) for z in row] for row in rows])
def q(z):return m.qstr(z)
def reshape24(v):return [[v[4*i+j] for j in range(4)] for i in range(24)]
def main():
 inp=ROOT/'viterbo_global_hexagon_octagon_product_input_v42.json';gp=ROOT/'viterbo_global_hexagon_octagon_geometry_v42.json';lp=ROOT/'viterbo_global_hexagon_octagon_linear_v42.json';cp=ROOT/'viterbo_global_hexagon_octagon_product_first_variation_compact_v42.json';op=ROOT/'viterbo_global_hexagon_octagon_product_first_variation_output_v42.json'
 D=json.loads(inp.read_text());G=json.loads(gp.read_text());L=json.loads(lp.read_text());C=parseM(L['C']);J=parseM(L['J']);pv=m.parse_q(G['primal_volume']);qv=m.parse_q(G['polar_volume']);pg=sp.Matrix([m.parse_q(z) for z in G['primal_gradient']]);qg=sp.Matrix([m.parse_q(z) for z in G['polar_gradient']]);mg=(qv*pg+pv*qg).applyfunc(lambda z:sp.radsimp(sp.factor(z)))
 rc=m.rank_exact(C);rj=m.rank_exact(J);rs=m.rank_exact(C.col_join(J) if False else sp.Matrix.vstack(C,J));raC=m.rank_exact(sp.Matrix.vstack(C,mg.T));raJ=m.rank_exact(sp.Matrix.vstack(J,mg.T));assert (rc,rj,rs,raC,raJ)==(68,68,68,68,68)
 stress=m.one_stress_solution(J,mg);assert stress['free_multiplier_dimension']==0 and stress['nonzero_multipliers']==63
 cert={'status':'PASS','name':D['name'],'dimension':4,'vertex_pairs':24,'facet_pairs':7,'primal_volume':q(pv),'polar_volume':q(qv),'Mahler_product':q(pv*qv),'primal_gradient':reshape24([q(z) for z in pg]),'polar_gradient_with_respect_to_primal_vertices':reshape24([q(z) for z in qg]),'Mahler_gradient':[q(z) for z in mg],
 'compact_geometry':{k:G[k] for k in ['primal_volume','polar_volume','primal_facets','polar_facets','primal_tetrahedra','polar_tetrahedra','primal_f_vector','polar_f_vector','primal_facet_sizes','polar_facet_sizes']},
 'variational_certificate':{'constraint_equations':68,'constraint_rank':68,'constraint_full_row_rank':True,'velocity_variables':96,'compatible_motion_dimension':28,'GL_trivial_dimension':16,'projective_compatible_motion_dimension':12,'Mahler_augmented_rank':68,'first_order_stationary_on_linearized_compatible_space':True,'regular_stratum_KKT_interpretation':'The complete fixed-face-lattice Mahler gradient lies in the exact determinant-Jacobian row space.','Mahler_stress':stress},
 'source_hashes':{inp.name:sha(inp),gp.name:sha(gp),lp.name:sha(lp)},'scope_warning':'Exact first variation over Q(sqrt(2)); fixed-face-lattice stationarity only.'}
 cp.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','name':D['name'],'Mahler_product':cert['Mahler_product'],'constraint_rank':68,'quotient_dimension':12,'first_order_stationary':True,'certificate':cp.name,'certificate_sha256':sha(cp)};op.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
