# v42 replay instructions

This bundle contains the exact artifacts for the v42 decomposition/separation
round of the four-dimensional centrally symmetric Mahler project.

## Environment

Python 3.11+ with the packages in `viterbo_global_requirements_v42.txt`.
All exact number-field calculations use SymPy's `QQ(sqrt(2))` domain. NumPy and
SciPy are used only by inherited geometry utilities; the final algebraic rank,
KKT, inertia, matroid, and factorization checks are exact.

## Integrity and semantic replay

```bash
python viterbo_global_replay_v42.py
```

This checks the v42 manifest and all stored semantic outputs.

## Rebuild all v42 computations

```bash
python viterbo_global_replay_v42.py --rebuild
```

This performs an integrity replay of the inherited v41 checkpoint and then
recomputes:

1. exact primal/polar geometry for the affine-regular hexagon times regular octagon;
2. the `68 x 96` circuit/determinant Jacobians over `QQ(sqrt(2))`;
3. complete fixed-face-lattice first variation and KKT stress;
4. two independent off-stratum extensions of the full second variation;
5. the exact reduced-Hessian inertia and `2+4+6` factor/mixed mode split;
6. direct-product/free-sum factorization and vector-matroid decomposition;
7. low-order vector-matroid separation censuses for the product, `P3`, and the regular 24-cell;
8. the aggregate semantic certificate.

The second-variation stage is the expensive step. The inherited v41 bundle is
checked as a prior checkpoint rather than recursively rebuilding every earlier
historical round.

## Scope

All computational checkmarks are computer-assisted analytic proof candidates.
The bundle proves neither the unrestricted four-dimensional symmetric Mahler
conjecture nor a reduction for all bi-indecomposable bodies.
