#!/usr/bin/env python3
"""Exact low-order vector-matroid separation analyzer over QQ(sqrt(2))."""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import sympy as sp
K=sp.QQ.algebraic_field(sp.sqrt(2))
def parse(z):return K.from_sympy(sp.radsimp(sp.sympify(str(z),locals={'sqrt':sp.sqrt})))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def independent(vectors,indices):
    # Exact Gaussian rank for at most four rows in a four-dimensional field.
    A=[[vectors[i][j] for j in range(4)] for i in indices];rows=len(A);rank=0
    for col in range(4):
        pivot=next((i for i in range(rank,rows) if not A[i][col].is_zero),None)
        if pivot is None:continue
        A[rank],A[pivot]=A[pivot],A[rank];inv=A[rank][col]**-1
        A[rank]=[x*inv for x in A[rank]]
        for i in range(rows):
            if i!=rank and not A[i][col].is_zero:
                c=A[i][col];A[i]=[A[i][j]-c*A[rank][j] for j in range(4)]
        rank+=1
        if rank==rows:return True
    return rank==rows

def ranks_all(vectors):
    m=len(vectors);N=1<<m;ranks=[0]*N;bases=[0]*N
    for mask in range(1,N):
        bit=mask & -mask;e=bit.bit_length()-1;prev=mask^bit;bmask=bases[prev];inds=[i for i in range(m) if (bmask>>i)&1]
        if len(inds)<4 and independent(vectors,inds+[e]):bmask|=bit
        bases[mask]=bmask;ranks[mask]=bmask.bit_count()
    return ranks,bases

def analyze_config(rows,name,max_elements=18):
    vectors=[[parse(z) for z in row] for row in rows];m=len(vectors);assert all(len(v)==4 for v in vectors)
    if m>max_elements:return {'name':name,'element_count':m,'skipped_full_separation_census':True,'reason':f'element count exceeds exact census cap {max_elements}'}
    ranks,_=ranks_all(vectors);full=(1<<m)-1;r=ranks[full];assert r==4
    hist={};witness={};minimum2=99;minimum3=99;proper_profiles={};lambda2_proper=[]
    for S in range(1,full):
        T=full^S
        if S>T:continue
        lam=ranks[S]+ranks[T]-r
        hist[str(lam)]=hist.get(str(lam),0)+1
        witness.setdefault(str(lam),{'side_A':[i for i in range(m) if (S>>i)&1],'side_B':[i for i in range(m) if (T>>i)&1],'rank_A':ranks[S],'rank_B':ranks[T]})
        if S.bit_count()>=2 and T.bit_count()>=2:minimum2=min(minimum2,lam)
        if S.bit_count()>=3 and T.bit_count()>=3:
            minimum3=min(minimum3,lam)
            profile=f'{lam}:{S.bit_count()}:{T.bit_count()}:{ranks[S]}:{ranks[T]}'
            proper_profiles[profile]=proper_profiles.get(profile,0)+1
            if lam==2:lambda2_proper.append({'side_A':[i for i in range(m) if (S>>i)&1],'side_B':[i for i in range(m) if (T>>i)&1],'rank_A':ranks[S],'rank_B':ranks[T]})
    return {'name':name,'element_count':m,'rank':r,'separation_histogram':hist,'minimum_lambda_sides_at_least_2':minimum2,'minimum_lambda_sides_at_least_3':minimum3,'witnesses':witness,
            'connected':hist.get('0',0)==0,'proper_separation_profiles':proper_profiles,'proper_lambda2_separation_count':len(lambda2_proper),'proper_lambda2_separations':lambda2_proper,'has_2_separation':minimum2<=1,'has_3_separation':minimum3<=2}

def main():
 p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('--certificate',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();D=json.loads(a.input.read_text())
 cert={'status':'PASS','name':D.get('name','unnamed'),'vertex_matroid_connectivity':analyze_config(D['vertex_pair_representatives'],'vertex vectors'),'normal_matroid_connectivity':analyze_config(D['facet_normal_pair_representatives'],'facet normals'),
       'interpretation':'lambda(S)=r(S)+r(E-S)-4. Lambda zero is a direct-sum decomposition; lambda one/two records the next low-order separation strata to target.',
       'scope_warning':'This is an exact finite vector-matroid census, not yet a Mahler inequality for 2-sums or 3-sums.'}
 a.certificate.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','name':cert['name'],'vertex_min_lambda_2':cert['vertex_matroid_connectivity'].get('minimum_lambda_sides_at_least_2'),'normal_min_lambda_2':cert['normal_matroid_connectivity'].get('minimum_lambda_sides_at_least_2'),'certificate':a.certificate.name,'certificate_sha256':sha(a.certificate)};a.output.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
