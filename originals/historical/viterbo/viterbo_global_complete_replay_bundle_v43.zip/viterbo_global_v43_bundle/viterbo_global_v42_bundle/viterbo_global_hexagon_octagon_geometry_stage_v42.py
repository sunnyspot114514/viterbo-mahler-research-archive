#!/usr/bin/env python3
from __future__ import annotations
import hashlib,importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('first_alg',ROOT/'viterbo_mahler_first_variation_algebraic.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 inp=ROOT/'viterbo_global_hexagon_octagon_product_input_v42.json';outp=ROOT/'viterbo_global_hexagon_octagon_geometry_v42.json'
 D=json.loads(inp.read_text());V=[tuple(m.parse_q(z) for z in row) for row in D['vertex_pair_representatives']];N=[tuple(m.parse_q(z) for z in row) for row in D['facet_normal_pair_representatives']]
 pv,pg,pm=m.volume_and_gradient(V,N);qv,qg,qm=m.polar_volume_and_gradient_wrt_primal(V,N)
 out={'status':'PASS','source_input':inp.name,'source_input_sha256':sha(inp),'primal_volume':m.qstr(pv),'polar_volume':m.qstr(qv),'primal_gradient':[m.qstr(z) for z in m.flatten(pg)],'polar_gradient':[m.qstr(z) for z in m.flatten(qg)],'primal_facets':len(pm['facet_records']),'polar_facets':len(qm['facet_records']),'primal_tetrahedra':pm['boundary']['tetrahedra_count'],'polar_tetrahedra':qm['boundary']['tetrahedra_count'],'primal_f_vector':pm['boundary']['triangulated_f_vector'],'polar_f_vector':qm['boundary']['triangulated_f_vector'],'primal_facet_sizes':pm['facet_size_distribution'],'polar_facet_sizes':qm['facet_size_distribution']}
 assert out['primal_facets']==14 and out['polar_facets']==48 and out['primal_tetrahedra']==204 and out['polar_tetrahedra']==48
 outp.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps({k:v for k,v in out.items() if k not in ('primal_gradient','polar_gradient')},indent=2,sort_keys=True))
if __name__=='__main__':main()
