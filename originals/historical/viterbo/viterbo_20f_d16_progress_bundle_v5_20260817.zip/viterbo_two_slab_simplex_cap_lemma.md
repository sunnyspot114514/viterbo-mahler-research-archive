# A reusable two-slab simplex-cap lemma for normalized bounded-12 families

Let

\[
Q=[-1,1]^4\cap\{|u\cdot x|\le1\}\cap\{|v\cdot x|\le1\},
\]

where every coordinate of \(u,v\in\mathbb R^4\) is nonzero. Put

\[
h_u=\|u\|_1-1,
\qquad
h_v=\|v\|_1-1.
\]

Assume

\[
0<h_u\le 2\min_i|u_i|,
\qquad
0<h_v\le 2\min_i|v_i|.
\]

Then each inequality \(\pm u\cdot x>1\) cuts from the cube one four-dimensional simplex cap, and likewise for \(v\). A single \(u\)-cap has volume

\[
\frac{h_u^4}{24\prod_i|u_i|},
\]

so the antipodal pair has volume

\[
\frac{h_u^4}{12\prod_i|u_i|}.
\]

The analogous formula holds for \(v\).

Suppose further that for each \(\tau\in\{+1,-1\}\) there exist \(\lambda_\tau,\mu_\tau>0\) such that

\[
\lambda_\tau+\mu_\tau
>
\bigl\|\lambda_\tau u+\tau\mu_\tau v\bigr\|_1.
\]

Then no \(u\)-cap has interior intersection with any \(v\)-cap. Consequently

\[
\boxed{
|Q|
=16
-
\frac{h_u^4}{12\prod_i|u_i|}
-
\frac{h_v^4}{12\prod_i|v_i|}.
}
\]

## Proof

Let \(s_i=\operatorname{sgn}(u_i)\), and write a point near the maximizing cube vertex as

\[
x_i=s_i(1-z_i),\qquad 0\le z_i\le2.
\]

Then

\[
u\cdot x=\|u\|_1-\sum_i|u_i|z_i.
\]

Thus the cap \(u\cdot x>1\) is

\[
\sum_i|u_i|z_i<h_u.
\]

The hypothesis \(h_u\le2\min_i|u_i|\) makes the coordinate upper bounds \(z_i\le2\) redundant in the cap interior. Hence it is a simplex of volume

\[
\frac{h_u^4}{4!\prod_i|u_i|}.
\]

Central symmetry gives the antipodal pair formula.

For disjointness, suppose \(u\cdot x>1\) and \(\tau v\cdot x>1\). Then

\[
(\lambda_\tau u+\tau\mu_\tau v)\cdot x
>
\lambda_\tau+\mu_\tau.
\]

But the support function of the cube is the \(\ell_1\)-norm:

\[
(\lambda_\tau u+\tau\mu_\tau v)\cdot x
\le
\|\lambda_\tau u+\tau\mu_\tau v\|_1,
\]

contradicting the assumed strict gap. Central symmetry covers the remaining sign combinations. Subtracting the four disjoint cap volumes from 16 proves the formula.

## Role in the current proof program

This lemma is the common polar-volume mechanism behind survivors 82, 88 and 89. In each family, the strict realization domain supplies explicit positive weights for the two support-gap inequalities. It removes the need for a family-wide polar triangulation and reduces the polar calculation to low-degree rational inequalities.
