# 四维 symmetric Mahler：12V/20F, c=0, D=16 本轮进展

日期：2026-08-17

## 结论

本轮完整关闭了两个连续 survivor：

\[
\boxed{\text{Family }89\quad\checkmark}
\]

和

\[
\boxed{\text{Family }88\quad\checkmark}.
\]

因此这一层从此前的

\[
4/14
\]

推进为

\[
\boxed{6/14\text{ 个连续 families 已关闭}},
\qquad
\boxed{8\text{ 个仍剩余}}.
\]

所有勾号仍表示 **computer-assisted analytic proof candidate**，尚未经过外部同行评审。

---

## Family 89

严格参数域可写成

\[
u,v,w,E>0,\qquad u+v+w+E=1,
\]

\[
0<t<1,\qquad 4tE>(1-t)w.
\]

它通过

\[
u=U,\quad v=(1-U)V,\quad w=(1-U)(1-V)W,
\]

\[
E=(1-U)(1-V)(1-W),
\]

\[
t=\frac{W+4(1-W)T}{4-3W}
\]

与单位开四立方体有理双射。

完整 240-chart closure 为

\[
240=52\text{ expected}+178\text{ direct violations}+10\text{ paired exclusions}.
\]

去重后恰有 20 个 section vertices。精确体积是

\[
|P|=\frac{2}{3}(w+9-t),
\]

\[
|P^\circ|
=2-\frac{w^3}{6(q+1)(r+1)(1-p)}-\frac{1+s}{6(1-s)}.
\]

polar 公式来自“立方体减去两对互不相交的四维单纯形帽”，不依赖 triangulation chamber。

Mahler 余量正分子的 tensor degree 为

\[
(2,3,6,2),
\]

252 个 Bernstein coefficients 中

\[
156>0,\qquad96=0,\qquad0<0,
\]

最小正系数为

\[
\frac{16}{9}.
\]

所以全域严格满足

\[
|P||P^\circ|>\frac{32}{3}.
\]

---

## Family 88

这一族的严格域更简单。令

\[
A=\frac{a-b}{2},\quad B=\frac{1-a}{2},\quad E=\frac{1+b}{2},
\]

\[
C=\frac{c-d}{2},\quad D=\frac{1-c}{2},\quad F=\frac{1+d}{2}.
\]

则严格域恰为

\[
A,B,E,C,D,F>0,
\qquad A+B+E=C+D+F=1,
\]

即

\[
\boxed{\Delta_2^\circ\times\Delta_2^\circ}.
\]

240-chart closure 为

\[
240=52\text{ expected}+180\text{ direct violations}+8\text{ wall exclusions}.
\]

仅有两条内部 determinant walls：

\[
AD=BC,
\qquad
CE=AF.
\]

墙外，精确 endpoint-offset 恒等式强迫至少一个 inactive coordinate 越出立方体；墙上 active matrix 恰好 rank 3，不会产生新的孤立 section vertex。

精确体积为

\[
|P|=\frac{2}{3}(a-b+c-d+16)=\frac{4}{3}(A+C+8),
\]

\[
|P^\circ|
=1-\frac{A^2}{12(A+2B)(A+2E)}
-\frac{C^2}{12(C+2D)(C+2F)}.
\]

这里的 polar 同样是立方体减去两对互不相交的四维单纯形帽。两类帽的同号相交间隙分别归约为

\[
AD\quad\text{或}\quad BC,
\]

异号相交间隙归约为

\[
AF\quad\text{或}\quad CE,
\]

均严格为正。

Mahler 余量正分子的 tensor degree 为

\[
(3,2,3,2).
\]

144 个 Bernstein coefficients 中

\[
91>0,\qquad53=0,\qquad0<0,
\]

最小正系数为 2。因此同样有

\[
|P||P^\circ|>\frac{32}{3}
\]

遍历整个严格域。

---

## 当前状态

\[
\boxed{
12V/20F,\ c=0,\ D=16:
\quad 6/14\text{ continuous survivors closed}
}
\]

已关闭的 family indices 为

\[
\boxed{81,82,88,89,90,91}.
\]

仍剩

\[
\boxed{2,17,42,76,80,85,86,87}.
\]

其中 7 个已经有 exact rational parametrization；Family 42 仍是唯一尚未完成有理参数化的分支。

本轮还强化了一个可抽象的结构：多个 survivor 在规范化后都可写成

\[
P^\circ=[-1,1]^4\cap\{|u\cdot y|\le1\}\cap\{|v\cdot y|\le1\},
\]

并且参数域本身恰好保证两对 simplex caps 不相交。若能把这一 cap 判据推广为统一引理，剩余若干 rational families 的 polar volume 可能不再需要逐族 triangulation。
