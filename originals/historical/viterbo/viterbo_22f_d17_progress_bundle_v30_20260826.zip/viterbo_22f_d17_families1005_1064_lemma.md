# Families 1005 and 1064: exact closure in the 12V/22F, c=0, D=17 layer

Date: 2026-08-26

All conclusions below are **computer-assisted analytic proof candidates**. They have exact replayable verifiers but have not yet undergone external peer review.

## Family 1005

A constant pivot on rows \((0,1,2,3)\) and columns \((2,3,4,5)\) has determinant \(8\). On the strict branch, a Schur equation

\[
(x_{4,2}-1)(x_{7,1}-x_{9,1})=0
\]

forces

\[
x_{7,1}=x_{9,1},
\]

because \(x_{4,2}=1\) is a defect boundary. With

\[
p=x_{2,0},\qquad q=x_{5,3},\qquad r=x_{9,3},
\]

the remaining rank ideal is zero-dimensional and uniquely determines all other defects.

The full strict domain is

\[
-1<r<q<1,
\qquad
\frac{q-r-2}{q-r+2}<p<q-r-1.
\]

Writing

\[
r=2C-1,\qquad q=r+2(1-C)B,
\]

and

\[
p=\frac{\delta-2+A\delta^2}{\delta+2},
\qquad \delta=2(1-C)B,
\qquad 0<A,B,C<1,
\]

gives a rational bijection from the open unit cube.

The exact verifier proves

\[
\operatorname{rank}X=4,\qquad f_0(P)=12,\qquad f_0(P^\circ)=22,
\]

using 32 primal and 79 polar tetrahedra. The Mahler margin factors as a positive \((1-C)\) factor times a tensor-Bernstein polynomial of degree

\[
(4,7,6).
\]

That polynomial has

\[
274>0,\qquad6=0,\qquad0<0
\]

Bernstein coefficients, with minimum positive coefficient \(4/3\). Therefore

\[
|P|\,|P^\circ|>\frac{32}{3}
\]

throughout the strict realization space.

## Family 1064

A constant pivot on rows \((0,1,2,9)\) and columns \((2,3,4,5)\) has determinant \(8\). The strict rank-four branch forces

\[
x_{3,5}=x_{4,4},\qquad x_{7,4}=x_{8,5},
\]

and

\[
x_{2,1}=\frac{a(c+1)-2}{c+3},
\]

where \(a=x_{0,1}\), \(c=x_{8,5}\), and \(t=x_{4,4}\).

The only potentially lost coefficient-zero branch is \(c+t=0\). Substitution into an original Schur equation yields

\[
2(a-1)(c+3)=0.
\]

Both alternatives lie outside the strict defect domain, so dividing by \(c+t\) loses no interior component.

The complete strict domain is

\[
-1<c,t<1,\qquad c+t<0,
\qquad
\frac{2c+t+3}{3-t}<a<1.
\]

It is rationally equivalent to the open unit cube via

\[
t=2C-1,\qquad c=-1+2(1-C)B,
\]

\[
a=L+(1-L)A,
\qquad L=\frac{2c+t+3}{3-t},
\qquad0<A,B,C<1.
\]

The exact verifier proves

\[
\operatorname{rank}X=4,\qquad f_0(P)=12,\qquad f_0(P^\circ)=22,
\]

using 32 primal and 77 polar tetrahedra. The sign-adjusted Mahler numerator is a tensor-Bernstein polynomial of degree

\[
(4,8,9),
\]

with

\[
415>0,\qquad35=0,\qquad0<0
\]

coefficients and minimum positive coefficient \(1\). Hence

\[
|P|\,|P^\circ|>\frac{32}{3}
\]

on the entire strict realization space.

## Canonical-label audit

An earlier prose progress update displayed the row template of canonical Family 131 under the heading “Family 2077.” The actual Family 2077 verifier and certificate use the canonical key recorded for Family 2077 in the preclassification certificate. Thus this was a report-label transcription error only; it has no effect on the machine certificates, canonical accounting, or the Family 2077 proof candidate.
