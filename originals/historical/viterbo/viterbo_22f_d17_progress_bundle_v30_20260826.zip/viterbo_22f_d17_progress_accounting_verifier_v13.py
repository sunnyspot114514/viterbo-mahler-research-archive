#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,sys
from fractions import Fraction
from pathlib import Path
BASE=Path('/mnt/data')
OLD=BASE/'viterbo_22f_d17_progress_accounting_certificate_v12.json'
OLD_STATUS=BASE/'viterbo_bounded12_status_20260825_v29.json'
PRE=BASE/'viterbo_22f_d17_preclassification_certificate.json'
LABEL=BASE/'viterbo_22f_d17_family_label_audit_20260826.json'
CERT=BASE/'viterbo_22f_d17_progress_accounting_certificate_v13.json'
OUT=BASE/'viterbo_22f_d17_progress_accounting_verifier_output_v13.json'
NEW_IDS=[1005,1064]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sgn_fraction(x):
    q=Fraction(str(x)); return 1 if q>0 else -1 if q<0 else 0
def check_basis_record(q):
    deg=q['degree']; expected=1
    for d in deg: expected*=d+1
    assert q['positive']>0 and q['zero']>=0
    assert q['positive']+q['zero']==expected
    assert Fraction(q['min_positive'])>0

def check_factorized_margin(mc):
    assert mc.get('factorized') is True
    by_side={}
    for rec in mc['records']:
        total=sgn_fraction(rec['coefficient'])
        assert total!=0
        for f in rec['factors']:
            cert=f['certificate']
            check_basis_record(cert['numerator']); check_basis_record(cert['denominator'])
            assert f['sign'] in (-1,1) and f['multiplicity']>=1
            total*=f['sign']**f['multiplicity']
        assert total==rec['sign']
        by_side[rec['side']]=rec['sign']
    assert set(by_side)=={'num','den'} and by_side['num']==by_side['den']

def run(fid):
    script=BASE/f'viterbo_22f_d17_family{fid}_verifier.py'
    out=BASE/f'viterbo_22f_d17_family{fid}_verifier_output.json'
    cert=BASE/f'viterbo_22f_d17_family{fid}_certificate.json'
    subprocess.run([sys.executable,str(script)],check=True,timeout=240,stdout=subprocess.DEVNULL)
    o=json.loads(out.read_text()); c=json.loads(cert.read_text())
    assert o['status']=='PASS' and c['status']=='PASS'
    assert o['canonical_id']==fid and c['canonical_id']==fid
    assert o['rank']==4 and o['strict_defects']==17
    assert o['primal_vertices']==12 and o['polar_vertices']==22
    check_factorized_margin(c['margin_certificate'])
    return {'status':'PASS','rank':4,'strict_defects':17,'primal_vertices':12,'polar_vertices':22,
            'tetrahedra_primal':o['tetrahedra_primal'],'tetrahedra_polar':o['tetrahedra_polar'],
            'parameter_domain':c['parameter_domain'],'rank_branch':c['rank_branch'],
            'margin_certificate':c['margin_certificate'],'script_sha256':sha(script),
            'certificate_sha256':sha(cert),'output_sha256':sha(out)}
def main():
    old=json.loads(OLD.read_text()); old_status=json.loads(OLD_STATUS.read_text())
    pre=json.loads(PRE.read_text()); label=json.loads(LABEL.read_text()); cert=json.loads(CERT.read_text())
    assert old['status']=='PASS' and cert['status']=='PASS' and label['status']=='PASS'
    assert old['remaining_ids']==old_status['frontier']['remaining_ids'] and len(old['remaining_ids'])==36
    assert all(i in old['remaining_ids'] for i in NEW_IDS)
    results={str(i):run(i) for i in NEW_IDS}
    remaining=[i for i in old['remaining_ids'] if i not in NEW_IDS]
    positive=sorted(old['Mahler_positive_exact_families']+NEW_IDS)
    assert remaining==cert['remaining_ids'] and positive==cert['Mahler_positive_exact_families']
    assert len(remaining)==34 and len(positive)==22
    assert cert['rerun_results'].keys()==results.keys()
    for k in results:
        for field in ['status','rank','strict_defects','primal_vertices','polar_vertices','tetrahedra_primal','tetrahedra_polar','parameter_domain','rank_branch','margin_certificate']:
            assert results[k][field]==cert['rerun_results'][k][field]
    disjoint=cert['disjoint_classification']; assert sum(disjoint.values())==2395
    surv=cert['survivor_level_accounting']; assert sum(v for k,v in surv.items() if k!='initial')==surv['initial']==121
    assert label['report_correction']['family_2077_key_matches_preclassification'] is True
    out={'status':'PASS','scope':cert['scope'],'newly_closed':NEW_IDS,'Mahler_positive_exact_total':22,
         'remaining':34,'total_pairing_templates':2395,'certificate':str(CERT),
         'certificate_sha256':sha(CERT),'label_audit_sha256':sha(LABEL),'rerun_results':results}
    OUT.write_text(json.dumps(out,indent=2,sort_keys=True)); print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
