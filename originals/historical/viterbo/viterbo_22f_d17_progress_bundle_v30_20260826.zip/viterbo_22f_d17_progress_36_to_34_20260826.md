# 12V/22F, c=0, D=17 progress: 36 to 34 remaining families

Date: 2026-08-26

## New closures

The exact verifiers for canonical Families 1005 and 1064 both return `PASS`. Each family has:

- a unique strict rank-four rational branch;
- a complete rational parametrization by an open unit cube;
- 17 strict defects;
- 12 primal vertices and 22 polar vertices throughout the domain;
- a globally valid primal/polar boundary decomposition;
- a strictly positive Mahler margin certified in tensor Bernstein form.

Hence

\[
\boxed{\text{Families }1005,1064\quad\checkmark}
\]

as computer-assisted analytic proof candidates.

### Family 1005

\[
-1<r<q<1,
\qquad
\frac{q-r-2}{q-r+2}<p<q-r-1.
\]

The principal positive Bernstein factor has degree \((4,7,6)\), with 274 positive coefficients, 6 zero coefficients, no negative coefficients, and minimum positive coefficient \(4/3\). The boundary decomposition contains 32 primal and 79 polar tetrahedra.

### Family 1064

\[
-1<c,t<1,\qquad c+t<0,
\qquad
\frac{2c+t+3}{3-t}<a<1.
\]

The branch \(c+t=0\), which could have been lost by division during elimination, is checked directly and forces \(2(a-1)(c+3)=0\); it has no strict solution. The main Bernstein numerator has degree \((4,8,9)\), with 415 positive coefficients, 35 zero coefficients, no negative coefficients, and minimum positive coefficient \(1\). The boundary decomposition contains 32 primal and 77 polar tetrahedra.

## Updated non-overlapping accounting

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ facet-containment templates}\\
&+1070\text{ antichain rank-}\ge5\text{ templates}\\
&+22\text{ segment vertex-loss templates}\\
&+4\text{ duplicate/antipodal primal-pair templates}\\
&+22\text{ exact Mahler-positive families}\\
&+13\text{ strict boundary/interval-impossible families}\\
&+34\text{ remaining algebraic survivors}.
\end{aligned}}
\]

At the original 121-survivor level:

\[
\boxed{121=26+22+4+22+13+34.}
\]

Thus the current frontier is

\[
\boxed{12V/22F,\ c=0,\ D=17:\quad121\to34.}
\]

## Report correction

An earlier prose update accidentally placed canonical Family 131 row data under the label Family 2077. A canonical-key audit confirms that the actual Family 2077 certificate and verifier match the Family 2077 preclassification key. No machine certificate or accounting entry is affected.

## Scope

All checkmarks denote computer-assisted analytic proof candidates. This remains part of the bounded-12 finite core for the four-dimensional symmetric Mahler conjecture. A complexity-independent finite-core or bi-shadow-rigid reduction theorem is still required to reach the full conjecture for arbitrary centrally symmetric convex bodies.
