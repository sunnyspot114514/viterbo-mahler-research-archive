#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 1064."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family1064_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family1064_verifier_output.json')
CID=1064
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
spec2=importlib.util.spec_from_file_location('gbase','/mnt/data/viterbo_22f_d17_family2060_verifier.py');gbase=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(gbase)
PRIMAL_TETRAHEDRA=[(0,4,5,7),(0,4,5,8),(0,4,7,9),(0,4,8,9),(0,5,7,9),(0,5,8,9),(1,3,6,10),(1,3,6,11),(1,3,8,10),(1,3,8,11),(1,6,10,11),(1,8,9,10),(1,8,9,11),(1,9,10,11),(2,3,4,7),(2,3,4,11),(2,3,5,7),(2,3,5,10),(2,3,6,10),(2,3,6,11),(2,4,7,9),(2,4,9,11),(2,5,7,9),(2,5,9,10),(2,6,10,11),(2,9,10,11),(3,4,5,7),(3,4,5,8),(3,4,8,11),(3,5,8,10),(4,8,9,11),(5,8,9,10)]
def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def certify_positive(expr,eng,label):
 expr=sp.factor(sp.cancel(expr));assert sp.N(expr.subs(eng.sample))>0,(label,expr.subs(eng.sample),expr)
 num,den=map(sp.factor,sp.together(expr).as_numer_denom());records=[];overall=1
 for side,poly in [('num',num),('den',den)]:
  coef,factors=sp.factor_list(poly);sgside=1 if coef>0 else -1;rec={'side':side,'coefficient':str(coef),'factors':[]}
  for f,m in factors:
   val=sp.N(f.subs(eng.sample));assert val!=0,(label,side,f);sg=1 if val>0 else -1
   ce=eng.positive_rational(sg*f,label+' '+side+' factor');rec['factors'].append({'factor':str(f),'multiplicity':int(m),'sign':sg,'certificate':ce})
   if m%2:sgside*=sg
  rec['sign']=sgside;records.append(rec);overall*=sgside
 assert overall>0,(label,overall,expr);return {'factorized':True,'records':records}
def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=v
 rr=(0,1,2,9);cc=(2,3,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ);eq=[sp.factor(sp.cancel(e)) for e in S]
 const,uns,rem,trace=base.constant_eliminate(eq,vs);nums=[sp.factor(sp.together(e).as_numer_denom()[0]) for e in rem];us=sorted(uns,key=str)
 G0=sp.groebner(nums,*us,order='grevlex',domain=sp.QQ)
 rel1=(x['x1_0']-1)*(x['x3_5']-x['x4_4'])*(x['x8_5']-1);rel2=(x['x1_0']-1)*(x['x7_4']-x['x8_5'])
 assert sp.factor(G0.reduce(rel1)[1])==0 and sp.factor(G0.reduce(rel2)[1])==0
 a,c,t=sp.symbols('a c t',real=True);brel=sp.factor((a*(c+1)-2)/(c+3))
 st=dict(const);st.update({x['x0_1']:a,x['x2_1']:brel,x['x8_5']:c,x['x7_4']:c,x['x3_5']:t,x['x4_4']:t})
 red=[base.apply_all(e,st) for e in rem];red=[sp.factor(sp.together(e).as_numer_denom()[0]) for e in red if e!=0]
 # Audit the coefficient-zero branch c+t=0 before dividing by it.
 branch_zero=[sp.factor(e.subs(t,-c)) for e in red]
 assert any(sp.factor(e-2*(a-1)*(c+3))==0 for e in branch_zero)
 unknown=[x['x1_0'],x['x5_2'],x['x6_3']];G=sp.groebner(red,*unknown,order='lex',domain=sp.QQ.frac_field(a,c,t));assert G.is_zero_dimensional and len(G.polys)==3
 sol={
  x['x1_0']:sp.factor(-(a*c*t-5*a*c-a*t-3*a+2*c**2+c*t+3*c-t+3)/((c+3)*(a*t-a+2*c+t+1))),
  x['x5_2']:sp.factor((a*c+a*t+4*a-c+t-2)/(-a*c+a*t-2*a+c+t+4)),
  x['x6_3']:sp.factor((-a*c+a*t-6*a+3*c+t+6)/((a+1)*(c+t))),
 }
 for po in G.polys:assert sp.factor(sp.cancel(po.as_expr().subs(sol)))==0
 st.update(sol);allsol={z:base.apply_all(z,st) for z in vs};X=M.subs(allsol).applyfunc(lambda z:sp.factor(sp.cancel(z)));assert all(sp.factor(sp.cancel(e.subs(allsol)))==0 for e in eq)
 return rec,rows,M,vs,X,(a,c,t),rr,cc,allsol,trace,G0,G,brel
def main():
 rec,rows,M,vs,X0,free,rr,cc,sol,trace,G0,G,brel=build_branch();a,c,t=free
 A,B,C=sp.symbols('A B C',real=True);tc=2*C-1;cchart=-1+2*(1-C)*B;L=sp.factor((2*cchart+tc+3)/(3-tc));ac=sp.factor(L+(1-L)*A);chart={a:ac,c:cchart,t:tc};cv=(A,B,C);sample_cube={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};sample={k:sp.factor(v.subs(sample_cube)) for k,v in chart.items()};eng=base.SignEngine(cv,sample_cube)
 inv={'C':sp.factor((t+1)/2),'B':sp.factor((c+1)/(1-t)),'A':sp.factor((a*(3-t)-(2*c+t+3))/(-2*(c+t)))};assert all(sp.factor(v.subs(chart)-s)==0 for s,v in [(C,inv['C']),(B,inv['B']),(A,inv['A'])])
 Fdom=sp.factor(a*t-3*a+2*c+t+3);coeff={'minus_c_plus_t':eng.positive_rational(-(cchart+tc),'-(c+t)'),'minus_F':eng.positive_rational(-Fdom.subs(chart),'-F'),'a_minus_L':eng.positive_rational(ac-L,'a-L'),'one_minus_a':eng.positive_rational(1-ac,'1-a')}
 X=X0.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)));pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8;V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=certify_positive(1-X[i,j]**2,eng,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(sp.cancel(F.extract(rrr,range(4)).det(method='domain-ge')))
   if det==0:continue
   sg=1 if det.subs(sample_cube)>0 else -1
   try:ce=certify_positive(sg*det,eng,f'extremality {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample_cube),float);fn=np.array(F.subs(sample_cube),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP=list(PRIMAL_TETRAHEDRA);pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP);assert all(sum(set(tet)<=set(f) for f in facP)==1 for tet in tetP)
 tetQ,ridQ=gbase.global_boundary_triangulation(facQ,ptsQ);qb=base.check_closed_sphere(tetQ);qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0,(label,k,ids);sg=1 if det.subs(sample_cube)>0 else -1;ce=certify_positive(sg*det,eng,f'{label} tet {k}');terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar');volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=certify_positive(margin,eng,'Mahler margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 1064','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relations':['x3_5=x4_4','x7_4=x8_5',f'x2_1={brel}'],'coefficient_zero_branch':'c+t=0 forces 2(a-1)(c+3)=0, impossible for strict defects','groebner_initial_length':len(G0.polys),'groebner_strict_length':len(G.polys),'completion':{str(k):str(v) for k,v in sol.items()}},'parameter_domain':{'original':'-1<c,t<1, c+t<0, (2c+t+3)/(3-t)<a<1','unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse':{k:str(v) for k,v in inv.items()}},'coefficient_certificates':coeff,'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'polar_boundary':qb,'primal_triangulation_source':{'source_local_id':1291,'source_sphere_orbit':5,'matching':[2,4,10,16,23],'signed_coordinate_permutation':{'permutation':[0,1,4,5,2,3],'signs':[1,1,1,-1,1,1]}},'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'polar_ridge_sizes':dict(Counter(map(len,ridQ))),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 1064 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
