# 12V/20F, c=0, D=16：两族完整关闭后的进展

日期：2026-08-17

## 当前结果

预分类已经给出

\[
92=72\text{ 个 rank}\ge5+6\text{ 个重复 facet-row}+14\text{ 个连续 survivors}.
\]

本轮对其中两个 survivor 完成了从低秩参数化到 Mahler 正性的全链条认证：

\[
\boxed{14\longrightarrow12\text{ 个未处理 survivors}.}
\]

两族都满足

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

遍历各自完整严格参数域。

---

## Family 91：标准开四维单纯形

参数域：

\[
A,B,C,D,E>0,
\qquad E=1-A-B-C-D.
\]

证书：

- pivot determinant \(16\)；
- 12 个 primal vertices 全部 extreme；
- 240 个 active charts：52 个预期出现、176 个严格排除、12 个内部墙分域；
- 恰有 20 个 section vertices；
- 四个 oriented-matroid chambers，记录数 \(66,64,66,64\)，无失败；
- degree-5 simplex Bernstein：126 个系数中 \(48>0,78=0\)，最小正系数 \(1/5\)。

结论：

\[
\boxed{\mathcal P(P)>32/3.}
\]

---

## Family 90：两个开二维单纯形的直积

参数域：

\[
A,B>0,
\quad A+B<1,
\qquad
C,D>0,
\quad C+D<1.
\]

证书：

- pivot determinant \(-16\)；
- 12 个 primal vertices 全部 extreme；
- 240 个 active charts：52 个预期出现、176 个严格排除、12 个内部墙分域；
- 恰有 20 个 section vertices；
- 四个 oriented-matroid chambers，每个 66 条记录，无失败；
- product-simplex Bernstein bidegree \((3,3)\)：100 个系数中 \(48>0,52=0\)，最小正系数 \(2\)。

结论：

\[
\boxed{\mathcal P(P)>32/3.}
\]

---

## 更新后的 bounded-12 状态

\[
\begin{array}{c|c}
\text{层}&\text{状态}\\
\hline
c=1&\checkmark\\
c=0,
12V/12F&\checkmark\\
c=0,
12V/14F&\checkmark\\
c=0,
12V/16F&\checkmark\\
c=0,
12V/18F&\checkmark\\
c=0,
12V/20F,
D=16&2/14\text{ survivors 已关闭，12 个剩余}
\end{array}
\]

所有勾号及本轮两族结论均表示 **computer-assisted analytic proof candidate**。

---

## 下一步

剩余 12 个 survivors 中：

- 11 个已经有 exact rational 四参数化；
- family 42 仍需非线性消元；
- 后续优先寻找参数域仍为 simplex、product-simplex 或可由少量 rational charts 覆盖的 families；
- 每族继续执行同一套固定协议：rank、strict domain、primal extremality、240-chart closure、chamber triangulation、exact volumes、Bernstein positivity。

因此当前并未关闭整个 \(D=16\) 层，但已经证明：14 个预分类连续 survivors 中至少两个不是潜在 equality family，并且可由相当小的独立证书彻底排除。
