# 4D symmetric Mahler bounded-12 progress: Families 86 and 87

Date: 2026-08-18

## Milestone

Within

\[
12V/20F,\qquad c=0,\qquad D=16,
\]

two additional four-parameter algebraic survivors have been closed as computer-assisted analytic proof candidates:

\[
\boxed{\text{Family }87\quad\checkmark},
\qquad
\boxed{\text{Family }86\quad\checkmark}.
\]

The survivor count is now

\[
\boxed{8/14\text{ closed},\qquad6\text{ remaining}}.
\]

Closed indices:

\[
81,82,86,87,88,89,90,91.
\]

Remaining indices:

\[
2,17,42,76,80,85.
\]

## Family 87

The strict domain is

\[
\Delta_3^\circ\times(0,1).
\]

After rank normalization, the polar is a four-cube cut by two symmetric slabs. Both same-sign and opposite-sign cap closures are strictly disjoint. The section has exactly 20 vertices by direct cap counting.

The strict Mahler margin is reduced to the bivariate polynomial

\[
N(T,E)=7T^2E+7TE^2-18TE-13T^2-13E^2+16T+16E.
\]

Its degree-\((2,2)\) Bernstein coefficient matrix is

\[
\begin{pmatrix}
0&8&3\\
8&23/2&11/2\\
3&11/2&2
\end{pmatrix},
\]

so the margin is strictly positive throughout the full domain.

## Family 86

The full strict domain is again

\[
\Delta_3^\circ\times(0,1).
\]

In normalized coordinates the two extra primal columns are

\[
u=\left(-\frac{A}{2-R},\ B+H,\ C+H,\ -D-H\right),
\]

\[
v=\frac1{1+R}(-1,-R,-R,R),
\qquad
H=\frac{(1-R)A}{2-R}.
\]

Same-sign cap closures are strictly disjoint. Opposite-sign cap interiors are disjoint, but their closures touch at exactly one antipodal pair:

\[
\pm(1-2R,1,1,-1).
\]

This point is already one of the prescribed section rows. Hence the exact section count is

\[
16-4+8+2-2=20.
\]

The exact primal volume is

\[
|P|=
\frac{4\bigl((1-R^2)A-5R^2+6R+8\bigr)}{3(2-R)}.
\]

The polar volume is obtained by subtracting the two antipodal cap-pair volumes from the normalized cube and undoing the pivot determinant.

A product inequality removes the three remaining barycentric coordinates:

\[
(B+H)(C+H)(D+H)>H^2(H+1-A).
\]

The resulting lower-margin numerator is

\[
\begin{aligned}
N(A,R)={}&A^2R^4-3A^2R^3+12A^2R^2+3A^2R-13A^2\\
&+4AR^4-7AR^3+4AR^2-20AR+16A\\
&-5R^4+28R^3-52R^2+32R.
\end{aligned}
\]

Its degree-\((2,4)\) Bernstein coefficient matrix is

\[
\begin{pmatrix}
0&8&22/3&5&3\\
8&27/2&32/3&45/8&3/2\\
3&27/4&9/2&3/4&0
\end{pmatrix}.
\]

Thus 13 coefficients are positive, 2 are zero, none are negative, and the minimum positive coefficient is \(3/4\). Therefore

\[
\boxed{|P||P^\circ|>32/3}
\]

throughout the full strict family.

## Verification status

Both exact verifiers returned `PASS` and independently recompute:

- rank-four completion;
- all sixteen strict defects;
- normalized two-slab geometry;
- exact 20-vertex section closure;
- primal and polar volume formulae;
- Bernstein positivity of the strict Mahler margin.

These are not externally reviewed theorems. They are computer-assisted analytic proof candidates within the bounded-12 program.
