#!/usr/bin/env python3
from pathlib import Path
from viterbo_d15_cube_family_common import verify
HERE=Path(__file__).resolve().parent
verify(HERE/'family736_certificate.json',HERE/'family736_verifier_output.json')
