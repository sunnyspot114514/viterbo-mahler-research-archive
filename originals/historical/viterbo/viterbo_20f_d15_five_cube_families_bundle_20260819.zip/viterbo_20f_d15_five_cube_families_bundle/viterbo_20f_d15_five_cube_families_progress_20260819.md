# 四维中心对称 Mahler：20F、D=15 五个开立方体 family 的关闭

日期：2026-08-19

## 本轮结论

在

\[
12V/20F,\qquad c=0,\qquad D=15
\]

的剩余 algebraic survivors 中，以下五个 canonical families 已获得完整的精确证书：

\[
\boxed{86,\ 284,\ 512,\ 736,\ 739}.
\]

每一族都满足

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

贯穿其完整严格 realization space。因此五族均可列为 **computer-assisted analytic proof candidates**。

## 统一的参数结构

五个 family 都可以选择三条自由 defect，使

\[
u=2A-1,\qquad v=2B-1,\qquad w=2C-1,
\]

而完整严格域恰好为

\[
\boxed{0<A,B,C<1}.
\]

这不是数值观察。对每个 dependent defect \(x_{ij}(A,B,C)\)，验证器将

\[
1-x_{ij}^2
\]

写成有理函数，并分别证明分子、分母在 tensor Bernstein basis 中系数非负且至少一个严格为正。由此全部 15 条 defect inequalities 在整个开立方体内严格成立。

五族均具有恒定的非零 \(4\times4\) pivot，determinant 为 \(\pm8\)，Schur complement 恒等为零，因此

\[
\operatorname{rank}X=4.
\]

对六个正向 primal columns，分别找到四个 incident facet normals，其 determinant 在全域保持非零，因此

\[
f_0(P)=12.
\]

由 prescribed support incidence、严格 non-incidence slacks、全域固定的 primal boundary triangulation 以及每个 polar facet 的全域 triangulation，得到

\[
f_0(P^\circ)=20.
\]

## Mahler 余量证书

| Family | primal tets | polar facet tets | margin degree | 正系数 | 零系数 | 最小正系数 |
|---:|---:|---:|---:|---:|---:|---:|
| 86 | 34 | 67 | (3, 3, 4) | 52 | 28 | 2 |
| 284 | 33 | 67 | (2, 6, 3) | 67 | 17 | 8/9 |
| 512 | 35 | 70 | (2, 4, 3) | 49 | 11 | 2 |
| 736 | 36 | 65 | (2, 4, 4) | 62 | 13 | 3/2 |
| 739 | 35 | 68 | (4, 3, 2) | 47 | 13 | 2 |

所有 family 的 margin numerator 都没有负 Bernstein coefficient；margin denominator 也具有同样的严格正证书。因此五个 family 在开参数域内严格高于 \(32/3\)。

## 精确体积公式

### Family 86

\[
|P|=(3*A**2*B**2*C**2 - A**2*B**2*C - 5*A**2*B*C**2 + 9*A**2*B*C - A**2*B + 2*A**2*C**2 - 7*A**2*C + 5*A**2 - 4*A*B**2*C + 11*A*B*C - 5*A*B - 7*A*C + 9*A - 4*B + 4)/(6*(A*B*C - A*C + A + 1)*(A*B*C - A*C + A - B + 1)).
\]

\[
|P^\circ|=4*(A*B*C**2 + A*B*C + A*B - 2*A*C**2 - A*C - A + 12)/3.
\]

### Family 284

\[
|P|=(3*A*B**3*C**2 - A*B**2*C**2 + 6*A*B**2*C - 2*A*B*C**2 + 3*A*B*C + 3*A*B + A*C + 5*A - 3*B**2*C**2 + B**2*C + B*C**2 - 12*B*C + B + 2*C**2 + C - 9)/(6*(B*C + 1)*(A*B**2*C - A*B*C + A*B + A - B*C + C - 2)).
\]

\[
|P^\circ|=4*(A*B**3*C - 3*A*B**2*C + A*B**2 + 3*A*B*C - 2*A*B - A*C + A - B**2*C - B**2 + 3*B*C + 2*B - 3*C + 11)/3.
\]

### Family 512

\[
|P|=(4*A*B*C**2 - A*B*C - 3*A*B - 3*A*C**2 - 4*A*C - 2*A - 4*B*C**2 + B*C + 3*B - 2*C**2 + 5*C + 6)/(6*(C + 1)*(A*B*C - A*B - A*C - B*C + B + 1)).
\]

\[
|P^\circ|=4*(A*B**3*C - A*B**3 - 4*A*B**2*C + 4*A*B**2 + 6*A*B*C - 6*A*B - 4*A*C + 4*A - B**3*C + B**3 + 4*B**2*C - 4*B**2 - 6*B*C + 6*B + 3*C + 8)/3.
\]

### Family 736

\[
|P|=-(A*B*C**2 - A*B*C - A*C - 4*B*C**2 + B*C + 3*B - 2*C**2 + 5*C + 6)/(6*(C + 1)*(B*C - B - 1)).
\]

\[
|P^\circ|=-4*(A*B**3*C - A*B**3 - 4*A*B**2*C + 4*A*B**2 + 6*A*B*C - 6*A*B - A*C**2 - 4*A*C - 8*A + B**3*C**2 - B**3*C - 4*B**2*C**2 + 4*B**2*C + 6*B*C**2 - 6*B*C - 3*C**2 - 8*C)/(3*(A + C)).
\]

### Family 739

\[
|P|=(A*B**2*C + 3*A*B**2 - 4*A*B*C - 3*A*B - B**2*C - 5*B**2 + 5*B*C + B + 5*C + 4)/(6*(B - C - 1)*(A*B - B - 1)).
\]

\[
|P^\circ|=-4*(A**3*B + A**2*B + A*B - B*C + B + C - 12)/3.
\]

## D=15 状态更新

本层完整预分类为

\[
748=669\text{ 个 rank}\ge5+51\text{ 个重复 rows}+28\text{ 个 algebraic survivors}.
\]

此前已经关闭：

\[
183,\ 240,\ 374,\ 426,\ 427,\ 673,\ 738,
\]

以及两个 vertex-loss families

\[
44,\ 342.
\]

加入本轮五族后，当前分类为

\[
\boxed{
748
=669+51
+2\text{ 个 vertex-loss}
+12\text{ 个 Mahler-positive}
+14\text{ 个 remaining}.
}
\]

剩余 canonical survivors 为

\[
\boxed{
50,244,272,281,286,396,497,509,514,541,675,683,728,747.
}
\]

## 证明标准说明

本轮证书包含：

- exact rank-four completion；
- 15 条严格 defect 的 Bernstein 证书；
- 12 个 primal vertices 的 active-normal-cone 证书；
- sample pulling triangulation 的全域 orientation 证书；
- primal boundary sphere 与各 facet-ball 的组合检查；
- exact \(|P|\)、\(|P^\circ|\)；
- Mahler margin numerator/denominator 的 Bernstein 证书；
- 五个 standalone family verifiers 和一个聚合重放器。

这些结果仍未经过外部同行审阅，也尚未构成完整四维 symmetric Mahler 猜想的证明。当前推进范围仍是 bounded-12 有限核心。
