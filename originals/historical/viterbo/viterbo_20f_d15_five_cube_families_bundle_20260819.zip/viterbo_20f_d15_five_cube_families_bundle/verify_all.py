#!/usr/bin/env python3
import json,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ids=[86,284,512,736,739]
items=[]
for idx in ids:
    subprocess.run([sys.executable,str(HERE/f'family{idx}_verifier.py')],check=True,cwd=HERE,stdout=subprocess.DEVNULL)
    d=json.loads((HERE/f'family{idx}_verifier_output.json').read_text())
    assert d['status']=='PASS' and d['rank']==4 and d['strict_defects']==15
    assert d['primal_vertices']==12 and d['polar_vertices']==20
    assert d['margin_numerator_bernstein']['negative']==0
    items.append({'family':idx,'margin':d['margin_numerator_bernstein']})
out={'status':'PASS','families':items,'conclusion':'All five full-cube D=15 families are certified Mahler-positive.'}
(HERE/'verify_all_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
