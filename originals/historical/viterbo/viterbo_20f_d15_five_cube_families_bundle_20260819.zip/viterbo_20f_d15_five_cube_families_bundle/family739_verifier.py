#!/usr/bin/env python3
from pathlib import Path
from viterbo_d15_cube_family_common import verify
HERE=Path(__file__).resolve().parent
verify(HERE/'family739_certificate.json',HERE/'family739_verifier_output.json')
