#!/usr/bin/env python3
from pathlib import Path
from viterbo_d15_cube_family_common import verify
HERE=Path(__file__).resolve().parent
verify(HERE/'family86_certificate.json',HERE/'family86_verifier_output.json')
