# Family 2255 exact closure lemma

## Scope

This note certifies canonical Family 2255 in the four-dimensional centrally symmetric Mahler bounded-12 classification at

\[
12V/22F,\qquad c=0,\qquad D=17.
\]

All claims are exact and machine-replayable. The conclusion is a computer-assisted analytic proof candidate, not a claim of external peer review.

## Rank-four branch

Use rows \((2,3,5,6)\) and columns \((1,2,3,5)\) as a pivot. Its determinant is

\[
\det=8.
\]

After all constant-coefficient eliminations, one Schur equation is

\[
(x_{2,0}-x_{3,0})(x_{7,5}+1)=0.
\]

Since \(x_{7,5}\in(-1,1)\), the strict branch satisfies

\[
x_{2,0}=x_{3,0}=:a.
\]

Set

\[
b=x_{5,4},\qquad c=x_{7,5}.
\]

The remaining rank ideal is zero-dimensional over \(\mathbb Q(a,b,c)\) and has the unique completion

\[
x_{0,1}=x_{1,1}=\frac{b-c}{b+c-2},
\]

\[
x_{10,1}=\frac{b+c+2}{b+c-2},
\]

\[
x_{8,2}=x_{9,2}=\frac{ab+ac-a-b-c-1}{a+1},
\]

with all other defects obtained by the constant elimination trace. Substitution into every original Schur equation gives zero identically.

## Full strict realization domain

The exact domain is

\[
-1<b,c<1,\qquad b+c<0,
\]

\[
\frac{b+c+2}{b+c-2}<a<\frac{c+1}{c-3}.
\]

The interval is nonempty because

\[
\frac{c+1}{c-3}-\frac{b+c+2}{b+c-2}
=
\frac{4(b+1)}{(c-3)(b+c-2)}>0.
\]

A rational bijection from the open unit cube is

\[
c=2C-1,
\]

\[
b=-1+2(1-C)B,
\]

\[
a=L+(U-L)A,
\]

where

\[
L=\frac{b+c+2}{b+c-2},\qquad
U=\frac{c+1}{c-3},
\qquad 0<A,B,C<1.
\]

Its inverse is

\[
C=\frac{c+1}{2},\qquad
B=\frac{b+1}{1-c},\qquad
A=\frac{a-L}{U-L}.
\]

Every one of the 17 defect inequalities \(1-x_{ij}^2>0\) has an exact factorized tensor-Bernstein certificate on this cube.

## Combinatorial closure

The rank factorization preserves all six antipodal primal vertex pairs. For each positive representative, four incident facet normals have a determinant of fixed nonzero sign throughout the parameter cube. Hence

\[
f_0(P)=12.
\]

The primal boundary is the 32-tetrahedron centrally symmetric simplicial sphere transported from source local matching 1582, sphere orbit 7, by

\[
\mathrm{perm}=(0,1,4,5,2,3),
\qquad
\mathrm{signs}=(-1,-1,-1,-1,-1,1).
\]

The polar boundary has a globally compatible 76-tetrahedron triangulation. All selected primal and polar simplex determinants have fixed strict signs. Consequently

\[
f_0(P^\circ)=22.
\]

## Mahler margin

The exact fixed triangulations produce rational expressions for \(|P|\) and \(|P^\circ|\). On the unit cube,

\[
|P|\,|P^\circ|-\frac{32}{3}
=
\frac{N(A,B,C)}{Q(A,B,C)}.
\]

The tensor-Bernstein certificate is

\[
\deg N=(3,7,7),
\]

\[
199\text{ positive},\qquad57\text{ zero},\qquad0\text{ negative},
\]

with minimum positive coefficient

\[
\frac{8}{49}.
\]

For the denominator,

\[
\deg Q=(2,4,5),
\]

\[
72\text{ positive},\qquad18\text{ zero},\qquad0\text{ negative},
\]

with minimum positive coefficient

\[
\frac32.
\]

Therefore

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout the full strict realization space.
