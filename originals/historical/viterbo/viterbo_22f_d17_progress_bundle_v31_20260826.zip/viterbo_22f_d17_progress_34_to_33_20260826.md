# Viterbo/Mahler bounded-12 progress: Family 2255

Date: 2026-08-26

## Result

Canonical Family 2255 in the layer

\[12V/22F,\quad c=0,\quad D=17\]

is now closed as a computer-assisted analytic proof candidate.

The strict rank-four branch is unique; its full realization space is rationally equivalent to the open unit cube. Exact verification gives rank 4, 17 strict defects, 12 primal vertices, 22 polar vertices, a 32-tetrahedron primal boundary and a 76-tetrahedron polar boundary.

The Mahler-margin Bernstein certificate has degree \((3,7,7)\), with 199 positive, 57 zero and no negative coefficients; the minimum positive coefficient is \(8/49\). Hence \(|P||P^\circ|>32/3\) on the entire strict family.

## Updated D=17 accounting

\[
2395=1230+1070+22+4+23+13+33.
\]

The 121 original algebraic survivors now split as

\[
121=26+22+4+23+13+33.
\]

Thus the D=17 frontier moves from 34 to 33 remaining canonical families.

## Scope warning

This remains part of the bounded-12 finite core of the four-dimensional symmetric Mahler conjecture. It is not yet the full four-dimensional theorem and has not undergone external peer review.
