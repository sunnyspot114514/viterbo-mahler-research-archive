#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 2255."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util

PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family2255_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family2255_verifier_output.json')
CID=2255
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
spec2=importlib.util.spec_from_file_location('gbase','/mnt/data/viterbo_22f_d17_family2060_verifier.py')
gbase=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(gbase)

PRIMAL_TETRAHEDRA=[
(0,4,7,8),(0,4,7,9),(0,4,8,9),(0,7,8,11),(0,7,9,11),(0,8,9,11),
(1,2,5,6),(1,2,5,9),(1,2,6,10),(1,2,9,10),(1,3,5,6),(1,3,5,8),(1,3,6,10),(1,3,8,10),(1,5,8,9),(1,8,9,10),
(2,3,4,5),(2,3,4,7),(2,3,5,6),(2,3,6,10),(2,3,7,11),(2,3,10,11),(2,4,5,9),(2,4,7,9),(2,7,9,11),(2,9,10,11),
(3,4,5,8),(3,4,7,8),(3,7,8,11),(3,8,10,11),(4,5,8,9),(8,9,10,11)]

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def factorized_positive(expr,chart,eng,sample_original,label):
    expr=sp.factor(sp.cancel(expr));assert sp.N(expr.subs(sample_original))>0,(label,expr.subs(sample_original),expr)
    num,den=map(sp.factor,sp.together(expr).as_numer_denom());records=[];total=sp.Rational(1)
    for side,poly,expsign in [('numerator',num,1),('denominator',den,-1)]:
        coef,factors=sp.factor_list(poly);side_sign=1 if coef>0 else -1
        rec={'side':side,'coefficient':str(coef),'factors':[]}
        for f,m in factors:
            fs=sp.factor(sp.cancel(f.subs(chart)));val=sp.N(fs.subs(eng.sample));assert val!=0,(label,side,f,fs)
            sg=1 if val>0 else -1;ce=eng.positive_rational(sg*fs,label+' '+side+' factor')
            rec['factors'].append({'factor':str(f),'multiplicity':int(m),'sign':int(sg),'certificate':ce})
            if m%2:side_sign*=sg
        rec['sign']=side_sign;records.append(rec);total*=side_sign**expsign
    assert total>0,(label,total,expr)
    return {'factorized':True,'records':records}

def proportional_member(exprs,target):
    target=sp.factor(target)
    for e in exprs:
        ratio=sp.factor(sp.cancel(e/target))
        if ratio.is_Rational and ratio!=0:return str(ratio)
    raise AssertionError(('target not found',target))

def build_branch():
    rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
    for i,row in enumerate(rows):
        for j,z in enumerate(row):
            if z==0:
                q=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=q;vs.append(q);x[str(q)]=q
            else:M[i,j]=z
    rr=(2,3,5,6);cc=(1,2,3,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
    orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
    S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ)
    eq=[sp.factor(sp.cancel(e)) for e in S]
    const,uns,rem,trace=base.constant_eliminate(eq,vs)
    relation=(x['x2_0']-x['x3_0'])*(x['x7_5']+1)
    ratio=proportional_member([sp.factor(sp.together(e).as_numer_denom()[0]) for e in rem],relation)
    a,b,c=sp.symbols('a b c',real=True)
    stage=dict(const);stage.update({x['x2_0']:a,x['x3_0']:a,x['x5_4']:b,x['x7_5']:c})
    red=[base.apply_all(e,stage) for e in rem];red=[sp.factor(e) for e in red if e!=0]
    unknown=sorted(set().union(*(e.free_symbols for e in red))-{a,b,c},key=str)
    nums=[sp.factor(sp.together(e).as_numer_denom()[0]) for e in red]
    G=sp.groebner(nums,*unknown,order='lex',domain=sp.QQ.frac_field(a,b,c));assert G.is_zero_dimensional and len(G.polys)==5
    sol={
      x['x0_1']:sp.factor((b-c)/(b+c-2)),
      x['x1_1']:sp.factor((b-c)/(b+c-2)),
      x['x10_1']:sp.factor((b+c+2)/(b+c-2)),
      x['x8_2']:sp.factor((a*b+a*c-a-b-c-1)/(a+1)),
      x['x9_2']:sp.factor((a*b+a*c-a-b-c-1)/(a+1)),
    }
    for po in G.polys:assert sp.factor(sp.cancel(po.as_expr().subs(sol)))==0
    stage.update(sol);allsol={z:base.apply_all(z,stage) for z in vs}
    X=M.subs(allsol).applyfunc(lambda z:sp.factor(sp.cancel(z)))
    assert all(sp.factor(sp.cancel(e.subs(allsol)))==0 for e in eq)
    return rec,rows,M,vs,X,(a,b,c),rr,cc,allsol,trace,ratio,G

def main():
    rec,rows,M,vs,X0,free,rr,cc,sol,trace,ratio,G=build_branch();a,b,c=free
    A,B,C=sp.symbols('A B C',real=True)
    cchart=2*C-1;bchart=sp.factor(-1+2*(1-C)*B);s=sp.factor(b+c)
    lower=sp.factor((s+2)/(s-2));upper=sp.factor((c+1)/(c-3));achart=sp.factor(lower+(upper-lower)*A)
    chart={a:achart,b:bchart,c:cchart};cv=(A,B,C);sample_cube={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};sample={k:sp.factor(v.subs(sample_cube)) for k,v in chart.items()};eng=base.SignEngine(cv,sample_cube)
    inverse={'C':sp.factor((c+1)/2),'B':sp.factor((b+1)/(1-c)),'A':sp.factor((a-lower)/(upper-lower))}
    assert all(sp.factor(expr.subs(chart)-sym)==0 for sym,expr in [(A,inverse['A']),(B,inverse['B']),(C,inverse['C'])])
    coeff={
      'minus_b_plus_c':eng.positive_rational((-(b+c)).subs(chart),'-b-c'),
      'upper_minus_lower':eng.positive_rational((upper-lower).subs(chart),'upper-lower'),
      'a_minus_lower':eng.positive_rational((a-lower).subs(chart),'a-lower'),
      'upper_minus_a':eng.positive_rational((upper-a).subs(chart),'upper-a'),
      'one_minus_c':eng.positive_rational((1-c).subs(chart),'1-c'),
    }
    X=X0.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)));pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8
    V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
    defects={}
    for z in vs:
        i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=factorized_positive(1-X0[i,j]**2,chart,eng,sample,'defect '+str(z))
    ext=[]
    for j in range(6):
        inc=[i for i in range(11) if rows[i][j]!=0];found=None
        for rrr in itertools.combinations(inc,4):
            det=sp.factor(sp.cancel(F.extract(rrr,range(4)).det(method='domain-ge')))
            if det==0:continue
            sg=1 if det.subs(sample_cube)>0 else -1
            try:ce=factorized_positive(sg*det,{},eng,sample_cube,f'extremality {j}')
            except AssertionError:continue
            found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
        assert found is not None,j
        ext.append(found)
    code=np.array(rows,int);facP=[]
    for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
    facQ=[]
    for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
    vn=np.array(V.subs(sample_cube),float);fn=np.array(F.subs(sample_cube),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
    tetP=list(PRIMAL_TETRAHEDRA);pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
    for tet in tetP:assert sum(set(tet)<=set(f) for f in facP)==1
    tetQ,ridQ=gbase.global_boundary_triangulation(facQ,ptsQ);qb=base.check_closed_sphere(tetQ);qfc=base.check_facet_balls(tetQ,facQ)
    def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
    def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
    def oriented(tets,point,label):
        terms=[];recs=[]
        for k,ids in enumerate(tets):
            det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0,(label,k,ids)
            sg=1 if det.subs(sample_cube)>0 else -1;ce=factorized_positive(sg*det,{},eng,sample_cube,f'{label} tet {k}')
            terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(det),'sign':sg,'certificate':ce})
        return terms,recs
    pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
    volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=eng.positive_rational(margin,'Mahler margin')
    cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2255','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,
      'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relation':'x2_0=x3_0 because (x2_0-x3_0)(x7_5+1)=0 and x7_5>-1','relation_ratio':ratio,'constant_elimination_steps':trace,'groebner_length':len(G.polys),'completion':{str(k):str(v) for k,v in sol.items()}},
      'parameter_domain':{'original':'-1<b,c<1, b+c<0, (b+c+2)/(b+c-2)<a<(c+1)/(c-3)','unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse':{k:str(v) for k,v in inverse.items()}},
      'coefficient_certificates':coeff,'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,
      'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'polar_boundary':qb,
      'primal_triangulation_source':{'source_local_id':1582,'source_sphere_orbit':7,'matching':[0,3,5,12,15],'signed_coordinate_permutation':{'permutation':[0,1,4,5,2,3],'signs':[-1,-1,-1,-1,-1,1]}},
      'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'polar_ridge_sizes':dict(Counter(map(len,ridQ))),
      'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),
      'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 2255 has Mahler product >32/3 throughout its full strict realization space.'}
    CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
