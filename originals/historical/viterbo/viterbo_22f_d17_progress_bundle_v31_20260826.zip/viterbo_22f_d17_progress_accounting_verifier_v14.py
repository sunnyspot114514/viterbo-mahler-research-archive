#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,sys
from fractions import Fraction
from pathlib import Path
BASE=Path('/mnt/data');OLD=BASE/'viterbo_22f_d17_progress_accounting_certificate_v13.json';CERT=BASE/'viterbo_22f_d17_progress_accounting_certificate_v14.json';OUT=BASE/'viterbo_22f_d17_progress_accounting_verifier_output_v14.json';FID=2255
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sgn(x):q=Fraction(str(x));return 1 if q>0 else -1 if q<0 else 0
def basis(q):
 n=1
 for d in q['degree']:n*=d+1
 assert q['positive']>0 and q['positive']+q['zero']==n and Fraction(q['min_positive'])>0
def margin(mc):
 if 'numerator' in mc:
  basis(mc['numerator']);basis(mc['denominator']);return
 assert mc['factorized'] is True;side={}
 for r in mc['records']:
  z=sgn(r['coefficient']);assert z
  for f in r['factors']:
   basis(f['certificate']['numerator']);basis(f['certificate']['denominator']);z*=f['sign']**f['multiplicity']
  assert z==r['sign'];side[r['side']]=z
 assert side['num']==side['den']
def main():
 old=json.loads(OLD.read_text());c=json.loads(CERT.read_text());assert old['status']==c['status']=='PASS'
 script=BASE/f'viterbo_22f_d17_family{FID}_verifier.py';fc=BASE/f'viterbo_22f_d17_family{FID}_certificate.json';fo=BASE/f'viterbo_22f_d17_family{FID}_verifier_output.json'
 subprocess.run([sys.executable,str(script)],check=True,timeout=600,stdout=subprocess.DEVNULL)
 a=json.loads(fc.read_text());o=json.loads(fo.read_text());assert a['status']==o['status']=='PASS';assert a['canonical_id']==o['canonical_id']==FID
 assert o['rank']==4 and o['strict_defects']==17 and o['primal_vertices']==12 and o['polar_vertices']==22;margin(a['margin_certificate'])
 assert FID in old['remaining_ids'] and FID not in c['remaining_ids'];assert len(c['remaining_ids'])==33 and len(c['Mahler_positive_exact_families'])==23
 assert sum(c['disjoint_classification'].values())==2395
 assert sum(v for k,v in c['survivor_level_accounting'].items() if k!='initial')==121
 out={'status':'PASS','newly_closed':[FID],'Mahler_positive_exact_total':23,'remaining':33,'total_pairing_templates':2395,'certificate':str(CERT),'certificate_sha256':sha(CERT),'family_script_sha256':sha(script),'family_certificate_sha256':sha(fc),'family_output_sha256':sha(fo)}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
