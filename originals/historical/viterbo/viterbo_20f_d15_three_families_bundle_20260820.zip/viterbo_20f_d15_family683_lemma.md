# Family 683: exact closure and Mahler positivity

## Statement

For the canonical `12V/20F, c=0, D=15` sign template indexed by `683`, every strict rank-four realization satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

## Rank-four completion

Take

\[
a=x_{0,0},\qquad b=x_{2,0},\qquad t=x_{1,1}.
\]

The pivot on rows `(0,1,2,4)` and columns `(2,3,4,5)` has determinant `8`. The remaining twelve defects are uniquely rational in \((a,b,t)\). Representative formulas are

\[
x_{0,1}=t,
\qquad
x_{1,0}=\frac{tb-2t-b}{t+1},
\qquad
x_{4,0}=-a+b-1,
\qquad
x_{5,4}=-\frac{3t-1}{t+1}.
\]

## Complete strict domain

All strict inequalities reduce to

\[
0<t<1,
\qquad -1<a<b<1,
\]

and

\[
(t+1)a+(1-t)b+2t<0.
\]

Introduce the positive slacks

\[
x=b-a,
\qquad
y=-\bigl((t+1)a+(1-t)b+2t\bigr).
\]

The bounds \(-1<a<b<1\) are then exactly

\[
0<x<2,
\qquad
0<y<(1-t)(2-x).
\]

Set

\[
t=T,
\qquad x=2B,
\qquad y=2(1-T)(1-B)A,
\qquad0<A,B,T<1.
\]

Equivalently,

\[
a=-T-(1-T)\bigl(B+(1-B)A\bigr),
\]

\[
b=(1+T)B-(1-T)(1-B)A-T.
\]

This is a rational bijection from the open unit cube onto the full strict realization space.

## Closure and topology

The exact verifier proves:

- rank `4` on the entire domain;
- all fifteen defects remain in `(-1,1)`;
- all twelve primal vertices remain extreme;
- the section has exactly twenty vertices;
- fixed triangulations use `35` primal and `68` polar tetrahedra;
- every orientation determinant has a global Bernstein sign certificate;
- the primal boundary and every primal/polar facet triangulation have the required sphere/ball topology.

## Mahler margin

The primal volume is

\[
|P|=-\frac{
ABT^3-4ABT^2+3ABT-AT^3+4AT^2-3AT-BT^3+BT+T^3-3T^2-13T-9
}{12(T+1)}.
\]

The polar volume is the exact rational expression stored in the output certificate. The margin has Bernstein data

\[
\begin{array}{c|c|c|c|c}
 &\text{degree}&>0&=0&\min_+\\
\hline
\text{numerator}&(4,3,12)&212&48&1/12\\
\text{denominator}&(3,2,10)&109&23&3/5
\end{array}
\]

and no negative coefficients. Thus the Mahler product is strictly above `32/3` on the full family.
