# Family 747: two-chart closure and Mahler positivity

## Statement

For the canonical `12V/20F, c=0, D=15` sign template indexed by `747`, every strict rank-four realization satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

The primal oriented matroid is constant, while the polar triangulation undergoes a finite flip across the internal wall `t=0`. The proof therefore uses two rational cube charts plus an exact wall certificate.

## Rank-four completion

Use

\[
a=x_{0,0},\qquad t=x_{0,1},\qquad s=x_{9,5}.
\]

The pivot on rows `(0,1,2,3)` and columns `(2,3,4,5)` has determinant `-8`. The Schur equations uniquely determine all other defects. For example,

\[
x_{1,0}=\frac{as+a+2s}{s-1},
\qquad
x_{2,0}=x_{3,0}=\frac{2a+s+1}{s-1},
\]

\[
x_{7,1}=x_{8,1}=-t,
\qquad
x_{9,1}=\frac{ts-3t+s-1}{2}.
\]

## Complete strict domain

The fifteen strict inequalities are equivalent to

\[
-1<a,t,s<1,
\qquad a+s<0,
\]

\[
H:=ts-3t+s+1>0,
\]

\[
G:=ats+5at-as-a+5ts+t-s-1<0.
\]

### Positive chart: `t>0`

Set

\[
s=2S-1,
\qquad
t=\frac{ST}{2-S},
\qquad
a=-1+2(1-S)A,
\]

with

\[
0<A,S,T<1.
\]

Here `H>0` is exactly `T<1`; on the interval \(-1<a<-s\), the affine function `G` is negative at both endpoints, so `G<0` is automatic.

### Negative chart: `t<0`

Set

\[
s=2S-1,
\qquad t=-T,
\]

and define the unique root of `G=0`

\[
a_0=-\frac{5ST+S-2T}{ST+S+2T}.
\]

The upper endpoint is `-s`, with width

\[
-s-a_0=
\frac{2S(1-S)(1+T)}{ST+S+2T}.
\]

Thus

\[
a=a_0+
A\frac{2S(1-S)(1+T)}{ST+S+2T},
\qquad0<A,S,T<1.
\]

Both charts extend to the same `t=0` wall:

\[
s=2S-1,
\qquad a=-1+2(1-S)A.
\]

## Exact closure

On each chart the verifier independently proves:

- rank exactly `4`;
- all fifteen defects strict;
- all twelve primal vertices extreme;
- exactly twenty polar vertices;
- `35` primal and `68` polar tetrahedra in globally valid chart-wise triangulations;
- all simplex orientations have fixed signs in the corresponding cube;
- the primal boundary and all facet triangulations have the required topology.

The two polar triangulations differ by a finite bistellar flip across `t=0`, but each gives an exact volume formula on its chart.

## Margin certificates

Positive chart:

\[
\begin{array}{c|c|c|c|c}
 &\text{degree}&>0&=0&\min_+\\
\hline
\text{numerator}&(4,9,4)&213&37&7/9\\
\text{denominator}&(3,6,3)&90&22&12/5
\end{array}
\]

Negative chart:

\[
\begin{array}{c|c|c|c|c}
 &\text{degree}&>0&=0&\min_+\\
\hline
\text{numerator}&(4,7,6)&243&37&1/42\\
\text{denominator}&(3,4,5)&98&22&1/2
\end{array}
\]

On the shared wall `t=0`, the margin is

\[
-\frac{
A^4S^5+5A^3S^4-12A^3S^3+22A^3S^2-11A^3S
+7A^2S^3-26A^2S^2+24A^2S-A^2
+3AS^2-13AS+2A-1
}{3(AS-A+1)^2}.
\]

The signed numerator has degree `(4,5)` with

\[
26>0,
\qquad4=0,
\qquad\min_+=1/10,
\]

and the denominator has degree `(2,2)` with

\[
6>0,
\qquad3=0,
\qquad\min_+=3/2.
\]

Therefore the margin is strictly positive on both open charts and on their common wall.
