#!/usr/bin/env python3
import sympy as sp,itertools,math,time,json
import numpy as np
from scipy.spatial import ConvexHull
from collections import Counter,defaultdict,deque
from pathlib import Path
A,B,R=sp.symbols('A B R', real=True);VARS=(A,B,R)
t=-R
b=-R+(1+R)*B
a=R-(1+R)*B+2*A*B
# family 675 exact rank-4 completion, free a=x1_0,b=x2_0,t=x1_1
x00=sp.factor(-(t*b-2*t+b)/(t-1))
x01=t
x10=a;x11=t;x20=b
x30=sp.factor((a*t-a+2*t*b-2*t)/(t-1))
x40=sp.factor(-(2*a*t**2-2*a*t+2*t**2*b-3*t**2+2*t*b-2*t+1)/(t-1)**2)
x45=sp.factor(-(3*t+1)/(t-1))
x50=sp.factor(a+b-1)
x62=sp.factor(-(3*a*t**2-2*a*t-a+4*t**2*b-7*t**2+4*t*b-2*t+1)/((a-1)*(t-1)**2))
x65=sp.factor(-(a*t**2-2*a*t+a+4*t**2*b-5*t**2+4*t*b-2*t-1)/((a-1)*(t-1)**2))
den7=sp.factor(a*t**2-2*a*t+a+3*t**2*b-2*t**2-2*t+b)
x72=sp.factor(-(3*a*t**2-2*a*t-a+5*t**2*b-2*t**2-2*t-b)/den7)
x73=sp.factor(-(a*t**2-2*a*t+a-t**2*b+2*t**2-4*t*b+2*t+b)/den7)
x84=x45;x91=t
vals={'x0_0':x00,'x0_1':x01,'x1_0':x10,'x1_1':x11,'x2_0':x20,'x3_0':x30,'x4_0':x40,'x4_5':x45,'x5_0':x50,'x6_2':x62,'x6_5':x65,'x7_2':x72,'x7_3':x73,'x8_4':x84,'x9_1':x91}
key='112000112022120000120022120201122002201021201120202010210020'
M=[];templ=[]
for i in range(10):
 row=[];tr=[]
 for j,ch in enumerate(key[6*i:6*i+6]):
  z=int(ch)-1;tr.append(z);row.append(vals[f'x{i}_{j}'] if z==0 else sp.Integer(z))
 M.append(row);templ.append(tr)
M=sp.Matrix(M);rs=(0,1,2,5);cs=(2,3,4,5);P=M.extract(rs,cs);assert P.det()==8
ri=[i for i in range(10) if i not in rs];cj=[0,1];assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs);assert all(sp.factor(x)==0 for x in FM*VM-M)
SAMPLE={A:sp.Rational(1,2),B:sp.Rational(1,2),R:sp.Rational(1,2)}

def bern(poly):
 p=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,p.degree_list()));co=dict(p.terms());out=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  out.append(sp.factor(z))
 return deg,out
cache={}
def pospoly(p,label=''):
 p=sp.factor(p);k=sp.srepr(p)
 if k not in cache:cache[k]=bern(p)
 deg,arr=cache[k];neg=[x for x in arr if x<0];pos=[x for x in arr if x>0]
 if neg or not pos:
  print('FAIL',label,'degree',deg,'pos',len(pos),'zero',sum(x==0 for x in arr),'neg',len(neg),'poly',p,flush=True);return None
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in arr),'min_positive':str(min(pos))}
def posrat(e,label=''):
 e=sp.cancel(e);sv=sp.N(e.subs(SAMPLE));assert sv>0,(label,sv,e)
 n,d=map(sp.factor,sp.together(e).as_numer_denom())
 if d.subs(SAMPLE)<0:n,d=-n,-d
 sn=pospoly(n,label+' num');sd=pospoly(d,label+' den')
 return (sn,sd) if sn and sd else None
# parameter-domain identities and all defects
assert sp.factor(b+R-(1+R)*B)==0
U1=sp.factor(((1-R)*b+2*R)/(1+R))
assert sp.factor(U1-(R+(1-R)*B))==0
assert sp.factor(a+b-2*A*B)==0
assert sp.factor(U1-a-2*B*(1-A))==0
defect_stats={nm:posrat(1-expr*expr,'defect '+nm) for nm,expr in vals.items()}
print('strict defects PASS',len(defect_stats),'cache',len(cache),flush=True)
# extremality
ext=[]
for j in range(6):
 inc=[i for i in range(10) if templ[i][j]!=0];found=None
 for rr in itertools.combinations(inc,4):
  de=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
  if de==0:continue
  sg=1 if de.subs(SAMPLE)>0 else -1
  if posrat(sg*de,f'ext{j}{rr}'):
   found=(j,rr,str(de));break
 assert found,j;ext.append(found)
print('extremality',[(j,r) for j,r,d in ext],'cache',len(cache),flush=True)
# sample hull and triangulations
Vnum=np.array(VM.subs(SAMPLE),float);Fnum=np.array(FM.subs(SAMPLE),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum])
assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
Acode=np.array(templ,int)
def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,eq in zip(h.simplices,h.equations):
  if abs(float(eq[:-1]@pr[0]+eq[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
facP=[]
for i in range(10):facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[tt for f in facP for tt in pull(f,ptsP)];tQ=[tt for f in facQ for tt in pull(f,ptsQ)]
print('facets',Counter(map(len,facP)),Counter(map(len,facQ)),'tets',len(tP),len(tQ),flush=True)
def check_closed_sphere(tets,nverts):
 tets=[tuple(sorted(t)) for t in tets];assert len(set(tets))==len(tets)
 tris=Counter(tuple(sorted(q)) for tt in tets for q in itertools.combinations(tt,3));assert set(tris.values())=={2}
 by=defaultdict(list)
 for k,tt in enumerate(tets):
  for q in itertools.combinations(tt,3):by[tuple(sorted(q))].append(k)
 adj=[set() for _ in tets]
 for ids in by.values():assert len(ids)==2;adj[ids[0]].add(ids[1]);adj[ids[1]].add(ids[0])
 seen={0};dq=deque([0])
 while dq:
  k=dq.popleft()
  for ell in adj[k]:
   if ell not in seen:seen.add(ell);dq.append(ell)
 assert len(seen)==len(tets);return {'tetrahedra':len(tets),'triangles':len(tris),'vertices':nverts}
def check_facet_balls(tets,facets):
 counts=[]
 for f in facets:
  group=[tuple(tt) for tt in tets if set(tt)<=set(f)];assert group and set(x for tt in group for x in tt)==set(f)
  tri=Counter(tuple(sorted(q)) for tt in group for q in itertools.combinations(tt,3));assert max(tri.values())<=2
  btri=[q for q,n in tri.items() if n==1];bvs=set(x for q in btri for x in q);bes=set(tuple(sorted(e)) for q in btri for e in itertools.combinations(q,2));assert len(bvs)-len(bes)+len(btri)==2
  counts.append(len(group))
 return {'facets':len(facets),'tetrahedra':len(tets),'per_facet':counts}
sphP=check_closed_sphere(tP,12);ballsP=check_facet_balls(tP,facP);ballsQ=check_facet_balls(tQ,facQ)
def pp(i):return VM[:,i] if i<6 else -VM[:,i-6]
def qq(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
def orient(tets,fn,name):
 out=[]
 for z,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[fn(i) for i in ids]).det(method='domain-ge')))
  if de==0:raise RuntimeError(('zero det',name,z,ids))
  sg=1 if de.subs(SAMPLE)>0 else -1
  if not posrat(sg*de,f'{name}{z}'):
   print('ORIENTATION WALL',name,z,ids,de,flush=True);return None
  out.append(sp.factor(sg*de))
 return out
pt=orient(tP,pp,'P');qt=orient(tQ,qq,'Q') if pt is not None else None
print('orientation',pt is not None,qt is not None,'cache',len(cache),flush=True)
if pt is None or qt is None:raise SystemExit(2)
volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)))
print('volP',volP,flush=True);print('volQ',volQ,flush=True);print('margin sample',sp.N(margin.subs(SAMPLE)),flush=True)
st=posrat(margin,'margin');print('margin stats',st,flush=True)
out={'status':'PASS','scope':'12V/20F,c=0,D=15','index':675,'domain':'0<A,B,R<1','parameterization':{'x1_1':str(t),'x2_0':str(b),'x1_0':str(a)},'pivot_rows':rs,'pivot_cols':cs,'pivot_det':8,'rank':4,'strict_defects':15,'defect_certificates':defect_stats,'primal_vertices':12,'polar_vertices':20,'extremality':ext,'primal_boundary':sphP,'primal_facet_balls':ballsP,'polar_facet_balls':ballsQ,'tetsP':len(tP),'tetsQ':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'margin':str(margin),'margin_stats':st,'fixed_sign_polynomials':len(cache),'conclusion':'Mahler product > 32/3 on the full strict realization space'}
Path('/mnt/data/viterbo_20f_d15_family675_verifier_output.json').write_text(json.dumps(out,indent=2,default=str));print(json.dumps(out,indent=2,default=str))
