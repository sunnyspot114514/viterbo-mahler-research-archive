# Replay instructions: Families 675, 683, and 747

These files certify three additional algebraic survivors in the bounded-12, `12V/20F, c=0, D=15` classification. All results remain computer-assisted analytic proof candidates pending external review.

## Run the independent verifiers

```bash
python viterbo_20f_d15_family675_verifier.py
python viterbo_20f_d15_family683_verifier.py
python viterbo_20f_d15_family747_chart_verifier.py pos
python viterbo_20f_d15_family747_chart_verifier.py neg
python viterbo_20f_d15_family747_face_verifier.py
python viterbo_20f_d15_three_final_families_output_checker.py
```

Expected result: every verifier reports `PASS`.

## Current exact accounting

```text
748 templates
= 669 rank >= 5
+ 51 duplicate facet-row templates
+ 2 primal-vertex-loss families
+ 23 Mahler-positive families
+ 3 remaining families (396, 509, 728).
```
