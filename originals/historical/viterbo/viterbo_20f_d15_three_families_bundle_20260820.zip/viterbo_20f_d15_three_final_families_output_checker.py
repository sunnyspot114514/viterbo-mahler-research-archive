#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
base=Path('/mnt/data')
checks={
 '675':('viterbo_20f_d15_family675_verifier_output.json',([2,3,8],64,44,'1/4')),
 '683':('viterbo_20f_d15_family683_verifier_output.json',([4,3,12],212,48,'1/12')),
 '747_pos':('viterbo_20f_d15_family747_pos_verifier_output.json',([4,9,4],213,37,'7/9')),
 '747_neg':('viterbo_20f_d15_family747_neg_verifier_output.json',([4,7,6],243,37,'1/42')),
}
out={'status':'PASS','checks':{},'hashes':{}}
for name,(fn,expect) in checks.items():
 o=json.loads((base/fn).read_text()); assert o['status']=='PASS'
 st=o['margin_stats'][0]; assert (st['degree'],st['positive'],st['zero'],st['min_positive'])==expect
 assert o['primal_vertices']==12 and o['polar_vertices']==20 and o['rank']==4 and o['strict_defects']==15
 out['checks'][name]={'status':'PASS','margin_numerator':st,'tetsP':o['tetsP'],'tetsQ':o['tetsQ']}
face=json.loads((base/'viterbo_20f_d15_family747_face_verifier_output.json').read_text());assert face['status']=='PASS';assert face['numerator']['negative']==0 and face['denominator']['negative']==0
out['checks']['747_face']=face
files=[
'viterbo_20f_d15_family675_verifier.py','viterbo_20f_d15_family675_verifier_output.json','viterbo_20f_d15_family675_lemma.md',
'viterbo_20f_d15_family683_verifier.py','viterbo_20f_d15_family683_verifier_output.json','viterbo_20f_d15_family683_lemma.md',
'viterbo_20f_d15_family747_chart_verifier.py','viterbo_20f_d15_family747_pos_verifier_output.json','viterbo_20f_d15_family747_neg_verifier_output.json','viterbo_20f_d15_family747_face_verifier.py','viterbo_20f_d15_family747_face_verifier_output.json','viterbo_20f_d15_family747_lemma.md']
for fn in files:
 p=base/fn;assert p.exists();out['hashes'][fn]=hashlib.sha256(p.read_bytes()).hexdigest()
(base/'viterbo_20f_d15_three_final_families_output_checker_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
