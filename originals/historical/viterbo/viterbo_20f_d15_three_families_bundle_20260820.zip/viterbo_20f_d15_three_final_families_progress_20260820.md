# 4D symmetric Mahler, bounded-12: `20F, D=15` progress

Date: 20 August 2026

## Milestone

Three further canonical rank-four families have been fully closed:

\[
\boxed{675,\ 683,\ 747\quad\checkmark}.
\]

The `D=15` accounting is now

\[
\boxed{
748
=669\text{ rank-}\ge5
+51\text{ repeated-row}
+2\text{ vertex-loss}
+23\text{ Mahler-positive}
+3\text{ remaining}.
}
\]

The only remaining canonical survivors are

\[
\boxed{396,\ 509,\ 728}.
\]

Every checkmark denotes a computer-assisted analytic proof candidate, not an externally reviewed theorem.

## Family 675

With free defects

\[
a=x_{1,0},\quad b=x_{2,0},\quad t=x_{1,1},
\]

the constant pivot determinant is `8`, and the rank-four Schur system has a unique rational completion. The full strict domain is

\[
-1<t<0,\quad -1<a,b<1,\quad a+b>0,
\]

\[
(t-1)a+(t+1)b-2t>0.
\]

It is rationally equivalent to the open unit cube:

\[
t=-R,
\qquad b=-R+(1+R)B,
\qquad a=R-(1+R)B+2AB,
\]

\[
0<A,B,R<1.
\]

The fixed triangulations contain `36` primal and `69` polar tetrahedra. The Mahler-margin numerator has tensor degree `(2,3,8)` with

\[
64>0,\quad44=0,\quad\min_+=1/4,
\]

and its denominator has degree `(2,2,6)` with

\[
36>0,\quad27=0,\quad\min_+=3/2.
\]

Therefore

\[
|P||P^\circ|>32/3
\]

on the entire family.

## Family 683

Use

\[
a=x_{0,0},\quad b=x_{2,0},\quad t=x_{1,1}.
\]

The pivot determinant is `8`. All strict inequalities reduce to

\[
0<t<1,\qquad -1<a<b<1,
\]

\[
(t+1)a+(1-t)b+2t<0.
\]

Let

\[
x=b-a,\qquad y=-((t+1)a+(1-t)b+2t).
\]

Then the domain is exactly

\[
0<x<2,
\qquad0<y<(1-t)(2-x).
\]

The rational unit-cube map is

\[
t=T,
\quad x=2B,
\quad y=2(1-T)(1-B)A.
\]

The exact verifier certifies `12` primal vertices, `20` polar vertices, and fixed triangulations with `35` and `68` tetrahedra. The margin numerator has degree `(4,3,12)` with

\[
212>0,\quad48=0,\quad\min_+=1/12,
\]

while the denominator has degree `(3,2,10)` with

\[
109>0,\quad23=0,\quad\min_+=3/5.
\]

## Family 747

The free defects are

\[
a=x_{0,0},\quad t=x_{0,1},\quad s=x_{9,5}.
\]

The pivot determinant is `-8`. The strict domain is

\[
-1<a,t,s<1,
\qquad a+s<0,
\]

\[
ts-3t+s+1>0,
\]

\[
ats+5at-as-a+5ts+t-s-1<0.
\]

The polar triangulation flips across the internal wall `t=0`, so the domain is covered by two rational cube charts.

### Positive chart

\[
s=2S-1,
\quad t=\frac{ST}{2-S},
\quad a=-1+2(1-S)A.
\]

The margin numerator has degree `(4,9,4)` with `213` positive and `37` zero coefficients; the smallest positive coefficient is `7/9`.

### Negative chart

\[
s=2S-1,
\quad t=-T,
\]

\[
a_0=-\frac{5ST+S-2T}{ST+S+2T},
\]

\[
a=a_0+A\frac{2S(1-S)(1+T)}{ST+S+2T}.
\]

The margin numerator has degree `(4,7,6)` with `243` positive and `37` zero coefficients; the smallest positive coefficient is `1/42`.

### Shared wall

At `t=0`, both charts give the same parameterization. A separate two-variable Bernstein certificate has numerator degree `(4,5)` with

\[
26>0,\quad4=0,\quad\min_+=1/10.
\]

Thus the whole family, including the flip wall, has Mahler product strictly above `32/3`.

## Next front

The remaining three families have a different algebraic character:

- `396` and `728` have generic Schur-Jacobian rank `11`, suggesting four-dimensional realization spaces in the current coordinates;
- `509` has a more difficult elimination ideal and is the main symbolic bottleneck.

The next stage is a component decomposition for `396` and `728`, followed by a block-elimination attack on `509`.
