# Family 675: exact closure and Mahler positivity

## Statement

For the canonical `12V/20F, c=0, D=15` sign template indexed by `675`, every strict rank-four realization has

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

Hence this branch is excluded as a Mahler minimizer. The result is a computer-assisted analytic proof candidate.

## Rank-four completion

Use

\[
a=x_{1,0},\qquad b=x_{2,0},\qquad t=x_{1,1}.
\]

The constant pivot on rows `(0,1,2,5)` and columns `(2,3,4,5)` has determinant `8`. The twelve Schur-complement equations have a unique rational solution for the other twelve defects. In particular

\[
x_{0,1}=x_{9,1}=t,
\qquad
x_{4,5}=x_{8,4}=-\frac{3t+1}{t-1},
\qquad
x_{5,0}=a+b-1,
\]

with the remaining entries given in the verifier.

## Complete strict domain

The fifteen inequalities \(|x_{ij}|<1\) reduce to

\[
-1<t<0,
\qquad -1<a,b<1,
\qquad a+b>0,
\]

and

\[
(t-1)a+(t+1)b-2t>0.
\]

Put `R=-t`. Non-emptiness forces `b>-R`, and the last inequality is

\[
a<\frac{(1-R)b+2R}{1+R}.
\]

The full domain is rationally and bijectively parameterized by the open unit cube:

\[
0<A,B,R<1,
\]

\[
t=-R,
\qquad
b=-R+(1+R)B,
\qquad
a=R-(1+R)B+2AB.
\]

Indeed, the lower endpoint is \(-b\), the upper endpoint is \(R+(1-R)B\), and their difference is exactly `2B`.

## Combinatorial closure

The verifier certifies:

- rank exactly `4`;
- all fifteen defects strict throughout the cube;
- all six positive primal columns extreme, hence `12` primal vertices;
- the prescribed primal boundary is a closed simplicial 3-sphere after triangulation;
- all twenty primal facets and all twelve polar facets are triangulated by balls;
- fixed global triangulations use `36` primal and `69` polar tetrahedra;
- every nonzero orientation determinant has a fixed sign on the full cube.

Thus the section has exactly the prescribed twenty polar vertices, with no hidden chamber switch.

## Volumes and margin

The primal volume simplifies to

\[
|P|=\frac{BR^2-BR-R^2+4R+9}{12}.
\]

The polar volume is the exact rational expression recorded in the verifier output. After forming

\[
|P||P^\circ|-\frac{32}{3},
\]

the signed numerator and denominator have tensor Bernstein certificates:

\[
\begin{array}{c|c|c|c|c}
 &\text{degree}&>0&=0&\min_+\\
\hline
\text{numerator}&(2,3,8)&64&44&1/4\\
\text{denominator}&(2,2,6)&36&27&3/2
\end{array}
\]

There are no negative coefficients. Hence the margin is strictly positive on the open cube.
