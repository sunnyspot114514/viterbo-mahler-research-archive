#!/usr/bin/env python3
import sympy as sp,itertools,math,json,sys,pickle
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
from collections import Counter,defaultdict,deque
chart=sys.argv[1]
A,S,T=sp.symbols('A S T', real=True);VARS=(A,S,T)
s=2*S-1
if chart=='pos':
 t=sp.factor(S*T/(2-S)); a=sp.factor(-1+2*(1-S)*A)
 sample={A:sp.Rational(1,2),S:sp.Rational(1,2),T:sp.Rational(1,2)}
elif chart=='neg':
 t=-T
 den=sp.factor(S*T+S+2*T)
 a0=sp.factor(-(5*S*T+S-2*T)/den)
 width=sp.factor(2*S*(1-S)*(T+1)/den)
 a=sp.factor(a0+width*A)
 sample={A:sp.Rational(1,2),S:sp.Rational(1,2),T:sp.Rational(1,2)}
else: raise SystemExit('chart')
# exact completion
x00=a;x01=t;x95=s
x10=sp.factor((a*s+a+2*s)/(s-1));x20=sp.factor((2*a+s+1)/(s-1));x30=x20
D=sp.factor(a*t*s+3*a*t-a*s+a+3*t*s+t+s-1)
x42=sp.factor((a*t*s-a*t-a*s-3*a-t*s+t-3*s-1)/D)
x43=sp.factor(-(a*t*s+7*a*t-a*s-3*a+7*t*s+t-3*s-1)/D);x52=x42;x54=x43
D6=sp.factor(2*a*t+t*s+t+s-1)
x62=sp.factor(-(a*t*s-a*t+a*s+a+2*t*s-2*t+2*s)/D6)
x65=sp.factor((a*t*s+3*a*t-a*s-a+4*t*s-2*s)/D6)
x71=-t;x81=-t;x91=sp.factor((t*s-3*t+s-1)/2)
vals={'x0_0':x00,'x0_1':x01,'x1_0':x10,'x2_0':x20,'x3_0':x30,'x4_2':x42,'x4_3':x43,'x5_2':x52,'x5_4':x54,'x6_2':x62,'x6_5':x65,'x7_1':x71,'x8_1':x81,'x9_1':x91,'x9_5':x95}
key='112000120000120022120202201120201210201221210020210200210221'
M=[];templ=[]
for i in range(10):
 row=[];tr=[]
 for j,ch in enumerate(key[6*i:6*i+6]):
  z=int(ch)-1;tr.append(z);row.append(vals[f'x{i}_{j}'] if z==0 else sp.Integer(z))
 M.append(row);templ.append(tr)
M=sp.Matrix(M);rs=(0,1,2,3);cs=(2,3,4,5);P=M.extract(rs,cs);assert P.det()==-8
ri=[i for i in range(10) if i not in rs];assert all(sp.factor(z)==0 for z in M.extract(ri,[0,1])-M.extract(ri,cs)*P.inv()*M.extract(rs,[0,1]))
VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs);assert all(sp.factor(z)==0 for z in FM*VM-M)

def bern(poly):
 p=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,p.degree_list()));co=dict(p.terms());out=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  out.append(sp.factor(z))
 return deg,out
cache={}
def pospoly(p,label=''):
 p=sp.factor(p);k=sp.srepr(p)
 if k not in cache:cache[k]=bern(p)
 deg,arr=cache[k];neg=[x for x in arr if x.is_negative];pos=[x for x in arr if x.is_positive]
 if neg or not pos:
  print('FAIL',chart,label,'degree',deg,'pos',len(pos),'zero',sum(x==0 for x in arr),'neg',len(neg),'poly',p,flush=True);return None
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in arr),'min_positive':str(min(pos)),'coefficients':arr}
def posrat(e,label=''):
 e=sp.cancel(e);sv=sp.N(e.subs(sample));assert sv>0,(chart,label,sv,e)
 n,d=map(sp.factor,sp.together(e).as_numer_denom())
 if d.subs(sample)<0:n,d=-n,-d
 sn=pospoly(n,label+' num');sd=pospoly(d,label+' den');return (sn,sd) if sn and sd else None
# domain slacks
H=sp.factor(t*s-3*t+s+1);G=sp.factor(a*t*s+5*a*t-a*s-a+5*t*s+t-s-1)
print('chart',chart,'H',H,'G',G,'a+s',sp.factor(a+s),flush=True)
defect_stats={nm:posrat(1-e*e,'defect '+nm) for nm,e in vals.items()}
print('defects',len(defect_stats),'cache',len(cache),flush=True)
# extremality
ext=[]
for j in range(6):
 inc=[i for i in range(10) if templ[i][j]!=0];found=None
 for rr in itertools.combinations(inc,4):
  de=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
  if de==0:continue
  sg=1 if de.subs(sample)>0 else -1
  if posrat(sg*de,f'ext{j}{rr}'):
   found=(j,rr,str(de));break
 assert found,j;ext.append(found)
# hull and triangulations
Vnum=np.array(VM.subs(sample),float);Fnum=np.array(FM.subs(sample),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
Acode=np.array(templ,int)
def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,eq in zip(h.simplices,h.equations):
  if abs(float(eq[:-1]@pr[0]+eq[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
facP=[]
for i in range(10):facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[tt for f in facP for tt in pull(f,ptsP)];tQ=[tt for f in facQ for tt in pull(f,ptsQ)]
print('tets',len(tP),len(tQ),flush=True)
def check_closed_sphere(tets,nverts):
 tets=[tuple(sorted(t)) for t in tets];assert len(set(tets))==len(tets);tris=Counter(tuple(sorted(q)) for tt in tets for q in itertools.combinations(tt,3));assert set(tris.values())=={2};return {'tetrahedra':len(tets),'triangles':len(tris),'vertices':nverts}
def check_facet_balls(tets,facets):
 counts=[]
 for f in facets:
  group=[tuple(tt) for tt in tets if set(tt)<=set(f)];assert group and set(x for tt in group for x in tt)==set(f)
  tri=Counter(tuple(sorted(q)) for tt in group for q in itertools.combinations(tt,3));assert max(tri.values())<=2
  btri=[q for q,n in tri.items() if n==1];bvs=set(x for q in btri for x in q);bes=set(tuple(sorted(e)) for q in btri for e in itertools.combinations(q,2));assert len(bvs)-len(bes)+len(btri)==2;counts.append(len(group))
 return {'facets':len(facets),'tetrahedra':len(tets),'per_facet':counts}
sphP=check_closed_sphere(tP,12);ballsP=check_facet_balls(tP,facP);ballsQ=check_facet_balls(tQ,facQ)
def pp(i):return VM[:,i] if i<6 else -VM[:,i-6]
def qq(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
def orient(tets,fn,name):
 out=[]
 for z,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[fn(i) for i in ids]).det(method='domain-ge')))
  if de==0:raise RuntimeError(('zero det',name,z,ids))
  sg=1 if de.subs(sample)>0 else -1
  if not posrat(sg*de,f'{name}{z}'):
   print('ORIENTATION WALL',chart,name,z,ids,de,flush=True);return None
  out.append(sp.factor(sg*de))
 return out
pt=orient(tP,pp,'P');qt=orient(tQ,qq,'Q') if pt is not None else None
print('orient',pt is not None,qt is not None,'cache',len(cache),flush=True)
if pt is None or qt is None:raise SystemExit(2)
def combine(lst):
 cnt=Counter(map(sp.cancel,lst));data=[];D0=sp.Integer(1)
 for e,cntv in cnt.items():
  n0,d0=map(sp.factor,sp.fraction(sp.cancel(e)));data.append((cntv,n0,d0));D0=sp.factor(sp.lcm(D0,d0))
 N0=sp.factor(sum(cntv*n0*sp.cancel(D0/d0) for cntv,n0,d0 in data));g0=sp.gcd(N0,D0);return sp.factor((N0/g0)/(24*(D0/g0)))
volP=combine(pt);volQ=combine(qt);margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));st=posrat(margin,'margin')
# face T=0 positive check (margin itself, substitute T=0 and use A,S variables)
face=sp.factor(sp.cancel(margin.subs(T,0)));print('face margin',face,flush=True)
out={'status':'PASS','scope':'12V/20F,c=0,D=15','index':747,'chart':chart,'domain':'0<A,S,T<1','parameterization':{'a':str(a),'t':str(t),'s':str(s)},'pivot_det':-8,'rank':4,'strict_defects':15,'defect_certificates':{k:[{kk:vv for kk,vv in z.items() if kk!='coefficients'} for z in v] for k,v in defect_stats.items()},'primal_vertices':12,'polar_vertices':20,'extremality':ext,'primal_boundary':sphP,'primal_facet_balls':ballsP,'polar_facet_balls':ballsQ,'tetsP':len(tP),'tetsQ':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'margin':str(margin),'margin_stats':[{k:v for k,v in z.items() if k!='coefficients'} for z in st],'face_T0_margin':str(face),'fixed_sign_polynomials':len(cache),'conclusion':'Mahler product > 32/3 on this chart'}
Path(f'/mnt/data/viterbo_20f_d15_family747_{chart}_verifier_output.json').write_text(json.dumps(out,indent=2,default=str));pickle.dump((volP,volQ,margin),open(f'/mnt/data/f747_{chart}_vol.pkl','wb'));print(json.dumps(out,indent=2,default=str))
