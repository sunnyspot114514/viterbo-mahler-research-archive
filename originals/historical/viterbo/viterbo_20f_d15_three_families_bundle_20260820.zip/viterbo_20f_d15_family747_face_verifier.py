#!/usr/bin/env python3
import sympy as sp,itertools,math,json
from pathlib import Path
A,S=sp.symbols('A S')
N=-(A**4*S**5 + 5*A**3*S**4 - 12*A**3*S**3 + 22*A**3*S**2 - 11*A**3*S + 7*A**2*S**3 - 26*A**2*S**2 + 24*A**2*S - A**2 + 3*A*S**2 - 13*A*S + 2*A - 1)
D=3*(A*S-A+1)**2
def bern(p):
 P=sp.Poly(sp.expand(p),A,S,domain='QQ');deg=tuple(map(int,P.degree_list()));co=dict(P.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,c in co.items():
   if all(kk[j]<=ii[j] for j in range(2)):
    z+=c*sp.prod(sp.Rational(math.comb(ii[j],kk[j]),math.comb(deg[j],kk[j])) for j in range(2))
  arr.append(sp.factor(z))
 return deg,arr
out={'status':'PASS','scope':'Family 747, t=0 face'}
for name,p in [('numerator',N),('denominator',D)]:
 deg,arr=bern(p);neg=[x for x in arr if x<0];pos=[x for x in arr if x>0]
 assert not neg and pos
 out[name]={'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in arr),'negative':0,'min_positive':str(min(pos))}
Path('/mnt/data/viterbo_20f_d15_family747_face_verifier_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
