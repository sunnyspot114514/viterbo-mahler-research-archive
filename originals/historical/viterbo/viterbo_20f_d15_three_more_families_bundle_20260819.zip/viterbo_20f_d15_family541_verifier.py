#!/usr/bin/env python3
import sympy as sp,itertools,math,json
import numpy as np
from scipy.spatial import ConvexHull
from collections import Counter
from pathlib import Path
A,T,B=sp.symbols('A T B', real=True);VARS=(A,T,B)
a=2*A-1;t=2*T-1;upper=sp.factor((2*a+t+1)/(t+3));b=sp.factor(a+(upper-a)*B)
m=sp.factor((1-t)/(t+3))
sol={
'x0_0':-( -2*a+b*t+3*b+2)/(t+3),'x0_1':m,
'x1_0':-(a*t+a+2)/(t+3),'x1_1':m,
'x2_0':-(a*t+a+2)/(t+3),'x2_1':m,
'x3_0':a,'x4_0':b,'x5_0':b,'x6_3':t,'x7_4':t,
'x8_2':(a*t-3*a-b*t+b-2)/(a*t+a-b*t+b+2),
'x8_5':-(a*t+a+b*t-b+2*t)/(a*t+a-b*t+b+2),
'x9_1':(a*t-3*a-b*t+5*b-2)/(a*t+a-b*t-3*b+2),
'x9_5':(a*t-3*a+b*t+3*b-2*t)/(a*t+a-b*t-3*b+2)}
key='112000112022112202120000120022120202200120200210201221210221'
M=[];templ=[];defs=[]
for i in range(10):
 row=[];tr=[]
 for j,ch in enumerate(key[6*i:6*i+6]):
  z=int(ch)-1;tr.append(z)
  if z==0:n=f'x{i}_{j}';row.append(sp.factor(sp.cancel(sol[n])));defs.append((i,j,n))
  else:row.append(sp.Integer(z))
 M.append(row);templ.append(tr)
M=sp.Matrix(M);rs=(3,4,5,7);cs=(1,2,3,5);P=M.extract(rs,cs);assert P.det()==8
ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs];assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs);assert all(sp.factor(x)==0 for x in FM*VM-M)
SAMPLE={A:sp.Rational(1,2),T:sp.Rational(1,2),B:sp.Rational(1,2)}
def bern(poly):
 p0=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,p0.degree_list()));co=dict(p0.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr
cache={}
def pospoly(poly,label=''):
 poly=sp.factor(poly);k=sp.srepr(poly)
 if k not in cache:cache[k]=bern(poly)
 deg,arr=cache[k];pos=[x for x in arr if x>0];neg=[x for x in arr if x<0]
 if neg or not pos:print('FAIL',label,poly,deg,neg[:3],flush=True);return None
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in arr),'min_positive':str(min(pos))}
def posrat(e,label=''):
 e=sp.cancel(e);assert e.subs(SAMPLE)>0,(label,e.subs(SAMPLE))
 n,d=map(sp.factor,sp.together(e).as_numer_denom())
 if d.subs(SAMPLE)<0:n,d=-n,-d
 sn=pospoly(n,label+' num');sd=pospoly(d,label+' den');return (sn,sd) if sn and sd else None
for i,j,n in defs:assert posrat(1-M[i,j]**2,n)
print('defects pass',len(cache),flush=True)
ext=[]
for j in range(6):
 inc=[i for i in range(10) if templ[i][j]!=0];found=None
 for rr in itertools.combinations(inc,4):
  de=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
  if de==0:continue
  sg=1 if de.subs(SAMPLE)>0 else -1
  if posrat(sg*de,f'ext{j}{rr}'):found=(j,rr,str(de));break
 assert found,j;ext.append(found)
print('ext',[(j,r) for j,r,d in ext],flush=True)
Vnum=np.array(VM.subs(SAMPLE),float);Fnum=np.array(FM.subs(SAMPLE),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
Acode=np.array(templ,int)
def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
facP=[]
for i in range(10):facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[tt for f in facP for tt in pull(f,ptsP)];tQ=[tt for f in facQ for tt in pull(f,ptsQ)]
print('facets',Counter(map(len,facP)),Counter(map(len,facQ)),'tets',len(tP),len(tQ),flush=True)
def check_sphere(tets):assert set(Counter(tuple(sorted(q)) for tt in tets for q in itertools.combinations(tt,3)).values())=={2}
def check_balls(tets,facets):
 for f in facets:
  g=[tt for tt in tets if set(tt)<=set(f)];assert g and set(x for tt in g for x in tt)==set(f)
  tri=Counter(tuple(sorted(q)) for tt in g for q in itertools.combinations(tt,3));bt=[q for q,n in tri.items() if n==1];bv=set(x for q in bt for x in q);be=set(tuple(sorted(e)) for q in bt for e in itertools.combinations(q,2));assert len(bv)-len(be)+len(bt)==2
check_sphere(tP);check_balls(tP,facP);check_balls(tQ,facQ)
def pp(i):return VM[:,i] if i<6 else -VM[:,i-6]
def qq(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
def orient(tets,fn,name):
 out=[]
 for z,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[fn(i) for i in ids]).det(method='domain-ge')));assert de!=0
  sg=1 if de.subs(SAMPLE)>0 else -1
  if not posrat(sg*de,f'{name}{z}'):print('WALL',name,z,ids,de,flush=True);return None
  out.append(sp.factor(sg*de))
  if z%10==0:print(name,z,'/',len(tets),'cache',len(cache),flush=True)
 return out
pt=orient(tP,pp,'P');qt=orient(tQ,qq,'Q') if pt is not None else None
print('orient',pt is not None,qt is not None,flush=True)
if pt is None or qt is None:raise SystemExit(2)
volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));st=posrat(margin,'margin')
print('volP',volP);print('volQ',volQ);print('margin stats',st,'cache',len(cache),flush=True)
out={'status':'PASS','scope':'12V/20F,c=0,D=15','index':541,'domain':'0<A,T,B<1; a=2A-1, t=2T-1, b=a+2T(1-A)B/(T+1)','domain_equivalence':'-1<a,t<1 and a<b<(2a+t+1)/(t+3)','parameterization':{'a':str(a),'b':str(b),'t':str(t)},'pivot_det':8,'rank':4,'strict_defects':15,'primal_vertices':12,'polar_vertices':20,'extremality':ext,'tetsP':len(tP),'tetsQ':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'margin':str(margin),'margin_stats':st,'fixed_sign_polynomials':len(cache),'conclusion':'Mahler product > 32/3 on full strict realization space'}
Path('/mnt/data/viterbo_20f_d15_family541_verifier_output.json').write_text(json.dumps(out,indent=2,default=str));print(json.dumps(out,indent=2,default=str))
