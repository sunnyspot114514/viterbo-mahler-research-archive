# 4D symmetric Mahler, bounded-12: 20F, D=15 progress

Date: 2026-08-19

This round closes three additional canonical algebraic survivors:

\[
\boxed{244,\quad 514,\quad 541\quad\checkmark}
\]

Every checkmark means **computer-assisted analytic proof candidate**, not an externally reviewed theorem.

## Family 244

Choose free defects \(a=x_{2,0}, b=x_{2,1}, c=x_{3,0}\). The rank-four Schur equations have a unique rational solution for the other twelve defects.

The strict domain is exactly

\[
-1<c<a<-c<1,
\qquad
-1<b<r_H(a,c),
\]

where, with \(u=-c\in(0,1)\) and \(t=a/u\in(-1,1)\),

\[
r_H(u,t)=-\frac{2t^2u^2+2tu-u^2+1}{1+u^2+2tu}.
\]

Indeed

\[
r_H+1=\frac{2u^2(1-t^2)}{1+u^2+2tu}>0,
\qquad
1-r_H=\frac{2(1+tu)^2}{1+u^2+2tu}>0.
\]

The exact cube parameterization is

\[
c=-U,
\qquad
a=U(2T-1),
\qquad
b=-1+(r_H+1)V,
\qquad0<U,T,V<1.
\]

The verifier certifies all fifteen strict defects, rank four, all twelve primal vertices, all twenty polar vertices, a 36-tetrahedron primal boundary, and 67 polar-facet tetrahedra. The Mahler-margin Bernstein statistics are

\[
\deg N=(13,11,3),\quad532>0,\quad140=0,
\quad\min_+=\frac{1024}{16335},
\]

\[
\deg D=(12,9,2),\quad305>0,\quad85=0,
\quad\min_+=\frac{16}{231}.
\]

Hence \(|P||P^\circ|>32/3\) on the full strict domain.

## Family 514

Take

\[
p=x_{0,1},\qquad q=x_{1,1},\qquad a=x_{2,0}.
\]

The unique rank-four completion is rational. The complete strict domain is

\[
\boxed{-1<p<q<1,
\qquad -1<a<\frac{p-1}{p+3}.}
\]

It is mapped bijectively to the open cube by

\[
p=2A-1,
\]

\[
q=p+2(1-A)B,
\]

\[
a=-1+\frac{2AC}{A+1},
\qquad0<A,B,C<1.
\]

The verifier obtains 35 primal and 70 polar-facet tetrahedra. The margin certificate has

\[
\deg N=(4,4,2),\quad67>0,\quad8=0,
\quad\min_+=4,
\]

\[
\deg D=(3,1,1),\quad16>0,\quad0=0,
\quad\min_+=9.
\]

Thus the entire family is strictly Mahler-positive.

## Family 541

Let

\[
a=x_{3,0},\qquad b=x_{4,0}=x_{5,0},
\qquad t=x_{6,3}=x_{7,4}.
\]

The complete strict domain reduces to

\[
\boxed{-1<a,t<1,
\qquad a<b<\frac{2a+t+1}{t+3}.}
\]

The unit-cube parameterization is

\[
a=2A-1,
\qquad t=2T-1,
\]

\[
b=a+\frac{2T(1-A)}{T+1}B,
\qquad0<A,T,B<1.
\]

The fixed boundary certificates use 33 primal and 68 polar-facet tetrahedra. The Mahler-margin Bernstein data are

\[
\deg N=(2,7,3),\quad68>0,\quad28=0,
\quad\min_+=\frac8{21},
\]

\[
\deg D=(1,5,2),\quad24>0,\quad12=0,
\quad\min_+=\frac9{10}.
\]

Therefore \(|P||P^\circ|>32/3\) throughout the full realization space.

## Updated D=15 accounting

The original exact preclassification remains

\[
748=669\text{ rank-}\ge5+51\text{ duplicate rows}+28\text{ algebraic survivors}.
\]

Before this round, two survivors were vertex-loss and seventeen were Mahler-positive. This round adds three Mahler-positive families. The updated classification is

\[
\boxed{
748=669+51+2\text{ vertex-loss}+20\text{ Mahler-positive}+6\text{ remaining}.
}
\]

The remaining canonical survivors are

\[
\boxed{396,\ 509,\ 675,\ 683,\ 728,\ 747.}
\]

Families 396 and 728 appear to have four-dimensional rank-four realization spaces in the current coordinates; 509 has a more difficult elimination pattern; 675, 683, and 747 retain constant nonzero pivots and are the next natural targets.
