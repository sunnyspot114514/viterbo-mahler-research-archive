#!/usr/bin/env python3
import sympy as sp,itertools,math,json
import numpy as np
from scipy.spatial import ConvexHull
from collections import Counter,defaultdict,deque
from pathlib import Path
A,B,C=sp.symbols('A B C', real=True);VARS=(A,B,C)
p=2*A-1;q=sp.factor(p+2*(1-A)*B);a=sp.factor(-1+2*A*C/(A+1))
sol={
'x0_0':(a*p+3*a-p+3)/2,'x0_1':p,
'x1_0':(a*q+a-q+1)/2,'x1_1':q,
'x2_0':a,
'x3_0':(a*p-a*q-q+1)/(p-1),'x3_2':(p-2*q+1)/(p-1),
'x4_0':(a*p-a*q-q+1)/(p-1),'x4_4':-(p-2*q+1)/(p-1),
'x5_0':a,
'x6_3':-(p-q+2)/(p-q-2),
'x7_3':-(p+q)/(p-q-2),
'x8_3':-(p-q+2)/(p-q-2),
'x9_1':-(3*a+1)/(a-1),
'x9_3':-(3*a*p-a*q+4*a-3*p+q+4)/((a-1)*(p-q-2))}
key='112000112002120000121002122012122020200100202102202120212100'
M=[];templ=[];defs=[]
for i in range(10):
 row=[];tr=[]
 for j,ch in enumerate(key[6*i:6*i+6]):
  z=int(ch)-1;tr.append(z)
  if z==0:n=f'x{i}_{j}';row.append(sp.factor(sp.cancel(sol[n])));defs.append((i,j,n))
  else:row.append(sp.Integer(z))
 M.append(row);templ.append(tr)
M=sp.Matrix(M);rs=(2,5,7,8);cs=(1,2,4,5);P=M.extract(rs,cs);assert P.det()==8
ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs];assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs);assert all(sp.factor(x)==0 for x in FM*VM-M)
SAMPLE={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)}

def bern(poly):
 p0=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,p0.degree_list()));co=dict(p0.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr
cache={}
def pospoly(poly,label=''):
 poly=sp.factor(poly);k=sp.srepr(poly)
 if k not in cache:cache[k]=bern(poly)
 deg,arr=cache[k];pos=[x for x in arr if x>0];neg=[x for x in arr if x<0]
 if neg or not pos:print('FAIL',label,poly,deg,neg[:3],flush=True);return None
 return {'degree':list(deg),'positive':len(pos),'zero':sum(x==0 for x in arr),'min_positive':str(min(pos))}
def posrat(e,label=''):
 e=sp.cancel(e);assert e.subs(SAMPLE)>0,(label,e.subs(SAMPLE))
 n,d=map(sp.factor,sp.together(e).as_numer_denom())
 if d.subs(SAMPLE)<0:n,d=-n,-d
 sn=pospoly(n,label+' num');sd=pospoly(d,label+' den');return (sn,sd) if sn and sd else None
for i,j,n in defs:assert posrat(1-M[i,j]**2,n)
print('defects PASS cache',len(cache),flush=True)
ext=[]
for j in range(6):
 inc=[i for i in range(10) if templ[i][j]!=0];found=None
 for rr in itertools.combinations(inc,4):
  de=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
  if de==0:continue
  sg=1 if de.subs(SAMPLE)>0 else -1
  if posrat(sg*de,f'ext{j}{rr}'):found=(j,rr,str(de));break
 assert found,j;ext.append(found)
print('ext PASS',[(j,r) for j,r,d in ext],flush=True)
Vnum=np.array(VM.subs(SAMPLE),float);Fnum=np.array(FM.subs(SAMPLE),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);print('hulls',len(ConvexHull(ptsP).vertices),len(ConvexHull(ptsQ).vertices),flush=True)
Acode=np.array(templ,int)
def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
facP=[]
for i in range(10):facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[tt for f in facP for tt in pull(f,ptsP)];tQ=[tt for f in facQ for tt in pull(f,ptsQ)]
print('facets',Counter(map(len,facP)),Counter(map(len,facQ)),'tets',len(tP),len(tQ),flush=True)
def check_closed_sphere(tets):
 tris=Counter(tuple(sorted(q)) for tt in tets for q in itertools.combinations(tt,3));assert set(tris.values())=={2};return len(tris)
def check_balls(tets,facets):
 for f in facets:
  g=[tt for tt in tets if set(tt)<=set(f)];assert g and set(x for tt in g for x in tt)==set(f)
  tri=Counter(tuple(sorted(q)) for tt in g for q in itertools.combinations(tt,3));btri=[q for q,n in tri.items() if n==1];bvs=set(x for q in btri for x in q);bes=set(tuple(sorted(e)) for q in btri for e in itertools.combinations(q,2));assert len(bvs)-len(bes)+len(btri)==2
check_closed_sphere(tP);check_balls(tP,facP);check_balls(tQ,facQ)
def pp(i):return VM[:,i] if i<6 else -VM[:,i-6]
def qq(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
def orient(tets,fn,name):
 out=[]
 for z,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[fn(i) for i in ids]).det(method='domain-ge')));assert de!=0
  sg=1 if de.subs(SAMPLE)>0 else -1
  if not posrat(sg*de,f'{name}{z}'):
   print('WALL',name,z,ids,de,flush=True);return None
  out.append(sp.factor(sg*de))
  if z%10==0:print(name,z,'/',len(tets),'cache',len(cache),flush=True)
 return out
pt=orient(tP,pp,'P');qt=orient(tQ,qq,'Q') if pt is not None else None
print('orient result',pt is not None,qt is not None,flush=True)
if pt is None or qt is None:raise SystemExit(2)
volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));st=posrat(margin,'margin')
print('volP',volP);print('volQ',volQ);print('margin stats',st,'cache',len(cache),flush=True)
out={'status':'PASS','scope':'12V/20F,c=0,D=15','index':514,'domain':'0<A,B,C<1; p=2A-1, q=p+2(1-A)B, a=-1+2AC/(A+1)','domain_equivalence':'-1<p<q<1 and -1<a<(p-1)/(p+3)','parameterization':{'a':str(a),'p':str(p),'q':str(q)},'pivot_det':8,'rank':4,'strict_defects':15,'primal_vertices':12,'polar_vertices':20,'extremality':ext,'tetsP':len(tP),'tetsQ':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'margin':str(margin),'margin_stats':st,'fixed_sign_polynomials':len(cache),'conclusion':'Mahler product > 32/3 on the full strict realization space'}
Path('/mnt/data/viterbo_20f_d15_family514_verifier_output.json').write_text(json.dumps(out,indent=2,default=str));print(json.dumps(out,indent=2,default=str))
