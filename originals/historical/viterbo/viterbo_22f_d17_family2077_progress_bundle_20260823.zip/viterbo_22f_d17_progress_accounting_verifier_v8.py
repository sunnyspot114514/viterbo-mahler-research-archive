#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/mnt/data')
OLD=ROOT/'viterbo_22f_d17_progress_accounting_certificate_v7.json'
OLDOUT=ROOT/'viterbo_22f_d17_progress_accounting_verifier_output_v7.json'
CERT=ROOT/'viterbo_22f_d17_progress_accounting_certificate_v8.json'
OUT=ROOT/'viterbo_22f_d17_progress_accounting_verifier_output_v8.json'
CID=2077

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 old=json.loads(OLD.read_text());oldout=json.loads(OLDOUT.read_text())
 assert old['status']=='PASS' and oldout['status']=='PASS'
 oldrem=set(old['remaining_ids']);assert CID in oldrem
 script=ROOT/f'viterbo_22f_d17_family{CID}_verifier.py'
 outpath=ROOT/f'viterbo_22f_d17_family{CID}_verifier_output.json'
 cp=subprocess.run([sys.executable,str(script)],capture_output=True,text=True,timeout=240)
 assert cp.returncode==0,(cp.stderr,cp.stdout[-3000:])
 fam=json.loads(outpath.read_text())
 assert fam['status']=='PASS' and fam['canonical_id']==CID
 assert fam['rank']==4 and fam['strict_defects']==17
 assert fam['primal_vertices']==12 and fam['polar_vertices']==22
 assert fam['tetrahedra_primal']==32 and fam['tetrahedra_polar']==81
 assert sha(fam['certificate'])==fam['certificate_sha256']
 rem=sorted(oldrem-{CID});mahler=sorted(set(old['Mahler_positive_exact_families'])|{CID})
 dis={'facet_containment':1230,'rank_ge_5_after_antichain':1070,'segment_loss_after_antichain':22,
      'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':len(mahler),
      'strict_rank4_boundary_or_interval_impossible':13,'remaining_algebraic_survivors':len(rem)}
 assert sum(dis.values())==2395
 surv={'initial':121,'facet_containment':26,'additional_segment_loss':22,
       'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':len(mahler),
       'strict_rank4_boundary_or_interval_impossible':13,'remaining':len(rem)}
 assert sum(v for k,v in surv.items() if k!='initial')==surv['initial']
 rerun={str(CID):{'script_sha256':sha(script),'output_sha256':sha(outpath),
                   'certificate_sha256':fam['certificate_sha256'],'status':'PASS',
                   'tetrahedra_primal':fam['tetrahedra_primal'],'tetrahedra_polar':fam['tetrahedra_polar'],
                   'margin_certificate':fam['margin_certificate']}}
 cert={'status':'PASS','scope':old['scope'],'scope_warning':old['scope_warning'],
       'total_pairing_templates':2395,'disjoint_classification':dis,'survivor_level_accounting':surv,
       'Mahler_positive_exact_families':mahler,
       'strict_rank4_boundary_or_interval_impossible':old['strict_rank4_boundary_or_interval_impossible'],
       'remaining_ids':rem,'newly_closed':{'Mahler_positive_exact':[CID]},'rerun_results':rerun,
       'source_hashes':{str(OLD):sha(OLD),str(OLDOUT):sha(OLDOUT),
         str(ROOT/'viterbo_22f_d17_preclassification_certificate.json'):sha(ROOT/'viterbo_22f_d17_preclassification_certificate.json')}}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 result={'status':'PASS','total_pairing_templates':2395,'initial_algebraic_survivors':121,
         'Mahler_positive_exact_families':mahler,'newly_closed':[CID],
         'remaining_algebraic_survivors':len(rem),'accounting_certificate':str(CERT),
         'accounting_certificate_sha256':sha(CERT),'reruns':rerun}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
