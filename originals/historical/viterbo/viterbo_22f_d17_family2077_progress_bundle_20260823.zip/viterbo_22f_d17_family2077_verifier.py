#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 2077."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import viterbo_22f_d17_family768_verifier as base

PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family2077_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family2077_verifier_output.json')
CID=2077
PRIMAL_TETRAHEDRA=[
(0,1,5,8),(0,1,5,10),(0,1,8,11),(0,1,10,11),
(0,5,7,8),(0,5,7,10),(0,7,8,11),(0,7,10,11),
(1,2,5,6),(1,2,5,9),(1,2,6,11),(1,2,9,11),
(1,4,5,6),(1,4,5,8),(1,4,6,11),(1,4,8,11),
(1,5,9,10),(1,9,10,11),(2,5,6,7),(2,5,7,10),
(2,5,9,10),(2,6,7,11),(2,7,10,11),(2,9,10,11),
(3,4,5,7),(3,4,5,8),(3,4,7,11),(3,4,8,11),
(3,5,7,8),(3,7,8,11),(4,5,6,7),(4,6,7,11)]

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,val in enumerate(row):
   if val==0:
    z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=val
 rr=(4,5,7,8);cc=(0,1,2,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==-8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ)
 eq=[sp.factor(sp.cancel(z)) for z in S]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 assert sorted(map(str,uns))==sorted(['x0_1','x10_2','x1_1','x3_2','x5_4','x6_2','x7_3','x9_4'])
 a,b,c=sp.symbols('a b c',real=True)
 stage0=dict(const);stage0.update({x['x0_1']:a,x['x3_2']:b,x['x5_4']:c})
 reduced=[base.apply_all(e,stage0) for e in rem]
 strict_factor=x['x7_3']-1
 assert sp.factor(reduced[2]/strict_factor).is_rational_function(*vs,a,b,c)
 reduced[2]=sp.factor(reduced[2]/strict_factor)
 unknown=[x['x10_2'],x['x1_1'],x['x6_2'],x['x7_3'],x['x9_4']]
 nums=[sp.together(e).as_numer_denom()[0] for e in reduced]
 K=sp.QQ.frac_field(a,b,c)
 G=sp.groebner(nums,*unknown,order='lex',domain=K)
 assert G.is_zero_dimensional and len(G.polys)==5
 D=sp.factor(b*c-b+c+3)
 D7=sp.factor(a*b*c**2-2*a*b*c+a*b+a*c**2+2*a*c+5*a+b*c**2-2*b*c+b+c**2+2*c-11)
 sol5={
  x['x10_2']:sp.factor(-(b*c-b+c+1)/2),
  x['x1_1']:sp.factor(-(2*a*b-2*a-b*c-b-c-1)/D),
  x['x6_2']:sp.factor((b*c-b+c+1)/2),
  x['x7_3']:sp.factor((a*b*c**2-2*a*b*c+a*b+a*c**2+2*a*c-11*a+b*c**2-2*b*c+b+c**2+2*c+5)/D7),
  x['x9_4']:sp.factor(-(b*c**2+b*c-2*b+c**2+c+2)/D),
 }
 # Verify that the reduced strict ideal is exactly the unique graph above.
 for poly in G.polys:
  assert sp.factor(sp.cancel(poly.as_expr().subs(sol5)))==0
 stage=dict(stage0);stage.update(sol5)
 sol={z:base.apply_all(z,stage) for z in vs}
 X=M.subs(sol).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(sp.cancel(e.subs(sol)))==0 for e in eq)
 assert all(not (z.free_symbols & set(vs)) for z in sol.values())
 return rec,rows,M,vs,X,(a,b,c),rr,cc,sol,trace,G,D,D7

def main():
 rec,rows,M,vs,X,free,rr,cc,sol,trace,G,D,D7=build_branch();a,b,c=free
 A,B,C=sp.symbols('A B C',real=True)
 chart={a:2*A-1,b:2*B-1,c:2*C-1};cv=(A,B,C)
 sample={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)}
 eng=base.SignEngine(cv,sample)
 coefficient_certificates={
  'D':eng.positive_rational(D.subs(chart),'D'),
  '-D7':eng.positive_rational((-D7).subs(chart),'-D7'),
 }
 X=X.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==-8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 F=X.extract(range(11),cc)
 assert all(sp.factor(z)==0 for z in F*V-X)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'))
  defects[str(z)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(z))
 # Exact primal extremality.
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'extremality vertex {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):
  facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),
           sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):
  facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),
           sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),float);fn=np.array(F.subs(sample),float)
 ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn])
 assert len(ConvexHull(ptsP).vertices)==12
 assert len(ConvexHull(ptsQ).vertices)==22
 tetP=list(PRIMAL_TETRAHEDRA);assert len(tetP)==len(set(tetP))==32
 pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([k for k,f in enumerate(facP) if set(tet)<=set(f)])==1,(tet,facP)
 tetQ=[z for f in facQ for z in base.pulling_triangulation(f,ptsQ)]
 assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')))
   assert det!=0,(label,k,ids)
   sg=1 if det.subs(sample)>0 else -1
   ce=eng.positive_rational(sg*det,f'{label} tetrahedron {k}')
   terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
 volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24))
 margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)))
 mc=eng.positive_rational(margin,'Mahler margin')
 cert={
  'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2077',
  'canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,
  'rank_branch':{
   'constant_elimination_steps':trace,
   'strict_branch_condition':'x7_3 != 1, so the factor (x7_3-1) is removed',
   'groebner_basis_length':len(G.polys),'groebner_zero_dimensional':bool(G.is_zero_dimensional),
   'groebner_basis':[str(sp.factor(p.as_expr())) for p in G.polys],
  },
  'coefficient_certificates':coefficient_certificates,
  'parameters':['A','B','C'],'parameter_domain':'0<A,B,C<1; equivalently -1<a,b,c<1',
  'completion':{str(k):str(v) for k,v in sol.items()},
  'strict_defects':len(defects),'defect_certificates':defects,
  'primal_vertices':12,'polar_vertices':22,'extremality':ext,
  'facet_size_counts_primal':dict(Counter(map(len,facP))),
  'facet_size_counts_polar':dict(Counter(map(len,facQ))),
  'primal_boundary':pb,
  'primal_triangulation_source':{'source_local_id':2064,'source_sphere_orbit':8,'matching':[0,4,6,12,16],
    'signed_coordinate_permutation':{'permutation':[2,4,1,0,3,5],'signs':[1,1,1,1,1,1]}},
  'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,
  'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),
  'orientation_records_primal':pr,'orientation_records_polar':qr,
  'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),
  'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),
  'source_hashes':{str(PRE):sha256(PRE)},
  'conclusion':'Family 2077 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,
      'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),
      'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),
      'conclusion':cert['conclusion']}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
