# 4D symmetric Mahler bounded-12 progress: D=17, 46 → 45

Date: 2026-08-23

## New closure

Canonical Family 2077 has been fully closed as a computer-assisted analytic proof candidate.

Its strict rank-four realization space is exactly

\[
(a,b,c)\in(-1,1)^3.
\]

The determinantal ideal becomes zero-dimensional over \(\mathbb Q(a,b,c)\) after removing the prohibited boundary factor \(x_{7,3}-1\). A five-element Gröbner basis gives the unique strict rational completion. All 17 defect inequalities hold over the full cube by exact Bernstein certificates.

The exact geometry remains

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

The primal boundary is transported from the original enumerated simplicial sphere and has 32 tetrahedra; the polar facet decomposition has 81 tetrahedra. Every selected orientation determinant has a full-domain sign certificate.

For the exact Mahler margin,

\[
|P|\,|P^\circ|-\frac{32}{3}=\frac{N}{Q},
\]

where the numerator has tensor-Bernstein degree \((2,5,7)\), with

\[
84>0,\qquad60=0,
\]

and minimum positive coefficient \(8/105\). The denominator has degree \((1,4,5)\), with

\[
39>0,\qquad21=0,
\]

and minimum positive coefficient \(27/40\).

Thus Family 2077 satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}
\]

throughout its complete strict realization space.

## Updated D=17 accounting

The complete non-overlapping accounting is now

\[
\begin{aligned}
2395={}&1230\text{ facet-containment templates}\\
&+1070\text{ antichain rank-}\ge5\text{ templates}\\
&+22\text{ segment vertex-loss templates}\\
&+4\text{ duplicate/antipodal primal-pair templates}\\
&+11\text{ exact Mahler-positive families}\\
&+13\text{ strict boundary/interval-impossible families}\\
&+45\text{ remaining algebraic survivors}.
\end{aligned}
\]

At the initial survivor level:

\[
121=26+22+4+11+13+45.
\]

The new accounting verifier reruns the Family 2077 verifier, checks its certificate hash, updates the disjoint classes, and returns `PASS`.

## Scope

This remains part of the bounded-12 finite core for the four-dimensional centrally symmetric Mahler conjecture. It is not yet a proof for arbitrary four-dimensional centrally symmetric convex bodies, and the computer-assisted proof candidate has not undergone external peer review.
