# Canonical Family 2077: exact closure in the 12V/22F, c=0, D=17 layer

Date: 2026-08-23

## Statement

For canonical pairing template 2077 in the four-dimensional centrally symmetric Mahler bounded-12 program, every strict rank-four realization has

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

The result is a computer-assisted analytic proof candidate. All algebra is exact; the finite certificates are replayable, but the result has not undergone external peer review.

## 1. Pairing template and rank-four branch

The canonical sign template is

\[
\begin{pmatrix}
0&0&1&-1&-1&-1\\
0&0&1&-1&-1&1\\
0&0&1&-1&1&-1\\
0&0&1&-1&1&1\\
0&1&-1&-1&-1&-1\\
1&-1&0&1&-1&1\\
1&-1&0&1&1&-1\\
1&-1&1&0&-1&1\\
1&-1&1&0&1&-1\\
1&0&0&1&-1&-1\\
1&0&1&0&-1&-1
\end{pmatrix}.
\]

Rows \((4,5,7,8)\) and columns \((0,1,2,5)\) form a constant pivot with determinant \(-8\). After constant-coefficient elimination, strictness removes the boundary branch \(x_{7,3}=1\). Set

\[
a=x_{0,1},\qquad b=x_{3,2},\qquad c=x_{5,4}.
\]

The remaining determinantal ideal over \(\mathbb Q(a,b,c)\) has a lexicographic Gröbner basis of length five and is zero-dimensional. It uniquely determines the five remaining independent defect variables. In particular, with

\[
D=bc-b+c+3,
\]

\[
\Delta=abc^2-2abc+ab+ac^2+2ac+5a+bc^2-2bc+b+c^2+2c-11,
\]

one obtains

\[
x_{10,2}=-\frac{bc-b+c+1}{2},
\qquad
x_{6,2}=\frac{bc-b+c+1}{2},
\]

\[
x_{1,1}=-\frac{2ab-2a-bc-b-c-1}{D},
\]

\[
x_{9,4}=-\frac{bc^2+bc-2b+c^2+c+2}{D},
\]

and

\[
x_{7,3}=
\frac{abc^2-2abc+ab+ac^2+2ac-11a+bc^2-2bc+b+c^2+2c+5}{\Delta}.
\]

All other defects are then obtained by constant linear elimination. The exact verifier checks every Schur-complement equation after substitution.

## 2. Full strict realization domain

Use

\[
a=2A-1,\qquad b=2B-1,\qquad c=2C-1.
\]

The full strict realization space is exactly

\[
\boxed{0<A,B,C<1},
\]

equivalently \(-1<a,b,c<1\). No additional semialgebraic inequality is needed.

The verifier proves all seventeen inequalities

\[
1-x_{ij}^2>0
\]

by tensor-Bernstein certificates. It also proves

\[
D>0,\qquad -\Delta>0
\]

throughout the cube, so every denominator used in the exact rank completion is nonzero with fixed sign.

## 3. Primal and polar combinatorics

The exact rank factorization gives six positive primal representatives and eleven positive facet representatives. For every primal vertex-pair, the verifier finds four incident facet normals with a determinant of fixed nonzero sign. Thus

\[
\boxed{f_0(P)=12}.
\]

The primal boundary is not reconstructed from an arbitrary numerical triangulation. It is transported exactly from source local matching 2064, sphere orbit 8, using signed-coordinate permutation

\[
(2,4,1,0,3,5)
\]

with all signs positive. The transported boundary consists of 32 tetrahedra and is checked to be a closed simplicial three-sphere compatible with all 22 actual facets.

At the rational interior sample \(A=B=C=1/2\), the polar has 22 vertices. Its twelve facet-balls admit 81 pulling tetrahedra. Every selected primal and polar simplex determinant receives a full-domain fixed-sign Bernstein certificate. Consequently the same combinatorial decompositions remain valid throughout the open parameter cube:

\[
\boxed{f_0(P^\circ)=22}.
\]

## 4. Mahler margin

The exact volumes are reconstructed as signed sums of the 32 primal and 81 polar cone tetrahedra. After substituting the unit-cube chart, the Mahler margin is a rational function

\[
|P|\,|P^\circ|-\frac{32}{3}=\frac{N(A,B,C)}{Q(A,B,C)}.
\]

The tensor-Bernstein certificate for the numerator has degree

\[
\boxed{(2,5,7)}
\]

and coefficient statistics

\[
\boxed{84>0,\qquad60=0,\qquad0<0},
\]

with minimum positive coefficient

\[
\boxed{\frac{8}{105}}.
\]

The denominator certificate has degree

\[
\boxed{(1,4,5)}
\]

and statistics

\[
\boxed{39>0,\qquad21=0,\qquad0<0},
\]

with minimum positive coefficient

\[
\boxed{\frac{27}{40}}.
\]

Therefore

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

throughout the complete strict realization space.

## 5. Verification status

The standalone verifier recomputes:

- the constant pivot and Schur equations;
- the strict-branch Gröbner basis;
- all seventeen defect inequalities;
- primal extremality;
- the transported 32-tetrahedron primal sphere;
- the 81-tetrahedron polar facet decomposition;
- all orientation signs;
- both exact volumes;
- the Mahler-margin Bernstein certificate.

It returns `PASS`.
