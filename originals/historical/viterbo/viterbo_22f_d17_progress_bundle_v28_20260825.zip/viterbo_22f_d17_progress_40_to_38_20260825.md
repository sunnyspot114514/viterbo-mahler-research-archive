# 四维中心对称 Mahler：22F、D=17 的两族推进

日期：2026-08-25

## 本轮结论

在

\[
12V/22F,\qquad c=0,\qquad D=17
\]

的 40 个剩余 algebraic survivors 中，canonical Families 1702 与 1849 已完成全链条验证：

\[
\boxed{\text{Family }1702\ \checkmark},
\qquad
\boxed{\text{Family }1849\ \checkmark}.
\]

两个勾号均表示 **computer-assisted analytic proof candidate**。本轮没有引入新的外部引理；所有结论均由原始 pairing template、精确 rank-four 消元、组合闭包、体积公式和 Bernstein 正性证书得到。

因此 D=17 的剩余数量更新为

\[
\boxed{40\longrightarrow38}.
\]

---

## Family 1702

### 唯一的 strict rank-four 分支

选择 rows \((0,1,2,10)\) 与 columns \((2,3,4,5)\) 作为 pivot，精确有

\[
\det=-8.
\]

Schur 方程在严格分支中首先强迫

\[
x_{2,0}=x_{0,0}=:a,
\]

以及

\[
x_{5,2}=-\frac{gh-g-h-1}{2},
\qquad
 g=x_{6,3},\ h=x_{7,2}.
\]

剩余 determinantal ideal 在 \(\mathbb Q(a,g,h)\) 上是零维的；lex Gröbner basis 长度为 12，并逐一线性决定其余 12 个 dependent defects。因此 strict rank-four completion 是唯一的三参数有理分支。

三个关键 denominator 为

\[
\begin{aligned}
D_1&=agh+ag+ah-3a-gh+3g-h+7>0,\\
D_2&=gh-g+h-5<0,\\
D_3&=ag-a+g+3>0
\end{aligned}
\]

贯穿完整参数域。

### 完整参数域与组合闭包

全部 17 个 strict defect inequalities 精确等价于

\[
\boxed{-1<a,g,h<1}.
\]

使用

\[
a=2A-1,\qquad g=2G-1,\qquad h=2H-1
\]

后，完整 realization space 是单位开立方体

\[
0<A,G,H<1.
\]

验证器确认：

\[
\operatorname{rank}X=4,
\qquad f_0(P)=12,
\qquad f_0(P^\circ)=22.
\]

primal boundary 由预分类中的 source local matching 1654 与 sphere orbit 7 精确运输而来，共含 32 个 tetrahedra；polar facet-balls 共使用 77 个全域定号 tetrahedra。

### Mahler 余量

\[
|P|\,|P^\circ|-\frac{32}{3}
=\frac{N_{1702}(A,G,H)}{Q_{1702}(A,G,H)}.
\]

分子 tensor Bernstein degree 为

\[
(3,6,3),
\]

112 个系数中

\[
\boxed{65>0,\qquad47=0,\qquad0<0},
\]

最小正系数为

\[
\boxed{\frac25}.
\]

分母 degree 为 \((2,3,2)\)，其中

\[
27>0,\qquad9=0,\qquad\min_+=3.
\]

因此完整严格域上

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

---

## Family 1849

### 唯一的 strict rank-four 分支

同样选择 rows \((0,1,2,10)\) 与 columns \((2,3,4,5)\) 为 pivot：

\[
\det=-8.
\]

经过 8 步常系数消元后，取自由参数

\[
p=x_{3,5},\qquad q=x_{6,2},\qquad r=x_{7,4}.
\]

剩余 ideal 在 \(\mathbb Q(p,q,r)\) 上的 lex Gröbner basis 长度为 6，且为零维；六个剩余 dependent defects 均被线性决定。配合前面的常系数消元，全部 14 个 dependent defects 都得到唯一有理 completion。

四个主要 denominator 为

\[
\begin{aligned}
D_1&=qr-q+r-5,\\
D_2&=pr-p+r+3,\\
D_3&=pr-p+2q+r+5,\\
D_4&=pqr+pq-pr-p+qr+q-r-9,
\end{aligned}
\]

其符号均在完整严格域内被 exact Bernstein 证书固定。

### 完整参数域与组合闭包

全部 strict conditions 精确等价于

\[
\boxed{-1<p,q,r<1}.
\]

令

\[
p=2P-1,\qquad q=2Q-1,\qquad r=2R-1,
\]

整个 realization space 即单位开立方体。

验证器确认：

\[
\operatorname{rank}X=4,
\qquad f_0(P)=12,
\qquad f_0(P^\circ)=22.
\]

primal triangulation 从 source local matching 992、sphere orbit 5 精确运输，共有 32 个 tetrahedra；polar facets 使用 78 个全域定号 tetrahedra。

### Mahler 余量

余量分子的 tensor Bernstein degree 为

\[
(5,4,5).
\]

180 个系数中：

\[
\boxed{160>0,\qquad20=0,\qquad0<0},
\]

最小正系数为

\[
\boxed{\frac23}.
\]

分母 degree 为 \((3,3,4)\)，其中

\[
74>0,\qquad6=0,\qquad\min_+=\frac34.
\]

因此：

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

贯穿 Family 1849 的完整 strict realization space。

---

## 更新后的 D=17 accounting

全部 2395 个 canonical pairing templates 现在不重叠地分类为

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ 个 facet containment}\\
&+1070\text{ 个 antichain 内 rank}\ge5\\
&+22\text{ 个 segment vertex-loss}\\
&+4\text{ 个 duplicate/antipodal primal pair}\\
&+18\text{ 个 exact Mahler-positive families}\\
&+13\text{ 个 strict boundary/interval-impossible}\\
&+38\text{ 个 remaining}.
\end{aligned}}
\]

在最初 121 个 algebraic survivors 层面：

\[
\boxed{121=26+22+4+18+13+38}.
\]

所以当前前沿为

\[
\boxed{
12V/22F,\quad c=0,\quad D=17:
\quad121\longrightarrow38.
}
\]

剩余 38 族中，33 族仍有恒定纯符号 \(\pm8\) pivot；以下 5 族需要 defect-dependent pivot 或完整 determinantal ideal：

\[
1654,\ 1656,\ 1770,\ 2070,\ 2394.
\]

Families 131 与 1260 仍按可能的四参数 realization spaces 单独处理。

---

## 证明范围

本轮结论仍属于四维 symmetric Mahler 猜想的 bounded-12 有限核心。完整四维猜想尚未解决；即使 bounded-12 全部封口，仍需要一个不依赖顶点或 facet 数量的 finite-core / bi-shadow-rigid reduction theorem。
