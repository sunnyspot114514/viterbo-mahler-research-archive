#!/usr/bin/env python3
"""Aggregate exact verifier for D=17 accounting update v11 (Families 1702 and 1849)."""
from pathlib import Path
import hashlib, json, subprocess, sys

R = Path('/mnt/data')
NEW = {1702, 1849}

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run_family(cid: int) -> dict:
    script = R / f'viterbo_22f_d17_family{cid}_verifier.py'
    proc = subprocess.run(
        [sys.executable, str(script)], cwd=str(R), capture_output=True, text=True, check=True
    )
    rerun = json.loads(proc.stdout)
    stored_path = R / f'viterbo_22f_d17_family{cid}_verifier_output.json'
    stored = json.loads(stored_path.read_text())
    assert rerun == stored, f'Family {cid}: rerun output differs semantically from stored output'
    return rerun

def main() -> None:
    a = json.loads((R/'viterbo_22f_d17_progress_accounting_certificate_v11.json').read_text())
    p = json.loads((R/'viterbo_22f_d17_progress_accounting_certificate_v10.json').read_text())
    assert a['status'] == 'PASS'
    assert set(a['remaining_ids']) == set(p['remaining_ids']) - NEW
    assert len(a['remaining_ids']) == 38
    assert set(a['Mahler_positive_exact_families']) == set(p['Mahler_positive_exact_families']) | NEW
    assert len(a['Mahler_positive_exact_families']) == 18
    assert sum(a['disjoint_classification'].values()) == 2395
    assert sum(v for k,v in a['survivor_level_accounting'].items() if k != 'initial') == 121
    for cid in sorted(NEW):
        rerun = run_family(cid)
        s = R/f'viterbo_22f_d17_family{cid}_verifier.py'
        c = R/f'viterbo_22f_d17_family{cid}_certificate.json'
        o = R/f'viterbo_22f_d17_family{cid}_verifier_output.json'
        co = json.loads(c.read_text()); oo = json.loads(o.read_text())
        rr = a['rerun_results'][str(cid)]
        assert rerun['status'] == co['status'] == oo['status'] == 'PASS'
        assert rerun['canonical_id'] == co['canonical_id'] == oo['canonical_id'] == cid
        assert rr['script_sha256'] == sha(s)
        assert rr['certificate_sha256'] == sha(c)
        assert rr['output_sha256'] == sha(o)
        assert rr['rank'] == 4 and rr['strict_defects'] == 17
        assert rr['primal_vertices'] == 12 and rr['polar_vertices'] == 22
        assert rr['margin_certificate'] == oo['margin_certificate']
    result = {
        'status':'PASS',
        'remaining':38,
        'newly_closed':sorted(NEW),
        'Mahler_positive_exact':18,
        'total_pairing_templates':2395,
        'survivor_level_total':121,
    }
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
