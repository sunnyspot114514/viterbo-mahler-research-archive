# Exact closure lemmas for D=17 Families 1702 and 1849

## Lemma A — Family 1702

For canonical Family 1702, the strict rank-four locus is a unique rational three-parameter family. With

\[
a=x_{0,0}=x_{2,0},\qquad g=x_{6,3},\qquad h=x_{7,2},
\]

one has

\[
x_{5,2}=-\frac{gh-g-h-1}{2},
\]

and the remaining twelve dependent defects are uniquely determined over \(\mathbb Q(a,g,h)\). The strict realization space is exactly \((-1,1)^3\). Throughout this space the primal polytope has 12 vertices, its polar has 22 vertices, and

\[
|P||P^\circ|>32/3.
\]

The last inequality is certified by a tensor Bernstein numerator of degree \((3,6,3)\) with 65 positive, 47 zero, and no negative coefficients; the least positive coefficient is \(2/5\).

## Lemma B — Family 1849

For canonical Family 1849, after constant elimination the strict rank-four locus is a unique rational three-parameter family with free coordinates

\[
p=x_{3,5},\qquad q=x_{6,2},\qquad r=x_{7,4}.
\]

The remaining six variables form a zero-dimensional linear lexicographic Gröbner system over \(\mathbb Q(p,q,r)\). The complete strict realization space is exactly \((-1,1)^3\). Throughout it the primal polytope has 12 vertices, its polar has 22 vertices, and

\[
|P||P^\circ|>32/3.
\]

The margin numerator has tensor Bernstein degree \((5,4,5)\), with 160 positive, 20 zero, and no negative coefficients; its least positive coefficient is \(2/3\).

Both lemmas are computer-assisted analytic proof candidates and depend on the exact D=17 preclassification certificate and the transported simplicial boundary complexes recorded in the machine certificates.
