#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 1849."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import viterbo_22f_d17_family768_verifier as base
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family1849_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family1849_verifier_output.json')
CID=1849
PRIMAL_TETRAHEDRA=[
(0,2,4,7),(0,2,4,9),(0,2,7,11),(0,2,9,11),(0,4,7,11),(0,4,9,11),
(1,4,5,8),(1,4,5,9),(1,4,8,9),(1,5,6,8),(1,5,6,10),(1,5,9,10),
(1,6,8,10),(1,8,9,10),(2,3,4,5),(2,3,4,7),(2,3,5,10),(2,3,7,10),
(2,4,5,9),(2,5,9,10),(2,7,10,11),(2,9,10,11),(3,4,5,8),(3,4,7,11),
(3,4,8,11),(3,5,6,8),(3,5,6,10),(3,6,8,10),(3,7,10,11),(3,8,10,11),
(4,8,9,11),(8,9,10,11)]
def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def build_branch():
 data=json.loads(PRE.read_text());rec=data['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,val in enumerate(row):
   if val==0:
    z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=val
 rr=(0,1,2,10);cc=(2,3,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==-8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ);eq=[sp.factor(sp.cancel(z)) for z in S]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 assert sorted(map(str,uns))==sorted(['x1_0','x3_5','x4_3','x5_2','x6_2','x7_4','x8_3','x8_5','x9_1'])
 p,q,r=sp.symbols('p q r',real=True)
 subfree={x['x3_5']:p,x['x6_2']:q,x['x7_4']:r}
 reduced=[]
 for e in rem:
  z=sp.factor(sp.cancel(e.subs(subfree)))
  if z!=0:reduced.append(sp.factor(sp.together(z).as_numer_denom()[0]))
 reduced=list(dict.fromkeys(reduced))
 dep=sorted(set(uns)-set(subfree),key=str);K=sp.QQ.frac_field(p,q,r)
 G=sp.groebner(reduced,*dep,order='lex',domain=K)
 assert G.is_zero_dimensional and len(G.polys)==6
 D1=sp.factor(q*r-q+r-5)
 D2=sp.factor(p*r-p+r+3)
 D3=sp.factor(p*r-p+2*q+r+5)
 D4=sp.factor(p*q*r+p*q-p*r-p+q*r+q-r-9)
 sol6={
  x['x1_0']:sp.factor((q*r-q+r+3)/D1),
  x['x4_3']:sp.factor(-(p*r+3*p+r-1)/D2),
  x['x5_2']:sp.factor((p*q-p-q-1)/2),
  x['x8_3']:sp.factor((p*r-p-2*q+r+1)/D3),
  x['x8_5']:sp.factor(-(p*q*r-p*q+q*r+q-2)/D3),
  x['x9_1']:sp.factor((p*q*r-3*p*q-p*r+3*p+q*r-3*q-r-5)/D4),
 }
 for poly in G.polys:assert sp.factor(sp.cancel(poly.as_expr().subs(sol6)))==0
 stage=dict(const);stage.update(subfree);stage.update(sol6)
 sol={z:base.apply_all(z,stage) for z in vs}
 X=M.subs(sol).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(sp.cancel(e.subs(sol)))==0 for e in eq)
 assert all(not (z.free_symbols&set(vs)) for z in sol.values())
 return rec,rows,vs,X,(p,q,r),rr,cc,sol,trace,G,(D1,D2,D3,D4)
def main():
 rec,rows,vs,X,free,rr,cc,sol,trace,G,dens=build_branch();p,q,r=free
 P,Q,R=sp.symbols('P Q R',real=True);chart={p:2*P-1,q:2*Q-1,r:2*R-1};cv=(P,Q,R);sample={P:sp.Rational(1,2),Q:sp.Rational(1,2),R:sp.Rational(1,2)}
 eng=base.SignEngine(cv,sample)
 coeff={}
 for k,d in enumerate(dens):
  sd=1 if d.subs({p:0,q:0,r:0})>0 else -1
  coeff[f'D{k+1}']=eng.positive_rational((sd*d).subs(chart),f'signed D{k+1}')
 X=X.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==-8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'extremality vertex {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),float);fn=np.array(F.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn])
 assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP=list(PRIMAL_TETRAHEDRA);assert len(tetP)==len(set(tetP))==32
 pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([k for k,f in enumerate(facP) if set(tet)<=set(f)])==1
 tetQ=[z for f in facQ for z in base.pulling_triangulation(f,ptsQ)];assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0
   sg=1 if det.subs(sample)>0 else -1;ce=eng.positive_rational(sg*det,f'{label} tetrahedron {k}')
   terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
 volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=eng.positive_rational(margin,'Mahler margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 1849','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,
  'rank_branch':{'constant_elimination_steps':trace,'groebner_basis_length':len(G.polys),'groebner_zero_dimensional':bool(G.is_zero_dimensional),'groebner_basis':[str(sp.factor(x.as_expr())) for x in G.polys]},
  'coefficient_certificates':coeff,'parameters':['P','Q','R'],'parameter_domain':'0<P,Q,R<1; equivalently -1<p,q,r<1','completion':{str(k):str(v) for k,v in sol.items()},
  'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,
  'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,
  'primal_triangulation_source':{'source_local_id':992,'source_sphere_orbit':5,'matching':[0,4,10,16,23],'signed_coordinate_permutation':{'permutation':[0,1,5,2,3,4],'signs':[1,1,-1,1,1,1]}},
  'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,
  'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},
  'conclusion':'Family 1849 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
