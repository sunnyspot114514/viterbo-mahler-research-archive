#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json
from pathlib import Path

BASE = Path('/mnt/data/work_d17_latest/viterbo_22f_d17_progress_accounting_certificate_v2.json')
FIVE_CERT = Path('/mnt/data/viterbo_22f_d17_five_boundary_families_certificate.json')
FAMILY_OUTPUTS = {
    611: Path('/mnt/data/viterbo_22f_d17_family611_boundary_replay_output.json'),
    1453: Path('/mnt/data/viterbo_22f_d17_family1453_boundary_replay_output.json'),
    2031: Path('/mnt/data/viterbo_22f_d17_family2031_boundary_replay_output.json'),
    2051: Path('/mnt/data/viterbo_22f_d17_family2051_boundary_replay_output.json'),
    2361: Path('/mnt/data/viterbo_22f_d17_family2361_boundary_replay_output.json'),
}
CERT = Path('/mnt/data/viterbo_22f_d17_progress_accounting_certificate_v3.json')
OUT = Path('/mnt/data/viterbo_22f_d17_progress_accounting_checker_output_v3.json')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    base = json.loads(BASE.read_text())
    five = json.loads(FIVE_CERT.read_text())
    assert base['status'] == 'PASS'
    assert five['status'] == 'PASS'
    assert five['classification'] == 'strict_rank4_boundary_only'

    expected = {611, 1453, 2031, 2051, 2361}
    assert set(five['canonical_ids']) == expected
    results = {}
    for cid, path in FAMILY_OUTPUTS.items():
        d = json.loads(path.read_text())
        assert d['status'] == 'PASS'
        assert d['result']['canonical_id'] == cid
        assert d['result']['status'] == 'strict_rank4_boundary_only'
        results[cid] = d

    cert_by_id = {f['canonical_id']: f for f in five['families']}
    assert set(cert_by_id) == expected
    for cid in expected:
        assert results[cid]['result'] == cert_by_id[cid]

    old_remaining = set(base['remaining_ids'])
    assert expected <= old_remaining
    remaining = sorted(old_remaining - expected)
    assert len(remaining) == 60

    boundary = sorted(set(base['strict_rank4_boundary_only']) | expected)
    assert boundary == [611, 1439, 1453, 2031, 2051, 2078, 2361]

    disjoint = dict(base['disjoint_classification'])
    disjoint['strict_rank4_boundary_only'] = 7
    disjoint['remaining_algebraic_survivors'] = 60
    assert sum(disjoint.values()) == 2395

    survivor = dict(base['survivor_level_accounting'])
    survivor['strict_rank4_boundary_only'] = 7
    survivor['remaining'] = 60
    assert survivor['initial'] == 121
    assert sum(v for k, v in survivor.items() if k != 'initial') == 121

    source_hashes = {
        str(BASE): sha(BASE),
        str(FIVE_CERT): sha(FIVE_CERT),
    }
    source_hashes.update({str(p): sha(p) for p in FAMILY_OUTPUTS.values()})

    cert = {
        'scope': '4D symmetric Mahler bounded-12, 12V/22F,c=0,D=17',
        'status': 'PASS',
        'total_pairing_templates': 2395,
        'disjoint_classification': disjoint,
        'Mahler_positive_exact_families': base['Mahler_positive_exact_families'],
        'strict_rank4_boundary_only': boundary,
        'new_strict_rank4_boundary_only': sorted(expected),
        'remaining_ids': remaining,
        'survivor_level_accounting': survivor,
        'source_hashes': source_hashes,
        'replay_elapsed_seconds': {str(cid): results[cid]['elapsed_seconds'] for cid in sorted(expected)},
        'scope_warning': 'All classifications are computer-assisted analytic proof candidates; no claim of external peer review is made.'
    }
    CERT.write_text(json.dumps(cert, indent=2, ensure_ascii=False, sort_keys=True) + '\n')

    out = {
        'status': 'PASS',
        'scope': cert['scope'],
        'total_templates': 2395,
        'initial_algebraic_survivors': 121,
        'remaining_survivors': 60,
        'newly_closed_boundary_only': sorted(expected),
        'all_boundary_only': boundary,
        'certificate': str(CERT),
        'certificate_sha256': sha(CERT),
        'individual_replays': {str(cid): str(FAMILY_OUTPUTS[cid]) for cid in sorted(expected)},
    }
    OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True) + '\n')
    print(json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True))


if __name__ == '__main__':
    main()
