#!/usr/bin/env python3
"""Exact boundary-only verifier for five 12V/22F,c=0,D=17 pairing families.

The script recomputes the canonical sign templates and rank-four Schur
systems from the preclassification certificate.  It uses only constant-pivot
linear algebra and explicit case splits.  Every strict branch forces at least
one nominal defect coordinate to equal +1 or -1, so no strict c=0,D=17
realization exists for canonical families 611, 1453, 2031, 2051, and 2361.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import sympy as sp

PRE = Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT = Path('/mnt/data/viterbo_22f_d17_five_boundary_families_certificate.json')
OUT = Path('/mnt/data/viterbo_22f_d17_five_boundary_families_verifier_output.json')

PIVOTS = {
    611: ((0, 1, 2, 4), (2, 3, 4, 5), 8),
    1453: ((0, 1, 3, 9), (2, 3, 4, 5), -8),
    2031: ((0, 1, 2, 4), (2, 3, 4, 5), -8),
    2051: ((0, 1, 2, 8), (2, 3, 4, 5), 8),
    2361: ((1, 2, 4, 6), (1, 2, 3, 5), 8),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(cid: int):
    data = json.loads(PRE.read_text())
    record = data['records'][cid]
    assert record['canonical_id'] == cid
    assert record['status'] == 'algebraic_survivor'
    rows = record['rows']
    M = sp.zeros(11, 6)
    variables: List[sp.Symbol] = []
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            if value == 0:
                x = sp.Symbol(f'x{i}_{j}', real=True)
                M[i, j] = x
                variables.append(x)
            else:
                M[i, j] = value
    rr, cc, expected_det = PIVOTS[cid]
    pivot = M.extract(rr, cc)
    assert pivot.det(method='domain-ge') == expected_det
    other_rows = [i for i in range(11) if i not in rr]
    other_cols = [j for j in range(6) if j not in cc]
    schur = M.extract(other_rows, other_cols) - M.extract(other_rows, cc) * pivot.inv() * M.extract(rr, other_cols)
    equations = [sp.factor(sp.cancel(z)) for z in schur]
    name = {str(x): x for x in variables}
    return record, rows, M, variables, name, equations


def apply_all(expr: sp.Expr, substitutions: Dict[sp.Symbol, sp.Expr]) -> sp.Expr:
    current = expr
    for _ in range(40):
        nxt = sp.factor(sp.cancel(current.subs(substitutions)))
        if nxt == current:
            return nxt
        current = nxt
    raise AssertionError('substitution did not stabilize')


def constant_eliminate(equations: Iterable[sp.Expr], variables: Iterable[sp.Symbol], initial=None):
    substitutions: Dict[sp.Symbol, sp.Expr] = dict(initial or {})
    unsolved = set(variables) - set(substitutions)
    remaining = list(equations)
    trace = []
    while True:
        remaining = [apply_all(e, substitutions) for e in remaining]
        remaining = [e for e in remaining if e != 0]
        choices = []
        for equation_index, equation in enumerate(remaining):
            for variable in sorted(unsolved, key=str):
                if not equation.has(variable):
                    continue
                try:
                    poly = sp.Poly(equation, variable)
                except sp.PolynomialError:
                    continue
                if poly.degree() != 1:
                    continue
                coefficient = sp.factor(sp.diff(equation, variable))
                if not coefficient.is_Rational or coefficient == 0:
                    continue
                rest = sp.factor(equation.subs(variable, 0))
                choices.append((sp.count_ops(rest), equation_index, str(variable), variable, coefficient, rest, equation))
        if not choices:
            break
        choices.sort(key=lambda z: z[:3])
        _, equation_index, _, variable, coefficient, rest, equation = choices[0]
        solution = sp.factor(-rest / coefficient)
        substitutions[variable] = solution
        unsolved.remove(variable)
        remaining.pop(equation_index)
        trace.append({'variable': str(variable), 'solution': str(solution), 'equation': str(equation)})
    remaining = [apply_all(e, substitutions) for e in remaining]
    remaining = [e for e in remaining if e != 0]
    return substitutions, unsolved, remaining, trace


def proportional_member(expressions: Iterable[sp.Expr], target: sp.Expr) -> str:
    target = sp.factor(target)
    for expression in expressions:
        ratio = sp.factor(sp.cancel(expression / target))
        if ratio.is_Rational and ratio != 0:
            return str(ratio)
    raise AssertionError(f'target factor not found: {target}')


def solve_linear(remaining: List[sp.Expr], variable: sp.Symbol, substitutions: Dict[sp.Symbol, sp.Expr],
                 expected_coefficient: sp.Expr | None = None):
    current = [apply_all(e, substitutions) for e in remaining]
    current = [e for e in current if e != 0]
    choices = []
    for index, equation in enumerate(current):
        if not equation.has(variable):
            continue
        try:
            poly = sp.Poly(equation, variable)
        except sp.PolynomialError:
            continue
        if poly.degree() != 1:
            continue
        coefficient = sp.factor(sp.diff(equation, variable))
        rest = sp.factor(equation.subs(variable, 0))
        choices.append((sp.count_ops(coefficient) + sp.count_ops(rest), index, equation, coefficient, rest))
    assert choices, variable
    choices.sort(key=lambda z: z[0])
    _, index, equation, coefficient, rest = choices[0]
    if expected_coefficient is not None:
        assert sp.factor(coefficient / expected_coefficient).is_Rational
    solution = sp.factor(sp.cancel(-rest / coefficient))
    substitutions[variable] = solution
    current.pop(index)
    return current, {'variable': str(variable), 'coefficient': str(coefficient), 'solution': str(solution), 'equation': str(equation)}


def verify_611():
    record, rows, M, variables, n, equations = build(611)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    factor1 = (n['x7_3'] - n['x8_3']) * (n['x9_1'] - 1) / 2
    r1 = proportional_member(residual, factor1)
    # Strictness excludes x9_1=1, so the strict branch has x7_3=x8_3.
    branch = {n['x7_3']: n['x8_3']}
    subs2, _, residual2, trace2 = constant_eliminate(equations, variables, branch)
    factor2 = -(n['x10_2'] + 1) * (n['x4_0'] - 1) * (n['x8_3'] - 1) / 4
    r2 = proportional_member(residual2, factor2)
    # x10_2 != -1 and x8_3 != 1 in the strict cube, hence x4_0=1.
    return {'canonical_id': 611, 'canonical_key': record['canonical_key'], 'status': 'strict_rank4_boundary_only',
            'case_tree': [
                {'equation': str(sp.factor(factor1)), 'strict_branch': 'x7_3=x8_3', 'ratio': r1},
                {'equation': str(sp.factor(factor2)), 'forced_boundary': 'x4_0=1', 'ratio': r2}],
            'constant_elimination_steps': len(trace) + len(trace2)}


def verify_1453():
    record, rows, M, variables, n, equations = build(1453)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    factor1 = (n['x6_4'] - n['x7_4']) * (n['x9_1'] - 1) / 2
    r1 = proportional_member(residual, factor1)
    branch = {n['x6_4']: n['x7_4']}
    subs2, _, residual2, trace2 = constant_eliminate(equations, variables, branch)
    factor2 = (n['x3_0'] - 1) * (n['x8_4'] - 1) / 2
    r2 = proportional_member(residual2, factor2)
    return {'canonical_id': 1453, 'canonical_key': record['canonical_key'], 'status': 'strict_rank4_boundary_only',
            'case_tree': [
                {'equation': str(sp.factor(factor1)), 'strict_branch': 'x6_4=x7_4', 'ratio': r1},
                {'equation': str(sp.factor(factor2)), 'forced_boundary': 'x3_0=1', 'ratio': r2}],
            'constant_elimination_steps': len(trace) + len(trace2)}


def verify_2031():
    record, rows, M, variables, n, equations = build(2031)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    factor1 = (n['x10_2'] - n['x5_2']) * (n['x9_3'] + 1) / 2
    r1 = proportional_member(residual, factor1)
    # Strictness excludes x9_3=-1, so x10_2=x5_2.
    relation = {n['x10_2']: n['x5_2']}
    subs2, uns2, residual2, trace2 = constant_eliminate(equations, variables, relation)
    # One residual equation is linear in x5_2 with coefficient
    # -(x0_0-x2_0)(x6_5+1)/4.  Split on x0_0=x2_0.
    variable = n['x5_2']
    eq_candidates = []
    for equation in residual2:
        if equation.has(variable) and sp.Poly(equation, variable).degree() == 1:
            coefficient = sp.factor(sp.diff(equation, variable))
            if sp.factor(coefficient / (-(n['x0_0'] - n['x2_0']) * (n['x6_5'] + 1) / 4)).is_Rational:
                eq_candidates.append(equation)
    assert eq_candidates
    equation_x5 = eq_candidates[0]
    # Case x0_0 != x2_0: solve x5_2, then constant elimination forces x0_0=-1.
    subs_neq = dict(subs2)
    current = list(residual2)
    current, step = solve_linear(current, n['x5_2'], subs_neq,
                                 -(n['x0_0'] - n['x2_0']) * (n['x6_5'] + 1) / 4)
    subs_neq2, _, _, trace_neq = constant_eliminate(current, variables, subs_neq)
    assert apply_all(M[0, 0], subs_neq2) == -1
    # Case x0_0=x2_0: constant equations directly force x1_0=1 (and more boundary coordinates).
    relation_eq = {n['x10_2']: n['x5_2'], n['x0_0']: n['x2_0']}
    subs_eq, _, _, trace_eq = constant_eliminate(equations, variables, relation_eq)
    assert apply_all(M[1, 0], subs_eq) == 1
    return {'canonical_id': 2031, 'canonical_key': record['canonical_key'], 'status': 'strict_rank4_boundary_only',
            'case_tree': [
                {'equation': str(sp.factor(factor1)), 'strict_branch': 'x10_2=x5_2', 'ratio': r1},
                {'split': 'x0_0 != x2_0', 'linear_equation': str(equation_x5), 'forced_boundary': 'x0_0=-1'},
                {'split': 'x0_0 = x2_0', 'forced_boundary': 'x1_0=1'}],
            'constant_elimination_steps': len(trace) + len(trace2) + len(trace_neq) + len(trace_eq)}


def verify_2051():
    record, rows, M, variables, n, equations = build(2051)
    subs, uns, residual, trace = constant_eliminate(equations, variables)
    # Continue with coefficients that are products/ratios of strict cube factors.
    strict_steps = []
    current = list(residual)
    for variable in [n['x10_3'], n['x3_3'], n['x7_3'], n['x6_2'], n['x4_2']]:
        current, step = solve_linear(current, variable, subs)
        strict_steps.append(step)
    current = [apply_all(e, subs) for e in current]
    target = -(n['x2_0'] + 1) * (n['x6_4'] - n['x9_4']) / (n['x9_4'] - 1)
    r1 = proportional_member(current, target)
    # If x6_4 != x9_4, strictness fails at x2_0=-1.
    # If x6_4=x9_4, strict equations force x3_3=1 directly.
    rel1 = {n['x6_4']: n['x9_4']}
    subs1, _, residual1, trace1 = constant_eliminate(equations, variables, rel1)
    current1 = list(residual1)
    current1, step10 = solve_linear(current1, n['x10_3'], subs1,
                                    -(n['x8_1'] - 1) / 2)
    current1, step3 = solve_linear(current1, n['x3_3'], subs1,
                                   (n['x2_0'] - 1) * (n['x5_2'] + 1) / 4)
    assert apply_all(M[3, 3], subs1) == 1
    return {'canonical_id': 2051, 'canonical_key': record['canonical_key'], 'status': 'strict_rank4_boundary_only',
            'case_tree': [
                {'equation': str(sp.factor(target)), 'split': 'x6_4 != x9_4', 'forced_boundary': 'x2_0=-1', 'ratio': r1},
                {'split': 'x6_4=x9_4', 'forcing_equation': step3['equation'], 'forcing_coefficient': step3['coefficient'], 'forced_boundary': 'x3_3=1'}],
            'strict_nonzero_coefficients': [s['coefficient'] for s in strict_steps] + [step10['coefficient'], step3['coefficient']],
            'constant_elimination_steps': len(trace) + len(trace1)}

def verify_2361():
    record, rows, M, variables, n, equations = build(2361)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    current = list(residual)
    strict_steps = []
    for variable in [n['x0_1'], n['x4_0'], n['x7_2'], n['x10_1']]:
        current, step = solve_linear(current, variable, subs)
        strict_steps.append(step)
    F = sp.factor(n['x8_2'] * n['x9_1'] - n['x8_2'] - n['x9_1'] - 3)
    assert sp.expand(F - ((1 - n['x8_2']) * (1 - n['x9_1']) - 4)) == 0
    # On (-1,1)^2, 0 < (1-x8_2)(1-x9_1) < 4, hence F<0.
    x00 = apply_all(M[0, 0], subs)
    x104 = apply_all(M[10, 4], subs)
    assert x00 == -1
    assert x104 == 1
    return {'canonical_id': 2361, 'canonical_key': record['canonical_key'], 'status': 'strict_rank4_boundary_only',
            'forced_boundaries': ['x0_0=-1', 'x10_4=1'],
            'special_nonzero_factor': {'factor': str(F), 'identity': '(1-x8_2)(1-x9_1)-4',
                                       'strict_sign': 'negative for -1<x8_2,x9_1<1'},
            'strict_elimination_steps': strict_steps,
            'constant_elimination_steps': len(trace)}


def main():
    results = [verify_611(), verify_1453(), verify_2031(), verify_2051(), verify_2361()]
    cert = {
        'scope': '4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17',
        'status': 'PASS',
        'classification': 'strict_rank4_boundary_only',
        'canonical_ids': [r['canonical_id'] for r in results],
        'families': results,
        'source_hashes': {str(PRE): sha256(PRE)},
        'conclusion': 'No listed canonical family admits a rank<=4 completion with all 17 defect coordinates strictly in (-1,1).',
    }
    CERT.write_text(json.dumps(cert, indent=2, sort_keys=True))
    output = {
        'status': 'PASS',
        'scope': cert['scope'],
        'closed_families': cert['canonical_ids'],
        'count': len(results),
        'classification': cert['classification'],
        'certificate': str(CERT),
        'certificate_sha256': sha256(CERT),
        'conclusion': cert['conclusion'],
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
