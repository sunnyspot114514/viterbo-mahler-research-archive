# 四维中心对称 Mahler：\(12V/22F,c=0,D=17\) 新一轮结构排除

日期：2026-08-22

## 结论

本轮对剩余 65 个 algebraic survivors 中优先级最高的 boundary-like 分支进行了精确 determinantal-ideal 审计。五个 canonical families

\[
\boxed{611,\ 1453,\ 2031,\ 2051,\ 2361}
\]

均被证明不能在所有 17 个 defect coordinates 都严格位于 \((-1,1)\) 时满足 \(\operatorname{rank}X\le4\)。它们只能落到 defect endpoint \(\pm1\)，因此属于 strict-rank-4 boundary-only 分支。

由此，\(D=17\) 的剩余 algebraic survivors 从

\[
65\longrightarrow\boxed{60}.
\]

这里的结论属于 computer-assisted analytic proof candidate，尚未经过外部同行审阅。

---

## Family 611

恒定 pivot 与 Schur 消元首先给出

\[
\frac{(x_{7,3}-x_{8,3})(x_{9,1}-1)}2=0.
\]

严格性排除 \(x_{9,1}=1\)，所以

\[
x_{7,3}=x_{8,3}.
\]

代回剩余 Schur 方程后得到

\[
-\frac{(x_{10,2}+1)(x_{4,0}-1)(x_{8,3}-1)}4=0.
\]

严格性又排除 \(x_{10,2}=-1\) 与 \(x_{8,3}=1\)，故只能有

\[
\boxed{x_{4,0}=1},
\]

与 strict defect 矛盾。

## Family 1453

同样先得到

\[
\frac{(x_{6,4}-x_{7,4})(x_{9,1}-1)}2=0.
\]

严格分支强迫 \(x_{6,4}=x_{7,4}\)。随后：

\[
\frac{(x_{3,0}-1)(x_{8,4}-1)}2=0.
\]

由于 \(x_{8,4}\ne1\)，最终

\[
\boxed{x_{3,0}=1}.
\]

## Family 2031

第一处分支方程为

\[
\frac{(x_{10,2}-x_{5,2})(x_{9,3}+1)}2=0.
\]

严格域排除 \(x_{9,3}=-1\)，所以 \(x_{10,2}=x_{5,2}\)。之后按 \(x_{0,0}=x_{2,0}\) 与否分支：

- 若 \(x_{0,0}\ne x_{2,0}\)，线性消元强迫 \(x_{0,0}=-1\)；
- 若 \(x_{0,0}=x_{2,0}\)，剩余常系数方程强迫 \(x_{1,0}=1\)。

两支都只存在于 defect 边界。

## Family 2051

Schur 方程给出

\[
-\frac{(x_{2,0}+1)(x_{6,4}-x_{9,4})}{x_{9,4}-1}=0.
\]

- 若 \(x_{6,4}\ne x_{9,4}\)，则 \(x_{2,0}=-1\)；
- 若 \(x_{6,4}=x_{9,4}\)，另一条方程为
  \[
  \frac{(x_{2,0}-1)(x_{3,3}-1)(x_{5,2}+1)}4=0.
  \]
  严格域中前后两个因子非零，故 \(x_{3,3}=1\)。

所以没有 strict interior rank-four branch。

## Family 2361

这一族原本看起来更像 genuine continuous family，但恒定 determinant-8 pivot 下的严格消元只使用以下非零因子：

\[
x_{6,4}\pm1,\qquad x_{8,2}+1,\qquad x_{9,1}+1,
\]

以及

\[
F=x_{8,2}x_{9,1}-x_{8,2}-x_{9,1}-3.
\]

关键恒等式为

\[
F=(1-x_{8,2})(1-x_{9,1})-4<0
\]

对所有 \(-1<x_{8,2},x_{9,1}<1\) 成立。因此消元步骤没有遗漏 coefficient-zero strict branch。唯一 rank-four completion 最终强迫

\[
\boxed{x_{0,0}=-1,\qquad x_{10,4}=1}.
\]

所以 Family 2361 同样只存在于边界。

---

## 更新后的不重叠 accounting

全部 2395 个 canonical pairing templates 现在分为

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ 个 facet containment}\\
&+1070\text{ 个 antichain 内 rank}\ge5\\
&+22\text{ 个 segment vertex-loss}\\
&+4\text{ 个 duplicate/antipodal primal pair}\\
&+2\text{ 个 exact Mahler-positive families}\\
&+7\text{ 个 strict rank-four boundary-only families}\\
&+60\text{ 个 remaining survivors}.
\end{aligned}}
\]

七个 boundary-only canonical IDs 为

\[
\boxed{611,\ 1439,\ 1453,\ 2031,\ 2051,\ 2078,\ 2361}.
\]

在最初的 121 个 algebraic survivors 层面：

\[
\boxed{121=26+22+4+2+7+60}.
\]

---

## 当前前沿

\[
\boxed{
12V/22F,\quad c=0,\quad D=17:\quad121\to60.
}
\]

剩余分支中，部分已确认存在严格三参数或四参数样本，不能再用简单 endpoint 强制排除；另一些则仍需 defect-dependent pivot 或分块 Gröbner 审计。下一阶段优先处理：

1. 具有恒定 pivot、但尚未稳定找到严格样本的分支；
2. 已有三参数严格样本且可能共享同一有理参数域的 family clusters；
3. 真正四参数的 Families 131 与 1260；
4. 抽取可跨 family 复用的 endpoint-forcing / coefficient-zero branch lemma。

---

## 独立重放与 accounting 检查

单进程串联五个 SymPy case-tree 时超过了当前容器的一次执行上限，因此没有把该超时 wrapper 计作成功证据。五个证明函数随后在相互隔离的进程中独立重放，均返回 `PASS`；各自运行时间约为：

\[
611:4.11s,\quad1453:3.79s,\quad2031:12.79s,\quad2051:5.60s,\quad2361:5.62s.
\]

轻量聚合 checker 随后逐项核对：

- 每份重放输出与五族总证书中的 symbolic result 完全一致；
- 五个 canonical IDs 原本都属于 v20 的 65 个 remaining survivors；
- 更新后的 remaining ID 集合恰有 60 项；
- 七个 boundary-only IDs 互不重复；
- 全部不重叠类别之和严格等于 2395；
- survivor-level 类别之和严格等于 121；
- 所有输入和输出文件哈希一致。

聚合 checker 最终返回：

\[
\boxed{\texttt{PASS}}.
\]

