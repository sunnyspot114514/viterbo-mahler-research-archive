#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 1446.

It reconstructs the unique strict rank-four branch, proves that its full strict
realization space is -1<r<p<1 and -1<q<1, verifies all 12 primal and 22 polar
vertices using a transported source-sphere triangulation, computes exact volumes,
and proves the Mahler margin by tensor-Bernstein positivity.
"""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
from typing import List
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import viterbo_22f_d17_family768_verifier as base

PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family1446_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family1446_verifier_output.json')
CID=1446

PRIMAL_TETRAHEDRA_1446=[
(0,2,7,10),(0,2,7,11),(0,2,10,11),(0,7,8,10),(0,7,8,11),(0,8,10,11),
(1,2,4,6),(1,2,4,11),(1,2,5,6),(1,2,5,9),(1,2,9,11),(1,4,6,8),
(1,4,8,11),(1,5,6,8),(1,5,8,9),(1,8,9,11),(2,3,4,5),(2,3,4,11),
(2,3,5,7),(2,3,7,11),(2,4,5,6),(2,5,7,10),(2,5,9,10),(2,9,10,11),
(3,4,5,8),(3,4,8,11),(3,5,7,8),(3,7,8,11),(4,5,6,8),(5,7,8,10),
(5,8,9,10),(8,9,10,11)]

def sha256(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()

def build_branch():
 data=json.loads(PRE.read_text()); rec=data['records'][CID]; assert rec['status']=='algebraic_survivor'; rows=rec['rows']
 M=sp.zeros(11,6);variables=[];x={}
 for i,row in enumerate(rows):
  for j,val in enumerate(row):
   if val==0:
    z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;variables.append(z);x[str(z)]=z
   else:M[i,j]=val
 rr=(2,3,5,7);cc=(1,2,4,5);pivot=M.extract(rr,cc);assert pivot.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*pivot.inv()*M.extract(rr,occ);eq=[sp.factor(sp.cancel(z)) for z in S]
 const,unsolved,reduced,trace=base.constant_eliminate(eq,variables)
 assert sorted(map(str,unsolved))==sorted(['x0_1','x10_1','x1_1','x2_0','x4_4','x5_3','x6_4','x8_4','x9_1'])
 rel1=-(x['x0_1']-x['x1_1'])*(x['x5_3']+1)/2
 rel2=-(x['x2_0']+1)*(x['x6_4']-x['x8_4'])/2
 base.proportional_member(reduced,rel1);base.proportional_member(reduced,rel2)
 p,q,r=sp.symbols('p q r',real=True)
 N=p*r+3*p-3*r-1
 x64=sp.factor(N/((p+1)*(r-1)))
 den=sp.factor(p*q*r+p*q-p*r+3*p-q*r-q-3*r+1)
 x53=sp.factor(-(p*q*r+p*q-p*r-5*p-q*r-q+5*r+1)/den)
 stage=dict(const);stage.update({x['x0_1']:q,x['x1_1']:q,x['x2_0']:p,x['x9_1']:r,x['x10_1']:r,x['x6_4']:x64,x['x8_4']:x64,x['x4_4']:-x64,x['x5_3']:x53})
 solution={z:base.apply_all(z,stage) for z in variables};completed=M.subs(solution).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(base.apply_all(e,stage)==0 for e in eq)
 return {'record':rec,'rows':rows,'original':M,'completed':completed,'variables':variables,'free':(p,q,r),'solution':solution,'pivot_rows':rr,'pivot_cols':cc,'rank_trace':{'constant_elimination_steps':trace,'strict_relations':[str(rel1),str(rel2)],'strict_branch':['x1_1=x0_1','x8_4=x6_4'],'completion_denominator':str(den)}}

def main():
 br=build_branch();rows=br['rows'];M=br['completed'];variables=br['variables'];p,q,r=br['free']
 A,B,R=sp.symbols('A B R',real=True)
 chart={r:2*R-1,p:2*R-1+2*(1-R)*A,q:2*R-1+2*(1-R)*B};cv=(A,B,R);sample={A:sp.Rational(2,5),B:sp.Rational(3,5),R:sp.Rational(1,3)};eng=base.SignEngine(cv,sample)
 X=M.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 rr=br['pivot_rows'];cc=br['pivot_cols'];pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
 # Strict domain converse: 1-x6_4^2 has sign of p-r in the free cube.
 converse=sp.factor(1-br['solution'][sp.Symbol('x6_4') ]**2) if False else None
 G=A*(1-R)+R*(1-B)+A*B*R
 coefficient_certificates={'completion_denominator':eng.positive_rational(8*(1-R)*G,'rank completion denominator'),'p_minus_r':eng.positive_rational(2*A*(1-R),'p-r'),'p_plus_1':eng.positive_rational(2*(R+A*(1-R)),'p+1'),'one_minus_r':eng.positive_rational(2*(1-R),'1-r')}
 defects={}
 for z in variables:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(z))
 extremality=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'extremality vertex {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j;extremality.append(found)
 code=np.array(rows,dtype=int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),dtype=float);fn=np.array(F.subs(sample),dtype=float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP=list(PRIMAL_TETRAHEDRA_1446);assert len(tetP)==len(set(tetP))==32;pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([k for k,f in enumerate(facP) if set(tet)<=set(f)])==1
 tetQ=[tet for f in facQ for tet in base.pulling_triangulation(f,ptsQ)];assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0
   sg=1 if det.subs(sample)>0 else -1;ce=eng.positive_rational(sg*det,f'{label} tetrahedron {k}');terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar');volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=eng.positive_rational(margin,'Mahler margin')
 cert={'scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 canonical Family 1446','status':'PASS','canonical_id':CID,'canonical_key':br['record']['canonical_key'],'rank':4,'rank_branch':br['rank_trace'],'coefficient_certificates':coefficient_certificates,'parameters':['A','B','R'],'parameter_domain':'0<A,B,R<1; equivalently -1<r<p<1 and -1<r<q<1','completion':{str(k):str(v) for k,v in br['solution'].items()},'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':extremality,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'primal_triangulation_source':{'source_local_id':2204,'source_sphere_orbit':8,'signed_coordinate_permutation':{'permutation':[0,3,5,2,1,4],'signs':[1,-1,1,-1,1,1]}},'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 1446 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
