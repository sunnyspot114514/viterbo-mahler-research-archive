#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/mnt/data')
OLD=ROOT/'viterbo_22f_d17_progress_accounting_certificate_v5.json'
CERT=ROOT/'viterbo_22f_d17_progress_accounting_certificate_v6.json'
OUT=ROOT/'viterbo_22f_d17_progress_accounting_verifier_output_v6.json'
FAMILIES=[1440,1446]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 old=json.loads(OLD.read_text());assert old['status']=='PASS';oldrem=set(old['remaining_ids']);assert set(FAMILIES)<=oldrem
 reruns={}
 for cid in FAMILIES:
  script=ROOT/f'viterbo_22f_d17_family{cid}_verifier.py'
  outpath=ROOT/f'viterbo_22f_d17_family{cid}_verifier_output.json'
  cp=subprocess.run([sys.executable,str(script)],capture_output=True,text=True,timeout=90)
  assert cp.returncode==0,(cid,cp.stderr,cp.stdout[-2000:])
  out=json.loads(outpath.read_text());assert out['status']=='PASS' and out['canonical_id']==cid
  assert out['rank']==4 and out['strict_defects']==17 and out['primal_vertices']==12 and out['polar_vertices']==22
  assert out['tetrahedra_primal']==32 and out['tetrahedra_polar']==77
  assert sha(out['certificate'])==out['certificate_sha256']
  reruns[str(cid)]={'script_sha256':sha(script),'output_sha256':sha(outpath),'certificate_sha256':out['certificate_sha256'],'status':'PASS'}
 rem=sorted(oldrem-set(FAMILIES));mahler=sorted(set(old['Mahler_positive_exact_families'])|set(FAMILIES))
 dis={'facet_containment':1230,'rank_ge_5_after_antichain':1070,'segment_loss_after_antichain':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':len(mahler),'strict_rank4_boundary_or_interval_impossible':13,'remaining_algebraic_survivors':len(rem)}
 assert sum(dis.values())==2395
 surv={'initial':121,'facet_containment':26,'additional_segment_loss':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':len(mahler),'strict_rank4_boundary_or_interval_impossible':13,'remaining':len(rem)}
 assert sum(v for k,v in surv.items() if k!='initial')==surv['initial']
 cert={'status':'PASS','scope':old['scope'],'scope_warning':old['scope_warning'],'total_pairing_templates':2395,'disjoint_classification':dis,'survivor_level_accounting':surv,'Mahler_positive_exact_families':mahler,'strict_rank4_boundary_or_interval_impossible':old['strict_rank4_boundary_or_interval_impossible'],'remaining_ids':rem,'newly_closed':{'Mahler_positive_exact':FAMILIES},'rerun_results':reruns,'source_hashes':{str(OLD):sha(OLD),str(ROOT/'viterbo_22f_d17_preclassification_certificate.json'):sha(ROOT/'viterbo_22f_d17_preclassification_certificate.json')}}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 result={'status':'PASS','total_pairing_templates':2395,'initial_algebraic_survivors':121,'Mahler_positive_exact_families':mahler,'newly_closed':FAMILIES,'remaining_algebraic_survivors':len(rem),'accounting_certificate':str(CERT),'accounting_certificate_sha256':sha(CERT),'reruns':reruns}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
