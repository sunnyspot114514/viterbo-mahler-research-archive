# 四维中心对称 Mahler：bounded-12 进展（D=17：52 → 50）

日期：2026-08-23

## 结论摘要

本轮完整关闭了 `12V/22F, c=0, D=17` 的两个 genuine 三参数连续分支：

\[
\boxed{\text{Family }1440\;\checkmark},
\qquad
\boxed{\text{Family }1446\;\checkmark}.
\]

两族均完成：

\[
\text{exact rank-4 branch}
+\text{完整 strict domain}
+\text{12 primal / 22 polar vertices}
\]

\[
+\text{transported source-sphere triangulation}
+\text{精确体积}
+\text{Bernstein-positive Mahler margin}.
\]

因此 `D=17` 的 algebraic survivors 由 52 降至

\[
\boxed{50}.
\]

所有勾号仍表示 **computer-assisted analytic proof candidate**；本结果尚未经过外部同行审阅，也不构成完整四维猜想的证明。

---

## Family 1440

严格 rank-four 分支先由 Schur 方程强迫

\[
x_{7,3}=x_{8,3}=t,
\qquad
x_{4,3}=-t.
\]

取

\[
p=x_{3,0},\qquad r=x_{9,1},\qquad t=x_{7,3}.
\]

其余 14 个 dependent defects 被唯一解成有理函数。例如

\[
x_{6,4}=x_{10,4}
=\frac{pt-3p-t-1}{pt+p-t+3},
\]

\[
x_{5,2}
=-\frac{rt-3r-t-1}{rt+r-t+3}.
\]

完整 strict realization space 恰好为

\[
\boxed{-1<p,r,t<1}.
\]

以

\[
p=2A-1,\qquad r=2B-1,\qquad t=2C-1
\]

映到单位开立方体。所有 17 个 defect inequalities、completion denominators、primal extremality determinants 和选定 tetrahedral determinants 均获得全域 Bernstein 定号证书。

组合闭包为

\[
\boxed{f_0(P)=12,\qquad f_0(P^\circ)=22}.
\]

使用 transported source sphere 的 32 个 primal tetrahedra，以及 77 个 polar-facet tetrahedra。

Mahler 余量的 Bernstein 证书为：

\[
\deg N=(3,2,6),
\qquad
50>0,\;34=0,\;0<0,
\qquad
\min_+=\frac45.
\]

分母为

\[
\deg D=(2,1,3),
\qquad
15>0,\;9=0,
\qquad
\min_+=3.
\]

因此整个 strict realization space 上

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}.
\]

---

## Family 1446

Schur 方程在 strict branch 中强迫

\[
x_{1,1}=x_{0,1},
\qquad
x_{8,4}=x_{6,4}.
\]

取

\[
p=x_{2,0},\qquad q=x_{0,1},\qquad r=x_{9,1}.
\]

关键 completion 为

\[
x_{6,4}
=\frac{pr+3p-3r-1}{(p+1)(r-1)},
\qquad
x_{4,4}=-x_{6,4},
\]

\[
x_{10,1}=r,
\]

以及一个以

\[
pqr+pq-pr+3p-qr-q-3r+1
\]

为分母的唯一有理表达式。

### 验核中发现并修正的参数域问题

最初探索时曾把 `q` 误当作独立遍历整个 `(-1,1)`。直接代回 defect `x_{0,0}` 后，发现这一 chart 会进入非严格区域。精确因式分解给出

\[
1-x_{0,0}^2
=-\frac{(p-1)(q-r)(pq-pr-q-r+2)}{(r-1)^2}.
\]

在其余基础条件下，真正需要的是

\[
\boxed{q>r}.
\]

最终完整 strict domain 为

\[
\boxed{-1<r<p<1,\qquad -1<r<q<1}.
\]

使用

\[
r=2R-1,
\]

\[
p=2R-1+2(1-R)A,
\qquad
q=2R-1+2(1-R)B,
\]

即可有理双射到

\[
0<A,B,R<1.
\]

修正参数域后重新从原 pairing template 运行完整 verifier，得到

\[
\boxed{f_0(P)=12,\qquad f_0(P^\circ)=22},
\]

并使用 32 个 primal tetrahedra 与 77 个 polar tetrahedra。

Mahler 余量证书：

\[
\deg N=(3,2,5),
\qquad
38>0,\;34=0,\;0<0,
\qquad
\min_+=\frac{8}{15},
\]

\[
\deg D=(2,1,3),
\qquad
15>0,\;9=0,
\qquad
\min_+=\frac32.
\]

所以

\[
\boxed{|P|\,|P^\circ|>\frac{32}{3}}
\]

贯穿完整 strict domain。

---

## 更新后的 D=17 accounting

全部 2395 个 canonical pairing templates 现在不重叠地分为

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ facet containment}\\
&+1070\text{ rank}\ge5\\
&+22\text{ segment vertex-loss}\\
&+4\text{ duplicate/antipodal primal pair}\\
&+6\text{ exact Mahler-positive families}\\
&+13\text{ strict boundary/interval-impossible}\\
&+50\text{ remaining}.
\end{aligned}}
\]

六个已完成的 Mahler-positive families 是

\[
\boxed{606,\;757,\;768,\;952,\;1440,\;1446}.
\]

在最初 121 个 algebraic survivors 层面：

\[
\boxed{121=26+22+4+6+13+50}.
\]

聚合 verifier 会在独立子进程中重新运行 Families 1440、1446 的完整 exact verifiers，核对证书 SHA-256，并检查 accounting 总数。结果为 `PASS`。

---

## 当前前沿

\[
\boxed{
12V/22F,\quad c=0,\quad D=17:
\quad121\to50.
}
\]

其余已关闭层保持不变：`c=1`、`12F`、`14F`、`16F`、`18F`、`20F`、`22F/D=19`、`22F/D=18`。

下一步继续对剩余 50 个 family 做两类处理：

1. coefficient-aware Schur case tree，寻找 strict boundary-only 分支；
2. 对有恒定纯符号 pivot 的 genuine 三参数分支进行 rational completion、transported source-sphere closure 与 Mahler positivity。
