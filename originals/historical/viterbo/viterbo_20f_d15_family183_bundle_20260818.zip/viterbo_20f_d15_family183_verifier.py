#!/usr/bin/env python3
import sympy as sp,json,itertools,sys
from math import comb
from pathlib import Path
W=Path(__file__).resolve().parent
C=json.load(open(W/'viterbo_20f_d15_family183_certificate.json'))
U,V,T=sp.symbols('U V W'); loc={'U':U,'V':V,'W':T}
vars=(U,V,T)
def parse(x): return sp.sympify(x,locals=loc)
def bern(poly):
 P=sp.Poly(sp.expand(poly),*vars); deg=tuple(map(int,P.degree_list())); co=dict(P.terms()); out=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg): f*=sp.Rational(comb(ii[j],kk[j]),comb(d,kk[j]))
    z+=cc*f
  out.append(sp.factor(z))
 return deg,out
def check_pos_record(r):
 expr=parse(r['expr']); n,d=map(sp.factor,sp.together(expr).as_numer_denom())
 sn=parse(r['numerator']); sd=parse(r['denominator'])
 assert sp.factor(n*sd-d*sn)==0
 dn,bn=bern(sn); dd,bd=bern(sd)
 assert list(dn)==r['numerator_degree'] and list(dd)==r['denominator_degree']
 assert all(x.is_nonnegative for x in bn) and any(x.is_positive for x in bn)
 assert all(x.is_nonnegative for x in bd) and any(x.is_positive for x in bd)
 assert sum(x.is_positive for x in bn)==r['numerator_positive']
 assert sum(x.is_zero for x in bn)==r['numerator_zero']
 assert str(min(x for x in bn if x.is_positive))==r['numerator_min_positive']
 assert sum(x.is_positive for x in bd)==r['denominator_positive']
 assert sum(x.is_zero for x in bd)==r['denominator_zero']
 return expr
M=sp.Matrix([[parse(x) for x in row] for row in C['completed_matrix']])
VM=sp.Matrix([[parse(x) for x in row] for row in C['primal_columns']])
FM=sp.Matrix([[parse(x) for x in row] for row in C['facet_normals']])
rs=C['pivot_rows']; cs=C['pivot_cols']; P=M.extract(rs,cs)
assert P.det()==parse(C['pivot_det'])==-8
ri=[i for i in range(10) if i not in rs]; cj=[j for j in range(6) if j not in cs]
assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
assert all(sp.factor(x)==0 for x in FM*VM-M)
# strict defects
for name,r in C['strict_defects'].items():
 i,j=map(int,name[1:].split('_')); expr=check_pos_record(r)
 assert sp.factor(expr-(1-M[i,j]**2))==0
# primal extremality
for j,r in C['primal_extremality'].items():
 mat=sp.Matrix.vstack(*[sp.Matrix([[sg*FM[i,k] for k in range(4)]]) for i,sg in r['choice']])
 det=sp.factor(mat.det()); assert sp.factor(det-parse(r['determinant']))==0
 check_pos_record(r['nonzero_certificate'])
# primal circuit volume
def col(idx): return VM[:,idx] if idx<6 else -VM[:,idx-6]
def det4(ids): return sp.factor(sp.det(sp.Matrix.hstack(*[col(i) for i in ids])))
volP=0
for rec in C['primal_volume_terms']:
 if 'oriented_det' in rec:
  z=det4(rec['subset']); o=parse(rec['oriented_det']); assert sp.factor(z-o)==0 or sp.factor(z+o)==0
  check_pos_record(rec['certificate']); volP+=o/12
 else:
  ss=0
  for t in rec['circuit_terms']:
   z=det4(t['subset']); o=parse(t['oriented_det']); assert sp.factor(z-o)==0 or sp.factor(z+o)==0
   check_pos_record(t['certificate']); ss+=o
  volP+=ss/24
volP=sp.factor(volP); assert sp.factor(volP-parse(C['volume_P']))==0
# cap/slab geometry
A=U; B=(1-U)*V; D=T; E=sp.factor(1-A-B); L=sp.factor(E+B*(1-B))
p=sp.factor(E/(1-A)); t=sp.factor(B/(1-A)); alpha=sp.factor(1/p); beta=sp.factor((1-B)/E)
m=sp.factor(E*(1-A)*(1-D)/L); s=sp.factor(1+D/m)
u=VM[:,0]; v=VM[:,1]
assert all(sp.factor(u[i]-z)==0 for i,z in enumerate([m,beta*m,-(m+D),-t*m]))
assert all(sp.factor(v[i]-z)==0 for i,z in enumerate([A-1,B-1,E,0]))
assert sp.factor(p+t-1)==0 and sp.factor(alpha*p-1)==0 and sp.factor(D+m*(beta+t)-1)==0
# The non-overlapping sign pair is separated because 1+1/E-alpha=(1-B)/E>0.
sep=sp.factor(1+1/E-alpha); assert sp.factor(sep-(1-B)/E)==0
# cap and overlap volumes; overlap follows from the degree-4 truncated-power formula on knots 0,p,1,s.
AA,BB,DD=sp.symbols('A B D')
def parse_cap(x):
 return sp.sympify(x,locals={'A':AA,'B':BB,'D':DD}).subs({AA:A,BB:B,DD:D}, simultaneous=True)
capu=parse_cap(C['cap_geometry']['single_u_cap_z_volume']); capv=parse_cap(C['cap_geometry']['single_v_cap_z_volume']); ov=parse_cap(C['cap_geometry']['single_overlap_z_volume'])
assert sp.factor(capu-(1-p**4)/(24*beta*s*t))==0
assert sp.factor(capv-p/(6*beta))==0
den0=p*s; den1=-p*(p-1)*(p-s)
I1=sp.factor((1/den0+(1-p)**4/den1)/(24*alpha*beta)); Ip=sp.factor(p**4/den0/(24*alpha*beta))
assert sp.factor(ov-(I1-Ip)/t)==0
volQ=sp.factor(16-32*capu-32*capv+32*ov); assert sp.factor(volQ-parse(C['volume_polar']))==0
margin=sp.factor(volP*volQ-sp.Rational(32,3)); assert sp.factor(margin-parse(C['mahler_margin']))==0
check_pos_record(C['mahler_certificate'])
assert C['mahler_certificate']['numerator_positive']==58 and C['mahler_certificate']['numerator_zero']==62
# closure summary is checked independently by 15 exact chunk verifiers.
cc=C['closure']['counts']; assert cc=={'expected':56,'violation':168,'singular':16,'unresolved':0}
out={'status':'PASS','template_index':183,'rank':4,'strict_defects':len(C['strict_defects']),
     'primal_vertices':12,'section_vertices':C['closure']['distinct_expected_vertices'],
     'closure_counts':cc,'volume_P':str(volP),'volume_polar':str(volQ),
     'margin_degree':C['mahler_certificate']['numerator_degree'],
     'margin_positive':C['mahler_certificate']['numerator_positive'],
     'margin_zero':C['mahler_certificate']['numerator_zero'],
     'margin_min_positive':C['mahler_certificate']['numerator_min_positive'],
     'conclusion':'Mahler product > 32/3 on the full strict domain'}
(W/'viterbo_20f_d15_family183_verifier_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
