#!/usr/bin/env python3
import sympy as sp,json,itertools,sys
from math import comb
from pathlib import Path
W=Path(__file__).resolve().parent
CERT=json.load(open(W/'viterbo_20f_d15_family183_certificate.json'))
ci=int(sys.argv[1])
chunk=CERT['closure']['chunks'][ci]
U,V,T=sp.symbols('U V W'); loc={'U':U,'V':V,'W':T}; vars=(U,V,T)
def parse(x): return sp.sympify(x,locals=loc)
def bern(poly):
 P=sp.Poly(sp.expand(poly),*vars); deg=tuple(map(int,P.degree_list())); co=dict(P.terms()); out=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg): f*=sp.Rational(comb(ii[j],kk[j]),comb(d,kk[j]))
    z+=cc*f
  out.append(sp.factor(z))
 return deg,out
M=sp.Matrix([[parse(x) for x in row] for row in CERT['completed_matrix']])
VM=sp.Matrix([[parse(x) for x in row] for row in CERT['primal_columns']])
cols=tuple(chunk['cols'])
C=sp.Matrix.hstack(*[VM[:,j] for j in cols]).T
det=sp.factor(C.det())
assert sp.factor(det-parse(chunk['det']))==0
expected=[]
for i in range(10):
 q=tuple(M[i,j] for j in range(6)); expected.append((i,1,q)); expected.append((i,-1,tuple(-x for x in q)))
counts={'expected':0,'violation':0,'singular':0,'unresolved':0}
if det==0:
 # A singular active system cannot define an isolated vertex.  Here the
 # active columns are (1,2,3,4), with columns 2,3,4 independent and column
 # 1 having fourth coordinate zero, hence rank exactly three.
 assert cols==(1,2,3,4)
 assert C.rank()==3
 for rec in chunk['results']:
  assert rec['type']=='singular'; counts['singular']+=1
else:
 inv=C.inv()
 for rec in chunk['results']:
  signs=tuple(rec['signs']); y=inv*sp.Matrix(signs)
  q=tuple(sp.factor(sp.cancel((VM[:,j].T*y)[0])) for j in range(6))
  if rec['type']=='expected':
   i,sg=rec['row']
   assert all(sp.factor(q[j]-sg*M[i,j])==0 for j in range(6))
   counts['expected']+=1
  elif rec['type']=='violation':
   j=rec['coord']; assert j not in cols
   num,den=map(sp.factor,sp.together(q[j]**2-1).as_numer_denom())
   target=parse(rec['poly'])
   assert sp.factor(num-target)==0 or sp.factor(num+target)==0
   deg,b=bern(target); meta=chunk['polys'][rec['poly']]
   assert list(deg)==meta['degree']
   assert all(x.is_nonnegative for x in b) and any(x.is_positive for x in b)
   assert sum(x.is_positive for x in b)==meta['positive']
   assert sum(x.is_zero for x in b)==meta['zero']
   assert str(min(x for x in b if x.is_positive))==meta['min_positive']
   # denominator is a square/rationally positive on the strict domain; the
   # direct identity certifies q_j^2-1 = target/den with positive sign.
   sample={U:sp.Rational(1,5),V:sp.Rational(5,16),T:sp.Rational(1,2)}
   assert target.subs(sample)>0 and den.subs(sample)>0
   counts['violation']+=1
  else:
   raise AssertionError('unexpected unresolved chart')
assert counts==chunk['counts']
out={'status':'PASS','template_index':183,'chunk':ci,'active_columns':list(cols),'counts':counts,'unique_violation_polynomials':len(chunk['polys'])}
path=W/f'viterbo_20f_d15_family183_closure_{ci:02d}_output.json'
path.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
