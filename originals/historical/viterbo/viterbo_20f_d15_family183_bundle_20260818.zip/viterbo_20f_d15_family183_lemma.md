# Family 183 in the 12V/20F, c=0, D=15 layer

**Status:** computer-assisted analytic proof candidate  
**Date:** 18 August 2026

## 1. Statement

Let `X` be the canonical pairing-sign template numbered 183 in the complete
`12V/20F, c=0, D=15` preclassification.  Its ten positive facet-pair rows
contain five single defects and five double defects.  Every strict rank-four
completion preserving all twelve primal vertices and exactly twenty polar
vertices satisfies

\[
  |P|\,|P^\circ|>\frac{32}{3}.
\]

Consequently Family 183 cannot contain a four-dimensional centrally
symmetric Mahler minimizer.

## 2. Exact rank-four completion and strict domain

Choose pivot rows

\[
  (1,3,4,9)
\]

and pivot columns

\[
  (2,3,4,5).
\]

The pivot determinant is the constant

\[
  \det P=-8.
\]

Introduce parameters

\[
  A>0,\qquad B>0,\qquad E=1-A-B>0,\qquad 0<D<1.
\]

The original free defects may be chosen as

\[
  a=2A-1,\qquad j=2B-1,
\]

and

\[
  c=c_0+(1-c_0)D,
  \qquad
  c_0=\frac{2AB-A+B^2-2B+1}{A+B^2-1}.
\]

All other defects are uniquely determined by the vanishing Schur complement.
The fifteen strict inequalities `|x_ij|<1` are equivalent to the domain above.
A rational bijection from the open unit cube is

\[
  A=U,\qquad B=(1-U)V,\qquad E=(1-U)(1-V),\qquad D=W,
\]

where

\[
  0<U,V,W<1.
\]

The exact verifier checks every Schur-complement equation and all fifteen
strict-defect Bernstein certificates.

## 3. Normalized primal columns

After the pivot normalization, columns 2,3,4,5 are the standard basis of
`R^4`.  Put

\[
  L=E+B(1-B),
\]

\[
  p=\frac{E}{1-A},\qquad
  t=\frac{B}{1-A}=1-p,
\]

\[
  \beta=\frac{1-B}{E},\qquad
  m=\frac{E(1-A)(1-D)}{L},\qquad
  s=1+\frac{D}{m},\qquad
  \alpha=\frac1p.
\]

The two remaining primal columns are

\[
  u=(m,\beta m,-(m+D),-tm),
\]

and

\[
  v=(A-1,B-1,E,0).
\]

They obey

\[
  p+t=1,\qquad \alpha p=1,\qquad D+m(\beta+t)=1.
\]

For each of the six positive primal columns, the certificate supplies four
incident signed facet normals with a nonzero determinant throughout the
strict domain.  Hence all six antipodal vertex pairs remain extreme:

\[
  f_0(P)=12.
\]

## 4. Exact section closure

The polar is

\[
  P^\circ=[-1,1]^4
  \cap\{|u\cdot y|\le1\}
  \cap\{|v\cdot y|\le1\}.
\]

An independent active-chart enumeration checks all

\[
  \binom64 2^4=240
\]

possible four-active-coordinate systems.  Its exact classification is

\[
  \boxed{
  240
  =56\text{ expected occurrences}
  +168\text{ strict cube violations}
  +16\text{ singular systems}.
  }
\]

The 56 expected occurrences represent exactly twenty distinct vertices.  The
168 rejected charts use 66 distinct Bernstein-positive violation
polynomials.  The sixteen singular charts all use active columns
`(1,2,3,4)`; their active matrix has rank exactly three and therefore cannot
produce an isolated section vertex.  There are no unresolved charts.
Thus

\[
  f_0(P^\circ)=20.
\]

## 5. Chamber-free primal volume

The positive facets consist of five tetrahedra and five five-vertex
three-polytopes.  For a five-vertex facet
`F=conv(w_1,...,w_5)`, use the circuit identity

\[
 \operatorname{vol}\operatorname{conv}(0,F)
 =\frac1{48}\sum_{i=1}^5
 \left|\det(w_1,\ldots,\widehat{w_i},\ldots,w_5)\right|.
\]

All determinant signs are fixed on the strict domain.  Summing the ten
antipodal facet-pair contributions gives

\[
|P|=
\frac{
A^2BD-A^2B-2A^2+AB^2D-3AB^2-2ABD+8A
-2B^3-B^2D+7B^2+BD+B-6
}{6(A+B^2-1)}.
\]

No primal triangulation chamber is assumed.

## 6. A single global polar-volume formula

At the cube corner `(-1,-1,+1,+1)`, use local coordinates `z_i` vanishing at
that corner.  The two relevant cap inequalities become

\[
  z_0+\beta z_1+s z_2+t z_3<1,
\]

and

\[
  \alpha z_0+\beta z_1+z_2<1.
\]

The second cap is a triangular prism in the `z_3` direction.  The other sign
pair is strictly disjoint: under the first cap,

\[
  \alpha z_0+\beta z_1+z_2<\alpha,
\]

whereas the opposite prism cap would require a value greater than
`1+1/E`, and

\[
  1+\frac1E-\alpha=\frac{1-B}{E}>0.
\]

The single-cap volumes in `z` coordinates are

\[
  C_u=\frac{1-p^4}{24\beta s t},
  \qquad
  C_v=\frac{p}{6\beta}.
\]

For the overlap, integrate in `z_3`.  On the tetrahedron

\[
  T=\{z\ge0:\alpha z_0+\beta z_1+z_2<1\},
\]

the affine function

\[
  \ell=z_0+\beta z_1+s z_2
\]

has vertex values

\[
  0,\ p,\ 1,\ s.
\]

Using

\[
  \operatorname{clamp}\frac{1-\ell}{t}
  =\frac{(1-\ell)_+-(p-\ell)_+}{t}
\]

and the degree-four truncated-power formula on a three-simplex yields the
single-overlap volume

\[
  J=
  \frac{p\bigl(p^3-p^2s+p^2+p-3s+1\bigr)}
  {24\beta s(p-s)}.
\]

The cube-to-corner-coordinate Jacobian is 16, and there are two antipodal
copies.  Therefore the global polar volume is

\[
  \boxed{
  |P^\circ|=16-32C_u-32C_v+32J.
  }
\]

This identity is valid across all internal oriented-matroid walls.  Those
walls only flip triangulations; they do not change the volume formula.

## 7. Mahler margin

Substitute

\[
  A=U,\qquad B=(1-U)V,\qquad D=W.
\]

Then

\[
  |P||P^\circ|-\frac{32}{3}=\frac{N(U,V,W)}{Q(U,V,W)}.
\]

The denominator has tensor Bernstein degree

\[
  (3,5,1)
\]

and coefficients

\[
  27>0,\qquad21=0,
\]

with minimum positive coefficient `3/5`.

The numerator has tensor Bernstein degree

\[
  (4,7,2)
\]

and coefficients

\[
  \boxed{58>0,\qquad62=0,\qquad0<0,}
\]

with minimum positive coefficient

\[
  \boxed{\frac6{35}}.
\]

Every tensor Bernstein basis function is positive in the open cube, so

\[
  |P||P^\circ|>\frac{32}{3}
\]

throughout the full strict realization space.

## 8. Verification result

The main exact verifier and all fifteen closure-chunk verifiers return
`PASS`.  An aggregate output checker confirms

\[
  \operatorname{rank}X=4,
  \quad 15\text{ strict defects},
  \quad f_0(P)=12,
  \quad f_0(P^\circ)=20,
\]

and the strict Mahler margin above.

This establishes Family 183 as a computer-assisted analytic proof candidate;
it is not yet an externally reviewed theorem.
