# 12V/20F, c=0, D=15: Family 183 closed

Family 183 has been upgraded from “Mahler-positive under a sampled polar
triangulation” to a full computer-assisted analytic proof candidate.

The key new step is a chamber-free polar-volume formula.  After rank-four
normalization, the polar is a four-cube intersected with a wedge-producing
slab and a triangular-prism-producing slab.  Their only nontrivial overlap is
integrated exactly by a degree-four truncated-power formula on a tetrahedron
whose knot values are `0,p,1,s`.  Hence all previously observed orientation
walls are merely triangulation flips.

Independent checks give:

- pivot determinant `-8` and exact Schur complement zero;
- 15 strict defect inequalities;
- 12 genuine primal vertices;
- 240 section charts classified as `56 expected + 168 violations + 16 rank-3 singular`, with no unresolved chart;
- exactly 20 polar vertices;
- chamber-free primal circuit volume;
- one global polar volume formula;
- Mahler-margin Bernstein degree `(4,7,2)`, with `58` positive, `62` zero,
  and no negative coefficients; minimum positive coefficient `6/35`.

Therefore

\[
  |P||P^\circ|>32/3
\]

on the full strict realization space.

The D=15 aggregate status is now

\[
  748=669+51+2+7+19,
\]

namely 669 rank obstructions, 51 duplicate-row templates, 2 vertex-loss
families, 7 Mahler-positive families, and 19 remaining algebraic survivors.
