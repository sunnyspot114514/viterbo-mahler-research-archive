#!/usr/bin/env python3
import json
from pathlib import Path
W=Path(__file__).resolve().parent
main=json.load(open(W/'viterbo_20f_d15_family183_verifier_output.json'))
assert main['status']=='PASS' and main['template_index']==183
assert main['rank']==4 and main['strict_defects']==15
assert main['primal_vertices']==12 and main['section_vertices']==20
agg={'expected':0,'violation':0,'singular':0,'unresolved':0}; polys=0
for i in range(15):
 p=W/f'viterbo_20f_d15_family183_closure_{i:02d}_output.json'
 d=json.load(open(p)); assert d['status']=='PASS' and d['chunk']==i
 for k in agg: agg[k]+=d['counts'][k]
 polys+=d['unique_violation_polynomials']
assert agg=={'expected':56,'violation':168,'singular':16,'unresolved':0}
assert agg==main['closure_counts']
out={'status':'PASS','template_index':183,'main_verifier':'PASS','closure_chunks':15,
     'closure_counts':agg,'chunk_polynomial_occurrences':polys,
     'distinct_section_vertices':20,'margin_positive':58,'margin_zero':62,
     'margin_min_positive':'6/35','conclusion':'Family 183 is closed as a computer-assisted analytic proof candidate'}
(W/'viterbo_20f_d15_family183_output_checker_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
