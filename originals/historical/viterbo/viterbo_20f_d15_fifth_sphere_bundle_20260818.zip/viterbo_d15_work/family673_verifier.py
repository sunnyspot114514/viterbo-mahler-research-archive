#!/usr/bin/env python3
"""Exact verifier for 12V/20F, c=0, D=15, canonical family 673.

Checks the rational rank-four completion, the tetrahedral strict domain,
all defect inequalities, primal extremality, sample hull incidence, global
fixed-sign facet triangulations, exact volumes, and simplex-Bernstein
positivity of the Mahler margin.
"""
from __future__ import annotations
import sympy as sp, numpy as np, itertools, math, json, hashlib, time
from scipy.spatial import ConvexHull
from pathlib import Path
HERE=Path(__file__).resolve().parent
INDEX=673

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def simplex_coeffs(poly,A,B,C):
    p=sp.Poly(sp.expand(poly),A,B,C,domain='QQ');terms=dict(p.terms());n=max([sum(k) for k in terms] or [0]);out={}
    for a0 in range(n+1):
      for a1 in range(n-a0+1):
       for a2 in range(n-a0-a1+1):
        a3=n-a0-a1-a2;alpha=(a0,a1,a2,a3);z=sp.Rational(0)
        for beta,coef in terms.items():
            m=sum(beta)
            if all(beta[j]<=alpha[j+1] for j in range(3)):
                multin=math.factorial(m)
                for q in beta:multin//=math.factorial(q)
                numer=math.prod(math.comb(alpha[j+1],beta[j]) for j in range(3))
                z+=coef*sp.Rational(numer,math.comb(n,m)*multin)
        out[alpha]=sp.factor(z)
    return n,out

def bern_stats(poly,A,B,C):
    n,co=simplex_coeffs(poly,A,B,C);vals=list(co.values());pos=[x for x in vals if x>0]
    return {'degree':n,'positive':sum(bool(x>0) for x in vals),'zero':sum(bool(x==0) for x in vals),'negative':sum(bool(x<0) for x in vals),'min_positive':str(min(pos)) if pos else None}

def positive(poly,A,B,C):
    st=bern_stats(poly,A,B,C);return st['negative']==0 and st['positive']>0,st

def project3(x):
    d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T

def pull(ids,coords):
    ids=sorted(ids)
    if len(ids)==4:return [tuple(ids)]
    pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
    for tri,eqn in zip(h.simplices,h.equations):
        if abs(float(eqn[:-1]@pr[0]+eqn[-1]))<1e-8:continue
        out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
    return sorted(out)

def main():
    t0=time.time();checks=[]
    pre=json.loads((HERE/'preclassification_certificate.json').read_text())
    assert INDEX in pre['fifth_sphere_exclusive_survivors']
    key=(HERE/'unique_templates.txt').read_text().splitlines()[INDEX]
    assert len(key)==60
    checks.append('preclassification_membership_and_template')
    rs=(3,4,5,6);cs=(1,2,3,4)
    M=[];variables=[];vmap={};templ=[]
    for i in range(10):
        row=[];tr=[]
        for j in range(6):
            z=int(key[6*i+j])-1;tr.append(z)
            if z==0:
                v=sp.symbols(f'x{i}_{j}');variables.append(v);vmap[str(v)]=v;row.append(v)
            else:row.append(sp.Integer(z))
        M.append(row);templ.append(tr)
    M=sp.Matrix(M);ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs]
    equations=list(M.extract(ri,cj)-M.extract(ri,cs)*M.extract(rs,cs).inv()*M.extract(rs,cj))
    free=[vmap[x] for x in ('x3_0','x4_0','x5_0')];deps=[v for v in variables if v not in free]
    sols=sp.solve(equations,deps,dict=True,simplify=False,check=False);assert len(sols)==1;sol=sols[0]
    MM=M.subs(sol).applyfunc(sp.factor)
    pivot=MM.extract(rs,cs);assert pivot.det()==8
    assert all(sp.factor(x)==0 for x in MM.extract(ri,cj)-MM.extract(ri,cs)*pivot.inv()*MM.extract(rs,cj))
    checks.append('unique_exact_rank_four_completion')
    a,b,c=free;A,B,C=sp.symbols('A B C');D=1-A-B-C
    sub={a:D-1,b:-A-B+C,c:-A+B-C}
    # Inverse domain coordinates: A=-(b+c)/2, B=(c-a)/2, C=(b-a)/2, D=1+a.
    assert sp.expand(-(sub[b]+sub[c])/2-A)==0
    assert sp.expand((sub[c]-sub[a])/2-B)==0
    assert sp.expand((sub[b]-sub[a])/2-C)==0
    assert sp.expand(1+sub[a]-D)==0
    assert sp.expand(A+B+C+D-1)==0
    Mc=MM.subs(sub).applyfunc(lambda z:sp.factor(sp.cancel(z)))
    # All fifteen defects are strict on A,B,C,D>0.
    defect_stats={}
    for v in variables:
        z=sp.factor(sol.get(v,v).subs(sub));expr=sp.factor(sp.cancel(1-z*z));num,den=map(sp.factor,sp.fraction(expr));ok,st=positive(num,A,B,C);assert ok
        # all completion denominators are nonzero because they are products of B+C, -(2B+2C+D), and 2A+D
        defect_stats[str(v)]=st
    checks.append('tetrahedral_strict_domain_and_fifteen_defects')
    VM=(pivot.inv()*MM.extract(rs,range(6))).subs(sub).applyfunc(lambda z:sp.factor(sp.cancel(z)))
    FM=Mc.extract(range(10),cs)
    sample={A:sp.Rational(1,10),B:sp.Rational(2,10),C:sp.Rational(3,10)}
    # Every primal column has four independent incident supporting normals.
    ext=[]
    for j in range(6):
        inc=[i for i in range(10) if templ[i][j]!=0];found=None
        for rr in itertools.combinations(inc,4):
            det=sp.factor(sp.cancel(FM.extract(rr,range(4)).det()))
            if det==0:continue
            n,d=map(sp.factor,sp.fraction(det));sn=1 if n.subs(sample)>0 else -1;sd=1 if d.subs(sample)>0 else -1
            okn,stn=positive(sn*n,A,B,C);okd,std=positive(sd*d,A,B,C)
            if okn and okd:found=(rr,str(det));break
        assert found;ext.append(found)
    checks.append('twelve_primal_vertices_extreme')
    Vnum=np.array(VM.subs(sample),float);Fnum=np.array(FM.subs(sample),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);Acode=np.array(templ,int)
    facP=[]
    for i in range(10):
        facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
    facQ=[]
    for j in range(6):
        facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
    hP=ConvexHull(ptsP);hQ=ConvexHull(ptsQ);assert len(hP.vertices)==12 and len(hQ.vertices)==20
    for hull,fac in ((hP,facP),(hQ,facQ)):
        cover=[]
        for tet in hull.simplices:
            T=set(map(int,tet));matches=[i for i,F in enumerate(fac) if T<=set(F)];assert matches;cover.append(matches)
        assert all(any(i in m for m in cover) for i in range(len(fac)))
    tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)]
    assert len(tP)==35 and len(tQ)==67
    checks.append('sample_hulls_match_all_prescribed_facets')
    def ppoint(i):return VM[:,i] if i<6 else -VM[:,i-6]
    def qpoint(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
    def oriented(tets,point):
        terms=[];stats=[]
        for ids in tets:
            det=sp.factor(sp.Matrix.hstack(*[point(i) for i in ids]).det());sg=1 if det.subs(sample)>0 else -1;z=sp.factor(sg*det);n,d=map(sp.factor,sp.fraction(z));sn=1 if n.subs(sample)>0 else -1;sd=1 if d.subs(sample)>0 else -1
            okn,stn=positive(sn*n,A,B,C);okd,std=positive(sd*d,A,B,C);assert okn and okd
            terms.append(z);stats.append((stn,std))
        return terms,stats
    pterms,pstats=oriented(tP,ppoint);qterms,qstats=oriented(tQ,qpoint)
    volP=sp.factor(sp.cancel(sum(pterms)/24));volQ=sp.factor(sp.cancel(sum(qterms)/24))
    expectedP=-(A**2-10*A-B**2-2*B*C+16*B-C**2+16*C+9)/(12*(A-B-C-1))
    expectedQ=4*(13*A**2*B+13*A**2*C-14*A*B**2-32*A*B*C-2*A*B-14*A*C**2-2*A*C+5*B**3+19*B**2*C+6*B**2+19*B*C**2+8*B*C-11*B+5*C**3+6*C**2-11*C)/(3*(B+C)*(A-B-C-1)*(A-B-C+1))
    assert sp.factor(volP-expectedP)==0 and sp.factor(volQ-expectedQ)==0
    checks.append('global_fixed_sign_facet_triangulations_and_exact_volumes')
    margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));num,den=map(sp.factor,sp.fraction(margin));sn=1 if num.subs(sample)>0 else -1;sd=1 if den.subs(sample)>0 else -1
    okn,nstats=positive(sn*num,A,B,C);okd,dstats=positive(sd*den,A,B,C);assert okn and okd
    assert nstats=={'degree':5,'positive':29,'zero':27,'negative':0,'min_positive':'3/5'}
    checks.append('degree_five_simplex_bernstein_mahler_margin')
    out={'status':'PASS','scope':'12V/20F,c=0,D=15','template_index':INDEX,'template_key':key,'domain':'A,B,C,D>0; A+B+C+D=1','rank':4,'defects':15,'primal_vertices':12,'polar_vertices':20,'primal_tetrahedra':len(tP),'polar_tetrahedra':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'margin_numerator_bernstein':nstats,'margin_denominator_bernstein':dstats,'checks':checks,'dependencies_sha256':{'unique_templates.txt':sha(HERE/'unique_templates.txt'),'preclassification_certificate.json':sha(HERE/'preclassification_certificate.json')},'elapsed_seconds':round(time.time()-t0,3),'conclusion':'Mahler product > 32/3 on the full strict tetrahedral domain'}
    (HERE/'family673_verifier_output.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
