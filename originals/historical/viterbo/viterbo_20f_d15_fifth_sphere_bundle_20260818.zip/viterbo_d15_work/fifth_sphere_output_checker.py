#!/usr/bin/env python3
"""Checks the five exact verifier outputs against the D=15 preclassification."""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
FAMS=[240,426,427,673,738]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pre=json.loads((HERE/'preclassification_certificate.json').read_text())
assert sorted(pre['fifth_sphere_exclusive_survivors'])==FAMS
rows={}
for i in FAMS:
 p=HERE/f'family{i}_verifier_output.json';d=json.loads(p.read_text())
 assert d['status']=='PASS' and d['template_index']==i
 assert 'Mahler product > 32/3' in d['conclusion']
 rows[str(i)]={'output':p.name,'sha256':sha(p),'conclusion':d['conclusion']}
out={
 'status':'PASS','scope':'12V/20F,c=0,D=15, fifth g2=4 sphere orbit',
 'exclusive_templates':pre['fifth_sphere_exclusive_templates'],
 'template_classification':pre['fifth_sphere_exclusive_classification'],
 'algebraic_survivors':FAMS,'closed_positive_survivors':FAMS,
 'remaining_survivors_from_fifth_sphere':[],
 'family_outputs':rows,
 'preclassification_sha256':sha(HERE/'preclassification_certificate.json'),
 'conclusion':'Every algebraic survivor contributed exclusively by the fifth cs g2=4 sphere has Mahler product > 32/3 on its full strict realization space.'
}
(HERE/'fifth_sphere_output_checker_output.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
