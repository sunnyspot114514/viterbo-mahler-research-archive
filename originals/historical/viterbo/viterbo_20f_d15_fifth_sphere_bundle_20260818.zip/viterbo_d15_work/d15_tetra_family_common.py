#!/usr/bin/env python3
"""Common exact verifier for a 3-parameter tetrahedral D=15 family.

The caller supplies a CONFIG dictionary.  The verifier reconstructs the
pairing matrix from the canonical sign template and proves, over an open
3-simplex, rank four, strict defects, primal extremality, the prescribed
20-facet cube section, globally valid primal/polar facet triangulations,
exact volumes, and Bernstein positivity of the Mahler margin.
"""
from __future__ import annotations
import sympy as sp
import numpy as np
import itertools, math, json, hashlib, time
from scipy.spatial import ConvexHull
from pathlib import Path
from collections import Counter, defaultdict, deque

HERE=Path(__file__).resolve().parent
A,B,C=sp.symbols('A B C'); D=1-A-B-C
BARY=(A,B,C,D)

def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def simplex_stats(poly):
    """Bernstein coefficients on A,B,C,D>0, A+B+C+D=1."""
    poly=sp.factor(poly)
    if not poly.free_symbols:
        z=sp.Rational(poly)
        return {'degree':0,'positive':int(z>0),'zero':int(z==0),'negative':int(z<0),'min_positive':str(z) if z>0 else None}
    p=sp.Poly(sp.expand(poly),A,B,C,domain='QQ')
    terms=dict(p.terms()); n=max([sum(k) for k in terms] or [0])
    pos=zero=neg=0; mn=None
    for a0 in range(n+1):
      for a1 in range(n-a0+1):
       for a2 in range(n-a0-a1+1):
        alpha=(a0,a1,a2,n-a0-a1-a2); z=sp.Rational(0)
        for beta,coef in terms.items():
            m=sum(beta)
            if all(beta[j]<=alpha[j+1] for j in range(3)):
                multin=math.factorial(m)
                for q in beta: multin//=math.factorial(q)
                numer=math.prod(math.comb(alpha[j+1],beta[j]) for j in range(3))
                z += coef*sp.Rational(numer,math.comb(n,m)*multin)
        z=sp.factor(z)
        if z>0: pos+=1; mn=z if mn is None or z<mn else mn
        elif z==0: zero+=1
        else: neg+=1
    return {'degree':n,'positive':pos,'zero':zero,'negative':neg,'min_positive':str(mn) if mn is not None else None}

def strictly_positive(poly):
    st=simplex_stats(poly)
    return st['negative']==0 and st['positive']>0,st

def factor_sign(poly,sample,cache):
    """Prove every irreducible factor has fixed nonzero sign in the open simplex."""
    poly=sp.factor(poly)
    coeff,factors=sp.factor_list(poly)
    total=1 if coeff>0 else -1
    details=[]
    for f,e in factors:
        val=sp.factor(f.subs(sample)); assert val!=0
        sg=1 if val>0 else -1
        g=sp.factor(sg*f); key=sp.srepr(g)
        if key not in cache: cache[key]=simplex_stats(g)
        st=cache[key]; assert st['negative']==0 and st['positive']>0, (f,st)
        total *= sg**e
        details.append({'factor':str(f),'power':e,'sign':sg,'bernstein':st})
    return total,details

def positive_rational(expr,sample,cache):
    expr=sp.cancel(expr); n,d=map(sp.factor,sp.fraction(expr))
    sn,ncert=factor_sign(n,sample,cache); sd,dcert=factor_sign(d,sample,cache)
    assert sn*sd>0
    return {'numerator':ncert,'denominator':dcert}

def project3(x):
    d=x-x[0]
    return d@np.linalg.svd(d,full_matrices=False)[2][:3].T

def pull(ids,coords):
    ids=sorted(ids)
    if len(ids)==4:return [tuple(ids)]
    pr=project3(coords[ids]); h=ConvexHull(pr); out=set()
    for tri,eqn in zip(h.simplices,h.equations):
        if abs(float(eqn[:-1]@pr[0]+eqn[-1]))<1e-8: continue
        out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
    return sorted(out)

def check_closed_sphere(tets,nverts):
    tets=[tuple(sorted(t)) for t in tets]
    assert len(set(tets))==len(tets)
    tris=Counter(tuple(sorted(f)) for t in tets for f in itertools.combinations(t,3))
    assert set(tris.values())=={2}
    by=defaultdict(list)
    for i,t in enumerate(tets):
        for f in itertools.combinations(t,3): by[tuple(sorted(f))].append(i)
    adj=[set() for _ in tets]
    for ids in by.values():
        if len(ids)==2: adj[ids[0]].add(ids[1]);adj[ids[1]].add(ids[0])
    seen={0};dq=deque([0])
    while dq:
        i=dq.popleft()
        for j in adj[i]:
            if j not in seen:seen.add(j);dq.append(j)
    assert len(seen)==len(tets)
    for v in range(nverts):
        lt=[tuple(x for x in t if x!=v) for t in tets if v in t]
        if not lt:continue
        vs=set(x for t in lt for x in t)
        es=set(tuple(sorted(e)) for t in lt for e in itertools.combinations(t,2))
        assert len(vs)-len(es)+len(lt)==2
    return {'tetrahedra':len(tets),'triangles':len(tris),'vertices_used':len(set(x for t in tets for x in t))}

def check_facet_balls(tets,facets):
    """Check each independently pulled 3D facet triangulation is a connected 3-ball."""
    stats=[]
    for f in facets:
        group=[tuple(t) for t in tets if set(t)<=set(f)]
        assert group and set(x for t in group for x in t)==set(f)
        tri=Counter(tuple(sorted(q)) for t in group for q in itertools.combinations(t,3))
        assert max(tri.values())<=2
        btri=[q for q,n in tri.items() if n==1]
        bvs=set(x for q in btri for x in q);bes=set(tuple(sorted(e)) for q in btri for e in itertools.combinations(q,2))
        assert len(bvs)-len(bes)+len(btri)==2
        adj=[set() for _ in group];by=defaultdict(list)
        for ii,t in enumerate(group):
            for q in itertools.combinations(t,3):by[tuple(sorted(q))].append(ii)
        for ids in by.values():
            if len(ids)==2:adj[ids[0]].add(ids[1]);adj[ids[1]].add(ids[0])
        seen={0};dq=deque([0])
        while dq:
            ii=dq.popleft()
            for jj in adj[ii]:
                if jj not in seen:seen.add(jj);dq.append(jj)
        assert len(seen)==len(group)
        stats.append(len(group))
    return {'tetrahedra':len(tets),'facets':len(facets),'per_facet':stats,'vertices_used':len(set(x for t in tets for x in t))}

def verify(CONFIG):
    t0=time.time(); index=CONFIG['index']; sample={A:sp.Rational(CONFIG['sample'][0]),B:sp.Rational(CONFIG['sample'][1]),C:sp.Rational(CONFIG['sample'][2])}
    assert D.subs(sample)>0
    key=(HERE/'unique_templates.txt').read_text().splitlines()[index]
    assert key==CONFIG['template_key']
    pre=json.loads((HERE/'preclassification_certificate.json').read_text())
    assert index in pre['fifth_sphere_exclusive_survivors']
    rs=tuple(CONFIG['pivot_rows']);cs=tuple(CONFIG['pivot_cols'])
    M=[];variables=[];vmap={};templ=[]
    for i in range(10):
        row=[];tr=[]
        for j in range(6):
            z=int(key[6*i+j])-1;tr.append(z)
            if z==0:
                v=sp.symbols(f'x{i}_{j}');variables.append(v);vmap[str(v)]=v;row.append(v)
            else: row.append(sp.Integer(z))
        M.append(row);templ.append(tr)
    M=sp.Matrix(M);ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs]
    equations=list(M.extract(ri,cj)-M.extract(ri,cs)*M.extract(rs,cs).inv()*M.extract(rs,cj))
    free=[vmap[x] for x in CONFIG['free_variables']];deps=[v for v in variables if v not in free]
    sols=sp.solve(equations,deps,dict=True,simplify=False,check=False);assert len(sols)==1
    sol=sols[0];MM=M.subs(sol).applyfunc(sp.factor)
    sub={free[i]:sp.sympify(CONFIG['substitution'][i],locals={'A':A,'B':B,'C':C,'D':D}) for i in range(3)}
    Mc=MM.subs(sub).applyfunc(lambda z:sp.factor(sp.cancel(z)))
    pivot=Mc.extract(rs,cs);assert sp.factor(pivot.det())==CONFIG['pivot_det']
    assert all(sp.factor(z)==0 for z in Mc.extract(ri,cj)-Mc.extract(ri,cs)*pivot.inv()*Mc.extract(rs,cj))
    # inverse barycentric identities supplied by caller
    invloc={'A':A,'B':B,'C':C,'D':D}
    invloc.update({str(free[i]):sub[free[i]] for i in range(3)})
    for e in CONFIG['inverse_identities']:
        assert sp.factor(sp.sympify(e,locals=invloc))==0,e
    cache={}; defect_stats={}
    for v in variables:
        z=sp.factor(sol.get(v,v).subs(sub));expr=sp.cancel(1-z*z);n,d=map(sp.factor,sp.fraction(expr))
        if n.subs(sample)<0:n=-n;d=-d
        ok,st=strictly_positive(n);assert ok,(v,n,st)
        factor_sign(d,sample,cache)
        defect_stats[str(v)]={'value':str(z),'bernstein_numerator':st}
    VM=(pivot.inv()*Mc.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)))
    FM=Mc.extract(range(10),cs)
    # Every primal column has a globally nonsingular active normal cone.
    extremality=[]
    for j in range(6):
        inc=[i for i in range(10) if templ[i][j]!=0];found=None
        for rr in itertools.combinations(inc,4):
            det=sp.cancel(FM.extract(rr,range(4)).det(method='domain-ge'))
            if det==0:continue
            sg=1 if det.subs(sample)>0 else -1
            try: positive_rational(sg*det,sample,cache)
            except Exception: continue
            found={'column':j,'active_rows':rr,'determinant':str(det)};break
        assert found is not None,j
        extremality.append(found)
    Vnum=np.array(VM.subs(sample),float);Fnum=np.array(FM.subs(sample),float)
    ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);Acode=np.array(templ,int)
    facP=[]
    for i in range(10):
        facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
    facQ=[]
    for j in range(6):
        facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
    hP=ConvexHull(ptsP);hQ=ConvexHull(ptsQ);assert len(hP.vertices)==12 and len(hQ.vertices)==20
    for hull,fac in ((hP,facP),(hQ,facQ)):
        cover=[]
        for tet in hull.simplices:
            T=set(map(int,tet));matches=[i for i,F in enumerate(fac) if T<=set(F)];assert matches;cover.append(matches)
        assert all(any(i in m for m in cover) for i in range(len(fac)))
    tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)]
    assert len(tP)==CONFIG['expected_primal_tetrahedra'] and len(tQ)==CONFIG['expected_polar_tetrahedra']
    sphereP=check_closed_sphere(tP,12); sphereQ=check_facet_balls(tQ,facQ)
    assert all(any(set(t)<=set(f) for f in facP) for t in tP)
    assert all(any(set(t)<=set(f) for f in facQ) for t in tQ)
    def ppoint(i):return VM[:,i] if i<6 else -VM[:,i-6]
    def qpoint(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
    orientation_records=[]
    def oriented(tets,point,label):
        terms=[]
        for ids in tets:
            det=sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'))
            sg=1 if det.subs(sample)>0 else -1;z=sp.cancel(sg*det)
            positive_rational(z,sample,cache)
            terms.append(z);orientation_records.append({'side':label,'simplex':ids,'term':str(z)})
        return terms
    pterms=oriented(tP,ppoint,'primal');qterms=oriented(tQ,qpoint,'polar')
    volP=sp.factor(sp.cancel(sum(pterms)/24));volQ=sp.factor(sp.cancel(sum(qterms)/24))
    margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));nM,dM=map(sp.factor,sp.fraction(margin))
    if margin.subs(sample)<0:raise AssertionError('negative sample margin')
    if nM.subs(sample)<0:nM=-nM;dM=-dM
    okN,stN=strictly_positive(nM);assert okN,stN
    # denominator need only be fixed positive
    positive_rational(dM,sample,cache)
    stD=simplex_stats(dM if dM.subs(sample)>0 else -dM)
    assert stN==CONFIG['expected_margin_numerator'],(stN,CONFIG['expected_margin_numerator'])
    assert stD==CONFIG['expected_margin_denominator'],(stD,CONFIG['expected_margin_denominator'])
    out={
      'status':'PASS','scope':'12V/20F,c=0,D=15','template_index':index,'template_key':key,
      'domain':'A,B,C,D>0; A+B+C+D=1','rank':4,'defects':len(variables),
      'primal_vertices':12,'polar_vertices':20,'primal_boundary':sphereP,'polar_boundary':sphereQ,
      'volume_P':str(volP),'volume_polar':str(volQ),
      'margin_numerator_bernstein':stN,'margin_denominator_bernstein':stD,
      'unique_fixed_sign_factors':len(cache),'elapsed_seconds':round(time.time()-t0,3),
      'dependencies_sha256':{'unique_templates.txt':sha(HERE/'unique_templates.txt'),'preclassification_certificate.json':sha(HERE/'preclassification_certificate.json')},
      'conclusion':'Mahler product > 32/3 on the full strict tetrahedral domain'
    }
    return out
