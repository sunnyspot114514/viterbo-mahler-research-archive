#!/usr/bin/env python3
import sympy as sp,json
from itertools import product,combinations
from math import comb
from collections import Counter,defaultdict,deque
from pathlib import Path
W=Path(__file__).resolve().parent
C=json.load(open(W/'family426_certificate.json'))
X,Y,T=sp.symbols('X Y T');vars=(X,Y,T);loc={'X':X,'Y':Y,'T':T}
def parse(s):return sp.sympify(s,locals=loc)
def bern(poly):
 P=sp.Poly(sp.expand(poly),*vars);ds=P.degree_list();co=dict(P.terms());out=[]
 for ii in product(*[range(d+1) for d in ds]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(ds):f*=sp.Rational(comb(ii[j],kk[j]),comb(d,kk[j]))
    z+=cc*f
  out.append(sp.factor(z))
 return ds,out
def positive_poly(p):
 ds,b=bern(p);return ds,b,(not any(z<0 for z in b) and any(z>0 for z in b))
base={k:sp.factor(parse(v)) for k,v in C['base_positive_factors'].items()}
base_stats={}
for k,p in base.items():
 ds,b,ok=positive_poly(p);assert ok;base_stats[k]=(ds,len([x for x in b if x>0]),len([x for x in b if x==0]),str(min(x for x in b if x>0)))
# Every denominator must be a positive constant times powers of the five certified factors.
def positive_factor_product(e):
 e=sp.factor(e); coeff,facs=sp.factor_list(e)
 for f,powr in facs:
  found=False
  for b in base.values():
   if sp.factor(f-b)==0:found=True;break
   if sp.factor(f+b)==0:
    coeff*=(-1)**powr;found=True;break
  if not found:
   raise AssertionError(f'unknown denominator factor {f}')
 return coeff>0
M=sp.Matrix([[parse(x) for x in row] for row in C['completed_matrix']]);rs=C['pivot_rows'];cs=C['pivot_cols'];P=M.extract(rs,cs)
assert P.det()==C['pivot_det']
ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs]
assert all(sp.factor(z)==0 for z in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
# Domain inversion and the two decisive inequalities.
U=X;V=(1-X)*Y;WW=(1-X)*(1-Y)
b=1-2*V;c=-1+2*WW
a=-U/(U+2*WW)+T*(U/(U+2*V)+U/(U+2*WW))
Fplus=sp.factor(a*(b+c+2)+b-c);Fminus=sp.factor(a*(b+c-2)+b-c)
assert sp.factor(Fplus-4*T*U/(U+2*V))==0
assert sp.factor(Fminus-4*(1-T)*U/(U+2*WW))==0
# Strict defects.
def_stats={}
for name,z in C['defects'].items():
 n=parse(z['numerator']);d=parse(z['denominator']);ds,bb,ok=positive_poly(n);assert ok and positive_factor_product(d)
 def_stats[name]={'degree':ds,'positive':len([x for x in bb if x>0]),'zero':len([x for x in bb if x==0]),'min_positive':str(min(x for x in bb if x>0))}
# Active normal certificates for six primal vertices.
FM=M.extract(range(10),cs)
vertex=[]
for q in C['vertex_certificates']:
 mat=sp.Matrix([[sg*FM[i,k] for k in range(4)] for i,sg in q['active_rows_signs']]);det=sp.factor(mat.det());target=parse(q['determinant']);assert sp.factor(det-target)==0
 n,d=map(sp.factor,sp.together(det).as_numer_denom());
 if d.subs({X:sp.Rational(1,2),Y:sp.Rational(1,2),T:sp.Rational(1,2)})<0:n=-n;d=-d
 if n.subs({X:sp.Rational(1,2),Y:sp.Rational(1,2),T:sp.Rational(1,2)})<0:n=-n
 if not positive_factor_product(d):raise AssertionError('vertex denominator')
 ds,bb,ok=positive_poly(n);assert ok
 vertex.append({'column':q['column'],'determinant':str(det)})
# Combinatorial closed-sphere checks for triangulated primal and polar boundaries.
def check_sphere(tets,nverts):
 tets=[tuple(sorted(t)) for t in tets];assert len(set(tets))==len(tets)
 tri=Counter(tuple(sorted(f)) for t in tets for f in combinations(t,3));assert set(tri.values())=={2}
 # tetra adjacency connected
 bytri=defaultdict(list)
 for i,t in enumerate(tets):
  for f in combinations(t,3):bytri[tuple(sorted(f))].append(i)
 adj=[set() for _ in tets]
 for ids in bytri.values():
  if len(ids)==2:adj[ids[0]].add(ids[1]);adj[ids[1]].add(ids[0])
 seen={0};dq=deque([0])
 while dq:
  i=dq.popleft()
  for j in adj[i]:
   if j not in seen:seen.add(j);dq.append(j)
 assert len(seen)==len(tets)
 # each used vertex link has Euler characteristic 2 and connected triangle adjacency
 for v in range(nverts):
  lt=[tuple(x for x in t if x!=v) for t in tets if v in t]
  if not lt:continue
  vs=set(x for t in lt for x in t);es=set(tuple(sorted(e)) for t in lt for e in combinations(t,2));assert len(vs)-len(es)+len(lt)==2
 return {'tetrahedra':len(tets),'triangles':len(tri),'vertices_used':len(set(x for t in tets for x in t))}
spP=check_sphere(C['primal_tetrahedra'],12);spQ={'tetrahedra':len(C['polar_tetrahedra']),'vertices_used':len(set(x for t in C['polar_tetrahedra'] for x in t))}
# Each tetrahedron lies in one prescribed supporting facet.
key=C['template_key'];A=[[int(key[6*i+j])-1 for j in range(6)] for i in range(10)]
facP=[]
for i in range(10):
 facP += [set(j if A[i][j]==1 else j+6 for j in range(6) if A[i][j]),set(j+6 if A[i][j]==1 else j for j in range(6) if A[i][j])]
facQ=[]
for j in range(6):
 facQ += [set(i if A[i][j]==1 else i+10 for i in range(10) if A[i][j]),set(i+10 if A[i][j]==1 else i for i in range(10) if A[i][j])]
assert all(any(set(t)<=f for f in facP) for t in C['primal_tetrahedra'])
assert all(any(set(t)<=f for f in facQ) for t in C['polar_tetrahedra'])
# Each independently pulled polar-facet triangulation is a connected tetrahedral 3-ball.
for f in facQ:
 group=[tuple(t) for t in C['polar_tetrahedra'] if set(t)<=f]
 assert group and set(x for t in group for x in t)==f
 tri=Counter(tuple(sorted(q)) for t in group for q in combinations(t,3));assert max(tri.values())<=2
 btri=[q for q,n in tri.items() if n==1];bvs=set(x for q in btri for x in q);bes=set(tuple(sorted(e)) for q in btri for e in combinations(q,2));assert len(bvs)-len(bes)+len(btri)==2
 # tetra adjacency through internal triangles
 adj=[set() for _ in group];by=defaultdict(list)
 for ii,t in enumerate(group):
  for q in combinations(t,3):by[tuple(sorted(q))].append(ii)
 for ids in by.values():
  if len(ids)==2:adj[ids[0]].add(ids[1]);adj[ids[1]].add(ids[0])
 seen={0};dq=deque([0])
 while dq:
  ii=dq.popleft()
  for jj in adj[ii]:
   if jj not in seen:seen.add(jj);dq.append(jj)
 assert len(seen)==len(group)
# Oriented simplex terms are positive and sum to the exact volumes.
cache={}
def check_terms(records):
 out=[]
 for r in records:
  z=parse(r['term']);n=parse(r['numerator']);d=parse(r['denominator']);assert sp.factor(z-n/d)==0 and positive_factor_product(d)
  k=str(n)
  if k not in cache:
   ds,bb,ok=positive_poly(n);assert ok;cache[k]=(ds,len([x for x in bb if x>0]),len([x for x in bb if x==0]),str(min(x for x in bb if x>0)))
  out.append(z)
 return out
pt=check_terms(C['primal_terms']);qt=check_terms(C['polar_terms']);volP=parse(C['volume_P']);volQ=parse(C['volume_polar'])
assert sp.factor(sum(pt)/24-volP)==0
assert sp.factor(sum(qt)/24-volQ)==0
# Mahler margin.
nM=parse(C['margin_numerator']);dM=parse(C['margin_denominator']);assert positive_factor_product(dM);degM,bM,ok=positive_poly(nM);assert ok
assert sp.factor(volP*volQ-sp.Rational(32,3)-nM/dM)==0
out={'status':'PASS','template_index':426,'rank':4,'strict_defects':len(def_stats),'primal_boundary':spP,'polar_boundary':spQ,'unique_oriented_numerators':len(cache),'margin_degree':degM,'margin_positive':len([x for x in bM if x>0]),'margin_zero':len([x for x in bM if x==0]),'margin_negative':len([x for x in bM if x<0]),'margin_min_positive':str(min(x for x in bM if x>0)),'conclusion':'Mahler product > 32/3 on the full strict domain'}
(W/'family426_verifier_output.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
