#!/usr/bin/env python3
import json
from pathlib import Path
from d15_tetra_family_common import verify
CONFIG={
 'index':738,
 'template_key':'112000120000120012120122120220122022200101200212201102210002',
 'pivot_rows':[1,2,4,7],'pivot_cols':[1,2,3,5],'pivot_det':8,
 'free_variables':['x1_0','x2_0','x4_0'],
 'substitution':['1-2*(A+B)','1-2*A','2*D-1'],
 'inverse_identities':['(1-x2_0)/2-A','(x2_0-x1_0)/2-B','(x1_0-x4_0)/2-C','(1+x4_0)/2-D'],
 'sample':['1/10','2/10','3/10'],
 'expected_primal_tetrahedra':35,'expected_polar_tetrahedra':69,
 'expected_margin_numerator':{'degree':8,'positive':30,'zero':135,'negative':0,'min_positive':'1/35'},
 'expected_margin_denominator':{'degree':7,'positive':20,'zero':100,'negative':0,'min_positive':'3/14'}
}
if __name__=='__main__':
 out=verify(CONFIG);p=Path(__file__).with_name('family738_verifier_output.json');p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
