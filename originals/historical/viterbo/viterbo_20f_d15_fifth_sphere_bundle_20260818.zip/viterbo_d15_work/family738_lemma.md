# Exact closure of D=15 Family 738

Family 738 is a rank-four three-parameter family in the 12V/20F, c=0, D=15 classification.

With free variables \(p=x_{1,0},q=x_{2,0},r=x_{4,0}\), its strict domain is

\[
-1<r<p<q<1,\qquad p-q-r+1>0.
\]

It is exactly the open simplex

\[
A=(1-q)/2,
\quad B=(q-p)/2,
\quad C=(p-r)/2,
\quad D=(1+r)/2,
\]

with \(A,B,C,D>0\) and \(A+B+C+D=1\).

The primal volume is

\[
|P|=\frac{AC+6A+6C}{6(A+C)}.
\]

The exact verifier proves rank four, all 15 strict defects, 12 primal vertices, 20 polar vertices, globally fixed facet triangulations, and an exact Mahler margin. The degree-8 simplex Bernstein coefficients of the positive margin numerator satisfy

\[
30>0,\qquad135=0,\qquad0<0,
\]

with minimum positive coefficient \(1/35\). Hence

\[
|P||P^\circ|>32/3
\]

on the full strict domain.
