# Exact closure of D=15 Family 427

Family 427 is a rank-four three-parameter family in the 12V/20F, c=0, D=15 classification.

With free variables \(p=x_{0,0},q=x_{1,0},r=x_{5,0}\), the strict domain is

\[
-1<p,q,r<1,\quad p<q,\quad q>r,\quad p-q+r<-1,\quad p-2q+r+2<0.
\]

It is exactly the open simplex

\[
A=1-q,
\quad B=(2q-p-r-2)/2,
\quad C=(1+r)/2,
\quad D=(1+p)/2,
\]

with \(A,B,C,D>0\) and \(A+B+C+D=1\).

The exact verifier proves rank four, all 15 strict defects, 12 primal vertices, 20 polar vertices, globally fixed facet triangulations, and an exact Mahler margin. The degree-8 simplex Bernstein coefficients of the positive margin numerator satisfy

\[
82>0,\qquad83=0,\qquad0<0,
\]

with minimum positive coefficient \(8/21\). Hence

\[
|P||P^\circ|>32/3
\]

on the full strict domain.
