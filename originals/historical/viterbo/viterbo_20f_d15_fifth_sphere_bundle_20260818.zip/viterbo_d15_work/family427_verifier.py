#!/usr/bin/env python3
import json
from pathlib import Path
from d15_tetra_family_common import verify
CONFIG={
 'index':427,
 'template_key':'112000112002120000120012120122122022200101200212202102210002',
 'pivot_rows':[2,4,5,8],'pivot_cols':[1,2,4,5],'pivot_det':-8,
 'free_variables':['x0_0','x1_0','x5_0'],
 'substitution':['2*D-1','1-A','2*C-1'],
 'inverse_identities':['1-x1_0-A','(2*x1_0-x0_0-x5_0-2)/2-B','(1+x5_0)/2-C','(1+x0_0)/2-D'],
 'sample':['1/10','2/10','3/10'],
 'expected_primal_tetrahedra':35,'expected_polar_tetrahedra':70,
 'expected_margin_numerator':{'degree':8,'positive':82,'zero':83,'negative':0,'min_positive':'8/21'},
 'expected_margin_denominator':{'degree':7,'positive':54,'zero':66,'negative':0,'min_positive':'18/7'}
}
if __name__=='__main__':
 out=verify(CONFIG);p=Path(__file__).with_name('family427_verifier_output.json');p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
