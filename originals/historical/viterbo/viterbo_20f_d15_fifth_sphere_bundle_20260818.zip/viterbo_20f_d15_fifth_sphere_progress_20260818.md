# 四维中心对称 Mahler：20F、D=15 第五个 g₂=4 球轨道完整关闭

日期：2026-08-18

## 结论

在

\[
12V/20F,\qquad c=0,\qquad D=15
\]

的精确预分类中，直接枚举得到五个中心对称 simplicial 3-sphere 组合轨道。第五个轨道是此前“一对中心对称 bistellar moves”构造遗漏的类型。

该轨道独占的 pairing templates 总数为

\[
104=90\text{ 个 rank}\ge5+9\text{ 个重复 facet rows}+5\text{ 个 algebraic survivors}.
\]

五个 survivors 的 canonical indices 为

\[
\boxed{240,\ 426,\ 427,\ 673,\ 738}.
\]

本轮完成 426、427、673、738 的 exact rank completion、严格 realization-space 认证、12 个 primal vertices、20 个 polar vertices、全域 facet triangulation、精确体积和 Bernstein 正余量。连同此前已完成的 240，得到

\[
\boxed{
\text{第五个 }g_2=4\text{ 球轨道的五个 algebraic survivors 全部满足}
\quad |P||P^\circ|>\frac{32}{3}.
}
\]

因此第五个球轨道在当前 bounded-12、20F、D=15 分类中已经整体关闭为 **computer-assisted analytic proof candidate**。

---

## 1. Family 240

该族的 strict realization space 为

\[
(0,1)\times\Delta_2^\circ.
\]

独立 verifier 认证：

- rank 恰为 4；
- 15 个 defects 全部严格；
- 固定 triangulation 使用 36 个 primal tetrahedra 和 68 个 polar-facet tetrahedra；
- Mahler 正余量的 Bernstein tensor degree 为 \((4,4,2)\)；
- 系数统计：
  \[
  65>0,\qquad10=0,\qquad0<0,
  \]
  最小严格正系数为 \(5/8\)。

因此

\[
\mathcal P(P)>\frac{32}{3}.
\]

---

## 2. Family 426

令

\[
U=X,\qquad V=(1-X)Y,\qquad W=(1-X)(1-Y),
\]

则 \(U,V,W>0\) 且 \(U+V+W=1\)。原始三个自由参数可写成

\[
b=1-2V,\qquad c=-1+2W,
\]

\[
a=-\frac{U}{U+2W}
+T\left(\frac{U}{U+2V}+\frac{U}{U+2W}\right),
\qquad0<X,Y,T<1.
\]

所以整个 strict realization space 被单位开立方体有理双射覆盖。

独立 exact verifier 认证：

- rank 恰为 4；
- 15 个 defects 全部严格；
- 六对 primal vertices 全部 extreme；
- primal boundary 使用 35 个 tetrahedra；
- polar facets 共使用 69 个 tetrahedra；
- Mahler 余量正分子的 tensor degree 为
  \[
  (11,10,4);
  \]
- 660 个 Bernstein coefficients 中
  \[
  486>0,\qquad174=0,\qquad0<0,
  \]
  最小严格正系数为
  \[
  \frac1{77}.
  \]

因此

\[
\boxed{\mathcal P(P)>\frac{32}{3}}
\]

贯穿整个 strict domain。

---

## 3. Family 427

取三个自由 defects

\[
p=x_{0,0},\qquad q=x_{1,0},\qquad r=x_{5,0}.
\]

rank-four completion 唯一确定其余 12 个 defects，其中包括

\[
x_{2,0}=p-q+1,
\qquad
x_{3,0}=p-q+r+2,
\]

\[
x_{1,1}=-\frac{p-3q+r+3}{p-q+r+1},
\qquad
x_{3,4}=-\frac{2p-q+r+2}{q-r}.
\]

完整 strict domain 等价于

\[
-1<p,q,r<1,
\quad p<q,
\quad q>r,
\]

\[
p-q+r<-1,
\qquad
p-2q+r+2<0.
\]

它正好是一个开四面体。令

\[
A=1-q,
\quad
B=\frac{2q-p-r-2}{2},
\quad
C=\frac{1+r}{2},
\quad
D=\frac{1+p}{2},
\]

则

\[
A,B,C,D>0,
\qquad
A+B+C+D=1.
\]

反向参数化为

\[
p=2D-1,
\qquad
q=1-A,
\qquad
r=2C-1.
\]

exact verifier 认证：

- constant pivot determinant 为 \(-8\)；
- 15 个 defects 全部严格；
- 12 个 primal vertices 和 20 个 polar vertices 全部保留；
- primal boundary 使用 35 个 tetrahedra；
- 12 个 polar facets 共使用 70 个 tetrahedra；
- 所有 oriented simplex determinants 在整个开四面体上保持固定严格符号；
- Mahler 余量正分子的 degree-8 simplex Bernstein coefficients 为
  \[
  82>0,\qquad83=0,\qquad0<0,
  \]
  最小严格正系数为
  \[
  \frac8{21};
  \]
- denominator 的 degree-7 simplex Bernstein coefficients 为
  \[
  54>0,\qquad66=0,
  \]
  最小严格正系数为 \(18/7\)。

所以

\[
\boxed{\mathcal P(P)>\frac{32}{3}}.
\]

---

## 4. Family 673

取

\[
a=x_{3,0},\qquad b=x_{4,0},\qquad c=x_{5,0}.
\]

完整 strict domain 为

\[
-1<a,b,c<1,
\qquad b+c<0,
\qquad a<b,
\qquad a<c.
\]

令

\[
A=-\frac{b+c}{2},
\quad
B=\frac{c-a}{2},
\quad
C=\frac{b-a}{2},
\quad
D=1+a,
\]

则

\[
A,B,C,D>0,
\qquad
A+B+C+D=1.
\]

反向参数化为

\[
a=D-1,
\quad
b=-A-B+C,
\quad
c=-A+B-C.
\]

精确体积为

\[
|P|=
-\frac{A^2-10A-B^2-2BC+16B-C^2+16C+9}
{12(A-B-C-1)}.
\]

polar volume 亦得到显式有理式。固定 triangulations 分别使用

\[
35\text{ 个 primal tetrahedra},
\qquad
67\text{ 个 polar tetrahedra}.
\]

Mahler 余量正分子的 degree-5 simplex Bernstein 系数为

\[
29>0,
\qquad27=0,
\qquad0<0,
\]

最小严格正系数为

\[
\frac35.
\]

因此

\[
\boxed{\mathcal P(P)>\frac{32}{3}}.
\]

---

## 5. Family 738

取

\[
p=x_{1,0},
\qquad q=x_{2,0},
\qquad r=x_{4,0}.
\]

完整 strict domain 为

\[
\boxed{
-1<r<p<q<1,
\qquad p-q-r+1>0.
}
\]

它也是一个开四面体。令

\[
A=\frac{1-q}{2},
\quad
B=\frac{q-p}{2},
\quad
C=\frac{p-r}{2},
\quad
D=\frac{1+r}{2},
\]

则

\[
A,B,C,D>0,
\qquad
A+B+C+D=1,
\]

反向参数化为

\[
p=1-2(A+B),
\qquad
q=1-2A,
\qquad
r=2D-1.
\]

rank-four completion 唯一确定其余 defects，例如

\[
x_{0,1}=x_{2,4}=x_{7,4}
=\frac{A-C}{A+C},
\]

\[
x_{3,3}=x_{9,1}
=-\frac{A-C}{A+C}.
\]

精确 primal volume 大幅简化为

\[
\boxed{
|P|=\frac{AC+6A+6C}{6(A+C)}.
}
\]

exact verifier 进一步认证：

- rank 恰为 4；
- 15 个 defects 全部严格；
- 12 个 primal vertices 和 20 个 polar vertices 全部保留；
- primal boundary 使用 35 个 tetrahedra；
- 12 个 polar facets 共使用 69 个 tetrahedra；
- Mahler 余量正分子的 degree-8 simplex Bernstein 系数为
  \[
  30>0,\qquad135=0,\qquad0<0,
  \]
  最小严格正系数为
  \[
  \frac1{35};
  \]
- denominator 的 degree-7 simplex Bernstein 系数为
  \[
  20>0,\qquad100=0,
  \]
  最小严格正系数为 \(3/14\)。

所以

\[
\boxed{\mathcal P(P)>\frac{32}{3}}.
\]

---

## 6. 对 D=15 全层状态的更新

完整预分类仍为

\[
748
=
669\text{ 个 rank}\ge5
+
51\text{ 个重复 facet rows}
+
28\text{ 个 algebraic survivors}.
\]

现在 28 个 survivors 中已经完成：

- vertex loss：
  \[
  44,\ 342;
  \]
- Mahler 严格正：
  \[
  240,\ 426,\ 427,\ 673,\ 738.
  \]

因此：

\[
\boxed{
748
=
669+51
+2\text{ 个 vertex-loss}
+5\text{ 个 Mahler-positive}
+21\text{ 个 remaining survivors}.
}
\]

剩余 indices 为

\[
50,86,183,244,272,281,284,286,374,396,497,
509,512,514,541,675,683,728,736,739,747.
\]

下一阶段应从前四个 sphere orbits 的 21 个 survivors 中，优先寻找：

1. 固定 primal convex-combination relations；
2. 重复或 antipodal columns；
3. forced extra section vertices；
4. 可归约为 simplex / product-simplex 的低维 realization spaces；
5. two-slab cap overlap 的统一体积公式。

---

## 证明标准说明

本报告中的勾号表示 **computer-assisted analytic proof candidate**：

- 离散 sign templates 来自完整 exact enumeration；
- rank completion 使用精确有理代数；
- realization domains 由显式双射和 Bernstein 证书验证；
- 体积来自全域定号的 facet triangulations；
- Mahler 余量由全非负且含严格正项的 Bernstein 表认证；
- 独立 verifier 均返回 `PASS`。

结果尚未经过第三方同行审阅，也尚未整理成正式论文与统一依赖锁定的发布包。它仍然属于四维 symmetric Mahler 猜想的 bounded-12 有限核心，并不等于完整四维猜想已经解决。
