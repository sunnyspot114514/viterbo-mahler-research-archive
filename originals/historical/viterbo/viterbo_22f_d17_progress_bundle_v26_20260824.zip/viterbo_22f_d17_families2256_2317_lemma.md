# Families 2256 and 2317: exact closure in the 12V/22F, D=17 layer

Date: 2026-08-24

## Scope

This note concerns the four-dimensional centrally symmetric Mahler problem inside the bounded-12 finite-core program, specifically

\[
12V/22F,\qquad c=0,\qquad D=17.
\]

Every checkmark below means a **computer-assisted analytic proof candidate**. It is not a claim of external peer review or of a complete proof of the unrestricted four-dimensional conjecture.

## 1. Family 2256

Choose the constant pivot

\[
X_{\{2,3,4,7\},\{1,2,3,4\}},\qquad \det=8.
\]

A strict rank-four equation contains the factor

\[
(-x_{2,0}+x_{3,0})(x_{7,5}+1)=0.
\]

Since \(|x_{7,5}|<1\), the second factor is nonzero and therefore

\[
x_{2,0}=x_{3,0}=:a.
\]

Let

\[
b=x_{7,5},\qquad c=x_{8,2}.
\]

The remaining Schur equations uniquely determine every dependent defect. Representative formulas are

\[
x_{0,1}=x_{1,1}=\frac{bc-3b-c-1}{bc+b-c-5},
\]

\[
x_{9,1}=x_{10,1}=\frac{ac+3a+c-1}{ac-a+c+3},
\]

\[
x_{4,0}=x_{5,0}=-\frac{ac-a+c+1}{2}.
\]

The full strict domain is exactly

\[
-1<b,c<1,\qquad -\frac{b+1}{3-b}<a<1.
\]

It is rationally equivalent to the open unit cube through

\[
b=2B-1,\qquad c=2C-1,
\]

\[
a=\frac{2A-B}{2-B},\qquad 0<A,B,C<1.
\]

The exact combinatorial interface is transported from source local matching 1597, sphere orbit 7. The verifier certifies

\[
\operatorname{rank}X=4,\quad f_0(P)=12,\quad f_0(P^\circ)=22,
\]

with 32 primal tetrahedra and 77 polar-facet tetrahedra.

The Mahler-margin numerator has tensor Bernstein degree

\[
(3,6,6),
\]

with

\[
160>0,\qquad 36=0,\qquad 0<0,
\]

and minimum positive coefficient \(4/15\). The denominator certificate has degree \((2,4,3)\), with 45 positive and 15 zero coefficients, minimum positive coefficient 3. Hence

\[
\boxed{|P||P^\circ|>32/3}
\]

throughout the full strict realization space.

## 2. Family 2317

Choose the constant pivot

\[
X_{\{0,1,2,4\},\{2,3,4,5\}},\qquad \det=8.
\]

A strict rank-four equation is

\[
(1-x_{10,1})(x_{3,5}-x_{6,5})=0.
\]

Since \(x_{10,1}<1\), the strict branch forces

\[
x_{3,5}=x_{6,5}=:q.
\]

Set

\[
p=x_{10,1},\qquad r=x_{4,0}.
\]

The unique rational completion includes

\[
x_{2,0}=-\frac{pqr-pr+qr-2q-5r-6}{pq-p-q-3},
\]

\[
x_{8,5}=-\frac{pqr-pq-pr-p+qr-q-3r-3}{2(p-r)},
\]

\[
x_{5,3}=\frac{pqr+3pq-pr+p-3qr-q-5r-3}{(p+1)(qr-q-r-3)}.
\]

The complete strict domain is

\[
-1<p<1,
\qquad
-1<r<\frac{p-1}{p+3},
\]

\[
-1<q<\frac{p(1-r)-5r-3}{(p+1)(1-r)}.
\]

A rational unit-cube chart is

\[
p=2A-1,
\]

\[
r=\frac{2AB-A-1}{A+1},
\]

\[
q=\frac{2ABC-2AC-AB+A+2BC-2C+1}{AB-A-1},
\qquad 0<A,B,C<1.
\]

The source-sphere transport comes from local matching 2065, sphere orbit 8. The verifier certifies

\[
\operatorname{rank}X=4,\quad f_0(P)=12,\quad f_0(P^\circ)=22,
\]

using 32 primal and 79 polar-facet tetrahedra.

The polar tetrahedron sum is algebraically large. Instead of relying on a generic symbolic `cancel`, the verifier proves that every tetrahedral denominator divides an explicit global common denominator, accumulates the numerators as exact multivariate `Poly` objects, and forms the Mahler margin before Bernstein conversion. This is a replayable exact certificate, not a numerical simplification heuristic.

The resulting margin numerator has tensor Bernstein degree

\[
(11,8,5),
\]

with

\[
468>0,\qquad 180=0,\qquad 0<0,
\]

and minimum positive coefficient \(128/1155\). The denominator has degree \((9,7,3)\), with 230 positive and 90 zero coefficients, minimum positive coefficient \(16/49\). Consequently

\[
\boxed{|P||P^\circ|>32/3}
\]

throughout the full strict realization space.

## 3. Updated accounting

The 2395 canonical templates are now partitioned as

\[
\begin{aligned}
2395={}&1230\text{ facet containments}
+1070\text{ rank-}\ge5\\
&+22\text{ segment vertex losses}
+4\text{ duplicate/antipodal primal pairs}\\
&+13\text{ exact Mahler-positive families}
+13\text{ strict boundary/impossible families}\\
&+43\text{ remaining survivors}.
\end{aligned}
\]

At the original 121-survivor level,

\[
121=26+22+4+13+13+43.
\]

Both new family verifiers and the updated aggregate accounting verifier return `PASS`.
