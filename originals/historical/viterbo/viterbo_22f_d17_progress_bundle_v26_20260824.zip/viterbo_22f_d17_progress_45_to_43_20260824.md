# 4D symmetric Mahler bounded-12 progress: D=17 survivors 45 -> 43

Date: 2026-08-24

## Main result

Two additional genuine continuous families in

\[
12V/22F,\qquad c=0,\qquad D=17
\]

have been fully closed:

\[
\boxed{2256,\ 2317\quad\checkmark}.
\]

Each family now has a unique strict rank-four completion, an exact rational parameterization of its full realization space, exact 12-primal/22-polar vertex closure, source-sphere-compatible boundary triangulations, exact volume formulas, and a Bernstein-positive Mahler margin.

The remaining D=17 algebraic survivors fall from

\[
45\longrightarrow\boxed{43}.
\]

## Family 2256

- Constant pivot determinant: 8.
- Full strict domain:
  \[
  -1<b,c<1,\qquad -(b+1)/(3-b)<a<1.
  \]
- Unit-cube chart:
  \[
  b=2B-1,\quad c=2C-1,\quad a=(2A-B)/(2-B).
  \]
- Boundary data: 32 primal tetrahedra, 77 polar tetrahedra.
- Margin numerator Bernstein degree: \((3,6,6)\).
- Coefficients: 160 positive, 36 zero, no negative.
- Minimum positive coefficient: \(4/15\).

## Family 2317

- Constant pivot determinant: 8.
- Full strict domain:
  \[
  -1<p<1,\quad -1<r<(p-1)/(p+3),
  \]
  \[
  -1<q<[p(1-r)-5r-3]/[(p+1)(1-r)].
  \]
- Exact rational unit-cube chart in variables \((A,B,C)\).
- Boundary data: 32 primal tetrahedra, 79 polar tetrahedra.
- Margin numerator Bernstein degree: \((11,8,5)\).
- Coefficients: 468 positive, 180 zero, no negative.
- Minimum positive coefficient: \(128/1155\).

Family 2317 required a custom exact common-denominator accumulation for the large polar tetrahedron sum. Every term denominator is proved to divide an explicit global denominator; numerator accumulation is performed in the polynomial ring before the Mahler margin is formed. This avoids treating a generic symbolic simplifier as part of the proof.

## Updated D=17 accounting

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ facet containment}
+1070\text{ rank}\ge5\\
&+22\text{ segment vertex-loss}
+4\text{ duplicate/antipodal pair}\\
&+13\text{ exact Mahler-positive}
+13\text{ boundary/impossible}\\
&+43\text{ remaining}.
\end{aligned}}
\]

The aggregate verifier independently reruns both family verifiers, checks certificate hashes, verifies category disjointness, and confirms both the 2395-template and 121-survivor totals. It returns `PASS`.

## Scope warning

These results remain computer-assisted analytic proof candidates within the bounded-12 finite core. They do not by themselves prove the unrestricted four-dimensional symmetric Mahler conjecture. A complexity-independent finite-core or bi-shadow-rigid reduction theorem is still required.
