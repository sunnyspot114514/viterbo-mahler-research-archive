#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/mnt/data')
OLD = ROOT / 'viterbo_22f_d17_progress_accounting_certificate_v8.json'
OLDOUT = ROOT / 'viterbo_22f_d17_progress_accounting_verifier_output_v8.json'
PRE = ROOT / 'viterbo_22f_d17_preclassification_certificate.json'
CERT = ROOT / 'viterbo_22f_d17_progress_accounting_certificate_v9.json'
OUT = ROOT / 'viterbo_22f_d17_progress_accounting_verifier_output_v9.json'
CIDS = (2256, 2317)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rerun_family(cid: int) -> dict:
    script = ROOT / f'viterbo_22f_d17_family{cid}_verifier.py'
    outpath = ROOT / f'viterbo_22f_d17_family{cid}_verifier_output.json'
    cp = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True,
        text=True,
        timeout=900,
    )
    if cp.returncode != 0:
        raise AssertionError({
            'cid': cid,
            'returncode': cp.returncode,
            'stdout_tail': cp.stdout[-5000:],
            'stderr_tail': cp.stderr[-5000:],
        })
    fam = json.loads(outpath.read_text())
    assert fam['status'] == 'PASS'
    assert fam['canonical_id'] == cid
    assert fam['rank'] == 4
    assert fam['strict_defects'] == 17
    assert fam['primal_vertices'] == 12
    assert fam['polar_vertices'] == 22
    assert fam['tetrahedra_primal'] == 32
    expected_polar = {2256: 77, 2317: 79}[cid]
    assert fam['tetrahedra_polar'] == expected_polar
    cert_path = Path(fam['certificate'])
    assert sha(cert_path) == fam['certificate_sha256']
    return {
        'script_sha256': sha(script),
        'output_sha256': sha(outpath),
        'certificate_sha256': fam['certificate_sha256'],
        'status': 'PASS',
        'tetrahedra_primal': fam['tetrahedra_primal'],
        'tetrahedra_polar': fam['tetrahedra_polar'],
        'margin_certificate': fam['margin_certificate'],
    }


def main() -> None:
    old = json.loads(OLD.read_text())
    oldout = json.loads(OLDOUT.read_text())
    assert old['status'] == 'PASS'
    assert oldout['status'] == 'PASS'
    assert sha(PRE) == old['source_hashes'][str(PRE)]

    oldrem = set(old['remaining_ids'])
    assert set(CIDS) <= oldrem

    rerun = {str(cid): rerun_family(cid) for cid in CIDS}

    remaining = sorted(oldrem - set(CIDS))
    mahler = sorted(set(old['Mahler_positive_exact_families']) | set(CIDS))
    boundary = list(old['strict_rank4_boundary_or_interval_impossible'])

    disjoint = {
        'facet_containment': 1230,
        'rank_ge_5_after_antichain': 1070,
        'segment_loss_after_antichain': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler),
        'strict_rank4_boundary_or_interval_impossible': len(boundary),
        'remaining_algebraic_survivors': len(remaining),
    }
    assert sum(disjoint.values()) == 2395

    survivor = {
        'initial': 121,
        'facet_containment': 26,
        'additional_segment_loss': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler),
        'strict_rank4_boundary_or_interval_impossible': len(boundary),
        'remaining': len(remaining),
    }
    assert sum(v for k, v in survivor.items() if k != 'initial') == survivor['initial']

    cert = {
        'status': 'PASS',
        'scope': old['scope'],
        'scope_warning': old['scope_warning'],
        'total_pairing_templates': 2395,
        'disjoint_classification': disjoint,
        'survivor_level_accounting': survivor,
        'Mahler_positive_exact_families': mahler,
        'strict_rank4_boundary_or_interval_impossible': boundary,
        'remaining_ids': remaining,
        'newly_closed': {'Mahler_positive_exact': list(CIDS)},
        'rerun_results': rerun,
        'source_hashes': {
            str(OLD): sha(OLD),
            str(OLDOUT): sha(OLDOUT),
            str(PRE): sha(PRE),
        },
    }
    CERT.write_text(json.dumps(cert, indent=2, sort_keys=True))

    result = {
        'status': 'PASS',
        'total_pairing_templates': 2395,
        'initial_algebraic_survivors': 121,
        'Mahler_positive_exact_families': mahler,
        'newly_closed': list(CIDS),
        'remaining_algebraic_survivors': len(remaining),
        'remaining_ids': remaining,
        'accounting_certificate': str(CERT),
        'accounting_certificate_sha256': sha(CERT),
        'reruns': rerun,
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
