#!/usr/bin/env python3
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
TRANS=Path('/mnt/data/f2256_transport.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family2256_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family2256_verifier_output.json')
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
CID=2256

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:
    z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=v
 rr=(2,3,4,7);cc=(1,2,3,4);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ)
 eq=[sp.factor(sp.cancel(e)) for e in S]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 relation=-(x['x2_0']-x['x3_0'])*(x['x7_5']+1)
 assert base.proportional_member(rem,relation)
 a,b,c=sp.symbols('a b c',real=True)
 D1=sp.factor(b*c+b-c-5);D2=sp.factor(a*c-a+c+3)
 f=sp.factor((b*c-3*b-c-1)/D1)
 g=sp.factor((a*c+3*a+c-1)/D2)
 st=dict(const);st.update({x['x2_0']:a,x['x3_0']:a,x['x7_5']:b,x['x8_2']:c,x['x0_1']:f,x['x1_1']:f,x['x9_1']:g,x['x10_1']:g})
 sol={z:base.apply_all(z,st) for z in vs}
 X=M.subs(sol).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(sp.cancel(e.subs(sol)))==0 for e in eq)
 assert all(not (e.free_symbols&set(vs)) for e in sol.values())
 return rec,rows,M,vs,X,(a,b,c),rr,cc,sol,trace,D1,D2,relation

def main():
 rec,rows,M,vs,X,free,rr,cc,sol,trace,D1,D2,relation=build_branch();a,b,c=free
 A,B,C=sp.symbols('A B C',real=True)
 chart={b:2*B-1,c:2*C-1,a:sp.factor((2*A-B)/(2-B))};cv=(A,B,C)
 sample={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)}
 eng=base.SignEngine(cv,sample)
 coeff={
  'two_minus_B':eng.positive_rational(2-B,'2-B'),
  'minus_D1':eng.positive_rational((-D1).subs(chart),'-D1'),
  'D2':eng.positive_rational(D2.subs(chart),'D2'),
  'strict_relation_factor':eng.positive_rational((b+1).subs(chart),'b+1'),
 }
 # Verify domain equivalence for the only nonautomatic defect pair.
 lower=sp.factor(-(b+1)/(3-b));invA=sp.factor((a-lower)/(1-lower))
 assert sp.factor(invA.subs(chart)-A)==0
 X=X.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'))
  defects[str(z)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'extremality {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):
  facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):
  facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),float);fn=np.array(F.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn])
 assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tr=json.loads(TRANS.read_text());tetP=[tuple(t) for t in tr['tetrahedra']]
 assert len(tetP)==len(set(tetP))==32
 pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([f for f in facP if set(tet)<=set(f)])==1,(tet,facP)
 tetQ=[z for f in facQ for z in base.pulling_triangulation(f,ptsQ)]
 assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0,(label,k,ids)
   sg=1 if det.subs(sample)>0 else -1
   ce=eng.positive_rational(sg*det,f'{label} tet {k}')
   terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
 volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=eng.positive_rational(margin,'Mahler margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2256','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,
  'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relation':str(relation),'strict_consequence':'x2_0=x3_0 because x7_5+1>0','constant_elimination_steps':trace,'completion':{str(k):str(v) for k,v in sol.items()}},
  'parameter_domain':{'original':'-1<b,c<1 and -(b+1)/(3-b)<a<1','unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse_A':str(invA)},
  'coefficient_certificates':coeff,'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,
  'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'primal_triangulation_source':tr,
  'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,
  'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE),str(TRANS):sha256(TRANS)},
  'conclusion':'Family 2256 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
