#!/usr/bin/env python3
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
TRANS=Path('/mnt/data/f2317_transport.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family2317_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family2317_verifier_output.json')
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
CID=2317

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=v
 rr=(0,1,2,4);cc=(2,3,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ);eq=[sp.factor(sp.cancel(e)) for e in S]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 relation=-(x['x10_1']-1)*(x['x3_5']-x['x6_5']);assert base.proportional_member(rem,relation)
 p,q,r=sp.symbols('p q r',real=True)
 s=sp.factor(-(p*q*r-p*r+q*r-2*q-5*r-6)/(p*q-p-q-3))
 z=sp.factor(-(p*q*r-p*q-p*r-p+q*r-q-3*r-3)/(2*(p-r)))
 w=sp.factor((p*q**2*r-p*q**2-p*r+p-q**2*r+q**2-2*q*r+2*q-5*r-3)/(2*(q*r-q-r-3)))
 y=sp.factor((p*q*r+3*p*q-p*r+p-3*q*r-q-5*r-3)/((p+1)*(q*r-q-r-3)))
 st=dict(const);st.update({x['x10_1']:p,x['x3_5']:q,x['x6_5']:q,x['x4_0']:r,x['x2_0']:s,x['x8_5']:z,x['x9_4']:w,x['x5_3']:y})
 sol={v:base.apply_all(v,st) for v in vs};X=M.subs(sol).applyfunc(lambda e:sp.factor(sp.cancel(e)))
 assert all(sp.factor(sp.cancel(e.subs(sol)))==0 for e in eq)
 assert all(not (e.free_symbols&set(vs)) for e in sol.values())
 return rec,rows,M,vs,X,(p,q,r),rr,cc,sol,trace,relation

def main():
 rec,rows,M,vs,X,free,rr,cc,sol,trace,relation=build_branch();p,q,r=free
 A,B,C=sp.symbols('A B C',real=True)
 chart={p:2*A-1,
        r:sp.factor((2*A*B-A-1)/(A+1)),
        q:sp.factor((2*A*B*C-2*A*C-A*B+A+2*B*C-2*C+1)/(A*B-A-1))}
 cv=(A,B,C);sample={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};eng=base.SignEngine(cv,sample)
 R0=sp.factor((p-1)/(p+3));U=sp.factor((p*(1-r)-5*r-3)/((p+1)*(1-r)))
 invB=sp.factor((r+1)/(R0+1));invC=sp.factor((q+1)/(U+1))
 assert sp.factor(invB.subs(chart)-B)==0 and sp.factor(invC.subs(chart)-C)==0
 coeff={
  'p_plus_1':eng.positive_rational((p+1).subs(chart),'p+1'),
  'p_minus_r':eng.positive_rational((p-r).subs(chart),'p-r'),
  'minus_pq_denom':eng.positive_rational((-(p*q-p-q-3)).subs(chart),'-pqden'),
  'minus_qr_denom':eng.positive_rational((-(q*r-q-r-3)).subs(chart),'-qrden'),
  'one_minus_p':eng.positive_rational((1-p).subs(chart),'1-p'),
  'r_plus_1':eng.positive_rational((r+1).subs(chart),'r+1'),
  'R0_minus_r':eng.positive_rational((R0-r).subs(chart),'R0-r'),
  'q_plus_1':eng.positive_rational((q+1).subs(chart),'q+1'),
  'U_minus_q':eng.positive_rational((U-q).subs(chart),'U-q')}
 X=X.subs(chart).applyfunc(lambda e:sp.factor(sp.cancel(e)));pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda e:sp.factor(sp.cancel(e)));F=X.extract(range(11),cc);assert all(sp.factor(e)==0 for e in F*V-X)
 defects={}
 for v in vs:
  i,j=map(int,str(v)[1:].split('_'));defects[str(v)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(v))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'ext {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),float);fn=np.array(F.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tr=json.loads(TRANS.read_text());tetP=[tuple(t) for t in tr['tetrahedra']];assert len(tetP)==len(set(tetP))==32;pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([f for f in facP if set(tet)<=set(f)])==1
 tetQ=[z for f in facQ for z in base.pulling_triangulation(f,ptsQ)];assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0
   sg=1 if det.subs(sample)>0 else -1;ce=eng.positive_rational(sg*det,f'{label} {k}');terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
 # Sum determinant terms over explicit common denominators.  This avoids an
 # otherwise very expensive generic rational-expression cancellation.
 dp=sp.factor((A+1)*(A**2*B*C-A**2*B-A**2*C+A**2+A-B*C+C))
 d1=sp.factor(A*B-A-1);d2=sp.factor(A*B*C-A*B-A*C+B*C-C);d3=sp.factor(A-B+1)
 dq=sp.expand(d3*d1**3*d2**2)
 def common_sum(terms,D):
  N=sp.Poly(0,A,B,C,domain=sp.QQ)
  for k,t in enumerate(terms):
   num,den=sp.together(t).as_numer_denom();mul=sp.cancel(D/den);assert sp.denom(mul)==1,(k,den,mul)
   N += sp.Poly(sp.expand(num*mul),A,B,C,domain=sp.QQ)
  return N
 Np=common_sum(pt,dp);Nq=common_sum(qt,dq)
 volP=sp.cancel(Np.as_expr()/(24*dp));volQ=Nq.as_expr()/(24*dq)
 Nm=sp.Poly(sp.expand(Np.as_expr()*Nq.as_expr()-sp.Integer(6144)*sp.expand(dp*dq)),A,B,C,domain=sp.QQ)
 Dm=sp.expand(sp.Integer(576)*dp*dq)
 if Dm.subs(sample)<0:Nm=-Nm;Dm=-Dm
 mc={'numerator':eng.positive_poly(Nm.as_expr(),'margin numerator'),'denominator':eng.positive_poly(Dm,'margin denominator')}
 margin=Nm.as_expr()/Dm
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2317','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,
 'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relation':str(relation),'strict_consequence':'x3_5=x6_5 because x10_1-1<0','constant_elimination_steps':trace,'completion':{str(k):str(v) for k,v in sol.items()}},
 'parameter_domain':{'original':'-1<p<1, -1<r<(p-1)/(p+3), -1<q<U(p,r)','U':str(U),'unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse_B':str(invB),'inverse_C':str(invC)},
 'coefficient_certificates':coeff,'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'primal_triangulation_source':tr,'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE),str(TRANS):sha256(TRANS)},'conclusion':'Family 2317 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
