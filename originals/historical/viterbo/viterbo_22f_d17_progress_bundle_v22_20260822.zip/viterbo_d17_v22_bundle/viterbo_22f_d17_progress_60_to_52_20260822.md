# Four-dimensional symmetric Mahler bounded-12 progress

## 12V/22F, c=0, D=17: 60 survivors reduced to 52

Date: 2026-08-22

All checkmarks in this report denote **computer-assisted analytic proof candidates**. The calculations are exact and replayable, but have not yet been independently peer reviewed.

## Summary

The previous non-overlapping accounting left 60 unresolved canonical families in the layer

\[
12V/22F,\qquad c=0,\qquad D=17.
\]

This round closes eight of them:

- six strict-rank-four boundary-only or interval-impossible families,
  \[
  1258,1435,1447,1448,1617,1771;
  \]
- two genuine continuous families with strict Mahler surplus,
  \[
  757,768.
  \]

Therefore

\[
\boxed{60\longrightarrow52}.
\]

The exact layer accounting is now

\[
\boxed{
\begin{aligned}
2395={}&1230\text{ facet-containment templates}\\
&+1070\text{ antichain templates with rank}\ge5\\
&+22\text{ segment vertex-loss templates}\\
&+4\text{ duplicate/antipodal primal-pair templates}\\
&+4\text{ exact Mahler-positive families}\\
&+13\text{ strict boundary or interval-impossible families}\\
&+52\text{ unresolved algebraic survivors}.
\end{aligned}}
\]

At the original 121-survivor level:

\[
\boxed{121=26+22+4+4+13+52}.
\]

The four exact Mahler-positive families currently are

\[
\boxed{606,757,768,952}.
\]

---

## 1. Six exact boundary/impossibility closures

A coefficient-zero-aware Schur case-tree verifier was applied to

\[
1258,1435,1447,1448,1617,1771.
\]

Five families force a nominal defect to \(1\) or \(-1\). Family 1617 reduces to the strict interval equation

\[
c(b-a)-a-b-2=0,
\qquad a,b,c\in(-1,1),
\]

which is impossible by splitting into \(b\ge a\) and \(b<a\).

No parameter-dependent factor is divided out without separately retaining its zero branch. The exact verifier concludes that none of the six families has a rank-at-most-four completion with all 17 defects in \((-1,1)\).

---

## 2. Family 768

The exact Schur system contains

\[
-\frac14(x_{4,3}+x_{6,3})(x_{7,4}-1)(x_{8,1}-1)=0.
\]

Strictness gives

\[
x_{6,3}=-x_{4,3}.
\]

Writing

\[
b=x_{4,3},\quad c=x_{7,4},\quad d=x_{8,1},
\]

all remaining defects are uniquely determined and the complete strict realization space is

\[
\boxed{-1<b,c,d<1}.
\]

The proof uses the original simplicial 3-sphere from source local matching 913, transported by an exact signed coordinate permutation. This supplies a genuine 32-tetrahedra primal boundary and avoids numerical diagonal choices on non-simplicial ridges.

The verifier proves

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

The Mahler-margin numerator has tensor Bernstein degree

\[
(5,4,4)
\]

with

\[
\boxed{89>0,\quad61=0,\quad0<0},
\qquad \min_+=\frac85.
\]

The denominator has degree \((3,1,3)\), with 20 positive and 12 zero coefficients. Hence

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

throughout the full family.

---

## 3. Family 757

The first strict relation is

\[
x_{7,3}=x_{8,3}-x_{4,3}-1.
\]

Set

\[
b=x_{4,3},\quad c=x_{8,3},\quad d=x_{9,1}.
\]

Compatibility of two independent equations for \(x_{6,2}\) forces

\[
x_{3,0}=
\frac{2bd-cd+c+d-3}{2b+cd-c+d+5}.
\]

The remaining Schur equations uniquely determine every other defect. The complete strict realization space is exactly

\[
\boxed{-1<b<c<1,\qquad -1<d<1}.
\]

It is mapped to the unit cube by

\[
b=2B-1,
\]

\[
c=2\bigl(B+(1-B)C\bigr)-1,
\]

\[
d=2D-1,
\qquad0<B,C,D<1.
\]

The source sphere from local matching 2097 provides another exact 32-tetrahedra primal boundary. The polar facets use 77 fixed-sign tetrahedra. The verifier proves

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

The Mahler-margin numerator has tensor Bernstein degree

\[
(6,6,3)
\]

and coefficient statistics

\[
\boxed{148>0,\quad48=0,\quad0<0},
\qquad \min_+=\frac4{15}.
\]

The denominator has degree \((4,4,2)\), with 56 positive and 19 zero coefficients. Thus

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

on the entire strict realization space.

---

## 4. Methodological improvement

The full-dimensional convex-hull triangulation may insert zero-volume slivers when adjacent non-simplicial facets choose incompatible diagonals on a shared ridge. This round replaces that discovery-time triangulation with the original simplicial sphere used before ridge merging.

The new protocol is:

1. recover the source local matching from the preclassification certificate;
2. find the exact signed coordinate permutation to the canonical template;
3. transport the source simplicial sphere;
4. verify the resulting 32 tetrahedra form a closed 3-sphere;
5. verify each tetrahedron lies in exactly one prescribed merged facet;
6. certify all determinant signs over the complete realization domain.

This removes an avoidable numerical interface from future family proofs.

---

## 5. Current frontier

The remaining 52 canonical families are

\[
\begin{aligned}
&131,961,1005,1064,1165,1260,1440,1446,1623,1654,1656,1702,\
&1759,1770,1849,1943,2007,2055,2056,2060,2070,2077,2080,2107,\
&2120,2156,2191,2199,2234,2236,2249,2255,2256,2257,2263,2269,\
&2270,2272,2273,2274,2317,2344,2345,2358,2364,2368,2382,2384,\
&2386,2387,2391,2394.
\end{aligned}
\]

Exploratory numerical scans, used only for prioritization, suggest:

- most are genuine three-parameter families;
- Families 131 and 1260 are likely four-parameter families;
- Families 1654,1656,1770,2070,2394 require defect-dependent pivots despite possessing strict numerical rank-four samples.

The next exact work will cluster the three-parameter completions by rational form and separately audit the five defect-dependent-pivot families.

---

## Scope

The bounded-12 proof tree currently has closed candidates for

\[
c=1,
\]

all \(c=0\) layers through \(12V/20F\), and the \(22F\) layers \(D=19,18\). The current frontier remains \(22F,D=17\).

This is not yet a proof of the full four-dimensional symmetric Mahler conjecture. Completing the finite core must eventually be paired with a complexity-independent finite-core or bi-shadow-rigid reduction theorem.
