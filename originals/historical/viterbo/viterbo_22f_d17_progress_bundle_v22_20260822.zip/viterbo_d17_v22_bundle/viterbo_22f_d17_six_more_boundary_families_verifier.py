#!/usr/bin/env python3
"""Exact strict-rank-four exclusions for six D=17 canonical families.

The selected 4x4 pivots each contain one nominal defect coordinate, but their
symbolic determinants are identically +/-8.  Hence they are globally valid on
all of parameter space.  Schur-complement equations and coefficient-aware case
splits show that canonical families 1258, 1435, 1447, 1448, 1617, and 1771
have no completion of rank <=4 with all 17 defects strictly in (-1,1).
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Iterable, List

import sympy as sp

PRE = Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT = Path('/mnt/data/viterbo_22f_d17_six_more_boundary_families_certificate.json')
OUT = Path('/mnt/data/viterbo_22f_d17_six_more_boundary_families_verifier_output.json')

PIVOTS = {
    1258: ((5, 7, 8, 9), (0, 2, 4, 5), 8),
    1435: ((2, 3, 4, 5), (1, 2, 4, 5), 8),
    1447: ((2, 3, 4, 7), (1, 2, 4, 5), -8),
    1448: ((2, 3, 4, 6), (1, 2, 3, 5), 8),
    1617: ((2, 4, 5, 8), (1, 2, 4, 5), -8),
    1771: ((1, 2, 5, 7), (1, 2, 4, 5), -8),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(cid: int):
    data = json.loads(PRE.read_text())
    record = data['records'][cid]
    assert record['canonical_id'] == cid
    assert record['status'] == 'algebraic_survivor'
    rows = record['rows']
    matrix = sp.zeros(11, 6)
    variables: List[sp.Symbol] = []
    names: Dict[str, sp.Symbol] = {}
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            if value == 0:
                x = sp.Symbol(f'x{i}_{j}', real=True)
                matrix[i, j] = x
                variables.append(x)
                names[str(x)] = x
            else:
                matrix[i, j] = value
    rr, cc, expected = PIVOTS[cid]
    pivot = matrix.extract(rr, cc)
    determinant = sp.factor(pivot.det(method='domain-ge'))
    assert determinant == expected
    other_rows = [i for i in range(11) if i not in rr]
    other_cols = [j for j in range(6) if j not in cc]
    schur = (
        matrix.extract(other_rows, other_cols)
        - matrix.extract(other_rows, cc) * pivot.inv() * matrix.extract(rr, other_cols)
    )
    equations = [sp.factor(sp.cancel(z)) for z in schur]
    return record, matrix, variables, names, equations, determinant


def apply_all(expr: sp.Expr, substitutions: Dict[sp.Symbol, sp.Expr]) -> sp.Expr:
    current = expr
    for _ in range(40):
        nxt = sp.factor(sp.cancel(current.subs(substitutions)))
        if nxt == current:
            return nxt
        current = nxt
    raise AssertionError('substitution did not stabilize')


def constant_eliminate(equations: Iterable[sp.Expr], variables: Iterable[sp.Symbol], initial=None):
    substitutions: Dict[sp.Symbol, sp.Expr] = dict(initial or {})
    unsolved = set(variables) - set(substitutions)
    remaining = list(equations)
    trace = []
    while True:
        remaining = [apply_all(e, substitutions) for e in remaining]
        remaining = [e for e in remaining if e != 0]
        choices = []
        for equation_index, equation in enumerate(remaining):
            for variable in sorted(unsolved, key=str):
                if not equation.has(variable):
                    continue
                try:
                    polynomial = sp.Poly(equation, variable)
                except sp.PolynomialError:
                    continue
                if polynomial.degree() != 1:
                    continue
                coefficient = sp.factor(sp.diff(equation, variable))
                if not coefficient.is_Rational or coefficient == 0:
                    continue
                rest = sp.factor(equation.subs(variable, 0))
                choices.append((sp.count_ops(rest), equation_index, str(variable), variable, coefficient, rest, equation))
        if not choices:
            break
        choices.sort(key=lambda z: z[:3])
        _, equation_index, _, variable, coefficient, rest, equation = choices[0]
        solution = sp.factor(-rest / coefficient)
        substitutions[variable] = solution
        unsolved.remove(variable)
        remaining.pop(equation_index)
        trace.append({'variable': str(variable), 'solution': str(solution), 'equation': str(equation)})
    remaining = [apply_all(e, substitutions) for e in remaining]
    remaining = [sp.factor(e) for e in remaining if e != 0]
    return substitutions, unsolved, remaining, trace


def proportional_member(expressions: Iterable[sp.Expr], target: sp.Expr) -> str:
    target = sp.factor(target)
    for expression in expressions:
        ratio = sp.factor(sp.cancel(expression / target))
        if ratio.is_Rational and ratio != 0:
            return str(ratio)
    raise AssertionError(f'target factor not found: {target}')


def verify_1258():
    rec, M, variables, n, equations, det = build(1258)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    e1 = (n['x5_2'] - n['x6_2']) * (n['x9_1'] + 1) / 2
    e2 = (n['x7_3'] - 1) * (n['x10_2'] + n['x5_2'] - n['x6_2'] + 1) / 2
    r1 = proportional_member(residual, e1)
    r2 = proportional_member(residual, e2)
    # Strict x9_1 != -1 gives x5_2=x6_2. Strict x7_3 != 1 then gives x10_2=-1.
    assert sp.factor(e2.subs(n['x5_2'], n['x6_2']) / ((n['x7_3'] - 1) * (n['x10_2'] + 1) / 2)) == 1
    return {
        'canonical_id': 1258, 'canonical_key': rec['canonical_key'], 'pivot_determinant': int(det),
        'case_tree': [
            {'equation': str(sp.factor(e1)), 'strict_branch': 'x5_2=x6_2', 'ratio': r1},
            {'equation': str(sp.factor(e2)), 'forced_boundary': 'x10_2=-1', 'ratio': r2},
        ],
        'constant_elimination_steps': len(trace),
    }


def verify_1435():
    rec, M, variables, n, equations, det = build(1435)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    equation = -(n['x5_4'] - n['x6_4']) * (n['x8_3'] - 1) / 2
    ratio = proportional_member(residual, equation)
    x40 = apply_all(M[4, 0], subs)
    forced = sp.factor(x40.subs(n['x5_4'], n['x6_4']))
    assert forced == -1
    return {
        'canonical_id': 1435, 'canonical_key': rec['canonical_key'], 'pivot_determinant': int(det),
        'case_tree': [
            {'equation': str(sp.factor(equation)), 'strict_branch': 'x5_4=x6_4', 'ratio': ratio},
            {'completion_identity': 'x4_0=-1 after x5_4=x6_4', 'forced_boundary': 'x4_0=-1'},
        ],
        'constant_elimination_steps': len(trace),
    }


def verify_1447():
    rec, M, variables, n, equations, det = build(1447)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    e1 = -(n['x2_0'] + 1) * (n['x5_4'] - n['x6_4']) / 2
    e2 = (n['x4_4'] + n['x6_4']) * (n['x8_3'] - 1) / 2
    r1 = proportional_member(residual, e1)
    r2 = proportional_member(residual, e2)
    x53 = apply_all(M[5, 3], subs)
    forced = sp.factor(x53.subs({n['x5_4']: n['x6_4'], n['x4_4']: -n['x6_4']}))
    assert forced == 1
    return {
        'canonical_id': 1447, 'canonical_key': rec['canonical_key'], 'pivot_determinant': int(det),
        'case_tree': [
            {'equation': str(sp.factor(e1)), 'strict_branch': 'x5_4=x6_4', 'ratio': r1},
            {'equation': str(sp.factor(e2)), 'strict_branch': 'x4_4=-x6_4', 'ratio': r2},
            {'completion_identity': 'x5_3=1 on the strict algebraic branch', 'forced_boundary': 'x5_3=1'},
        ],
        'constant_elimination_steps': len(trace),
    }


def verify_1448():
    rec, M, variables, n, equations, det = build(1448)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    plus = n['x4_3'] * n['x5_2'] - n['x4_3'] + n['x5_2'] + 2*n['x5_3'] + 1
    minus = n['x4_3'] * n['x5_2'] - n['x4_3'] - n['x5_2'] + 2*n['x5_3'] - 1
    e1 = (n['x2_0'] + 1) * plus / 4
    e2 = (n['x7_4'] - 1) * minus / 4
    r1 = proportional_member(residual, e1)
    r2 = proportional_member(residual, e2)
    difference = sp.factor(plus - minus)
    assert sp.expand(difference - 2*(n['x5_2'] + 1)) == 0
    return {
        'canonical_id': 1448, 'canonical_key': rec['canonical_key'], 'pivot_determinant': int(det),
        'case_tree': [
            {'equation': str(sp.factor(e1)), 'strict_branch': str(sp.factor(plus)) + '=0', 'ratio': r1},
            {'equation': str(sp.factor(e2)), 'strict_branch': str(sp.factor(minus)) + '=0', 'ratio': r2},
            {'difference_identity': str(difference), 'forced_boundary': 'x5_2=-1'},
        ],
        'constant_elimination_steps': len(trace),
    }


def verify_1617():
    rec, M, variables, n, equations, det = build(1617)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    relation = (n['x4_3'] + 1) * (n['x3_4'] + n['x5_4'] - n['x6_4'] + 1) / 2
    ratio = proportional_member(residual, relation)
    strict_sub = {n['x6_4']: n['x3_4'] + n['x5_4'] + 1}
    reduced_targets = [sp.factor(sp.cancel(e.subs(strict_sub))) for e in residual]
    a, b, c = n['x2_0'], n['x4_0'], n['x3_4']
    impossible = c*(b-a) - a - b - 2
    impossible_ratio = proportional_member(reduced_targets, impossible)
    # Exact interval proof:
    # if b>=a, c(b-a)<b-a and F<-2(a+1)<0;
    # if b<a, -c(a-b)<a-b and F<-2(b+1)<0.
    assert sp.expand(((b-a) - a - b - 2) + 2*(a+1)) == 0
    assert sp.expand(((a-b) - a - b - 2) + 2*(b+1)) == 0
    return {
        'canonical_id': 1617, 'canonical_key': rec['canonical_key'], 'pivot_determinant': int(det),
        'case_tree': [
            {'equation': str(sp.factor(relation)), 'strict_branch': 'x6_4=x3_4+x5_4+1', 'ratio': ratio},
            {'reduced_equation': str(impossible), 'ratio': impossible_ratio,
             'strict_interval_contradiction': {
                 'case_b_ge_a': 'c(b-a)<b-a, while (b-a)-a-b-2=-2(a+1)<0',
                 'case_b_lt_a': '-c(a-b)<a-b, while (a-b)-a-b-2=-2(b+1)<0',
             }},
        ],
        'constant_elimination_steps': len(trace),
    }


def verify_1771():
    rec, M, variables, n, equations, det = build(1771)
    subs, _, residual, trace = constant_eliminate(equations, variables)
    e1 = (n['x5_3'] + 1) * (n['x0_1'] - n['x1_1'] + n['x9_1'] - 1) / 2
    e2 = -(n['x10_1'] - n['x9_1']) * (n['x2_0'] - 1) / 2
    r1 = proportional_member(residual, e1)
    r2 = proportional_member(residual, e2)
    x103 = apply_all(M[10, 3], subs)
    reduced = sp.factor(x103.subs({
        n['x0_1']: n['x1_1'] - n['x9_1'] + 1,
        n['x10_1']: n['x9_1'],
    }))
    target = -1 + (n['x5_3'] + 1) * (n['x1_1'] - n['x9_1']) / 2
    assert sp.factor(reduced - target) == 0
    # Strict x0_1<1 and x0_1=x1_1-x9_1+1 imply x1_1<x9_1.
    # Since x5_3+1>0, target is strictly smaller than -1.
    return {
        'canonical_id': 1771, 'canonical_key': rec['canonical_key'], 'pivot_determinant': int(det),
        'case_tree': [
            {'equation': str(sp.factor(e1)), 'strict_branch': 'x0_1=x1_1-x9_1+1', 'ratio': r1},
            {'equation': str(sp.factor(e2)), 'strict_branch': 'x10_1=x9_1', 'ratio': r2},
            {'completion_identity': 'x10_3=-1+(x5_3+1)(x1_1-x9_1)/2',
             'strict_interval_contradiction': 'x0_1<1 gives x1_1<x9_1; x5_3+1>0, hence x10_3<-1'},
        ],
        'constant_elimination_steps': len(trace),
    }


def main():
    records = [verify_1258(), verify_1435(), verify_1447(), verify_1448(), verify_1617(), verify_1771()]
    closed = [r['canonical_id'] for r in records]
    certificate = {
        'scope': '4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17',
        'status': 'PASS',
        'classification': 'strict_rank4_boundary_or_interval_impossible',
        'canonical_ids': closed,
        'families': records,
        'source_hashes': {str(PRE): sha256(PRE)},
        'conclusion': 'No listed canonical family admits a rank<=4 completion with all 17 defect coordinates strictly in (-1,1).',
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    output = {
        'status': 'PASS',
        'scope': certificate['scope'],
        'closed_families': closed,
        'count': len(closed),
        'classification': certificate['classification'],
        'certificate': str(CERT),
        'certificate_sha256': sha256(CERT),
        'conclusion': certificate['conclusion'],
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
