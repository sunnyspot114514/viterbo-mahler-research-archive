# Replay order

Python dependencies: Python 3, SymPy, NumPy, SciPy.

Run:

```bash
python viterbo_22f_d17_progress_accounting_verifier_v5.py
```

The aggregate verifier re-runs the previous v4 accounting verifier, which in turn re-runs the six-family boundary verifier and Family 768 verifier; it then re-runs Family 757 and checks the updated disjoint accounting.

All outputs must report `PASS`.
