# Two exact Mahler-positive families in the 12V/22F, c=0, D=17 layer

Date: 2026-08-22

Scope: four-dimensional centrally symmetric Mahler problem, bounded-12 finite core.

All conclusions below are **computer-assisted analytic proof candidates**. They have exact arithmetic and replayable verifiers, but have not yet been externally peer reviewed.

## 1. Canonical Family 768

The canonical pairing template has a constant pivot

\[
X_{\{0,1,2,3\},\{2,3,4,5\}},\qquad \det=8.
\]

After eliminating every variable that occurs with a nonzero constant coefficient, the remaining Schur system contains

\[
-\frac14(x_{4,3}+x_{6,3})(x_{7,4}-1)(x_{8,1}-1)=0.
\]

The strict defect conditions exclude \(x_{7,4}=1\) and \(x_{8,1}=1\), hence

\[
x_{6,3}=-x_{4,3}.
\]

Write

\[
b=x_{4,3},\qquad c=x_{7,4},\qquad d=x_{8,1}.
\]

The remaining equations are triangular and uniquely determine all other defects. The only parameter-dependent divisors are

\[
bd-b-d-3,
\]

and

\[
bcd+bc+bd-3b+cd+c-3d-7.
\]

Under

\[
-1<b,c,d<1,
\]

both are strictly negative. Thus the complete strict realization space is the open cube. We use

\[
b=2B-1,\quad c=2C-1,\quad d=2D-1,
\qquad 0<B,C,D<1.
\]

The source simplicial 3-sphere, transported from local matching 913 to the canonical coordinates, gives a genuine 32-tetrahedra triangulation of the primal boundary. It has

\[
(f_0,f_1,f_2,f_3)=(12,44,64,32).
\]

Every tetrahedral determinant remains nonzero with fixed sign throughout the parameter cube. The polar boundary is certified facetwise by 78 tetrahedra. Consequently

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

The exact volumes are

\[
|P|=
-\frac{
B^2CD^2-B^2CD-B^2D^2-B^2D+2B^2-3BCD-BD^2+2BD+4B+4D
}{6(BCD-B-D)},
\]

and

\[
|P^\circ|=
-\frac{4Q_{768}(B,C,D)}{3(BD-B-D)^2},
\]

where \(Q_{768}\) is recorded in the machine certificate.

For the Mahler margin

\[
|P||P^\circ|-\frac{32}{3},
\]

the sign-adjusted numerator has tensor Bernstein degree

\[
(5,4,4).
\]

Its 150 coefficients satisfy

\[
\boxed{89>0,\qquad61=0,\qquad0<0},
\]

with minimum positive coefficient

\[
\frac85.
\]

The denominator has degree \((3,1,3)\), with

\[
20>0,\qquad12=0,
\]

and minimum positive coefficient \(3\). Therefore

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

throughout the full strict realization space.

---

## 2. Canonical Family 757

This family has the same constant pivot location and determinant:

\[
X_{\{0,1,2,3\},\{2,3,4,5\}},\qquad \det=8.
\]

After constant-coefficient elimination, one residual factor is

\[
-\frac12(x_{9,1}-1)(x_{4,3}+x_{7,3}-x_{8,3}+1)=0.
\]

Strictness gives

\[
x_{7,3}=x_{8,3}-x_{4,3}-1.
\]

Set

\[
b=x_{4,3},\qquad c=x_{8,3},\qquad d=x_{9,1}.
\]

Two independent equations for \(x_{6,2}\) are compatible only if

\[
2ab+acd-ac+ad+5a-2bd+cd-c-d+3=0,
\]

where \(a=x_{3,0}\). Hence

\[
\boxed{
a=
\frac{2bd-cd+c+d-3}{2b+cd-c+d+5}
}.
\]

The denominator is strictly positive in the strict domain. The remaining equations uniquely determine \(x_{6,2}\), \(x_{10,2}\), and the pair \((x_{5,2},x_{5,4})\). The 2-by-2 coefficient determinant for the last solve is

\[
\frac{(d+1)(b-c+2)(bd-b-cd+c-4)}{4(2b+cd-c+d+5)},
\]

which is strictly negative in the full strict domain.

The free defect \(x_{7,3}=c-b-1\) shows that strictness is equivalent to

\[
\boxed{-1<b<c<1,\qquad -1<d<1}.
\]

A rational cube parametrization is

\[
b=2B-1,
\]

\[
c=2\bigl(B+(1-B)C\bigr)-1,
\]

\[
d=2D-1,
\qquad0<B,C,D<1.
\]

All 17 defect inequalities have independent tensor-Bernstein certificates on this cube.

The transported source simplicial sphere from local matching 2097 supplies a compatible 32-tetrahedra primal boundary. The polar facets are certified by 77 tetrahedra. Thus

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

The exact primal volume is

\[
|P|=
\frac{
2B^2C^2D-2B^2C^2+B^2CD^2-B^2CD-4BC^2D+4BC^2
-BCD^2+7BCD-8BC+2BD^2-5BD+2C^2D-2C^2-6CD+8C-6
}{6(BCD-BC-BD-CD+C-1)}.
\]

The polar volume is a rational function recorded in the certificate and is obtained from a fixed-sign facetwise decomposition.

The Mahler-margin numerator has tensor Bernstein degree

\[
(6,6,3).
\]

Its 196 coefficients satisfy

\[
\boxed{148>0,\qquad48=0,\qquad0<0},
\]

with minimum positive coefficient

\[
\frac4{15}.
\]

The denominator has degree \((4,4,2)\), with

\[
56>0,\qquad19=0,
\]

and minimum positive coefficient \(9/8\). Therefore

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

throughout the full strict realization space.

---

## 3. Verification standard

Both verifiers reconstruct the families from the original canonical pairing templates. They verify:

1. the exact Schur-complement rank branch and every divided coefficient;
2. all strict defect inequalities;
3. primal vertex extremality;
4. the transported source-sphere boundary triangulation;
5. fixed signs for every selected primal and polar tetrahedron;
6. exact volume formulas;
7. tensor-Bernstein positivity of the Mahler margin.

The aggregate accounting verifier re-runs both family verifiers before updating the D=17 survivor count.
