# Six additional boundary-only or interval-impossible D=17 families

Date: 2026-08-22

Scope: \(12V/22F,\ c=0,\ D=17\).

The six canonical families

\[
1258,\ 1435,\ 1447,\ 1448,\ 1617,\ 1771
\]

do not admit rank-at-most-four completions with all 17 defect coordinates in \((-1,1)\).

- **1258.** Strictness turns
  \[
  (x_{5,2}-x_{6,2})(x_{9,1}+1)=0
  \]
  into \(x_{5,2}=x_{6,2}\). A second equation then forces \(x_{10,2}=-1\).

- **1435.** Strictness forces \(x_{5,4}=x_{6,4}\); the exact completion then gives \(x_{4,0}=-1\).

- **1447.** The strict branch gives \(x_{5,4}=x_{6,4}\) and \(x_{4,4}=-x_{6,4}\), after which \(x_{5,3}=1\).

- **1448.** Two strict branch equations differ by
  \[
  2(x_{5,2}+1)=0,
  \]
  hence \(x_{5,2}=-1\).

- **1617.** The Schur system reduces to
  \[
  c(b-a)-a-b-2=0,
  \qquad a,b,c\in(-1,1).
  \]
  If \(b\ge a\), then \(c(b-a)<b-a\), while
  \[
  (b-a)-a-b-2=-2(a+1)<0.
  \]
  If \(b<a\), the symmetric argument gives
  \[
  (a-b)-a-b-2=-2(b+1)<0.
  \]
  Thus no strict solution exists.

- **1771.** The strict branch yields
  \[
  x_{0,1}=x_{1,1}-x_{9,1}+1,
  \qquad x_{10,1}=x_{9,1},
  \]
  and
  \[
  x_{10,3}=-1+\frac{(x_{5,3}+1)(x_{1,1}-x_{9,1})}{2}.
  \]
  Since \(x_{0,1}<1\), one has \(x_{1,1}<x_{9,1}\), hence \(x_{10,3}<-1\).

Every coefficient-zero branch used in these arguments is explicitly retained in the case-tree verifier; no generic division is silently assumed.
