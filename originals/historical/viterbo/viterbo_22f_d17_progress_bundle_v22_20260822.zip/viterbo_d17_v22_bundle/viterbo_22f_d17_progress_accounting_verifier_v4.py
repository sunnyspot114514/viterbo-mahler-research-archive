#!/usr/bin/env python3
"""Aggregate exact accounting verifier for the D=17 progress update v4."""
from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path

OLD = Path('/mnt/data/viterbo_22f_d17_progress_accounting_certificate_v3.json')
PRE = Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
SIX = Path('/mnt/data/viterbo_22f_d17_six_more_boundary_families_verifier.py')
SIX_OUT = Path('/mnt/data/viterbo_22f_d17_six_more_boundary_families_verifier_output.json')
F768 = Path('/mnt/data/viterbo_22f_d17_family768_verifier.py')
F768_OUT = Path('/mnt/data/viterbo_22f_d17_family768_verifier_output.json')
CERT = Path('/mnt/data/viterbo_22f_d17_progress_accounting_certificate_v4.json')
OUT = Path('/mnt/data/viterbo_22f_d17_progress_accounting_verifier_output_v4.json')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    # Recompute every newly claimed exact classification from the original templates.
    subprocess.run([sys.executable, str(SIX)], check=True, stdout=subprocess.DEVNULL)
    subprocess.run([sys.executable, str(F768)], check=True, stdout=subprocess.DEVNULL)

    old = json.loads(OLD.read_text())
    pre = json.loads(PRE.read_text())
    six = json.loads(SIX_OUT.read_text())
    f768 = json.loads(F768_OUT.read_text())

    assert old['status'] == 'PASS'
    assert pre['global_templates'] == 2395
    assert six['status'] == 'PASS'
    assert f768['status'] == 'PASS' and f768['canonical_id'] == 768

    six_ids = set(six['closed_families'])
    assert six_ids == {1258, 1435, 1447, 1448, 1617, 1771}
    new_mahler = {768}
    newly_closed = six_ids | new_mahler

    old_remaining = set(old['remaining_ids'])
    assert len(old_remaining) == 60
    assert newly_closed <= old_remaining
    remaining = sorted(old_remaining - newly_closed)
    assert len(remaining) == 53

    mahler_ids = sorted(set(old['Mahler_positive_exact_families']) | new_mahler)
    boundary_ids = sorted(set(old['strict_rank4_boundary_only']) | six_ids)
    assert mahler_ids == [606, 768, 952]
    assert len(boundary_ids) == 13

    classes = {
        'facet_containment': 1230,
        'rank_ge_5_after_antichain': 1070,
        'segment_loss_after_antichain': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler_ids),
        'strict_rank4_boundary_or_interval_impossible': len(boundary_ids),
        'remaining_algebraic_survivors': len(remaining),
    }
    assert sum(classes.values()) == 2395

    survivor = {
        'initial': 121,
        'facet_containment': 26,
        'additional_segment_loss': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler_ids),
        'strict_rank4_boundary_or_interval_impossible': len(boundary_ids),
        'remaining': len(remaining),
    }
    assert sum(v for k, v in survivor.items() if k != 'initial') == survivor['initial']

    cert = {
        'scope': '4D symmetric Mahler bounded-12, 12V/22F,c=0,D=17',
        'scope_warning': 'All classifications are computer-assisted analytic proof candidates; no claim of external peer review is made.',
        'status': 'PASS',
        'total_pairing_templates': 2395,
        'disjoint_classification': classes,
        'survivor_level_accounting': survivor,
        'Mahler_positive_exact_families': mahler_ids,
        'strict_rank4_boundary_or_interval_impossible': boundary_ids,
        'newly_closed': {
            'Mahler_positive_exact': [768],
            'boundary_or_interval_impossible': sorted(six_ids),
        },
        'remaining_ids': remaining,
        'source_hashes': {
            str(OLD): sha(OLD),
            str(PRE): sha(PRE),
            str(SIX): sha(SIX),
            str(SIX_OUT): sha(SIX_OUT),
            str(F768): sha(F768),
            str(F768_OUT): sha(F768_OUT),
        },
    }
    CERT.write_text(json.dumps(cert, indent=2, sort_keys=True))

    out = {
        'status': 'PASS',
        'total_templates': 2395,
        'initial_algebraic_survivors': 121,
        'remaining_survivors': len(remaining),
        'newly_closed': cert['newly_closed'],
        'Mahler_positive_exact_families': mahler_ids,
        'boundary_or_interval_impossible_count': len(boundary_ids),
        'certificate': str(CERT),
        'certificate_sha256': sha(CERT),
    }
    OUT.write_text(json.dumps(out, indent=2, sort_keys=True))
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
