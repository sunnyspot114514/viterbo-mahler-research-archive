#!/usr/bin/env python3
"""Aggregate exact accounting verifier for the D=17 progress update v5."""
from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path

OLD_VERIFIER = Path('/mnt/data/viterbo_22f_d17_progress_accounting_verifier_v4.py')
OLD = Path('/mnt/data/viterbo_22f_d17_progress_accounting_certificate_v4.json')
PRE = Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
F757 = Path('/mnt/data/viterbo_22f_d17_family757_verifier.py')
F757_OUT = Path('/mnt/data/viterbo_22f_d17_family757_verifier_output.json')
CERT = Path('/mnt/data/viterbo_22f_d17_progress_accounting_certificate_v5.json')
OUT = Path('/mnt/data/viterbo_22f_d17_progress_accounting_verifier_output_v5.json')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    subprocess.run([sys.executable, str(OLD_VERIFIER)], check=True, stdout=subprocess.DEVNULL)
    subprocess.run([sys.executable, str(F757)], check=True, stdout=subprocess.DEVNULL)

    old = json.loads(OLD.read_text())
    pre = json.loads(PRE.read_text())
    f757 = json.loads(F757_OUT.read_text())
    assert old['status'] == 'PASS'
    assert pre['global_templates'] == 2395
    assert f757['status'] == 'PASS' and f757['canonical_id'] == 757

    old_remaining = set(old['remaining_ids'])
    assert 757 in old_remaining and len(old_remaining) == 53
    remaining = sorted(old_remaining - {757})
    assert len(remaining) == 52

    mahler_ids = sorted(set(old['Mahler_positive_exact_families']) | {757})
    boundary_ids = sorted(old['strict_rank4_boundary_or_interval_impossible'])
    assert mahler_ids == [606, 757, 768, 952]
    assert len(boundary_ids) == 13

    classes = {
        'facet_containment': 1230,
        'rank_ge_5_after_antichain': 1070,
        'segment_loss_after_antichain': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler_ids),
        'strict_rank4_boundary_or_interval_impossible': len(boundary_ids),
        'remaining_algebraic_survivors': len(remaining),
    }
    assert sum(classes.values()) == 2395
    survivor = {
        'initial': 121,
        'facet_containment': 26,
        'additional_segment_loss': 22,
        'forced_duplicate_or_antipodal_primal_pair': 4,
        'Mahler_positive_exact_family': len(mahler_ids),
        'strict_rank4_boundary_or_interval_impossible': len(boundary_ids),
        'remaining': len(remaining),
    }
    assert sum(v for k, v in survivor.items() if k != 'initial') == 121

    cert = {
        'scope': '4D symmetric Mahler bounded-12, 12V/22F,c=0,D=17',
        'scope_warning': 'All classifications are computer-assisted analytic proof candidates; no claim of external peer review is made.',
        'status': 'PASS',
        'total_pairing_templates': 2395,
        'disjoint_classification': classes,
        'survivor_level_accounting': survivor,
        'Mahler_positive_exact_families': mahler_ids,
        'strict_rank4_boundary_or_interval_impossible': boundary_ids,
        'newly_closed': {'Mahler_positive_exact': [757]},
        'remaining_ids': remaining,
        'source_hashes': {
            str(OLD_VERIFIER): sha(OLD_VERIFIER),
            str(OLD): sha(OLD),
            str(PRE): sha(PRE),
            str(F757): sha(F757),
            str(F757_OUT): sha(F757_OUT),
        },
    }
    CERT.write_text(json.dumps(cert, indent=2, sort_keys=True))
    out = {
        'status': 'PASS',
        'total_templates': 2395,
        'initial_algebraic_survivors': 121,
        'remaining_survivors': len(remaining),
        'newly_closed': {'Mahler_positive_exact': [757]},
        'Mahler_positive_exact_families': mahler_ids,
        'boundary_or_interval_impossible_count': len(boundary_ids),
        'certificate': str(CERT),
        'certificate_sha256': sha(CERT),
    }
    OUT.write_text(json.dumps(out, indent=2, sort_keys=True))
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
