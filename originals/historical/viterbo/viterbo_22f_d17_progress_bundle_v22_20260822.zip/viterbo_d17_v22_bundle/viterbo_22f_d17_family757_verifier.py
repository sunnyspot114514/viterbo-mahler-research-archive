#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 757.

The verifier reconstructs the unique strict rank-four branch from the original
11x6 sign template, proves that its realization space is the full open cube
(-1,1)^3, certifies all 12 primal vertices and all 22 facets, derives exact
primal/polar volumes from fixed-sign tetrahedral decompositions, and proves the
Mahler margin by tensor-Bernstein positivity.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List

import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

PRE = Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')

# This is the original simplicial 3-sphere underlying source local matching 2097,
# transported to canonical Family 757 by the signed coordinate map
# perm=(0,3,2,1,4,5), signs=(1,-1,-1,-1,1,1).
PRIMAL_TETRAHEDRA_757 = [
    (0, 3, 5, 7), (0, 3, 5, 10), (0, 3, 7, 11), (0, 3, 10, 11),
    (0, 5, 7, 10), (0, 7, 10, 11), (1, 4, 5, 6), (1, 4, 5, 8),
    (1, 4, 6, 11), (1, 4, 8, 11), (1, 5, 6, 9), (1, 5, 8, 10),
    (1, 5, 9, 10), (1, 6, 9, 11), (1, 8, 10, 11), (1, 9, 10, 11),
    (2, 4, 5, 7), (2, 4, 5, 9), (2, 4, 7, 11), (2, 4, 9, 11),
    (2, 5, 7, 10), (2, 5, 9, 10), (2, 7, 10, 11), (2, 9, 10, 11),
    (3, 4, 5, 7), (3, 4, 5, 8), (3, 4, 7, 11), (3, 4, 8, 11),
    (3, 5, 8, 10), (3, 8, 10, 11), (4, 5, 6, 9), (4, 6, 9, 11),
]

CERT = Path('/mnt/data/viterbo_22f_d17_family757_certificate.json')
OUT = Path('/mnt/data/viterbo_22f_d17_family757_verifier_output.json')


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tensor_bernstein(poly: sp.Expr, variables: tuple[sp.Symbol, ...]):
    p = sp.Poly(sp.expand(poly), *variables, domain='QQ')
    degrees = tuple(map(int, p.degree_list()))
    powers = dict(p.terms())
    coefficients = []
    for beta in itertools.product(*[range(d + 1) for d in degrees]):
        value = sp.Rational(0)
        for alpha, coefficient in powers.items():
            if all(alpha[j] <= beta[j] for j in range(len(variables))):
                weight = sp.Rational(1)
                for j, degree in enumerate(degrees):
                    weight *= sp.Rational(math.comb(beta[j], alpha[j]), math.comb(degree, alpha[j]))
                value += coefficient * weight
        coefficients.append(sp.factor(value))
    return degrees, coefficients


class SignEngine:
    def __init__(self, variables: tuple[sp.Symbol, ...], sample: Dict[sp.Symbol, sp.Rational]):
        self.variables = variables
        self.sample = sample
        self.cache: Dict[str, tuple[tuple[int, ...], List[sp.Rational]]] = {}

    def positive_poly(self, polynomial: sp.Expr, label: str = '') -> dict:
        polynomial = sp.factor(polynomial)
        key = sp.srepr(polynomial)
        if key not in self.cache:
            self.cache[key] = tensor_bernstein(polynomial, self.variables)
        degree, coefficients = self.cache[key]
        positive = [x for x in coefficients if x > 0]
        negative = [x for x in coefficients if x < 0]
        assert not negative and positive, (label, degree, negative[:3], polynomial)
        return {
            'degree': list(degree),
            'positive': len(positive),
            'zero': sum(x == 0 for x in coefficients),
            'min_positive': str(min(positive)),
        }

    def positive_rational(self, expression: sp.Expr, label: str = '') -> dict:
        expression = sp.cancel(expression)
        assert sp.N(expression.subs(self.sample)) > 0, (label, expression.subs(self.sample), expression)
        numerator, denominator = map(sp.factor, sp.together(expression).as_numer_denom())
        if denominator.subs(self.sample) < 0:
            numerator, denominator = -numerator, -denominator
        return {
            'numerator': self.positive_poly(numerator, label + ' numerator'),
            'denominator': self.positive_poly(denominator, label + ' denominator'),
        }


def apply_all(expr: sp.Expr, substitutions: Dict[sp.Symbol, sp.Expr]) -> sp.Expr:
    current = expr
    for _ in range(60):
        nxt = sp.factor(sp.cancel(current.subs(substitutions)))
        if nxt == current:
            return nxt
        current = nxt
    raise AssertionError('substitution did not stabilize')


def constant_eliminate(equations: Iterable[sp.Expr], variables: Iterable[sp.Symbol], initial=None):
    substitutions: Dict[sp.Symbol, sp.Expr] = dict(initial or {})
    unsolved = set(variables) - set(substitutions)
    remaining = list(equations)
    trace = []
    while True:
        remaining = [apply_all(e, substitutions) for e in remaining]
        remaining = [e for e in remaining if e != 0]
        choices = []
        for equation_index, equation in enumerate(remaining):
            for variable in sorted(unsolved, key=str):
                if not equation.has(variable):
                    continue
                try:
                    polynomial = sp.Poly(equation, variable)
                except sp.PolynomialError:
                    continue
                if polynomial.degree() != 1:
                    continue
                coefficient = sp.factor(sp.diff(equation, variable))
                if not coefficient.is_Rational or coefficient == 0:
                    continue
                rest = sp.factor(equation.subs(variable, 0))
                choices.append((sp.count_ops(rest), equation_index, str(variable), variable, coefficient, rest, equation))
        if not choices:
            break
        choices.sort(key=lambda z: z[:3])
        _, equation_index, _, variable, coefficient, rest, equation = choices[0]
        solution = sp.factor(-rest / coefficient)
        substitutions[variable] = solution
        unsolved.remove(variable)
        remaining.pop(equation_index)
        trace.append({'variable': str(variable), 'solution': str(solution), 'equation': str(equation)})
    remaining = [apply_all(e, substitutions) for e in remaining]
    remaining = [sp.factor(e) for e in remaining if e != 0]
    return substitutions, unsolved, remaining, trace


def project3(points: np.ndarray) -> np.ndarray:
    delta = points - points[0]
    return delta @ np.linalg.svd(delta, full_matrices=False)[2][:3].T


def pulling_triangulation(ids: List[int], coordinates: np.ndarray) -> List[tuple[int, int, int, int]]:
    ids = sorted(ids)
    if len(ids) == 4:
        return [tuple(ids)]
    projected = project3(coordinates[ids])
    hull = ConvexHull(projected)
    out = set()
    for triangle, equation in zip(hull.simplices, hull.equations):
        # Facets containing the pulling vertex are not coned again.
        if abs(float(equation[:-1] @ projected[0] + equation[-1])) < 1e-8:
            continue
        out.add(tuple(sorted([ids[0]] + [ids[i] for i in triangle])))
    return sorted(out)


def check_closed_sphere(tetrahedra: List[tuple[int, ...]]) -> dict:
    triangles = Counter(tuple(sorted(q)) for tet in tetrahedra for q in itertools.combinations(tet, 3))
    assert set(triangles.values()) == {2}
    vertices = set(x for tet in tetrahedra for x in tet)
    edges = set(tuple(sorted(e)) for tet in tetrahedra for e in itertools.combinations(tet, 2))
    return {'vertices': len(vertices), 'edges': len(edges), 'triangles': len(triangles), 'tetrahedra': len(tetrahedra)}


def check_facet_balls(tetrahedra: List[tuple[int, ...]], facets: List[List[int]]) -> List[int]:
    counts = []
    for index, facet in enumerate(facets):
        group = [tet for tet in tetrahedra if set(tet) <= set(facet)]
        assert group and set(x for tet in group for x in tet) == set(facet), (index, facet)
        triangles = Counter(tuple(sorted(q)) for tet in group for q in itertools.combinations(tet, 3))
        boundary = [q for q, count in triangles.items() if count == 1]
        bvertices = set(x for q in boundary for x in q)
        bedges = set(tuple(sorted(e)) for q in boundary for e in itertools.combinations(q, 2))
        assert len(bvertices) - len(bedges) + len(boundary) == 2
        counts.append(len(group))
    return counts


def proportional_member(expressions: Iterable[sp.Expr], target: sp.Expr) -> str:
    target = sp.factor(target)
    for expression in expressions:
        ratio = sp.factor(sp.cancel(expression / target))
        if ratio.is_Rational and ratio != 0:
            return str(ratio)
    raise AssertionError(f'target equation not found: {target}')


def member_with_expected_ratio(expressions: Iterable[sp.Expr], target: sp.Expr, expected: sp.Expr) -> str:
    target = sp.factor(target)
    expected = sp.factor(expected)
    for expression in expressions:
        if sp.factor(sp.cancel(expression - expected*target)) == 0:
            return str(expected)
    raise AssertionError(f'target equation with expected ratio not found: {target}, {expected}')


def build_branch():
    data = json.loads(PRE.read_text())
    record = data['records'][757]
    assert record['status'] == 'algebraic_survivor'
    rows = record['rows']
    matrix = sp.zeros(11, 6)
    variables: List[sp.Symbol] = []
    names = {}
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            if value == 0:
                x = sp.Symbol(f'x{i}_{j}', real=True)
                matrix[i, j] = x
                variables.append(x)
                names[str(x)] = x
            else:
                matrix[i, j] = value

    pivot_rows = (0, 1, 2, 3)
    pivot_cols = (2, 3, 4, 5)
    pivot = matrix.extract(pivot_rows, pivot_cols)
    assert pivot.det(method='domain-ge') == 8
    other_rows = [i for i in range(11) if i not in pivot_rows]
    other_cols = [j for j in range(6) if j not in pivot_cols]
    schur = matrix.extract(other_rows, other_cols) - matrix.extract(other_rows, pivot_cols) * pivot.inv() * matrix.extract(pivot_rows, other_cols)
    equations = [sp.factor(sp.cancel(z)) for z in schur]

    x = names
    constant_solution, unsolved, residual, constant_trace = constant_eliminate(equations, variables)
    assert sorted(map(str, unsolved)) == sorted([
        'x10_2', 'x3_0', 'x4_3', 'x5_2', 'x5_4', 'x6_2', 'x7_3', 'x8_3', 'x9_1'
    ])

    a, b, c, d = sp.symbols('a b c d', real=True)
    relation = -(x['x9_1'] - 1) * (x['x4_3'] + x['x7_3'] - x['x8_3'] + 1) / 2
    relation_ratio = proportional_member(residual, relation)
    stage = dict(constant_solution)
    stage.update({x['x3_0']: a, x['x4_3']: b, x['x7_3']: c-b-1, x['x8_3']: c, x['x9_1']: d})

    residual1 = [apply_all(z, stage) for z in residual]
    residual1 = [z for z in residual1 if z != 0]
    x10_equations = [z for z in residual1 if z.has(x['x10_2'])]
    assert len(x10_equations) == 1
    x10_solution = sp.factor(sp.solve(x10_equations[0], x['x10_2'])[0])
    assert x10_solution == (b+c)/(b-c+2)
    stage[x['x10_2']] = x10_solution

    residual2 = [apply_all(z, stage) for z in residual]
    residual2 = [z for z in residual2 if z != 0]
    x6_equations = [z for z in residual2 if z.has(x['x6_2'])]
    assert len(x6_equations) == 2
    x6_solutions = [sp.factor(sp.solve(z, x['x6_2'])[0]) for z in x6_equations]
    consistency = sp.factor(sp.together(x6_solutions[0]-x6_solutions[1]).as_numer_denom()[0])
    expected_consistency = 4*(2*a*b + a*c*d - a*c + a*d + 5*a - 2*b*d + c*d - c - d + 3)
    assert sp.factor(consistency/expected_consistency) in (1, -1)
    a_den = 2*b + c*d - c + d + 5
    a_solution = sp.factor((2*b*d - c*d + c + d - 3)/a_den)
    assert sp.factor(expected_consistency.subs(a, a_solution)) == 0
    stage[x['x3_0']] = a_solution
    x6_solution = sp.factor(x6_solutions[0].subs(a, a_solution))
    stage[x['x6_2']] = x6_solution

    residual3 = [apply_all(z, stage) for z in residual]
    residual3 = [z for z in residual3 if z != 0]
    x5_equations = [z for z in residual3 if z.has(x['x5_2']) or z.has(x['x5_4'])]
    assert len(x5_equations) == 2
    coefficient_matrix = sp.Matrix([
        [sp.diff(z, x['x5_2']), sp.diff(z, x['x5_4'])] for z in x5_equations
    ])
    x5_determinant = sp.factor(coefficient_matrix.det())
    x5_solutions = sp.solve(x5_equations, [x['x5_2'], x['x5_4']], dict=True, simplify=False)
    assert len(x5_solutions) == 1
    stage.update({key: sp.factor(value) for key, value in x5_solutions[0].items()})

    solution = {variable: apply_all(variable, stage) for variable in variables}
    assert all(not (expression.free_symbols & set(variables)) for expression in solution.values())
    completed = matrix.subs(solution).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    assert all(apply_all(z, stage) == 0 for z in equations)

    return {
        'record': record,
        'rows': rows,
        'original': matrix,
        'completed': completed,
        'variables': variables,
        'free': (b, c, d),
        'solution': solution,
        'pivot_rows': pivot_rows,
        'pivot_cols': pivot_cols,
        'rank_trace': {
            'constant_elimination_steps': constant_trace,
            'strict_relation': 'x7_3=x8_3-x4_3-1',
            'relation_equation': str(sp.factor(relation)),
            'relation_ratio': relation_ratio,
            'x10_2_solution': str(x10_solution),
            'x6_consistency_equation': str(expected_consistency),
            'x3_0_solution': str(a_solution),
            'x6_2_solution': str(x6_solution),
            'x5_linear_system_determinant': str(x5_determinant),
        },
        'branch_coefficients': {
            'a_den': a_den,
            'one_minus_a': 1-a_solution,
            'b_minus_c_plus_2': b-c+2,
            'minus_second_x6_coefficient': -(b*d-b-c*d+c-4),
            'd_plus_1': d+1,
            'x5_determinant': x5_determinant,
        },
    }

def main():
    branch = build_branch()
    rows = branch['rows']
    matrix = branch['completed']
    variables = branch['variables']
    b, c, d = branch['free']
    B, C, D = sp.symbols('B C D', real=True)
    chart = {b: 2*B - 1, c: 2*(B + (1-B)*C) - 1, d: 2*D - 1}
    chart_variables = (B, C, D)
    sample = {B: sp.Rational(2, 5), C: sp.Rational(1, 2), D: sp.Rational(3, 5)}
    engine = SignEngine(chart_variables, sample)

    coefficient_certificates = {}
    for name, expression in branch['branch_coefficients'].items():
        chart_expression = sp.factor(sp.cancel(expression.subs(chart)))
        sign = 1 if chart_expression.subs(sample) > 0 else -1
        coefficient_certificates[name] = {
            'certified_sign': sign,
            'certificate': engine.positive_rational(sign*chart_expression, name),
        }

    completed = matrix.subs(chart).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    pivot_rows = branch['pivot_rows']
    pivot_cols = branch['pivot_cols']
    pivot = completed.extract(pivot_rows, pivot_cols)
    assert pivot.det(method='domain-ge') == 8
    vertex_matrix = (pivot.inv() * completed.extract(pivot_rows, range(6))).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    facet_matrix = completed.extract(range(11), pivot_cols)
    assert all(sp.factor(z) == 0 for z in facet_matrix * vertex_matrix - completed)

    defect_certificates = {}
    for x in variables:
        i, j = map(int, str(x)[1:].split('_'))
        defect_certificates[str(x)] = engine.positive_rational(1 - completed[i, j]**2, 'defect ' + str(x))

    # Exact primal extremality: four independent incident facet normals for
    # every positive vertex representative.
    extremality = []
    for j in range(6):
        incident = [i for i in range(11) if rows[i][j] != 0]
        found = None
        for rr in itertools.combinations(incident, 4):
            determinant = sp.factor(facet_matrix.extract(rr, range(4)).det(method='domain-ge'))
            if determinant == 0:
                continue
            sign = 1 if determinant.subs(sample) > 0 else -1
            try:
                certificate = engine.positive_rational(sign * determinant, f'extremality vertex {j}')
            except AssertionError:
                continue
            found = {'vertex_pair': j, 'facet_rows': list(rr), 'determinant': str(determinant), 'certificate': certificate}
            break
        assert found is not None, j
        extremality.append(found)

    code = np.array(rows, dtype=int)
    facets_p: List[List[int]] = []
    for i in range(11):
        facets_p += [
            sorted(j if code[i, j] == 1 else j + 6 for j in range(6) if code[i, j]),
            sorted(j + 6 if code[i, j] == 1 else j for j in range(6) if code[i, j]),
        ]
    facets_q: List[List[int]] = []
    for j in range(6):
        facets_q += [
            sorted(i if code[i, j] == 1 else i + 11 for i in range(11) if code[i, j]),
            sorted(i + 11 if code[i, j] == 1 else i for i in range(11) if code[i, j]),
        ]

    vnum = np.array(vertex_matrix.subs(sample), dtype=float)
    fnum = np.array(facet_matrix.subs(sample), dtype=float)
    points_p = np.vstack([vnum.T, -vnum.T])
    points_q = np.vstack([fnum, -fnum])
    assert len(ConvexHull(points_p).vertices) == 12
    assert len(ConvexHull(points_q).vertices) == 22

    # Use the transported source-sphere triangulation.  It is a genuine closed
    # simplicial 3-sphere, is compatible with every merged facet, and contains
    # no degenerate ridge slivers.  Fixed determinant signs below make it valid
    # throughout the full parameter cube.
    tetra_p = list(PRIMAL_TETRAHEDRA_757)
    assert len(tetra_p) == len(set(tetra_p)) == 32
    primal_boundary = check_closed_sphere(tetra_p)
    primal_facet_counts = check_facet_balls(tetra_p, facets_p)
    for tet in tetra_p:
        hits = [k for k, facet in enumerate(facets_p) if set(tet) <= set(facet)]
        assert len(hits) == 1, (tet, hits)

    # Polar facets can be triangulated independently for volume; compatibility
    # on common polygonal ridges is irrelevant because overlaps have measure 0.
    tetra_q = [tet for facet in facets_q for tet in pulling_triangulation(facet, points_q)]
    assert len(tetra_q) == len(set(tetra_q))
    polar_facet_counts = check_facet_balls(tetra_q, facets_q)

    def point_p(i: int):
        return vertex_matrix[:, i] if i < 6 else -vertex_matrix[:, i - 6]

    def point_q(i: int):
        return facet_matrix[i, :].T if i < 11 else -facet_matrix[i - 11, :].T

    def oriented_terms(tetrahedra, point, label):
        terms = []
        records = []
        for index, ids in enumerate(tetrahedra):
            determinant = sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')))
            assert determinant != 0, (label, index, ids)
            sign = 1 if determinant.subs(sample) > 0 else -1
            certificate = engine.positive_rational(sign * determinant, f'{label} tetrahedron {index}')
            terms.append(sp.factor(sign * determinant))
            records.append({'ids': list(ids), 'signed_determinant': str(sp.factor(sign * determinant)), 'certificate': certificate})
        return terms, records

    primal_terms, primal_records = oriented_terms(tetra_p, point_p, 'primal')
    polar_terms, polar_records = oriented_terms(tetra_q, point_q, 'polar')
    volume_p = sp.factor(sp.cancel(sum(primal_terms) / 24))
    volume_q = sp.factor(sp.cancel(sum(polar_terms) / 24))
    margin = sp.factor(sp.cancel(volume_p * volume_q - sp.Rational(32, 3)))
    margin_certificate = engine.positive_rational(margin, 'Mahler margin')

    certificate = {
        'scope': '4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17, canonical Family 757',
        'status': 'PASS',
        'canonical_id': 757,
        'canonical_key': branch['record']['canonical_key'],
        'rank': 4,
        'rank_branch': branch['rank_trace'],
        'coefficient_certificates': coefficient_certificates,
        'parameters': ['B', 'C', 'D'],
        'parameter_domain': '0<B,C,D<1; equivalently -1<b<c<1 and -1<d<1',
        'completion': {str(k): str(v) for k, v in branch['solution'].items()},
        'strict_defects': len(defect_certificates),
        'defect_certificates': defect_certificates,
        'primal_vertices': 12,
        'polar_vertices': 22,
        'extremality': extremality,
        'facet_size_counts_primal': dict(Counter(map(len, facets_p))),
        'facet_size_counts_polar': dict(Counter(map(len, facets_q))),
        'primal_boundary': primal_boundary,
        'primal_triangulation_source': {
            'source_local_id': 2097,
            'source_sphere_orbit': 8,
            'signed_coordinate_permutation': {
                'permutation': [0, 3, 2, 1, 4, 5],
                'signs': [1, -1, -1, -1, 1, 1],
            },
        },
        'primal_facet_tetrahedra': primal_facet_counts,
        'polar_facet_tetrahedra': polar_facet_counts,
        'tetrahedra_primal': len(tetra_p),
        'tetrahedra_polar': len(tetra_q),
        'orientation_records_primal': primal_records,
        'orientation_records_polar': polar_records,
        'volume_P': str(volume_p),
        'volume_polar': str(volume_q),
        'Mahler_margin': str(margin),
        'margin_certificate': margin_certificate,
        'fixed_sign_polynomials': len(engine.cache),
        'source_hashes': {str(PRE): sha256(PRE)},
        'conclusion': 'Family 757 has |P||P^o|>32/3 throughout its full strict realization space.',
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    output = {
        'status': 'PASS',
        'canonical_id': 757,
        'rank': 4,
        'strict_defects': len(defect_certificates),
        'primal_vertices': 12,
        'polar_vertices': 22,
        'tetrahedra_primal': len(tetra_p),
        'tetrahedra_polar': len(tetra_q),
        'volume_P': str(volume_p),
        'volume_polar': str(volume_q),
        'Mahler_margin': str(margin),
        'margin_certificate': margin_certificate,
        'certificate': str(CERT),
        'certificate_sha256': sha256(CERT),
        'conclusion': certificate['conclusion'],
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
