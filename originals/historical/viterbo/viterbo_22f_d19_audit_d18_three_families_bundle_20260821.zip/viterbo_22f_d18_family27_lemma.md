# Family 27 in 12V/22F, c=0, D=18

Date: 2026-08-21

## Claim

On its complete strict rank-four realization space, canonical Family 27 satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

This is a computer-assisted analytic proof candidate.

## Exact rank-four branch

Use free defects

\[
p=x_{5,5},\qquad q=x_{6,3},\qquad r=x_{7,5},\qquad s=x_{8,2}.
\]

Rows \((0,1,2,3)\) and columns \((2,3,4,5)\) form a constant pivot with determinant \(-8\). The fourteen Schur-complement equations have a zero-dimensional Gröbner basis of length fourteen over \(\mathbb Q(p,q,r,s)\), and determine all other defects uniquely as rational functions. Hence there is one strict rational four-parameter branch in this pivot chart.

## Complete strict domain

The exact defect inequalities reduce to

\[
-1<p,q,r,s<1,\qquad p+r<0.
\]

The whole domain is rationally and bijectively parameterized by the unit open four-cube:

\[
p=2U-1,\qquad r=2(1-U)V-1,
\]

\[
q=2Q-1,\qquad s=2S-1,
\qquad 0<U,V,Q,S<1.
\]

The inverse map is

\[
U=\frac{p+1}{2},\qquad V=\frac{r+1}{1-p},
\qquad Q=\frac{q+1}{2},\qquad S=\frac{s+1}{2}.
\]

Every one of the eighteen inequalities \(1-x_{ij}^2>0\), and every completion denominator, has a tensor-Bernstein certificate with no negative coefficients and at least one positive coefficient.

## Extremality and combinatorial closure

All six primal vertex-pairs have full-dimensional normal cones. The certified facet-wise boundary decompositions contain

\[
35\text{ primal boundary tetrahedra},\qquad
76\text{ polar-facet tetrahedra}.
\]

The primal tetrahedra form a closed triangulated three-sphere, while every primal and polar facet decomposition is a triangulated three-ball. Every nonzero simplex determinant has a fixed Bernstein-certified sign throughout the domain. Consequently

\[
f_0(P)=12,\qquad f_0(P^\circ)=22.
\]

There is no hidden facet, vertex loss, or oriented-matroid chamber switch.

## Exact volume and Mahler margin

The exact primal volume is

\[
\begin{aligned}
|P|={}&\bigl(3Q^2S^2U^2-5Q^2S^2U+2Q^2S^2
 +Q^2SU^2V-6Q^2SU^2-2Q^2SUV\\
&+3Q^2SU+Q^2SV+2Q^2S-Q^2U^2V+3Q^2U^2+Q^2UV+2Q^2U\\
&+4QS^2U-4QS^2-3QSUV-8QSU+2QSV+4QS+3QUV+4QU+2QV\\
&-4SV+4V\bigr)\\
&\big/\Bigl(6(QSU-QS-QU-V)(QSU-QS-QU+S-1)\Bigr).
\end{aligned}
\]

The polar volume is

\[
\begin{aligned}
|P^\circ|=\frac43\bigl(&QS U^3V-QS U^3-3QS U^2V+4QS U^2
+3QSUV-6QSU\\
&-QSV+4QS-QU^3V+QU^3+2QU^2V-4QU^2-QUV+6QU-4Q+12\bigr).
\end{aligned}
\]

For \(|P||P^\circ|-32/3\), the sign-adjusted numerator has tensor degree

\[
(5,2,3,3)
\]

and Bernstein statistics

\[
158>0,\qquad130=0,\qquad0<0,
\]

with minimum positive coefficient \(4/5\). The denominator has degree

\[
(2,1,2,2)
\]

and statistics

\[
37>0,\qquad17=0,\qquad0<0,
\]

with minimum positive coefficient \(9/4\).

Therefore the Mahler margin is strictly positive on the whole strict realization space.
