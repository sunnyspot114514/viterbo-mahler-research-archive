# 四维中心对称 Mahler：新引理验核与 22F,D=18 推进

日期：2026-08-21

## 结论

本轮首先对新使用的 Guberman 局部极小体必要条件进行了原文级验核，然后完成了 `12V/22F,c=0,D=18` 中三个连续分支：

\[
\boxed{\text{Families }20,27,34\quad\checkmark}.
\]

因此该层的 13 个 algebraic survivors 现已关闭 3 个，剩余 10 个：

\[
\boxed{28,29,32,33,43,49,51,67,69,71}.
\]

所有勾号均表示 computer-assisted analytic proof candidate，尚未经过外部同行审阅。

## 1. Guberman 定理接口验核

已核对原始 arXiv v1 的 Theorem 3.2。其适用对象是：在“中心对称多胞体、顶点数至多为固定值”的类别中成为局部 volume-product 极小者的多胞体。结论包含 cube 与 cross-polytope 两个例外；非例外情形要求：

1. 每个顶点至少属于 \(n-1\) 个非单纯 facets；
2. 每个 facet 至少包含 \(n-1\) 个图度数至少 \(n+1\) 的顶点。

本项目只在 bounded-class minimizer 论证中使用该条件，不把它解释为所有同层多胞体的普遍性质。

对四维 `12V,c=0`，若 single-defect row-pairs 数为 \(s\)，第 \(j\) 个方向被 single row 漏掉 \(d_j\) 次，则每个实际顶点恰属于 \(s-d_j\) 个非单纯 facets。于是必要条件为

\[
s-d_j\ge3,\qquad s\ge4,\qquad d_j\le s-3.
\]

若总 facet-pairs 数为 \(m\)，每行只有一或两个 defects，则

\[
D=2m-s\le2m-4.
\]

这重新验证了 `22F,D=19` 的极小者排除，并验证 `D=18` 时四条 single defects 必须位于四个不同方向。实际 facet、图边、顶点度数和 facet 内高图度顶点均由 exact verifier 直接重建，没有把 facet-pair 数误当作实际 facet 数。

## 2. Family 20

Family 20 的 rank-four branch 唯一，完整严格域由两个对称 open chambers `b<c`、`b>c` 及公共墙 `b=c` 覆盖。

open chamber 的 Mahler-margin Bernstein 证书：

\[
\deg N=(2,6,4,4),\quad299>0,\quad226=0,\quad\min_+=1/9,
\]

\[
\deg Q=(1,4,3,1),\quad45>0,\quad35=0,\quad\min_+=3/4.
\]

公共墙独立得到：

\[
69>0,\quad36=0,\quad\min_+=8/15.
\]

两侧体积公式在墙上精确一致。该族保持 12 个 primal vertices 与 22 个 polar vertices。

## 3. Family 27

取自由 defects

\[
p=x_{5,5},\ q=x_{6,3},\ r=x_{7,5},\ s=x_{8,2}.
\]

rank-four completion 唯一。完整严格域精确为

\[
-1<p,q,r,s<1,\qquad p+r<0.
\]

它与单位开四立方体有理双射：

\[
p=2U-1,\quad r=2(1-U)V-1,\quad q=2Q-1,\quad s=2S-1.
\]

固定全域 boundary decompositions 使用

\[
35\text{ 个 primal tetrahedra},\qquad76\text{ 个 polar tetrahedra}.
\]

Mahler-margin 证书：

\[
\deg N=(5,2,3,3),\quad158>0,\quad130=0,\quad\min_+=4/5,
\]

\[
\deg Q=(2,1,2,2),\quad37>0,\quad17=0,\quad\min_+=9/4.
\]

所以整个严格域上 \(|P||P^\circ|>32/3\)。

## 4. Family 34

取自由 defects

\[
p=x_{5,3},\ q=x_{6,2},\ r=x_{7,4},\ s=x_{9,5}.
\]

完整严格域就是

\[
-1<p,q,r,s<1.
\]

固定全域 decompositions 使用

\[
33\text{ 个 primal tetrahedra},\qquad76\text{ 个 polar tetrahedra}.
\]

Mahler-margin 证书：

\[
\deg N=(3,3,2,6),\quad180>0,\quad156=0,\quad\min_+=4/9,
\]

\[
\deg Q=(2,2,1,3),\quad45>0,\quad27=0,\quad\min_+=3/4.
\]

因此 Family 34 也在完整开四立方体上严格满足目标下界。

## 5. 当前证明树

\[
\boxed{
\begin{array}{c|c}
12V/22F,c=0 & \text{状态}\\
\hline
D=19 & \checkmark\ \text{（bounded-class 极小者结构排除）}\\
D=18 & 13\to10\text{ 个连续 survivors}
\end{array}}
\]

下一步优先处理 Family 29 与 49。它们的 rank-four completion 已经唯一化，strict domain 只比自由参数立方体多出少量低次数不等式；Families 28、33 则需要多 chart 参数化。
