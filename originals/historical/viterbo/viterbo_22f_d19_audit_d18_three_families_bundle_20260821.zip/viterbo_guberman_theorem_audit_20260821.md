# Audit of the Guberman local-minimizer condition used in the 4D bounded-12 Mahler program

Date: 2026-08-21

## External source checked

Agam Guberman, *A connection between the Mahler conjecture and floating bodies*, arXiv:2608.10994v1 (submitted 2026-08-11).

Theorem 3.2 applies to a centrally symmetric polytope that is a **local minimum of the volume product among centrally symmetric polytopes with at most a fixed number of vertices**. It says that one of the following holds:

1. every vertex belongs to at least `n-1` nonsimplex facets and every facet contains at least `n-1` vertices of graph degree at least `n+1`;
2. the polytope is a linear image of the cube;
3. the polytope is a linear image of the cross-polytope.

The paper also states that the proof has an at-most-facets version and can be combined with the dual statement.

## Scope discipline

The theorem is used only inside the bounded-class minimizer argument. It is **not** used to assert that every polytope in a combinatorial layer satisfies these conditions. Consequently, a layer closed solely by this theorem is labelled “excluded for a local minimizer,” not “direct Mahler inequality proved for every member of the layer.”

The cube and cross-polytope exceptions are disjoint from the genuine `12V/22F` branch by their vertex/facet counts.

## Translation to the 4D pairing matrix

In the `12V`, `c=0` setup there are six antipodal vertex pairs and `m` antipodal facet pairs. In the layers under consideration every facet row has one or two defects:

- a single-defect row-pair represents two 5-vertex, hence nonsimplex, facets;
- a double-defect row-pair represents two tetrahedral facets.

Let `s` be the number of single-defect row-pairs, and let `d_j` be the number of single rows whose omitted vertex direction is `j`.

For either actual vertex in direction `j`, the number of incident nonsimplex facets is exactly

` s - d_j `.

In dimension four, Theorem 3.2 therefore gives the necessary local-minimizer conditions

` s - d_j >= 3 ` for every `j`,

hence

` s >= 4`,  `d_j <= s-3`.

If every row has one or two defects and the total defect count is `D`, then

`D = s + 2(m-s) = 2m-s`,

so every non-cube/non-cross local minimizer in these layers must satisfy

`D <= 2m-4`.

## Recheck of 22F, D=19

Here `m=11` and `D=19`, so `s=2m-D=3`. This contradicts `s>=4`.

Equivalently, the six actual nonsimplex facets supply only `6*5=30` vertex–nonsimplex-facet incidences, whereas 12 vertices each requiring at least 3 such incidences would require at least 36.

The exact verifier rechecked all 92 canonical templates and found single-direction partitions

- `(1,1,1)`: 20;
- `(2,1)`: 66;
- `(3)`: 6.

All 92 violate the vertex condition. Thus `22F,D=19` is closed **in the bounded-class local-minimizer architecture**.

## Recheck of 22F, D=18

Here `s=4`, so `d_j <= 1`. Therefore the four single defects must lie in four distinct coordinate directions.

The exact combinatorial implementation was audited to use actual facets and graph degrees, not facet-pair counts:

- it expands every row-pair into two actual facets;
- reconstructs graph edges from the full facet incidence list;
- computes actual vertex degrees;
- checks the number of high-degree vertices in each actual facet.

After this filter and exact low-rank/degeneracy checks, the accounting is

`62 = 13 facet-condition failures + 34 rank>=5 + 1 duplicate primal pair + 1 insufficient incident facets + 13 algebraic survivors`.

## Reliability status

- The external theorem is a very recent arXiv v1 dependency and should be cited explicitly as such.
- The theorem statement, local-minimum hypothesis, cube/cross exceptions, and dual/facet remark have been checked against the original paper.
- The combinatorial translation and all template-level conclusions are independently replayed with exact integer/rational arithmetic.
- This audit does not constitute peer review of the external theorem itself.
