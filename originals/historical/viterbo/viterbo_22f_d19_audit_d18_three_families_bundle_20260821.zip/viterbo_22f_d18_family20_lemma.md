# Family 20 in 12V/22F, c=0, D=18

## Claim

On its full strict rank-four realization space, canonical Family 20 satisfies

`|P| |P^o| > 32/3`.

This is a computer-assisted analytic proof candidate.

## Pairing template and rank completion

The template has 11 antipodal facet rows: four single-defect rows and seven double-defect rows. Use free defects

`a=x4_0`, `b=x7_2`, `c=x8_3`, `d=x10_1`.

Rows `(0,1,4,10)` and columns `(2,3,4,5)` form a constant pivot with determinant `8`.

The 14 Schur-complement equations have a zero-dimensional Gröbner basis of length 14 over `Q(a,b,c,d)`, and uniquely determine every remaining defect as a rational function. Thus there is one strict rational four-parameter branch in this pivot chart.

## Strict domain

Define

`K=3-b-c-bc`,

`U_b=1-4(1-b)/K`, `U_c=1-4(1-c)/K`.

The full strict domain is

`-1<a,b,c<1`,  `-1<d<min(U_b,U_c)`.

There is an exact signed-coordinate symmetry interchanging `b` and `c`. It is therefore enough to certify the open chamber `b<c`, its image `b>c`, and the common wall `b=c`.

For `b<c`, use

`a=2A-1`,

`b=2B-1`,

`c=2B-1+2(1-B)C`,

`d=-1 + [2B(1-C)/(1+B-BC)]T`,

with `0<A,B,C,T<1`.

All 18 defect inequalities and all completion denominators have exact Bernstein sign certificates. The wall `b=c` is independently parameterized and certified.

## Extremality and section closure

All six primal vertex-pairs have full-dimensional normal cones, so `f_0(P)=12`.

The exact facet-wise boundary decompositions certify:

- 22 actual primal facets: 14 tetrahedral and 8 five-vertex facets;
- 12 actual polar facets;
- 32 primal boundary tetrahedra;
- 74 polar-facet tetrahedra.

The primal tetrahedra form a closed 3-sphere, and each primal and polar facet triangulation is a 3-ball. Every nonzero simplex determinant has a fixed Bernstein-certified sign on its chart. Thus the section has exactly 22 vertices and no hidden facet/vertex loss.

## Mahler margin on the open chamber

The exact primal volume is

```
(A*B^2*C^2*T - 2*A*B^2*C*T + A*B^2*T
 - A*B*C^2*T + 2*A*B*C*T - A*B*T
 + 2*B^2*C^2 - 4*B^2*C + 2*B^2
 + B*C^2*T + 2*B*C^2 - 3*B*C*T - 10*B*C
 + 2*B*T + 8*B - 2*C + 6)
/[6(B*C-B-1)^2].
```

The polar volume is the exact rational formula stored in the machine certificate.

For `|P||P^o|-32/3`, the sign-adjusted numerator has tensor Bernstein degree `(2,6,4,4)` with

- 299 positive coefficients;
- 226 zero coefficients;
- no negative coefficients;
- minimum positive coefficient `1/9`.

The denominator has degree `(1,4,3,1)` with 45 positive, 35 zero, no negative coefficients, and minimum positive coefficient `3/4`.

Hence the margin is strictly positive throughout the open chamber.

## Common wall b=c

The wall is triangulated and checked independently. Its exact primal volume is

`(A B^2 T - A B T + 2B^2 + 2BT + 8B + 6)/(6(B+1)^2)`.

The wall margin numerator has degree `(2,6,4)` with

- 69 positive;
- 36 zero;
- no negative coefficients;
- minimum positive `8/15`.

Its denominator has degree `(1,4,1)` with minimum positive coefficient `9/4`.

The open-chamber volume formulas specialize exactly to the wall formulas at `C=0`, so the two certified pieces glue without a gap.

## Conclusion

By the `b<->c` symmetry, the two open chambers and common wall cover the complete strict realization space. Therefore

`|P||P^o| > 32/3`

throughout Family 20.
