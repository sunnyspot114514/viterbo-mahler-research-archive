#!/usr/bin/env python3
"""Independent exact verifier for 12V/22F, c=0, D=18, canonical family 27.

The verifier recomputes, rather than imports, the rank-four branch from the
canonical sign template.  It proves the full strict realization domain, treats
both open chambers and their common wall, certifies extremality and the listed
facet boundary, derives exact primal/polar volumes, and proves the Mahler
margin by tensor-Bernstein positivity.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

UNIQUE = Path('/mnt/data/viterbo_d18_work/unique_d18.txt')
OUT = Path('/mnt/data/viterbo_22f_d18_family27_verifier_output.json')
CERT = Path('/mnt/data/viterbo_22f_d18_family27_certificate.json')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def decode_template(cid: int = 20) -> tuple[str, list[list[int]]]:
    keys = {int(i): key for i, key in (line.split() for line in UNIQUE.read_text().splitlines() if line.strip())}
    key = keys[cid]
    vals = [ord(c) - ord('1') for c in key]
    rows = [vals[6*i:6*i+6] for i in range(11)]
    assert sum(row.count(0) for row in rows) == 18
    assert Counter(row.count(0) for row in rows) == Counter({2: 7, 1: 4})
    return key, rows


def tensor_bernstein(poly: sp.Expr, variables: tuple[sp.Symbol, ...]):
    p = sp.Poly(sp.expand(poly), *variables, domain='QQ')
    degrees = tuple(map(int, p.degree_list()))
    powers = dict(p.terms())
    coeffs = []
    for beta in itertools.product(*[range(d + 1) for d in degrees]):
        value = sp.Rational(0)
        for alpha, co in powers.items():
            if all(alpha[j] <= beta[j] for j in range(len(variables))):
                weight = sp.Rational(1)
                for j, degree in enumerate(degrees):
                    weight *= sp.Rational(math.comb(beta[j], alpha[j]), math.comb(degree, alpha[j]))
                value += co * weight
        coeffs.append(sp.factor(value))
    return degrees, coeffs


class SignEngine:
    def __init__(self, variables: tuple[sp.Symbol, ...], sample: dict[sp.Symbol, sp.Rational]):
        self.variables = variables
        self.sample = sample
        self.cache: dict[str, tuple[tuple[int, ...], list[sp.Rational]]] = {}

    def positive_poly(self, poly: sp.Expr, label: str = '') -> dict:
        poly = sp.factor(poly)
        key = sp.srepr(poly)
        if key not in self.cache:
            self.cache[key] = tensor_bernstein(poly, self.variables)
        degree, coeffs = self.cache[key]
        positive = [x for x in coeffs if x > 0]
        negative = [x for x in coeffs if x < 0]
        assert not negative and positive, (label, degree, negative[:3], poly)
        return {
            'degree': list(degree),
            'positive': len(positive),
            'zero': sum(x == 0 for x in coeffs),
            'min_positive': str(min(positive)),
        }

    def positive_rational(self, expression: sp.Expr, label: str = '') -> dict:
        expression = sp.cancel(expression)
        assert sp.N(expression.subs(self.sample)) > 0, (label, expression.subs(self.sample), expression)
        numerator, denominator = map(sp.factor, sp.together(expression).as_numer_denom())
        if denominator.subs(self.sample) < 0:
            numerator, denominator = -numerator, -denominator
        return {
            'numerator': self.positive_poly(numerator, label + ' numerator'),
            'denominator': self.positive_poly(denominator, label + ' denominator'),
        }


def project3(points: np.ndarray) -> np.ndarray:
    delta = points - points[0]
    return delta @ np.linalg.svd(delta, full_matrices=False)[2][:3].T


def pulling_triangulation(ids: list[int], coords: np.ndarray) -> list[tuple[int, int, int, int]]:
    ids = sorted(ids)
    if len(ids) == 4:
        return [tuple(ids)]
    projected = project3(coords[ids])
    hull = ConvexHull(projected)
    out = set()
    for triangle, equation in zip(hull.simplices, hull.equations):
        if abs(float(equation[:-1] @ projected[0] + equation[-1])) < 1e-8:
            continue
        out.add(tuple(sorted([ids[0]] + [ids[i] for i in triangle])))
    return sorted(out)


def check_closed_sphere(tetrahedra: list[tuple[int, ...]]) -> dict:
    triangles = Counter(tuple(sorted(q)) for tet in tetrahedra for q in itertools.combinations(tet, 3))
    assert set(triangles.values()) == {2}
    vertices = set(x for tet in tetrahedra for x in tet)
    edges = set(tuple(sorted(e)) for tet in tetrahedra for e in itertools.combinations(tet, 2))
    return {'vertices': len(vertices), 'edges': len(edges), 'triangles': len(triangles), 'tetrahedra': len(tetrahedra)}


def check_facet_balls(tetrahedra: list[tuple[int, ...]], facets: list[list[int]]) -> list[int]:
    counts = []
    for index, facet in enumerate(facets):
        group = [tet for tet in tetrahedra if set(tet) <= set(facet)]
        assert group and set(x for tet in group for x in tet) == set(facet), (index, facet)
        triangles = Counter(tuple(sorted(q)) for tet in group for q in itertools.combinations(tet, 3))
        boundary = [q for q, count in triangles.items() if count == 1]
        bvertices = set(x for q in boundary for x in q)
        bedges = set(tuple(sorted(e)) for q in boundary for e in itertools.combinations(q, 2))
        assert len(bvertices) - len(bedges) + len(boundary) == 2
        counts.append(len(group))
    return counts


def build_rank_branch(rows: list[list[int]]):
    matrix = sp.zeros(11, 6)
    variables = []
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            if value == 0:
                x = sp.symbols(f'x{i}_{j}')
                matrix[i, j] = x
                variables.append(x)
            else:
                matrix[i, j] = value

    pivot_rows = [0, 1, 2, 3]
    pivot_cols = [2, 3, 4, 5]
    pivot = matrix.extract(pivot_rows, pivot_cols)
    assert pivot.det() == -8
    other_rows = [i for i in range(11) if i not in pivot_rows]
    other_cols = [j for j in range(6) if j not in pivot_cols]
    schur = sp.simplify(
        matrix.extract(other_rows, other_cols)
        - matrix.extract(other_rows, pivot_cols) * pivot.inv() * matrix.extract(pivot_rows, other_cols)
    )
    equations = [sp.factor(e) for e in list(schur)]

    p = matrix[5, 5]
    q = matrix[6, 3]
    r = matrix[7, 5]
    s = matrix[8, 2]
    free = (p, q, r, s)
    dependent = [x for x in variables if x not in free]
    field = sp.QQ.frac_field(*free)
    groebner = sp.groebner(
        [sp.Poly(e, *dependent, domain=field).as_expr() for e in equations],
        *dependent,
        order='lex',
        domain=field,
    )
    assert groebner.is_zero_dimensional and len(groebner.polys) == 14
    solutions = sp.solve(equations, dependent, dict=True, simplify=False)
    assert len(solutions) == 1
    solution = {x: sp.factor(v) for x, v in solutions[0].items()}
    assert all(sp.factor(e.subs(solution)) == 0 for e in equations)
    return matrix.subs(solution), variables, free, solution, pivot_rows, pivot_cols, groebner

def exact_template_symmetry(rows: list[list[int]]) -> dict:
    perm = (0, 1, 3, 2, 4, 5)
    flips = (-1, -1, -1, -1, -1, -1)
    normalized = tuple(sorted(tuple(r) for r in rows))
    transformed = []
    for row in rows:
        t = [0] * 6
        for k in range(6):
            t[perm[k]] = flips[k] * row[k]
        first = next(x for x in t if x)
        if first < 0:
            t = [-x for x in t]
        transformed.append(tuple(t))
    assert tuple(sorted(transformed)) == normalized
    return {'perm': perm, 'flips': flips, 'action': 'a,d fixed; b,c exchanged'}


def verify_chart(
    base_matrix: sp.Matrix,
    variables: list[sp.Symbol],
    rows: list[list[int]],
    substitutions: dict[sp.Symbol, sp.Expr],
    chart_variables: tuple[sp.Symbol, ...],
    sample: dict[sp.Symbol, sp.Rational],
    name: str,
):
    matrix = base_matrix.subs(substitutions).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    pivot_rows = (0, 1, 2, 3)
    pivot_cols = (2, 3, 4, 5)
    pivot = matrix.extract(pivot_rows, pivot_cols)
    assert pivot.det() == -8
    vertex_matrix = (pivot.inv() * matrix.extract(pivot_rows, range(6))).applyfunc(lambda z: sp.factor(sp.cancel(z)))
    facet_matrix = matrix.extract(range(11), pivot_cols)
    assert all(sp.factor(z) == 0 for z in facet_matrix * vertex_matrix - matrix)

    engine = SignEngine(chart_variables, sample)
    defect_stats = {}
    for x in variables:
        expression = sp.cancel(x.subs(substitutions) if x in substitutions else matrix[int(str(x).split('_')[0][1:]), int(str(x).split('_')[1])])
        # Reading from the completed matrix avoids dependence on whether x was free or dependent.
        i, j = map(int, str(x)[1:].split('_'))
        expression = matrix[i, j]
        defect_stats[str(x)] = engine.positive_rational(1 - expression**2, 'defect ' + str(x))

    extremality = []
    for j in range(6):
        incident = [i for i in range(11) if rows[i][j] != 0]
        found = None
        for rr in itertools.combinations(incident, 4):
            determinant = sp.factor(facet_matrix.extract(rr, range(4)).det(method='domain-ge'))
            if determinant == 0:
                continue
            sign = 1 if determinant.subs(sample) > 0 else -1
            try:
                certificate = engine.positive_rational(sign * determinant, f'extremality vertex {j} rows {rr}')
            except AssertionError:
                continue
            found = {'vertex_pair': j, 'facet_rows': list(rr), 'determinant': str(determinant), 'certificate': certificate}
            break
        assert found is not None, j
        extremality.append(found)

    vnum = np.array(vertex_matrix.subs(sample), dtype=float)
    fnum = np.array(facet_matrix.subs(sample), dtype=float)
    points_p = np.vstack([vnum.T, -vnum.T])
    points_q = np.vstack([fnum, -fnum])
    assert len(ConvexHull(points_p).vertices) == 12
    assert len(ConvexHull(points_q).vertices) == 22

    code = np.array(rows, dtype=int)
    facets_p = []
    for i in range(11):
        facets_p += [
            sorted(j if code[i, j] == 1 else j + 6 for j in range(6) if code[i, j]),
            sorted(j + 6 if code[i, j] == 1 else j for j in range(6) if code[i, j]),
        ]
    facets_q = []
    for j in range(6):
        facets_q += [
            sorted(i if code[i, j] == 1 else i + 11 for i in range(11) if code[i, j]),
            sorted(i + 11 if code[i, j] == 1 else i for i in range(11) if code[i, j]),
        ]

    tetra_p = [tet for facet in facets_p for tet in pulling_triangulation(facet, points_p)]
    tetra_q = [tet for facet in facets_q for tet in pulling_triangulation(facet, points_q)]
    sphere_p = check_closed_sphere(tetra_p)
    balls_p = check_facet_balls(tetra_p, facets_p)
    balls_q = check_facet_balls(tetra_q, facets_q)

    def point_p(i: int):
        return vertex_matrix[:, i] if i < 6 else -vertex_matrix[:, i - 6]

    def point_q(i: int):
        return facet_matrix[i, :].T if i < 11 else -facet_matrix[i - 11, :].T

    def oriented_terms(tetrahedra, point, label):
        terms = []
        records = []
        for index, ids in enumerate(tetrahedra):
            determinant = sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')))
            assert determinant != 0, (label, index, ids)
            sign = 1 if determinant.subs(sample) > 0 else -1
            certificate = engine.positive_rational(sign * determinant, f'{label} tetrahedron {index}')
            terms.append(sp.factor(sign * determinant))
            records.append({'ids': list(ids), 'signed_determinant': str(sp.factor(sign * determinant)), 'certificate': certificate})
        return terms, records

    primal_terms, primal_records = oriented_terms(tetra_p, point_p, 'primal')
    polar_terms, polar_records = oriented_terms(tetra_q, point_q, 'polar')
    volume_p = sp.factor(sp.cancel(sum(primal_terms) / 24))
    volume_q = sp.factor(sp.cancel(sum(polar_terms) / 24))
    margin = sp.factor(sp.cancel(volume_p * volume_q - sp.Rational(32, 3)))
    margin_certificate = engine.positive_rational(margin, 'Mahler margin')

    return {
        'name': name,
        'parameters': [str(x) for x in chart_variables],
        'substitutions': {str(k): str(v) for k, v in substitutions.items()},
        'rank': 4,
        'pivot_determinant': -8,
        'strict_defects': len(defect_stats),
        'defect_certificates': defect_stats,
        'primal_vertices': 12,
        'polar_vertices': 22,
        'extremality': extremality,
        'facet_size_counts_primal': dict(Counter(map(len, facets_p))),
        'facet_size_counts_polar': dict(Counter(map(len, facets_q))),
        'primal_boundary': sphere_p,
        'primal_facet_tetrahedra': balls_p,
        'polar_facet_tetrahedra': balls_q,
        'tetrahedra_primal': len(tetra_p),
        'tetrahedra_polar': len(tetra_q),
        'orientation_records_primal': primal_records,
        'orientation_records_polar': polar_records,
        'volume_P': str(volume_p),
        'volume_polar': str(volume_q),
        'Mahler_margin': str(margin),
        'margin_certificate': margin_certificate,
        'fixed_sign_polynomials': len(engine.cache),
    }, volume_p, volume_q, margin


def main() -> None:
    key, rows = decode_template(27)
    matrix, variables, free, solution, pivot_rows, pivot_cols, groebner = build_rank_branch(rows)
    p, q, r, s = free

    U, V, Q, S = sp.symbols('U V Q S', real=True)
    chart = {
        p: 2*U - 1,
        r: 2*(1-U)*V - 1,
        q: 2*Q - 1,
        s: 2*S - 1,
    }
    result, volume_p, volume_q, margin = verify_chart(
        matrix, variables, rows, chart, (U, V, Q, S),
        {U: sp.Rational(1, 3), V: sp.Rational(1, 2), Q: sp.Rational(2, 5), S: sp.Rational(3, 5)},
        'full strict domain',
    )

    certificate = {
        'scope': '4D symmetric Mahler, bounded-12, 12V/22F,c=0,D=18, canonical family 27',
        'status': 'PASS',
        'canonical_template': key,
        'source_hashes': {str(UNIQUE): sha256(UNIQUE)},
        'rank_ideal': {
            'defect_variables': len(variables),
            'free_variables': [str(x) for x in free],
            'dependent_variables': [str(x) for x in variables if x not in free],
            'pivot_rows': pivot_rows,
            'pivot_cols': pivot_cols,
            'pivot_determinant': -8,
            'groebner_basis_length': len(groebner.polys),
            'zero_dimensional_over_free_parameter_field': bool(groebner.is_zero_dimensional),
            'unique_solution': {str(x): str(v) for x, v in solution.items()},
        },
        'full_strict_domain': {
            'formula': '-1<p,q,r,s<1 and p+r<0',
            'unit_cube_chart': 'p=2U-1, r=2(1-U)V-1, q=2Q-1, s=2S-1, 0<U,V,Q,S<1',
            'inverse': 'U=(p+1)/2, V=(r+1)/(1-p), Q=(q+1)/2, S=(s+1)/2',
        },
        'full_domain': result,
        'conclusion': 'Mahler product is strictly greater than 32/3 on the full strict realization space.',
    }
    CERT.write_text(json.dumps(certificate, indent=2, sort_keys=True))
    output = {
        'status': 'PASS',
        'scope': certificate['scope'],
        'canonical_family': 27,
        'rank_completion': 'unique rational four-parameter branch',
        'domain': certificate['full_strict_domain'],
        'primal_vertices': result['primal_vertices'],
        'polar_vertices': result['polar_vertices'],
        'tetrahedra_primal': result['tetrahedra_primal'],
        'tetrahedra_polar': result['tetrahedra_polar'],
        'volume_P': result['volume_P'],
        'volume_polar': result['volume_polar'],
        'margin_certificate': result['margin_certificate'],
        'certificate': str(CERT),
        'certificate_sha256': sha256(CERT),
        'conclusion': certificate['conclusion'],
    }
    OUT.write_text(json.dumps(output, indent=2, sort_keys=True))
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
