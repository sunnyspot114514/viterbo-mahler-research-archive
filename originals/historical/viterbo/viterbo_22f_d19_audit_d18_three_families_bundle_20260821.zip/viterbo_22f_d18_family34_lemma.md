# Family 34 in 12V/22F, c=0, D=18

Date: 2026-08-21

## Claim

On its complete strict rank-four realization space, canonical Family 34 satisfies

\[
|P|\,|P^\circ|>\frac{32}{3}.
\]

This is a computer-assisted analytic proof candidate.

## Exact rank-four branch and complete domain

Use free defects

\[
p=x_{5,3},\qquad q=x_{6,2},\qquad r=x_{7,4},\qquad s=x_{9,5}.
\]

Rows \((0,1,2,3)\) and columns \((2,3,4,5)\) give a constant pivot of determinant \(-8\). The fourteen Schur equations have a zero-dimensional Gröbner basis of length fourteen over \(\mathbb Q(p,q,r,s)\), and uniquely determine all other defects.

The complete strict domain is simply

\[
-1<p,q,r,s<1.
\]

Set

\[
p=2A-1,\qquad q=2B-1,\qquad r=2C-1,\qquad s=2D-1,
\qquad0<A,B,C,D<1.
\]

All eighteen strict defect inequalities and all completion denominators have exact tensor-Bernstein certificates on this unit four-cube.

## Extremality and closure

The six primal vertex-pairs have full-dimensional normal cones. Certified full-domain boundary decompositions use

\[
33\text{ primal boundary tetrahedra},\qquad
76\text{ polar-facet tetrahedra}.
\]

They certify closed/ball topology facet by facet and fixed signs for every nonzero simplex determinant. Hence

\[
f_0(P)=12,\qquad f_0(P^\circ)=22,
\]

with no hidden chamber switch or combinatorial leakage.

## Mahler margin

The exact primal volume is

\[
\begin{aligned}
|P|={}&\bigl(3A^2B^2CD^3-4A^2B^2CD^2+A^2B^2CD-3A^2B^2D^3+A^2B^2D^2\\
&-6A^2BCD^2+8A^2BCD-A^2BC+7A^2BD^2-A^2BD+3A^2CD-4A^2C-4A^2D\\
&-4AB^2CD^2+4AB^2CD+4AB^2D^2+7ABCD-5ABC-4ABD-4AC-4BC\bigr)\\
&\big/\Bigl(6(ABD-A-B)(ABCD^2-ABCD-ABD^2-ACD+AC+AD+C)\Bigr).
\end{aligned}
\]

The exact polar volume is

\[
|P^\circ|=\frac43\left(ABCD^3-ABD^3-ABD^2-ABD-AB-ACD^2+12\right).
\]

The sign-adjusted Mahler-margin numerator has tensor degree

\[
(3,3,2,6)
\]

with

\[
180>0,\qquad156=0,\qquad0<0,
\]

and minimum positive coefficient \(4/9\). Its denominator has degree

\[
(2,2,1,3)
\]

with

\[
45>0,\qquad27=0,\qquad0<0,
\]

and minimum positive coefficient \(3/4\).

Therefore the Mahler margin is strictly positive throughout the complete strict domain.
