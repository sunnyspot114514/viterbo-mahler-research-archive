#!/usr/bin/env python3
"""Exact symbolic verifier for eight D=14 vertex-loss branches.

The input objects are 10x6 pairing sign templates.  A zero entry is replaced by
an independent symbolic defect variable.  For each branch a constant nonzero
4x4 pivot is used.  Rank <= 4 is then equivalent to vanishing of the Schur
complement.  The script verifies exact algebraic identities showing that, on
the strict defect domain (-1,1)^14, one normalized primal column is a strict
convex combination of two other antipodal columns.
"""
from __future__ import annotations
import json, hashlib, zipfile
from pathlib import Path
import sympy as sp

OUT = Path('/mnt/data/viterbo_20f_d14_vertex_loss_verifier_output.json')

TEMPLATES = {
8:'112000112002112020112022120000120002201200201202202100202102',
154:'112000112002112020120000120002120020202201202210210200212100',
959:'112000112002120000120002120120120122200100200102200210200212',
1065:'112000112002120000120002122010122012200100200102202100202102',
1838:'112000112022112202120000120022120202200110200120200210200221',
2411:'112000112022120000120002202210202212210202211200212002212100',
2651:'112000112022120000120022120201120212200010200021200210200221',
2815:'112000120000120001120002120020120022210100210202210220211200',
}
# NOTE: template strings are checked below against their required zero pattern;
# this catches accidental transcription errors.
EXPECTED_ZERO_POSITIONS = {
8: [(0,0),(0,1),(1,0),(1,1),(2,0),(2,1),(3,0),(3,1),(4,0),(5,0),(6,2),(7,2),(8,3),(9,3)],
154:[(0,0),(0,1),(1,0),(1,1),(2,0),(2,1),(3,0),(4,0),(5,0),(6,5),(7,4),(8,1),(9,1),(9,3)],
959:[(0,0),(0,1),(1,0),(1,1),(2,0),(3,0),(4,0),(4,3),(5,0),(5,3),(6,3),(7,3),(8,4),(9,4)],
1065:[(0,0),(0,1),(1,0),(1,1),(2,0),(3,0),(4,0),(4,4),(5,0),(5,4),(6,3),(7,3),(8,3),(9,3)],
1838:[(0,0),(0,1),(1,0),(1,1),(2,0),(2,1),(3,0),(4,0),(5,0),(6,3),(6,4),(7,3),(8,4),(9,5)],
2411:[(0,0),(0,1),(1,0),(1,1),(2,0),(3,0),(4,4),(5,4),(6,1),(7,1),(7,2),(8,1),(9,1),(9,3)],
2651:[(0,0),(0,1),(1,0),(1,1),(2,0),(3,0),(4,0),(4,5),(5,0),(5,4),(6,4),(7,5),(8,4),(9,5)],
2815:[(0,0),(0,1),(1,0),(2,0),(2,5),(3,0),(4,0),(5,0),(6,1),(6,3),(7,1),(8,1),(9,1),(9,2)],
}
PIVOTS = {
8:((0,1,2,4),(2,3,4,5)),
154:((0,1,2,3),(2,3,4,5)),
959:((2,3,4,6),(1,2,4,5)),
1065:((2,3,6,8),(1,2,4,5)),
1838:((0,1,2,3),(2,3,4,5)),
2411:((0,1,2,3),(2,3,4,5)),
2651:((2,3,4,7),(1,2,3,4)),
2815:((0,1,3,4),(2,3,4,5)),
}
REL = {
8:(0,1,4,'x4_0'),
154:(1,2,3,'x0_1'),
959:(0,1,2,'x2_0'),
1065:(0,1,4,'x2_0'),
1838:(0,1,2,'x3_0'),
2411:(1,2,3,'x0_1'),
2651:(0,1,2,'x2_0'),
2815:(1,2,3,'x0_1'),
}

SOURCE_BUNDLE = Path('/mnt/data/viterbo_20f_d15_complete_and_d14_preclassification_bundle_20260820.zip')
SOURCE_UNIQUE_SHA256 = '8cb0e7c09e3121dab8e6675d54bebfc2fd654183a1f1da06735bb960c4806c46'

def verify_source_bridge():
    assert SOURCE_BUNDLE.exists(), SOURCE_BUNDLE
    with zipfile.ZipFile(SOURCE_BUNDLE) as zf:
        raw=zf.read('viterbo_d14_work/unique_templates.txt')
    assert hashlib.sha256(raw).hexdigest()==SOURCE_UNIQUE_SHA256
    lines=raw.decode().splitlines()
    for fid,t in TEMPLATES.items():
        assert lines[fid]==t, (fid, lines[fid], t)
    return {'bundle':str(SOURCE_BUNDLE),'unique_templates_sha256':SOURCE_UNIQUE_SHA256,'matched_indices':list(TEMPLATES)}

def parse_template(s:str):
    assert len(s)==60
    vals=[int(ch)-1 for ch in s]
    return sp.Matrix(10,6,vals)

def symbolize(M):
    vars={}
    for i in range(10):
        for j in range(6):
            if M[i,j]==0:
                x=sp.Symbol(f'x{i}_{j}')
                M[i,j]=x; vars[str(x)]=x
    return M,vars

def schur(M,rs,cs):
    rr=[i for i in range(10) if i not in rs]
    cc=[j for j in range(6) if j not in cs]
    A=M.extract(rs,cs)
    assert A.det()!=0
    S=sp.simplify(M.extract(rr,cc)-M.extract(rr,cs)*A.inv()*M.extract(rs,cc))
    R={(r,c):sp.factor(S[ii,jj]) for ii,r in enumerate(rr) for jj,c in enumerate(cc)}
    return A,R

def z(e):
    assert sp.factor(e)==0, sp.factor(e)

def build(fid):
    M0=parse_template(TEMPLATES[fid])
    zeros=[(i,j) for i in range(10) for j in range(6) if M0[i,j]==0]
    assert zeros==EXPECTED_ZERO_POSITIONS[fid], (fid,zeros)
    M,V=symbolize(M0)
    rs,cs=PIVOTS[fid]
    A,R=schur(M,rs,cs)
    return M,V,A,R,rs,cs

def relation_vector(M,rs,j,k,l,lam):
    return [sp.factor(M[r,j]+lam*M[r,k]+(1-lam)*M[r,l]) for r in rs]

source_bridge=verify_source_bridge()
records=[]
for fid in TEMPLATES:
    M,V,A,R,rs,cs=build(fid)
    det=sp.factor(A.det())
    assert abs(int(det))==8
    j,k,l,xname=REL[fid]
    x=V[xname]; lam=(1-x)/2
    rel=relation_vector(M,rs,j,k,l,lam)
    checks=[]

    if fid==154:
        z(R[(4,1)]-(V['x0_1']-V['x1_1']))
        z(R[(5,1)]-(V['x0_1']-V['x2_1']))
        sub={V['x1_1']:V['x0_1'],V['x2_1']:V['x0_1']}
        for e in rel:z(e.subs(sub))
        checks=['x0_1=x1_1=x2_1 from Schur equations']
    elif fid==959:
        z(R[(7,0)]-(V['x2_0']-V['x3_0']))
        z(2*R[(8,0)]-(V['x2_0']-V['x4_0'])*(V['x8_4']+1))
        sub={V['x3_0']:V['x2_0'],V['x4_0']:V['x2_0']}
        for e in rel:z(e.subs(sub))
        checks=['x2_0=x3_0','(x2_0-x4_0)(x8_4+1)=0; strict x8_4>-1']
    elif fid==1065:
        z(R[(7,0)]-(V['x2_0']-V['x3_0']))
        sub={V['x3_0']:V['x2_0']}
        for e in rel:z(e.subs(sub))
        checks=['x2_0=x3_0 from Schur equation']
    elif fid==2411:
        z(2*R[(4,1)]-(V['x0_1']-V['x1_1'])*(V['x4_4']-1))
        sub={V['x1_1']:V['x0_1']}
        for e in rel:z(e.subs(sub))
        checks=['(x0_1-x1_1)(x4_4-1)=0; strict x4_4<1']
    elif fid==2651:
        z(2*R[(6,0)]-(V['x2_0']-V['x3_0'])*(V['x6_4']-1))
        z(R[(9,0)]-(V['x2_0']-V['x4_0']))
        sub={V['x3_0']:V['x2_0'],V['x4_0']:V['x2_0']}
        for e in rel:z(e.subs(sub))
        checks=['(x2_0-x3_0)(x6_4-1)=0; strict x6_4<1','x2_0=x4_0']
    elif fid==2815:
        for e in rel:z(e)
        checks=['relation is identically visible on constant pivot rows']
    elif fid==8:
        a,A0,b,B,c,C,d,D,e,f,u,v,w,q=[V[n] for n in ['x0_0','x0_1','x1_0','x1_1','x2_0','x2_1','x3_0','x3_1','x4_0','x5_0','x6_2','x7_2','x8_3','x9_3']]
        z(R[(5,1)]-(A0-B))
        z((R[(6,1)]-R[(7,1)]).subs(B,A0)+(A0-1)*(u-v)/2)
        z((R[(6,0)]-R[(7,0)]).subs({B:A0,v:u})-(-a+b))
        z((R[(8,1)]-R[(9,1)]).subs({B:A0,D:C})-(C+1)*(w-q)/2)
        # strict factors imply B=A0,u=v,a=b,D=C,f=e,w=q
        sub={B:A0,v:u,b:a,D:C,f:e,q:w,d:c}
        I=(a-e)*u+a-2*c-e-2
        II=(A0-1)*u+A0-2*C+1
        III=2*a-(c+e)*(w+1)-2
        IV=2*A0-(C+1)*w-C+1
        z(I+2*R[(6,0)].subs(sub))
        z(II+2*R[(6,1)].subs(sub))
        z(III+2*R[(8,0)].subs(sub))
        z(IV+2*R[(8,1)].subs(sub))
        Lu=-A0*c-A0+C*a-C*e-a+c+e+1
        Lw=-A0*c-A0*e+C*a-C+a-c-e-1
        z((A0-1)*I-(a-e)*II-2*Lu)
        z((C+1)*III-(c+e)*IV-2*Lw)
        Ta=2*a-A0*e+A0-e-1
        Tc=2*c-C*e+C+e+1
        z(Lu+(A0*Tc-C*Ta+Ta-Tc)/2)
        z(Lw+(A0*Tc-C*Ta-Ta+Tc)/2)
        # Lu=Lw=0 => Ta=Tc and (A0-C)Ta=0. If A0=C, II=(A0-1)(u-1), impossible in strict domain.
        subrel={B:A0,v:u,b:a,D:C,f:e,q:w,d:c}
        for rv in rel:
            rr=sp.factor(rv.subs(subrel).subs({Ta:0,Tc:0}))
            # direct substitution of a,c via Ta=Tc=0
            rr=rr.subs({a:(A0*e-A0+e+1)/2,c:(C*e-C-e-1)/2})
            z(rr)
        checks=['strict A0<1 gives u=v','then a=b,d=c,f=e','strict C>-1 gives w=q','two elimination identities give Ta=Tc=0; A0=C would force u=1']
    elif fid==1838:
        a,A0,b,B,c,C,d,e,f,u,v,w,q,y=[V[n] for n in ['x0_0','x0_1','x1_0','x1_1','x2_0','x2_1','x3_0','x4_0','x5_0','x6_3','x6_4','x7_3','x8_4','x9_5']]
        z(R[(4,1)]-(A0-B)); z(R[(5,1)]-(A0-C))
        subABC={B:A0,C:A0}
        z((R[(7,1)]-R[(8,1)]).subs(subABC)-(A0+1)*(w-q)/2)
        z((R[(7,1)]-R[(9,1)]).subs(subABC)-(A0+1)*(w+y)/2)
        z((R[(7,0)]-R[(8,0)]).subs({**subABC,q:w})-(b-c)*(w-1)/2)
        # strict factors give B=C=A0,q=w,y=-w,c=b
        sub={B:A0,C:A0,q:w,y:-w,c:b}
        F=2*R[(6,0)].subs(sub)
        G=2*R[(6,1)].subs(sub)
        Tb=2*b-A0*d+A0+d+1
        z((A0+1)*F-(b+d)*G-2*Tb)
        H=2*R[(7,1)].subs(sub)
        J=2*R[(9,0)].subs(sub)
        z((A0+1)*J-(-a+2*b+d)*H-2*(2*A0*(a-b)+Tb))
        # A0=0 would make G=u+v-2, impossible for strict u,v<1; hence a=b.
        bexpr=(A0*d-A0-d-1)/2
        subfinal={B:A0,C:A0,q:w,y:-w,c:b,a:b}
        for rv in rel:
            z(sp.factor(rv.subs(subfinal).subs(b,bexpr)))
        checks=['B=C=A0','strict A0>-1 gives q=w and y=-w','strict w<1 gives b=c','elimination gives Tb=0','A0=0 would force u+v=2; hence A0!=0 and a=b']
    else:
        raise AssertionError(fid)

    records.append({
        'template_index':fid,'pivot_rows':list(rs),'pivot_columns':list(cs),'pivot_determinant':int(det),
        'lost_positive_vertex':j,'antipodal_endpoints':[k,l],
        'lambda':f'(1-{xname})/2','strict_lambda_interval':'0<lambda<1 because -1<defect<1',
        'relation':f'v_{j} = lambda*(-v_{k}) + (1-lambda)*(-v_{l})',
        'checks':checks,'status':'PASS'
    })

result={
 'scope':'12V/20F,c=0,D=14',
 'claim':'eight algebraic survivor templates cannot represent genuine 12-vertex polytopes',
 'assumptions':['all defect variables are strictly between -1 and 1','pairing-matrix rank is at most 4'],
 'closed_template_indices':list(TEMPLATES),
 'count':len(records),'source_bridge':source_bridge,'records':records,'overall':'PASS'
}
OUT.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'overall':'PASS','closed':list(TEMPLATES),'count':len(records),'output':str(OUT)},indent=2))
