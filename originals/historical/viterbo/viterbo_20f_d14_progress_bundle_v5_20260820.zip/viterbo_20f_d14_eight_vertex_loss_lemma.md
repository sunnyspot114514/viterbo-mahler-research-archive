# Eight exact vertex-loss certificates in the `12V/20F, c=0, D=14` preclassification

Date: 20 August 2026

## Statement

Let `X` be one of the eight canonical pairing templates with indices

\[
8,\ 154,\ 959,\ 1065,\ 1838,\ 2411,\ 2651,\ 2815
\]

in the exact `D=14` preclassification. Replace every zero entry by a strict defect variable in `(-1,1)`, and assume

\[
\operatorname{rank}X\le 4.
\]

Then the corresponding centrally symmetric configuration cannot have six genuine antipodal vertex pairs. In every case one positive candidate vertex lies in the relative interior of an edge joining two other antipodal vertices.

More precisely, the following identities hold:

| Template | Forced convex-combination identity | Parameter |
|---:|---|---|
| 8 | \(v_0=\lambda(-v_1)+(1-\lambda)(-v_4)\) | \(\lambda=(1-x_{4,0})/2\) |
| 154 | \(v_1=\lambda(-v_2)+(1-\lambda)(-v_3)\) | \(\lambda=(1-x_{0,1})/2\) |
| 959 | \(v_0=\lambda(-v_1)+(1-\lambda)(-v_2)\) | \(\lambda=(1-x_{2,0})/2\) |
| 1065 | \(v_0=\lambda(-v_1)+(1-\lambda)(-v_4)\) | \(\lambda=(1-x_{2,0})/2\) |
| 1838 | \(v_0=\lambda(-v_1)+(1-\lambda)(-v_2)\) | \(\lambda=(1-x_{3,0})/2\) |
| 2411 | \(v_1=\lambda(-v_2)+(1-\lambda)(-v_3)\) | \(\lambda=(1-x_{0,1})/2\) |
| 2651 | \(v_0=\lambda(-v_1)+(1-\lambda)(-v_2)\) | \(\lambda=(1-x_{2,0})/2\) |
| 2815 | \(v_1=\lambda(-v_2)+(1-\lambda)(-v_3)\) | \(\lambda=(1-x_{0,1})/2\) |

Since the parameter in each row is a strict defect,

\[
-1<x<1\quad\Longrightarrow\quad 0<\frac{1-x}{2}<1.
\]

Thus the displayed relation is always a strict convex combination. Each template has at most five genuine antipodal vertex pairs, hence at most ten vertices.

## Rank-to-Schur reduction

For every template, the verifier selects a constant `4 x 4` pairing submatrix with determinant `+8` or `-8`. After normalizing the corresponding four primal columns, rank at most four is equivalent to the vanishing of the `6 x 2` Schur complement.

A linear relation among the six normalized primal columns is equivalent to the same relation among their values on the four pivot rows. The verifier therefore proves the identities using only exact Schur-complement equations.

## The six short branches

Templates 154, 959, 1065, 2411, 2651 and 2815 close immediately.

Examples:

- Template 154 has Schur equations
  \[
  x_{0,1}=x_{1,1}=x_{2,1}.
  \]
  Substituting \(\lambda=(1-x_{0,1})/2\) makes
  \[
  X_{R,1}+\lambda X_{R,2}+(1-\lambda)X_{R,3}=0
  \]
  on the four pivot rows.

- Template 959 has
  \[
  x_{2,0}=x_{3,0},
  \qquad
  (x_{2,0}-x_{4,0})(x_{8,4}+1)=0.
  \]
  Strictness gives \(x_{8,4}+1>0\), hence
  \[
  x_{2,0}=x_{3,0}=x_{4,0},
  \]
  which yields the stated edge relation.

- Template 2411 has
  \[
  (x_{0,1}-x_{1,1})(x_{4,4}-1)=0.
  \]
  Since \(x_{4,4}<1\), the first factor vanishes.

- Template 2815 already displays its column relation identically on a constant pivot; no further elimination is needed.

The other two short cases are checked in the same exact fashion in the verifier.

## Template 8

Use the abbreviations

\[
a=x_{0,0},\ A=x_{0,1},\ b=x_{1,0},\ B=x_{1,1},\
c=x_{2,0},\ C=x_{2,1},\ e=x_{4,0},
\]

and let \(u,v,w,z\) denote the four later single defects appearing in columns 2 and 3.

The Schur equations first give

\[
A=B.
\]

The difference of two second-column Schur equations is

\[
(A-1)(u-v)=0.
\]

Because \(A<1\), this gives \(u=v\). The corresponding first-column difference then gives

\[
a=b.
\]

The remaining linear Schur equations give the paired equalities in the other rows, and

\[
(C+1)(w-z)=0.
\]

Since \(C>-1\), one has \(w=z\).

After these substitutions, the four independent residual equations may be written

\[
\begin{aligned}
I&=(a-e)u+a-2c-e-2=0,\\
II&=(A-1)u+A-2C+1=0,\\
III&=2a-(c+e)(w+1)-2=0,\\
IV&=2A-(C+1)w-C+1=0.
\end{aligned}
\]

Eliminating \(u\) and \(w\) gives

\[
\begin{aligned}
L_u&=-Ac-A+Ca-Ce-a+c+e+1=0,\\
L_w&=-Ac-Ae+Ca-C+a-c-e-1=0.
\end{aligned}
\]

Define

\[
T_a=2a-Ae+A-e-1,
\qquad
T_c=2c-Ce+C+e+1.
\]

The exact identities

\[
L_u=-\frac{AT_c-CT_a+T_a-T_c}{2},
\]

\[
L_w=-\frac{AT_c-CT_a-T_a+T_c}{2}
\]

show that \(T_a=T_c\) and \((A-C)T_a=0\). If \(A=C\), equation `II` becomes

\[
(A-1)(u-1)=0,
\]

which is impossible in the strict domain. Hence

\[
T_a=T_c=0.
\]

With

\[
\lambda=\frac{1-e}{2},
\]

these are exactly the four pivot-row coordinates of

\[
v_0+\lambda v_1+(1-\lambda)v_4=0.
\]

## Template 1838

Write

\[
a=x_{0,0},\quad A=x_{0,1},\quad
b=x_{1,0},\quad c=x_{2,0},\quad d=x_{3,0}.
\]

The Schur equations imply that the three second-coordinate defects coincide. The later second-coordinate equations force two defects to agree and the final one to be their negative. A first-coordinate difference then gives

\[
b=c.
\]

Eliminating the sum of two remaining defects gives

\[
T_b:=2b-Ad+A+d+1=0.
\]

The last first-coordinate Schur equation satisfies the exact identity

\[
(A+1)J-(-a+2b+d)H
=2\bigl(2A(a-b)+T_b\bigr),
\]

where \(H=J=0\) are Schur residuals. Thus

\[
A(a-b)=0.
\]

The branch \(A=0\) would force two strict defects to have sum 2, which is impossible. Therefore

\[
a=b=c.
\]

Taking

\[
\lambda=\frac{1-d}{2}
\]

gives

\[
v_0=\lambda(-v_1)+(1-\lambda)(-v_2).
\]

## Consequence for `D=14`

The exact preclassification had

\[
4319=4024\text{ rank-obstructed}+268\text{ repeated-row}+27\text{ algebraic survivors}.
\]

The present certificates remove eight survivors by primal vertex loss. The current accounting is therefore

\[
\boxed{
4319
=4024\text{ rank-obstructed}
+268\text{ repeated-row}
+8\text{ vertex-loss}
+19\text{ unresolved algebraic survivors}.
}
\]

This does not yet close the `D=14` layer. The remaining nineteen templates require rank-component decomposition, section closure and, for genuine families, Mahler-volume certificates.
