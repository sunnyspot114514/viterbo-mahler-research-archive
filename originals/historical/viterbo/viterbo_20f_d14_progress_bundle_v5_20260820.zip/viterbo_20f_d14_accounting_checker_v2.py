#!/usr/bin/env python3
import json
from pathlib import Path
P=Path('/mnt/data')
pre=json.loads((P/'viterbo_20f_d14_preclassification_certificate.json').read_text())
objs=[
 json.loads((P/'viterbo_20f_d14_vertex_loss_verifier_output.json').read_text()),
 json.loads((P/'viterbo_20f_d14_three_facet_loss_verifier_output.json').read_text()),
 json.loads((P/'viterbo_20f_d14_five_square_families_verifier_output.json').read_text()),
 json.loads((P/'viterbo_20f_d14_three_more_families_verifier_output.json').read_text()),
]
sets=[set(x['closed_template_indices']) for x in objs]
assert all(not sets[i]&sets[j] for i in range(len(sets)) for j in range(i+1,len(sets)))
closed=set().union(*sets);surv=set(pre['algebraic_survivor_indices']);remaining=sorted(surv-closed)
expected=[1102,1282,2503,2742,3775,4300,4304,4318]
assert remaining==expected and len(closed)==19
assert 4024+268+8+3+8+8==4319
out={'status':'PASS','scope':'12V/20F,c=0,D=14','accounting':{'global_templates':4319,'rank_ge_5':4024,'duplicate_rows':268,'primal_vertex_loss':8,'polar_vertex_loss':3,'Mahler_positive':8,'remaining':8},'closed_indices':sorted(closed),'remaining_indices':remaining}
(P/'viterbo_20f_d14_accounting_checker_v2_output.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
