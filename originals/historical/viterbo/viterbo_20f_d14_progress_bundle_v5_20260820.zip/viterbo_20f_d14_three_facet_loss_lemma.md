# Three exact polar-vertex losses in the `12V/20F, c=0, D=14` preclassification

Date: 20 August 2026

## Statement

For canonical algebraic survivor templates

\[
447,\qquad2723,\qquad2871,
\]

assume all fourteen defect entries lie strictly in `(-1,1)` and the pairing matrix has rank at most four. Then one of the ten listed positive section rows lies in the relative interior of an edge joining two other listed rows. Consequently the associated cube section has at most nine antipodal vertex pairs, and the primal object has fewer than twenty genuine facets.

The exact relations are:

| Template | Lost section row | Strict segment relation |
|---:|---:|---|
| 447 | 5 | \(r_5=\lambda r_6+(1-\lambda)r_7\), \(0<\lambda<1\) |
| 2723 | 6 | \(r_6=(1-\theta)r_5+\theta r_7\), \(0<\theta<1\) |
| 2871 | 2 | \(r_2=\lambda r_1+(1-\lambda)r_3\), \(\lambda=(1-x_{2,5})/2\) |

## Template 447

Rows 5, 6 and 7 share their first four coordinates. Write their last two coordinates as

\[
P_5=(m,n),\qquad P_6=(p,1),\qquad P_7=(1,q).
\]

A constant `4 x 4` pivot has determinant 8. The two Schur-complement coordinates define two linear functionals

\[
K_0=(x_{0,0}-x_{2,0},\ x_{0,0}-x_{1,0}),
\]

\[
K_1=(x_{0,1}-x_{2,1},\ x_{0,1}-x_{1,1}).
\]

Exact subtraction of the row-5, row-6 and row-7 Schur equations gives

\[
K_i\cdot(P_5-P_6)=0,
\qquad
K_i\cdot(P_7-P_6)=0,
\qquad i=0,1.
\]

At least one of `K_0,K_1` is nonzero. Indeed, if both vanished, the same Schur equations would force

\[
x_{0,0}=1,
\qquad
x_{0,1}=-1,
\]

contradicting strictness. Hence both difference vectors lie in the same one-dimensional kernel, so `P_5,P_6,P_7` are collinear.

Write

\[
P_5=\lambda P_6+(1-\lambda)P_7.
\]

Since `m<1` and `p<1`, one gets `lambda>0`; since `n<1` and `q<1`, one gets `lambda<1`. Thus row 5 is strictly non-extreme.

## Template 2723

Rows 5, 6 and 7 again share four coordinates. Their two free coordinate pairs are

\[
P_5=(m,-1),\qquad P_6=(p,n),\qquad P_7=(1,q).
\]

The relevant nonzero Schur functional is

\[
K_1=(x_{0,1}+1,-x_{1,1}-1).
\]

It cannot vanish in the strict domain because `x_{0,1}+1>0`. Exact Schur subtraction gives

\[
K_1\cdot(P_6-P_5)=0,
\qquad
K_1\cdot(P_7-P_5)=0.
\]

Therefore the three points are collinear. Writing

\[
P_6=(1-\theta)P_5+\theta P_7,
\]

one may take

\[
\theta=\frac{n+1}{q+1}.
\]

The inequalities `n>-1` and `p<1` yield

\[
0<\theta<1.
\]

Thus row 6 is strictly non-extreme.

## Template 2871

Rows 1, 2 and 3 share coordinates 1 through 4. The first Schur equation is exactly

\[
x_{1,0}x_{2,5}-x_{1,0}+2x_{2,0}
-x_{2,5}x_{3,0}-x_{3,0}=0.
\]

Setting

\[
\lambda=\frac{1-x_{2,5}}2
\]

gives

\[
x_{2,0}=\lambda x_{1,0}+(1-\lambda)x_{3,0},
\]

and the sixth coordinate satisfies the same affine relation between `-1`, `x_{2,5}` and `+1`. Hence

\[
r_2=\lambda r_1+(1-\lambda)r_3.
\]

Strictness gives `0<lambda<1`.

## Updated `D=14` accounting

Combining the eight primal vertex-loss certificates with these three polar vertex-loss certificates gives

\[
\boxed{
4319
=4024\text{ rank-obstructed}
+268\text{ repeated-row}
+8\text{ primal vertex-loss}
+3\text{ polar vertex-loss}
+16\text{ unresolved algebraic survivors}.
}
\]

The `D=14` layer is not yet closed. The sixteen remaining templates pass these elementary extremality filters and require rank-component decomposition, exact section closure and, for genuine families, Mahler-margin analysis.
