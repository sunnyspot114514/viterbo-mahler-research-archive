#!/usr/bin/env python3
"""Exact symbolic verifier for three D=14 polar-vertex/facet-loss branches."""
from __future__ import annotations
import json, hashlib, zipfile
from pathlib import Path
import sympy as sp

OUT=Path('/mnt/data/viterbo_20f_d14_three_facet_loss_verifier_output.json')
BUNDLE=Path('/mnt/data/viterbo_20f_d15_complete_and_d14_preclassification_bundle_20260820.zip')
SOURCE_SHA='8cb0e7c09e3121dab8e6675d54bebfc2fd654183a1f1da06735bb960c4806c46'
IDS=[447,2723,2871]
PIVOTS={447:((0,1,2,3),(2,3,4,5)),2723:((0,1,2,4),(2,3,4,5)),2871:((0,1,3,4),(2,3,4,5))}

def z(e):
    assert sp.factor(e)==0,sp.factor(e)

def load():
    with zipfile.ZipFile(BUNDLE) as q: raw=q.read('viterbo_d14_work/unique_templates.txt')
    assert hashlib.sha256(raw).hexdigest()==SOURCE_SHA
    lines=raw.decode().splitlines()
    return {i:lines[i] for i in IDS}

def build(s,rs,cs):
    M=sp.Matrix(10,6,[int(x)-1 for x in s])
    V={}
    for i in range(10):
        for j in range(6):
            if M[i,j]==0:
                x=sp.Symbol(f'x{i}_{j}');M[i,j]=x;V[str(x)]=x
    rr=[i for i in range(10) if i not in rs];cc=[j for j in range(6) if j not in cs]
    A=M.extract(rs,cs);assert abs(int(A.det()))==8
    S=sp.simplify(M.extract(rr,cc)-M.extract(rr,cs)*A.inv()*M.extract(rs,cc))
    R={(r,c):sp.factor(S[ii,jj]) for ii,r in enumerate(rr) for jj,c in enumerate(cc)}
    return M,V,A,R

templates=load();records=[]

# Template 447: row 5 lies strictly between rows 6 and 7.
M,V,A,R=build(templates[447],*PIVOTS[447])
a,b,c=[V[x] for x in ['x0_0','x1_0','x2_0']];A0,B,C=[V[x] for x in ['x0_1','x1_1','x2_1']]
m,n,p,q=[V[x] for x in ['x5_4','x5_5','x6_4','x7_5']]
d1=sp.Matrix([m-p,n-1]);d2=sp.Matrix([1-p,q-1])
K0=sp.Matrix([a-c,a-b]);K1=sp.Matrix([A0-C,A0-B])
z(2*(R[(5,0)]-R[(6,0)])-(K0.dot(d1)))
z(2*(R[(5,1)]-R[(6,1)])-(K1.dot(d1)))
z(2*(R[(7,0)]-R[(6,0)])-(K0.dot(d2)))
z(2*(R[(7,1)]-R[(6,1)])-(K1.dot(d2)))
# If K0=K1=0, Schur residuals force a=1 and A0=-1, violating strictness.
sub={b:a,c:a,B:A0,C:A0}
z(R[(5,0)].subs(sub)-(1-a));z(R[(5,1)].subs(sub)-(-A0-1))
# Collinearity and strict coordinates imply row5 is in the open segment [row6,row7].
records.append({'template_index':447,'lost_section_row':5,'endpoint_rows':[6,7],
 'relation':'r5=lambda*r6+(1-lambda)*r7','strictness_argument':'m<1 gives lambda>0; n<1 gives lambda<1',
 'certificate':'two Schur linear functionals annihilate both difference vectors; simultaneous zero functionals force boundary defects','status':'PASS'})

# Template 2723: row 6 lies strictly between rows 5 and 7.
M,V,A,R=build(templates[2723],*PIVOTS[2723])
a,b,e=[V[x] for x in ['x0_0','x1_0','x4_0']];A0,B=[V[x] for x in ['x0_1','x1_1']]
m,p,n,q=[V[x] for x in ['x5_4','x6_4','x6_5','x7_5']]
d1=sp.Matrix([p-m,n+1]);d2=sp.Matrix([1-m,q+1])
K0=sp.Matrix([a+e,-(b+e)]);K1=sp.Matrix([A0+1,-(B+1)])
z(2*(R[(6,0)]-R[(5,0)])-K0.dot(d1))
z(2*(R[(6,1)]-R[(5,1)])-K1.dot(d1))
z(2*(R[(7,0)]-R[(5,0)])-K0.dot(d2))
z(2*(R[(7,1)]-R[(5,1)])-K1.dot(d2))
# K1 is nonzero in the strict domain because both A0+1 and B+1 are positive.
records.append({'template_index':2723,'lost_section_row':6,'endpoint_rows':[5,7],
 'relation':'r6=(1-theta)*r5+theta*r7','theta':'(x6_5+1)/(x7_5+1)',
 'strictness_argument':'x6_5>-1 gives theta>0; x6_4<1 gives theta<1',
 'certificate':'the nonzero Schur functional K1 annihilates both difference vectors, forcing collinearity','status':'PASS'})

# Template 2871: direct Schur equation gives row 2 between rows 1 and 3.
M,V,A,R=build(templates[2871],*PIVOTS[2871])
x1,x2,x3,y=[V[x] for x in ['x1_0','x2_0','x3_0','x2_5']]
z(2*R[(2,0)]-(x1*y-x1+2*x2-y*x3-x3))
lam=(1-y)/2
# Check the varying coordinates; all other row coordinates are identical.
z((x2-(lam*x1+(1-lam)*x3))-R[(2,0)])
z(y-(lam*(-1)+(1-lam)*1))
records.append({'template_index':2871,'lost_section_row':2,'endpoint_rows':[1,3],
 'relation':'r2=lambda*r1+(1-lambda)*r3','lambda':'(1-x2_5)/2',
 'strictness_argument':'-1<x2_5<1 gives 0<lambda<1','certificate':'single exact Schur equation','status':'PASS'})

result={'scope':'12V/20F,c=0,D=14','claim':'three algebraic survivor templates lose one polar section vertex and therefore do not have 20 genuine facets',
 'source_bridge':{'bundle':str(BUNDLE),'unique_templates_sha256':SOURCE_SHA,'matched_indices':IDS},
 'closed_template_indices':IDS,'count':3,'records':records,'overall':'PASS'}
OUT.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'overall':'PASS','closed':IDS,'output':str(OUT)},indent=2))
