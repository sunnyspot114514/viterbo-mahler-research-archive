#!/usr/bin/env python3
"""Aggregate exact verifier for five D=14 two-parameter survivor families.

Families (canonical template indices): 2391, 2653, 2744, 4086, 4211.
Each strict realization space is the full open square (-1,1)^2.  The script
checks the bridge to the original 4319-template preclassification, rank-four
completion, branch exhaustiveness where a boundary component occurs, all
strict defects, primal extremality, prescribed facet-ball topology, globally
fixed triangulations, exact volumes, and tensor-Bernstein positivity of the
Mahler margin.
"""
from __future__ import annotations
import hashlib, itertools, json, math, zipfile
from collections import Counter, defaultdict, deque
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

OUT=Path('/mnt/data/viterbo_20f_d14_five_square_families_verifier_output.json')
SOURCE=Path('/mnt/data/viterbo_20f_d15_complete_and_d14_preclassification_bundle_20260820.zip')
SOURCE_SHA='8cb0e7c09e3121dab8e6675d54bebfc2fd654183a1f1da06735bb960c4806c46'
A,B=sp.symbols('A B', real=True); VARS=(A,B)
p,q=sp.symbols('p q', real=True); PMAP={p:2*A-1,q:2*B-1}

FAMILIES={
2391:{
 'pivot':((0,1,2,3),(2,3,4,5)),'sample':(sp.Rational(1,5),sp.Rational(-1,3)),'free':('x4_2','x5_4'),'tets':(36,67),
 'sol':{'x0_0':(1-p*q)/(p+q+2),'x0_1':(p-1)/(p+3),'x1_0':(p*q-1)/(p+q+2),'x1_1':(1-p)/(p+3),'x2_0':-(p*q+2*q+1)/(p+q+2),'x3_0':(p-q)/(p+q+2),'x4_2':p,'x5_2':(1+p+q-p*q)/2,'x5_4':q,'x6_3':p,'x7_3':(1+p+q-p*q)/2,'x7_4':q,'x8_1':(p-1)/(p+3),'x9_1':(p-1)/(p+3)},
 'volP':(p**2+2*p*q+10*p+8*q+15)/(3*(p+3)*(p+q+2)),
 'volQ':-(p**2*q**2-4*p**2*q+11*p**2+4*p*q-28*p-q**2+8*q-167)/12,
 'mN':([4,3],14,6,'256/3'),'mD':([2,1],5,1,'72'),'branch':'unique'},
2653:{
 'pivot':((2,3,5,6),(1,2,3,5)),'sample':(sp.Rational(-1,5),sp.Rational(-1,3)),'free':('x7_5','x8_2'),'tets':(34,68),
 'sol':{'x0_0':(p+1)/(p-3),'x0_1':(p*q-3*p-q-1)/(p*q+p-q-5),'x1_0':(p+1)/(p-3),'x1_1':(p*q-3*p-q-1)/(p*q+p-q-5),'x2_0':(p+1)/(p-3),'x3_0':(p+1)/(p-3),'x4_0':-(p*q-q-2)/(p-3),'x4_5':-(p*q-p-q-1)/2,'x5_0':-(p*q-q-2)/(p-3),'x5_4':(p*q-p-q-1)/2,'x6_4':-p,'x7_5':p,'x8_2':q,'x9_1':(p*q+p-q+3)/(p*q+p-q-5)},
 'volP':-(p**2*q+p**2-6*p*q-18*p+5*q+41)/(12*(p-3)),
 'volQ':-(p**2*q**3-3*p**2*q**2-p**2*q-13*p**2-2*p*q**3+10*p*q**2-22*p*q-34*p+q**3-7*q**2+23*q+303)/(6*(p*q+p-q-5)),
 'mN':([4,4],19,6,'384'),'mD':([2,1],6,0,'576'),'branch':'unique'},
2744:{
 'pivot':((1,2,3,9),(2,3,4,5)),'sample':(sp.Rational(1,5),sp.Rational(-1,3)),'free':('x6_3','x7_5'),'tets':(34,70),
 'sol':{'x0_0':(q-1)/(q+3),'x0_1':-(p*q+p-q+3)/(p*q+p-q-5),'x1_0':(q-1)/(q+3),'x1_1':-(p*q+p-q+3)/(p*q+p-q-5),'x2_0':-(q-1)/(q+3),'x3_0':-(q-1)/(q+3),'x4_5':q,'x5_4':-q,'x6_3':p,'x7_1':-(p*q+p-q+3)/(p*q+p-q-5),'x7_5':q,'x8_1':-(p*q+p-q+3)/(p*q+p-q-5),'x8_4':-q,'x9_1':-(p*q+5*p-q-1)/(p*q+p-q-5)},
 'volP':(p*q**2+8*p*q+11*p-q**2-12*q-39)/(3*(q+3)*(p*q+p-q-5)),
 'volQ':-(p*q-3*p+4*q**2-9*q-41)/3,
 'mN':([2,4],12,3,'32'),'mD':([1,2],6,0,'72'),'branch':'boundary_plus_strict'},
4086:{
 'pivot':((1,2,4,6),(1,2,4,5)),'sample':(sp.Rational(1,5),sp.Rational(-1,3)),'free':('x0_1','x7_4'),'tets':(35,70),
 'sol':{'x0_0':(3*p*q+p+q-1)/(p*q-p-q-3),'x0_1':p,'x1_0':(p*q-p+3*q+1)/(p*q-p-q-3),'x2_0':-(p*q+3*p-q+1)/(p*q-p-q-3),'x3_0':-(3*p*q+p+q-1)/(p*q-p-q-3),'x3_4':-q,'x4_3':-(p*q+p-3*q+1)/(p*q+p+q-3),'x5_4':q,'x6_3':(p*q-3*p+q+1)/(p*q+p+q-3),'x7_3':(3*p*q-p-q-1)/(p*q+p+q-3),'x7_4':q,'x8_1':p,'x8_3':-(3*p*q-p-q-1)/(p*q+p+q-3),'x9_1':p},
 'volP':-4*(p**2+4*p*q+q**2-6)/(3*(p*q-p-q-3)*(p*q+p+q-3)),
 'volQ':-8*(p*q-5)/3,
 'mN':([3,3],8,8,'256/3'),'mD':([2,2],7,2,'72'),'branch':'endpoint_plus_strict'},
4211:{
 'pivot':((3,5,7,8),(0,2,3,5)),'sample':(sp.Rational(-1,5),sp.Rational(1,3)),'free':('x1_0','x4_2'),'tets':(36,68),
 'sol':{'x0_0':(p*q+p-q+1)/2,'x0_1':-(p*q+p-3*q+1)/(p*q+p+q+5),'x1_0':p,'x2_0':-(p*q-p+q+1)/2,'x2_4':(p*q-p+3*q+1)/(p*q-p-q+5),'x3_4':-(p*q+3*p-q+1)/(p*q-p-q+5),'x4_2':q,'x4_4':(p*q**2-p*q-q**2+q-4)/(p*q-p-q+5),'x5_4':(p*q-p-q-3)/(p*q-p-q+5),'x6_3':q,'x7_1':-(p*q-3*p+q+1)/(p*q+p+q+5),'x8_1':(p*q+p+q-3)/(p*q+p+q+5),'x9_1':-(p*q**2+p*q+q**2+q+4)/(p*q+p+q+5),'x9_5':q},
 'volP':(p**2*q**2-5*p**2+12*p*q-q**2+65)/(3*(p*q-p-q+5)*(p*q+p+q+5)),
 'volQ':(p*q**3+11*p*q-5*q**2+81)/6,
 'mN':([3,5],22,2,'768/5'),'mD':([2,2],9,0,'288'),'branch':'unique'},
}


def source_lines():
 with zipfile.ZipFile(SOURCE) as zf: raw=zf.read('viterbo_d14_work/unique_templates.txt')
 assert hashlib.sha256(raw).hexdigest()==SOURCE_SHA
 return raw.decode().splitlines()

def bern(poly):
 P=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,P.degree_list()));co=dict(P.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(2)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr

def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,eqn in zip(h.simplices,h.equations):
  if abs(float(eqn[:-1]@pr[0]+eqn[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
def check_sphere(tets,nverts):
 tri=Counter(tuple(sorted(q3)) for t in tets for q3 in itertools.combinations(t,3));assert set(tri.values())=={2}
 by=defaultdict(list)
 for k,t in enumerate(tets):
  for q3 in itertools.combinations(t,3):by[tuple(sorted(q3))].append(k)
 adj=[set() for _ in tets]
 for z in by.values():assert len(z)==2;adj[z[0]].add(z[1]);adj[z[1]].add(z[0])
 seen={0};dq=deque([0])
 while dq:
  k=dq.popleft()
  for l in adj[k]:
   if l not in seen:seen.add(l);dq.append(l)
 assert len(seen)==len(tets)
 return {'tetrahedra':len(tets),'triangles':len(tri),'vertices':nverts}
def check_balls(tets,facets):
 per=[]
 for f in facets:
  g=[t for t in tets if set(t)<=set(f)];assert g and set(x for t in g for x in t)==set(f)
  tri=Counter(tuple(sorted(q3)) for t in g for q3 in itertools.combinations(t,3));assert max(tri.values())<=2
  bt=[q3 for q3,n in tri.items() if n==1];vs=set(x for z in bt for x in z);es=set(tuple(sorted(e)) for z in bt for e in itertools.combinations(z,2));assert len(vs)-len(es)+len(bt)==2;per.append(len(g))
 return per

def verify_family(idx,cfg,key):
 sample={p:cfg['sample'][0],q:cfg['sample'][1]};cache={}
 def positive_poly(poly,label):
  poly=sp.factor(sp.cancel(poly).subs(PMAP));k=sp.srepr(poly)
  if k not in cache:cache[k]=bern(poly)
  deg,arr=cache[k];pos=[x for x in arr if x.is_positive];zero=[x for x in arr if x.is_zero];neg=[x for x in arr if x.is_negative];unk=[x for x in arr if not(x.is_positive or x.is_zero or x.is_negative)]
  assert pos and not neg and not unk,(idx,label,poly,deg,neg[:2],unk[:2])
  return {'degree':list(deg),'positive':len(pos),'zero':len(zero),'negative':0,'unknown':0,'min_positive':str(min(pos))}
 def positive_rat(expr,label):
  expr=sp.factor(sp.cancel(expr));assert expr.subs(sample)>0,(idx,label,expr.subs(sample),expr)
  n,d=map(sp.factor,sp.together(expr).as_numer_denom())
  if d.subs(sample)<0:n,d=-n,-d
  return {'numerator':positive_poly(n,label+'N'),'denominator':positive_poly(d,label+'D')}
 # Original symbolic matrix and Schur branch check.
 M0=sp.Matrix(10,6,[int(c)-1 for c in key]);orig=[]
 for i in range(10):
  for j in range(6):
   if M0[i,j]==0:
    x=sp.Symbol(f'x{i}_{j}');M0[i,j]=x;orig.append(x)
 rs,cs=cfg['pivot'];A0=M0.extract(rs,cs);assert abs(int(A0.det()))==8
 rr=[i for i in range(10) if i not in rs];cc=[j for j in range(6) if j not in cs]
 Sch0=M0.extract(rr,cc)-M0.extract(rr,cs)*A0.inv()*M0.extract(rs,cc);polys=[sp.factor(sp.together(e).as_numer_denom()[0]) for e in Sch0]
 fn=[sp.Symbol(n) for n in cfg['free']];dep=[x for x in orig if x not in fn]
 G=sp.groebner(polys,*dep,order='lex',domain=sp.QQ.frac_field(*fn));assert G.is_zero_dimensional and len(G.polys)==12
 branch_note=cfg['branch']
 if idx==2744:
  fsub={fn[0]:p,fn[1]:q}; polsub=[sp.factor(z.subs(fsub)) for z in polys]
  x=sp.Symbol('x9_1');last=sp.factor(G.polys[-1].as_expr().subs(fsub));num=sp.factor(sp.together(last).as_numer_denom()[0])
  expected=(p*x+3*p-3*x-1)*(p*q*x+p*q+p*x+5*p-q*x-q-5*x-1)
  assert sp.factor(num/expected).free_symbols <= {p,q}
  # First factor gives boundary defects x0_0=1,x1_0=-1,x2_0=1,x3_0=-1,x4_5=1,x5_4=-1,x8_4=-1.
  xb=-(3*p-1)/(p-3);solb=sp.solve([z.subs(x,xb) for z in polsub],[y for y in dep if y!=x],dict=True,simplify=False)[0]
  assert sp.factor(solb[sp.Symbol('x0_0')]-1)==0 and sp.factor(solb[sp.Symbol('x4_5')]-1)==0
 elif idx==4086:
  fsub={fn[0]:p,fn[1]:q};x=sp.Symbol('x9_1');num=sp.factor(sp.together(G.polys[-1].as_expr().subs(fsub)).as_numer_denom()[0]);assert sp.factor(num/((p-x)*(x+1))).free_symbols <= {p,q}
  # x=-1 is excluded by the strict defect condition, hence x=p.
 # Build completed matrix.
 M=[];templ=[];defects=[]
 for i in range(10):
  row=[];tr=[]
  for j,ch in enumerate(key[6*i:6*i+6]):
   z=int(ch)-1;tr.append(z)
   if z==0:
    nm=f'x{i}_{j}';assert nm in cfg['sol'];row.append(sp.factor(sp.cancel(cfg['sol'][nm])));defects.append((i,j,nm))
   else:row.append(sp.Integer(z))
  M.append(row);templ.append(tr)
 M=sp.Matrix(M);assert len(defects)==14
 P=M.extract(rs,cs);assert abs(int(P.det()))==8
 Sch=M.extract(rr,cc)-M.extract(rr,cs)*P.inv()*M.extract(rs,cc);assert all(sp.factor(sp.cancel(x))==0 for x in Sch)
 for i,j,nm in defects:positive_rat(1-M[i,j]**2,nm)
 VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs);assert all(sp.factor(x)==0 for x in FM*VM-M)
 ext=[]
 for j in range(6):
  inc=[i for i in range(10) if templ[i][j]!=0];found=None
  for rows in itertools.combinations(inc,4):
   de=sp.factor(FM.extract(rows,range(4)).det(method='domain-ge'))
   if de==0:continue
   sg=1 if de.subs(sample)>0 else -1
   try:positive_rat(sg*de,f'ext{j}{rows}')
   except AssertionError:continue
   found=(j,list(rows),str(de));break
  assert found;ext.append(found)
 Vnum=np.array(VM.subs(sample),float);Fnum=np.array(FM.subs(sample),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
 code=np.array(templ,int);facP=[];facQ=[]
 for i in range(10):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+10 for i in range(10) if code[i,j]),sorted(i+10 if code[i,j]==1 else i for i in range(10) if code[i,j])]
 tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)];assert (len(tP),len(tQ))==cfg['tets'];sph=check_sphere(tP,12);bp=check_balls(tP,facP);bq=check_balls(tQ,facQ)
 def pv(i):return VM[:,i] if i<6 else -VM[:,i-6]
 def qv(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
 def oriented(tets,point,name):
  out=[]
  for k,ids in enumerate(tets):
   de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert de!=0;sg=1 if de.subs(sample)>0 else -1;positive_rat(sg*de,f'{name}{k}');out.append(sp.factor(sg*de))
  return out
 volP=sp.factor(sp.cancel(sum(oriented(tP,pv,'P'))/24));volQ=sp.factor(sp.cancel(sum(oriented(tQ,qv,'Q'))/24));assert sp.factor(volP-cfg['volP'])==0 and sp.factor(volQ-cfg['volQ'])==0
 margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=positive_rat(margin,'margin')
 for key0,exp in [('numerator',cfg['mN']),('denominator',cfg['mD'])]:
  st=mc[key0];assert st['degree']==exp[0] and st['positive']==exp[1] and st['zero']==exp[2] and st['min_positive']==exp[3]
 return {'template_index':idx,'status':'PASS','branch_exhaustiveness':branch_note,'domain':'-1<p,q<1','rank':4,'strict_defects':14,'primal_vertices':12,'polar_vertices':20,'primal_tetrahedra':len(tP),'polar_tetrahedra':len(tQ),'primal_boundary':sph,'primal_facet_tetrahedra':bp,'polar_facet_tetrahedra':bq,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_numerator_bernstein':mc['numerator'],'margin_denominator_bernstein':mc['denominator'],'fixed_sign_polynomials_checked':len(cache),'extremality_certificates':ext}

def main():
 lines=source_lines();records=[]
 for idx,cfg in FAMILIES.items():records.append(verify_family(idx,cfg,lines[idx]));print('PASS',idx,flush=True)
 out={'status':'PASS','scope':'12V/20F,c=0,D=14','source_bridge':{'bundle':str(SOURCE),'unique_templates_sha256':SOURCE_SHA},'closed_template_indices':list(FAMILIES),'count':len(records),'records':records,'conclusion':'all five strict two-parameter survivor families have Mahler product > 32/3'}
 OUT.write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'status':'PASS','closed':list(FAMILIES),'output':str(OUT)},indent=2))
if __name__=='__main__':main()
