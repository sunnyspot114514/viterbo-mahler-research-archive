# 四维中心对称 Mahler：`12V/20F, c=0, D=14` 最新进展

日期：2026-08-20

## 当前结论

`D=14` 的全局精确预分类为

\[
4319
=
4024\text{ 个 rank-}\ge5
+
268\text{ 个重复 facet rows}
+
27\text{ 个 algebraic survivors}.
\]

本轮累计已经关闭 19 个 algebraic survivors：

\[
\boxed{
8\text{ 个 primal vertex-loss}
+
3\text{ 个 polar vertex-loss}
+
8\text{ 个 Mahler-positive continuous families}.
}
\]

因此当前完整 accounting 是

\[
\boxed{
4319=4024+268+8+3+8+8.
}
\]

只剩八个 canonical survivors：

\[
\boxed{
1102,\ 1282,\ 2503,\ 2742,\ 3775,\ 4300,\ 4304,\ 4318.
}
\]

所有勾号均表示 **computer-assisted analytic proof candidate**，尚未经过外部同行审阅。

---

## 一、此前已经完成的 16 个关闭

### Primal vertex-loss

\[
8,154,959,1065,1838,2411,2651,2815.
\]

每个分支都强迫某个候选 vertex 严格落在另外两个 antipodal vertices 的开线段中，因此实际至多为 `10V`。

### Polar/section vertex-loss

\[
447,2723,2871.
\]

每个分支都强迫一条规定 section row 严格位于另外两条 rows 的开线段中，因此 section 至多有 18 个 vertices，原对象不是 genuine `20F`。

### 五个二维 Mahler-positive families

\[
2391,2653,2744,4086,4211.
\]

五个 realization spaces 都是完整开方形

\[
-1<p,q<1.
\]

其 Mahler-margin Bernstein 数据为：

| Family | degree | 正系数 | 零系数 | 最小正系数 |
|---:|---:|---:|---:|---:|
| 2391 | \((4,3)\) | 14 | 6 | \(256/3\) |
| 2653 | \((4,4)\) | 19 | 6 | \(384\) |
| 2744 | \((2,4)\) | 12 | 3 | \(32\) |
| 4086 | \((3,3)\) | 8 | 8 | \(256/3\) |
| 4211 | \((3,5)\) | 22 | 2 | \(768/5\) |

全部负系数数目为 0，并有严格正 coefficient，因此

\[
|P||P^\circ|>\frac{32}{3}
\]

贯穿各自完整严格域。

---

## 二、新关闭 Family 461

取三个自由 defects

\[
p=x_{4,2},\qquad q=x_{5,2},\qquad r=x_{9,3}.
\]

rank-
4 completion 是唯一的有理三参数分支。全部 strict conditions 精确等价于

\[
-1<p,q,r<1,
\qquad
p+q>0.
\]

令

\[
P_0=\frac{1-p}{2},
\qquad
Q_0=\frac{1-q}{2},
\qquad
E_0=\frac{p+q}{2},
\]

则

\[
P_0,Q_0,E_0>0,
\qquad
P_0+Q_0+E_0=1.
\]

所以 realization space 是

\[
\boxed{\Delta_2^\circ\times(0,1)}.
\]

使用 stick-breaking

\[
p=1-2A,
\qquad
q=1-2(1-A)B,
\qquad
r=2C-1,
\]

可有理双射到单位开立方体。

全域证书得到

\[
35\text{ 个 primal tetrahedra},
\qquad
70\text{ 个 polar tetrahedra}.
\]

精确体积为

\[
|P|=
\frac{
 p^2r^2-2p^2r+p^2+2pqr^2-4pqr+2pq+3pr^2-20pr+17p
 +q^2r^2-2q^2r+q^2+3qr^2-20qr+17q-8r+40
}{3(pr-p+qr-q-4)^2},
\]

\[
|P^\circ|=
\frac{
 p^2r-p^2+pqr-pq-4pr+4p+q^2r-q^2-4qr+4q+7r+41
}{3}.
\]

Mahler 余量分子的 Bernstein degree 为

\[
(4,4,3),
\]

系数统计：

\[
\boxed{69>0,\qquad31=0,\qquad0<0,\qquad\min_+=256/3.}
\]

分母 degree 为 \((2,2,2)\)，27 个 coefficients 全部严格为正，最小值为 144。

因此

\[
\boxed{\text{Family }461\quad\checkmark}.
\]

---

## 三、新关闭 Family 1106

取

\[
p=x_{0,0},
\qquad
q=x_{5,2},
\qquad
r=x_{5,3}.
\]

完整严格域为

\[
\boxed{-1<p<1,\qquad-1<r<q<1.}
\]

单位立方体参数化：

\[
p=2A-1,
\qquad
r=2C-1,
\qquad
q=r+2(1-C)B,
\qquad0<A,B,C<1.
\]

rank-
4 completion 唯一，并且 14 个 defects 全部严格；六对 primal vertices 和十对 polar vertices 全部保持 extreme。

固定 triangulations 使用

\[
32\text{ 个 primal tetrahedra},
\qquad
68\text{ 个 polar tetrahedra}.
\]

精确体积为

\[
|P|=
\frac{
 p^2qr^2+2p^2qr+p^2q-p^2r^3-2p^2r^2-p^2r
 +4pq^3-2pq^2r+2pq^2-2pqr^2+4pqr+2pq
 -2pr^3-8pr^2+2p
 -4q^3-2q^2r-6q^2-3qr^2+2qr+9q-r^3-6r^2+r+10
}{6(q+1)(pq^2-pr^2-q^2-r^2+2)},
\]

\[
|P^\circ|=
-\frac{8(
 pqr-5pq-pr^2+3pr-2p+qr+7q-r^2+3r+10
)}{3(pq-pr-q-r-2)}.
\]

Margin numerator 的 Bernstein degree 为

\[
(3,4,5),
\]

并满足

\[
\boxed{35>0,\qquad85=0,\qquad0<0,\qquad\min_+=512/45.}
\]

分母 degree 为 \((2,4,4)\)，31 个正 coefficients、44 个零 coefficients，最小正系数 24。

因此

\[
\boxed{\text{Family }1106\quad\checkmark}.
\]

---

## 四、新关闭 Family 1770

取自由 defects

\[
p=x_{2,3},
\qquad
q=x_{4,4},
\qquad
r=x_{6,2}.
\]

全部 dependent defects 由 rank-
4 条件唯一确定。完整严格域就是

\[
\boxed{-1<p,q,r<1},
\]

即单位开立方体。

固定全域 triangulations 使用

\[
32\text{ 个 primal tetrahedra},
\qquad
70\text{ 个 polar tetrahedra}.
\]

体积为

\[
|P|=
-\frac{
 pqr-pq-pr^2-5pr-6p-qr+q-r^2-3r+16
}{6(pr+p+r-3)},
\]

\[
|P^\circ|=-2\,(p\,\,2\,q\,r\,\,2 - 2\,p\,\,2\,q\,r + p\,\,2\,q + p\,\,2\,r\,\,2 - 2\,p\,\,2\,r + p\,\,2 + 2\,p\,q\,r\,\,2 - 16\,p\,q\,r - 2\,p\,q - 2\,p\,r\,\,2 + 18\,p + q\,r\,\,2 - 6\,q\,r + 21\,q - 3\,r\,\,2 + 26\,r - 39)/(3\,(p\,q\,r - p - q - r + 2)) .
\]

Mahler margin numerator 的 Bernstein degree 为

\[
(3,2,4),
\]

并有

\[
\boxed{25>0,\qquad35=0,\qquad0<0,\qquad\min_+=64/3.}
\]

分母 degree 为 \((2,1,2)\)，9 个正 coefficients、9 个零 coefficients，最小正系数 72。

因此

\[
\boxed{\text{Family }1770\quad\checkmark}.
\]


---

## 五、当前准确状态

\[
\boxed{
\begin{array}{c|r}
\text{类别}&\text{数量}\\
\hline
\operatorname{rank}\ge5&4024\\
\text{重复 facet rows}&268\\
\text{primal vertex loss}&8\\
\text{polar vertex loss}&3\\
\text{Mahler-positive continuous families}&8\\
\text{尚未关闭}&8
\end{array}
}
\]

当前剩余：

\[
\boxed{
1102,1282,2503,2742,3775,4300,4304,4318.
}
\]

其中：

- `2503,2742,3775,4300,4304` 的 generic realization space 数值上为三维；
- `4318` 为四维；
- `1102,1282` 没有全 \(\{\pm1\}\) 常数 pivot，需要改用含 defect 的非零 pivot 分域，或直接处理 determinantal ideal。

---

## 六、证明范围

这些结果仍然只覆盖四维 symmetric Mahler 猜想中的 bounded-12 有限核心：

\[
12V/20F,
\qquad c=0,
\qquad D=14.
\]

完整四维证明仍需关闭其余 bounded-12 层，并建立不依赖 \(f_0,f_3\) 的 global finite-core / bi-shadow-rigid reduction theorem。
