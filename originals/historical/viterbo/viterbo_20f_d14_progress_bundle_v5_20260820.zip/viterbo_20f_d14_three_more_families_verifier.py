#!/usr/bin/env python3
"""Aggregate exact verifier for D=14 survivor families 461, 1106, 1770."""
from __future__ import annotations
import hashlib,itertools,json,math,zipfile
from collections import Counter,defaultdict,deque
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

OUT=Path('/mnt/data/viterbo_20f_d14_three_more_families_verifier_output.json')
SOURCE=Path('/mnt/data/viterbo_20f_d15_complete_and_d14_preclassification_bundle_20260820.zip')
SHA='8cb0e7c09e3121dab8e6675d54bebfc2fd654183a1f1da06735bb960c4806c46'
A,B,C=sp.symbols('A B C',real=True);VARS=(A,B,C)
p,q,r=sp.symbols('p q r',real=True)

CFG={
461:{'pivot':((1,2,3,8),(2,3,4,5)),'free':('x4_2','x5_2','x9_3'),'sample':{p:sp.Rational(1,2),q:sp.Rational(1,2),r:sp.Rational(-1,2)},'map':{p:1-2*A,q:1-2*(1-A)*B,r:2*C-1},'domain':'-1<p,q,r<1 and p+q>0; equivalently Delta_2^o x (0,1)','tets':(35,70),
'sol':{'x0_0':(p*r-p+q*r-q+4*r)/(p*r-p+q*r-q-4),'x0_1':(p*r-p+q*r-q-4*r)/(p*r-p+q*r-q-4),'x1_0':-(p*r-p-q*r+q-2*r-2)/(p*r-p+q*r-q-4),'x1_1':(p*r-p-q*r+q-2*r-2)/(p*r-p+q*r-q-4),'x2_0':(p*r-p-q*r+q+2*r+2)/(p*r-p+q*r-q-4),'x2_1':-(p*r-p-q*r+q+2*r+2)/(p*r-p+q*r-q-4),'x3_0':(p*r-p+q*r-q+4)/(p*r-p+q*r-q-4),'x4_2':p,'x5_2':q,'x6_3':-(p*r-p-r-1)/2,'x7_3':-(q*r-q-r-1)/2,'x8_1':(p*r-p+q*r-q+4)/(p*r-p+q*r-q-4),'x9_1':(p*r-p+q*r-q+4)/(p*r-p+q*r-q-4),'x9_3':r},
'volP':(p**2*r**2-2*p**2*r+p**2+2*p*q*r**2-4*p*q*r+2*p*q+3*p*r**2-20*p*r+17*p+q**2*r**2-2*q**2*r+q**2+3*q*r**2-20*q*r+17*q-8*r+40)/(3*(p*r-p+q*r-q-4)**2),
'volQ':(p**2*r-p**2+p*q*r-p*q-4*p*r+4*p+q**2*r-q**2-4*q*r+4*q+7*r+41)/3,
'mN':([4,4,3],69,31,'256/3'),'mD':([2,2,2],27,0,'144')},
1106:{'pivot':((1,2,3,9),(2,3,4,5)),'free':('x0_0','x5_2','x5_3'),'sample':{p:sp.Rational(0),q:sp.Rational(1,4),r:sp.Rational(-1,2)},'map':{p:2*A-1,r:2*C-1,q:(2*C-1)+2*(1-C)*B},'domain':'-1<p<1 and -1<r<q<1','tets':(32,68),
'sol':{'x0_0':p,'x0_1':(p*q**2+p*r**2-2*p-q**2+r**2)/(p*q**2-p*r**2-q**2-r**2+2),'x1_0':p,'x1_1':(p*q**2+p*r**2-2*p-q**2+r**2)/(p*q**2-p*r**2-q**2-r**2+2),'x2_0':(p*q-p*r-r-1)/(q+1),'x3_0':(p*q-p*r-r-1)/(q+1),'x4_2':q,'x4_3':r,'x5_2':q,'x5_3':r,'x6_4':(p*q+p*r+2*p-q+r)/(p*q-p*r-q-r-2),'x7_4':(p*q+p*r+2*p-q+r)/(p*q-p*r-q-r-2),'x8_1':-(p*q**2-2*p*q*r-2*p*q+p*r**2+2*p*r-q**2-2*q*r-2*q+r**2+2*r+2)/(p*q**2-p*r**2-q**2-r**2+2),'x9_1':-(p*q**2-2*p*q*r-2*p*q+p*r**2+2*p*r-q**2-2*q*r-2*q+r**2+2*r+2)/(p*q**2-p*r**2-q**2-r**2+2)},
'volP':(p**2*q*r**2+2*p**2*q*r+p**2*q-p**2*r**3-2*p**2*r**2-p**2*r+4*p*q**3-2*p*q**2*r+2*p*q**2-2*p*q*r**2+4*p*q*r+2*p*q-2*p*r**3-8*p*r**2+2*p-4*q**3-2*q**2*r-6*q**2-3*q*r**2+2*q*r+9*q-r**3-6*r**2+r+10)/(6*(q+1)*(p*q**2-p*r**2-q**2-r**2+2)),
'volQ':-8*(p*q*r-5*p*q-p*r**2+3*p*r-2*p+q*r+7*q-r**2+3*r+10)/(3*(p*q-p*r-q-r-2)),
'mN':([3,4,5],35,85,'512/45'),'mD':([2,4,4],31,44,'24')},
1770:{'pivot':((5,7,8,9),(0,1,3,5)),'free':('x2_3','x4_4','x6_2'),'sample':{p:sp.Rational(1,5),q:sp.Rational(-1,3),r:sp.Rational(-1,5)},'map':{p:2*A-1,q:2*B-1,r:2*C-1},'domain':'-1<p,q,r<1','tets':(32,70),
'sol':{'x0_0':(p*q*r**2+p*q-p*r**2-2*p*r+p+q*r**2-2*q*r-q-r**2+4*r-1)/(2*(p*q*r-p-q-r+2)),'x0_1':-(p*q-p*r+q*r-2*q+1)/(p*q*r-p-q-r+2),'x1_0':(p*q*r**2+p*q-p*r**2-2*p*r+p+q*r**2-2*q*r-q-r**2+4*r-1)/(2*(p*q*r-p-q-r+2)),'x1_1':-(p*q-p*r+q*r-2*q+1)/(p*q*r-p-q-r+2),'x2_0':-(p*r+p+r-1)/2,'x2_3':p,'x3_0':-(p*r+p+r-1)/2,'x3_3':p,'x4_4':q,'x5_4':q,'x6_2':r,'x7_2':r,'x8_4':-(p*q*r-p*q-2*p+q*r-q+2)/(p*r+p+r-3),'x9_4':-(p*q*r-p*q-2*p+q*r-q+2)/(p*r+p+r-3)},
'volP':-(p*q*r-p*q-p*r**2-5*p*r-6*p-q*r+q-r**2-3*r+16)/(6*(p*r+p+r-3)),
'volQ':-2*(p**2*q*r**2-2*p**2*q*r+p**2*q+p**2*r**2-2*p**2*r+p**2+2*p*q*r**2-16*p*q*r-2*p*q-2*p*r**2+18*p+q*r**2-6*q*r+21*q-3*r**2+26*r-39)/(3*(p*q*r-p-q-r+2)),
'mN':([3,2,4],25,35,'64/3'),'mD':([2,1,2],9,9,'72')},
}

def lines():
 with zipfile.ZipFile(SOURCE) as z:raw=z.read('viterbo_d14_work/unique_templates.txt')
 assert hashlib.sha256(raw).hexdigest()==SHA;return raw.decode().splitlines()
def bern(poly):
 P=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,P.degree_list()));co=dict(P.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr
def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
def sphere(tets):
 tri=Counter(tuple(sorted(z)) for t in tets for z in itertools.combinations(t,3));assert set(tri.values())=={2};return {'tetrahedra':len(tets),'triangles':len(tri),'vertices':12}
def balls(tets,facets):
 out=[]
 for f in facets:
  g=[t for t in tets if set(t)<=set(f)];assert g and set(x for t in g for x in t)==set(f);tri=Counter(tuple(sorted(z)) for t in g for z in itertools.combinations(t,3));assert max(tri.values())<=2;bt=[z for z,n in tri.items() if n==1];vs=set(x for z in bt for x in z);es=set(tuple(sorted(e)) for z in bt for e in itertools.combinations(z,2));assert len(vs)-len(es)+len(bt)==2;out.append(len(g))
 return out

def verify(idx,cfg,key):
 sample=cfg['sample'];pmap=cfg['map'];cache={}
 def pp(poly,label):
  poly=sp.factor(sp.cancel(poly).subs(pmap));k=sp.srepr(poly)
  if k not in cache:cache[k]=bern(poly)
  deg,arr=cache[k];pos=[x for x in arr if x.is_positive];zero=[x for x in arr if x.is_zero];neg=[x for x in arr if x.is_negative];unk=[x for x in arr if not(x.is_positive or x.is_zero or x.is_negative)];assert pos and not neg and not unk,(idx,label,poly,deg,neg[:3]);return {'degree':list(deg),'positive':len(pos),'zero':len(zero),'negative':0,'unknown':0,'min_positive':str(min(pos))}
 def pr(expr,label):
  expr=sp.factor(sp.cancel(expr));assert expr.subs(sample)>0,(idx,label,expr.subs(sample),expr);n,d=map(sp.factor,sp.together(expr).as_numer_denom());
  if d.subs(sample)<0:n,d=-n,-d
  return {'numerator':pp(n,label+'N'),'denominator':pp(d,label+'D')}
 # symbolic original and uniqueness of rank branch
 M0=sp.Matrix(10,6,[int(ch)-1 for ch in key]);orig=[]
 for i in range(10):
  for j in range(6):
   if M0[i,j]==0:x=sp.Symbol(f'x{i}_{j}');M0[i,j]=x;orig.append(x)
 rs,cs=cfg['pivot'];P0=M0.extract(rs,cs);assert abs(int(P0.det()))==8;rr=[i for i in range(10) if i not in rs];cc=[j for j in range(6) if j not in cs];S0=M0.extract(rr,cc)-M0.extract(rr,cs)*P0.inv()*M0.extract(rs,cc);polys=[sp.factor(sp.together(e).as_numer_denom()[0]) for e in S0];fn=[sp.Symbol(x) for x in cfg['free']];dep=[x for x in orig if x not in fn];G=sp.groebner(polys,*dep,order='lex',domain=sp.QQ.frac_field(*fn));assert G.is_zero_dimensional and len(G.polys)==len(dep)
 # completed matrix
 M=[];templ=[];defs=[]
 for i in range(10):
  row=[];tr=[]
  for j,ch in enumerate(key[6*i:6*i+6]):
   z=int(ch)-1;tr.append(z)
   if z==0:nm=f'x{i}_{j}';row.append(sp.factor(sp.cancel(cfg['sol'][nm])));defs.append((i,j,nm))
   else:row.append(sp.Integer(z))
  M.append(row);templ.append(tr)
 M=sp.Matrix(M);assert len(defs)==14;P=M.extract(rs,cs);assert abs(int(P.det()))==8;S=M.extract(rr,cc)-M.extract(rr,cs)*P.inv()*M.extract(rs,cc);assert all(sp.factor(sp.cancel(x))==0 for x in S)
 for i,j,nm in defs:pr(1-M[i,j]**2,nm)
 VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda x:sp.factor(sp.cancel(x)));FM=M.extract(range(10),cs);assert all(sp.factor(x)==0 for x in FM*VM-M)
 for j in range(6):
  inc=[i for i in range(10) if templ[i][j]!=0];ok=False
  for z in itertools.combinations(inc,4):
   de=sp.factor(FM.extract(z,range(4)).det(method='domain-ge'))
   if de==0:continue
   sg=1 if de.subs(sample)>0 else -1
   try:pr(sg*de,f'e{j}{z}');ok=True;break
   except AssertionError:pass
  assert ok
 Vnum=np.array(VM.subs(sample),float);Fnum=np.array(FM.subs(sample),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20;code=np.array(templ,int);facP=[];facQ=[]
 for i in range(10):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+10 for i in range(10) if code[i,j]),sorted(i+10 if code[i,j]==1 else i for i in range(10) if code[i,j])]
 tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)];assert (len(tP),len(tQ))==cfg['tets'];sph=sphere(tP);bp=balls(tP,facP);bq=balls(tQ,facQ)
 def pv(i):return VM[:,i] if i<6 else -VM[:,i-6]
 def qv(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
 def ori(ts,point,name):
  out=[]
  for k,z in enumerate(ts):de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in z]).det(method='domain-ge')));sg=1 if de.subs(sample)>0 else -1;pr(sg*de,f'{name}{k}');out.append(sp.factor(sg*de))
  return out
 volP=sp.factor(sp.cancel(sum(ori(tP,pv,'P'))/24));volQ=sp.factor(sp.cancel(sum(ori(tQ,qv,'Q'))/24));assert sp.factor(volP-cfg['volP'])==0 and sp.factor(volQ-cfg['volQ'])==0;margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=pr(margin,'margin')
 for part,exp in [('numerator',cfg['mN']),('denominator',cfg['mD'])]:st=mc[part];assert st['degree']==exp[0] and st['positive']==exp[1] and st['zero']==exp[2] and st['min_positive']==exp[3]
 return {'template_index':idx,'status':'PASS','domain':cfg['domain'],'rank':4,'strict_defects':14,'primal_vertices':12,'polar_vertices':20,'primal_tetrahedra':len(tP),'polar_tetrahedra':len(tQ),'primal_boundary':sph,'primal_facet_tetrahedra':bp,'polar_facet_tetrahedra':bq,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_numerator_bernstein':mc['numerator'],'margin_denominator_bernstein':mc['denominator'],'fixed_sign_polynomials_checked':len(cache)}

def main():
 ls=lines();rec=[]
 for idx,cfg in CFG.items():rec.append(verify(idx,cfg,ls[idx]));print('PASS',idx,flush=True)
 out={'status':'PASS','scope':'12V/20F,c=0,D=14','source_bridge':{'bundle':str(SOURCE),'unique_templates_sha256':SHA},'closed_template_indices':list(CFG),'count':len(rec),'records':rec,'conclusion':'all three rank-four families have Mahler product > 32/3'};OUT.write_text(json.dumps(out,indent=2));print(json.dumps({'status':'PASS','closed':list(CFG),'output':str(OUT)},indent=2))
if __name__=='__main__':main()
