#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
R=Path('/mnt/data')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.load(open(R/'viterbo_22f_d17_progress_accounting_certificate_v10.json'))
p=json.load(open(R/'viterbo_22f_d17_progress_accounting_certificate_v9.json'))
new={2060,2107,2156}
assert a['status']=='PASS'
assert set(a['remaining_ids'])==set(p['remaining_ids'])-new
assert len(a['remaining_ids'])==40
assert set(a['Mahler_positive_exact_families'])==set(p['Mahler_positive_exact_families'])|new
assert sum(a['disjoint_classification'].values())==2395
assert sum(v for k,v in a['survivor_level_accounting'].items() if k!='initial')==121
for cid in sorted(new):
 s=R/f'viterbo_22f_d17_family{cid}_verifier.py';c=R/f'viterbo_22f_d17_family{cid}_certificate.json';o=R/f'viterbo_22f_d17_family{cid}_verifier_output.json'
 co=json.load(open(c));oo=json.load(open(o));rr=a['rerun_results'][str(cid)]
 assert co['status']==oo['status']=='PASS' and co['canonical_id']==oo['canonical_id']==cid
 assert rr['script_sha256']==sha(s) and rr['certificate_sha256']==sha(c) and rr['output_sha256']==sha(o)
print(json.dumps({'status':'PASS','remaining':40,'newly_closed':sorted(new),'Mahler_positive_exact':len(a['Mahler_positive_exact_families']),'total_pairing_templates':2395},indent=2))
