# 四维中心对称 Mahler：bounded-12 进展 v27

日期：2026-08-24

## 本轮结论

在

\[
12V/22F,\qquad c=0,\qquad D=17
\]

中，新增完整关闭三个 genuine 连续分支：

\[
\boxed{2060,\quad2107,\quad2156.}
\]

三个分支均完成：唯一 strict rank-4 completion、完整 realization space、12 个 primal vertices、22 个 polar vertices、全域兼容边界三角剖分、精确体积以及 Mahler 余量 Bernstein 正性。三个独立 verifier 均返回 `PASS`。

因此剩余 algebraic survivors 从 43 降到

\[
\boxed{40}.
\]

所有结论仍标记为 **computer-assisted analytic proof candidate**，尚未经过外部同行审阅。

## Family 2060

严格 rank 分支先强迫

\[
x_{6,4}=x_{5,5}.
\]

取自由参数

\[
p=x_{2,0},\qquad q=x_{5,5},\qquad r=x_{8,3}.
\]

其余 defects 唯一有理解出。完整严格域为

\[
-1<q,r<1,\qquad qr+q+3r-1>0,
\]

以及

\[
-1<p<p_{\max}(q,r),
\]

其中

\[
p_{\max}=-\frac{q^2r+q^2+4qr+7r-5}{q^2r+q^2-4q-5r-1}.
\]

令

\[
r=C,
\qquad
q=\frac{1-3C+4BC}{1+C},
\qquad
p=-1+(p_{\max}+1)A,
\]

即可与开单位立方体 \((0,1)^3\) 有理双射。关键域因子化为

\[
qr+q+3r-1=4BC,
\]

\[
G(p,q,r)=16BC(1-A).
\]

全域边界分解使用 37 个 primal tetrahedra 和 81 个 polar tetrahedra。Mahler 余量分子 Bernstein degree 为

\[
(2,8,10),
\]

其系数为

\[
258>0,\qquad39=0,\qquad0<0,
\]

最小正系数为 \(16/15\)。

## Family 2107

strict rank 分支强迫

\[
x_{6,0}=x_{3,0}.
\]

取

\[
p=x_{3,0},\qquad q=x_{8,5},\qquad r=x_{9,2}.
\]

完整域精确为

\[
-1<q,r<1,
\qquad
-1<p<\frac{q+1}{q-3}.
\]

令

\[
q=2B-1,
\qquad r=2C-1,
\qquad p=-1+\left(1+\frac{q+1}{q-3}\right)A,
\]

得到单位立方体参数化。主导 strict 因子变为

\[
pq-3p-q-1=4(1-A)(1-B)>0.
\]

全域使用 35 个 primal tetrahedra 和 76 个 polar tetrahedra。余量分子 Bernstein degree 为

\[
(2,6,5),
\]

并满足

\[
95>0,\qquad31=0,\qquad0<0,
\]

最小正系数为 \(8/5\)。

## Family 2156

strict rank 方程依次强迫

\[
x_{4,3}=-x_{7,3}
\]

及另外两条线性 completion 关系。取

\[
a=x_{3,0},\qquad b=x_{5,2},\qquad c=x_{7,5}.
\]

完整严格域为

\[
-1<b,c<1,
\qquad
\frac{b-1}{b+3}<a<1.
\]

以

\[
b=2B-1,
\qquad c=2C-1,
\qquad a=\frac{2A+B-1}{B+1}
\]

参数化后，唯一非自动的域因子直接化为

\[
ab+3a-b+1=4A>0.
\]

全域边界分解使用 37 个 primal tetrahedra和 74 个 polar tetrahedra。Mahler 余量分子 Bernstein degree 为

\[
(3,7,4),
\]

系数统计为

\[
111>0,\qquad49=0,\qquad0<0,
\]

最小正系数为 \(1/7\)。

## 新的三角剖分接口

本轮没有直接采用 Qhull 在退化非单纯 facet 中产生的零体积 sliver。验证器从完整 facet incidence 恢复所有二维 ridges，对每个 ridge 使用统一全局顶点序的 polygon fan，再把 facet 的最小顶点锥化到这些 ridge triangles。

所得 primal 与 polar boundary triangulations 均通过：

- 每个三角形恰属于两个 tetrahedra；
- 每个 facet 子复形是三维球；
- 所有选定 tetrahedron determinants 在完整参数域中保持严格定号。

因此这是 ridge-compatible 的全局证书，不依赖数值退化三角剖分。

## 最新 accounting

全部 2395 个 canonical templates 现在不重叠地分成

\[
\begin{aligned}
2395={}&1230\text{ 个 facet containment}\\
&+1070\text{ 个 antichain 内 rank}\ge5\\
&+22\text{ 个 segment vertex-loss}\\
&+4\text{ 个 duplicate/antipodal primal pair}\\
&+16\text{ 个 exact Mahler-positive families}\\
&+13\text{ 个 strict boundary/interval-impossible}\\
&+40\text{ 个 remaining}.
\end{aligned}
\]

在最初的 121 个 algebraic survivors 层面：

\[
\boxed{121=26+22+4+16+13+40.}
\]

## 当前范围

当前成果继续扩大 bounded-12 有限核心。完整四维 symmetric Mahler conjecture 尚未解决；即使有限核心最终封闭，仍需要一个不依赖 \(f_0,f_3\) 的 finite-core / bi-shadow-rigid reduction theorem，才能覆盖任意复杂度的四维中心对称凸体。
