#!/usr/bin/env python3
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json');CERT=Path('/mnt/data/viterbo_22f_d17_family2156_certificate.json');OUT=Path('/mnt/data/viterbo_22f_d17_family2156_verifier_output.json')
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);CID=2156

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def factorized_positive(expression,chart,eng,sample,label):
 expression=sp.factor(sp.cancel(expression));assert sp.N(expression.subs(sample))>0,(label,expression.subs(sample));num,den=map(sp.factor,sp.together(expression).as_numer_denom());records=[];total=1
 for side,poly in [('numerator',num),('denominator',den)]:
  coef,factors=sp.factor_list(poly)
  if coef<0:total*=-1
  for f,m in factors:
   fs=sp.factor(sp.cancel(f.subs(chart)));val=sp.N(fs.subs(eng.sample));assert val!=0
   sg=1 if val>0 else -1;ce=eng.positive_rational(sg*fs,label+' '+side+' factor')
   if int(m)%2:total*=sg
   records.append({'side':side,'factor':str(f),'multiplicity':int(m),'sign':int(sg),'certificate':ce})
 assert total>0,(label,total);return {'factorized':True,'records':records}
def affine_dim(points):return np.linalg.matrix_rank(points-points[0],tol=1e-8)
def polygon_tris(ids,coords):
 ids=sorted(ids);pts=coords[ids];delta=pts-pts[0];vh=np.linalg.svd(delta,full_matrices=False)[2];xy=delta@vh[:2].T;h=ConvexHull(xy);order=[ids[i] for i in h.vertices];root=min(order);k=order.index(root);order=order[k:]+order[:k];return [tuple(sorted((root,order[i],order[i+1]))) for i in range(1,len(order)-1)]
def global_boundary(facets,coords):
 ridges={}
 for i,j in itertools.combinations(range(len(facets)),2):
  inter=tuple(sorted(set(facets[i])&set(facets[j])))
  if len(inter)>=3 and affine_dim(coords[list(inter)])==2:ridges[inter]=polygon_tris(inter,coords)
 out=[]
 for f in facets:
  root=min(f)
  for ridge,tris in ridges.items():
   if root not in ridge and set(ridge)<=set(f):out += [tuple(sorted((root,)+tri)) for tri in tris]
 return sorted(set(out)),ridges

def build():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=v
 rr=(2,3,9,10);cc=(2,3,4,5);P=M.extract(rr,cc);assert P.det()==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc];S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ);eq=[sp.factor(sp.cancel(e)) for e in S]
 st,uns,rem,tr=base.constant_eliminate(eq,vs)
 rel1=-(x['x4_3']+x['x7_3'])*(x['x9_1']-1)/2;rel2=(x['x3_0']-1)*(x['x5_2']*x['x7_5']-x['x5_2']+2*x['x7_3']+x['x7_5']+1)/4;rel3=(x['x9_1']-1)*(x['x4_3']*x['x8_4']-x['x4_3']-2*x['x8_3']+x['x8_4']+1)/4
 assert base.proportional_member(rem,rel1);assert base.proportional_member(rem,rel2);assert base.proportional_member(rem,rel3)
 a,b,c=sp.symbols('a b c',real=True)
 st.update({x['x4_3']:-x['x7_3'],x['x7_3']:-(x['x5_2']*x['x7_5']-x['x5_2']+x['x7_5']+1)/2,x['x3_0']:a,x['x5_2']:b,x['x7_5']:c})
 # Solve the third strict relation for x8_3 before the remaining equations.
 st[x['x8_3']]=sp.factor((st[x['x4_3']]*x['x8_4']-st[x['x4_3']]+x['x8_4']+1)/2)
 rem=[base.apply_all(e,st) for e in rem];rem=[sp.factor(e) for e in rem if e!=0]
 target=[x['x6_2'],x['x6_4'],x['x8_4'],x['x9_1']];sl=sp.solve(rem,target,dict=True,simplify=False);assert len(sl)==1;st.update(sl[0]);sol={z:base.apply_all(z,st) for z in vs};X=M.subs(sol).applyfunc(lambda z:sp.factor(sp.cancel(z)));assert all(sp.factor(e.subs(sol))==0 for e in eq)
 return rec,rows,M,vs,X,(a,b,c),rr,cc,sol,tr,(rel1,rel2,rel3)

def main():
 rec,rows,M,vs,X0,(a,b,c),rr,cc,sol,tr,relations=build();A,B,C=sp.symbols('A B C',real=True);bch=2*B-1;cch=2*C-1;lower=sp.factor((bch-1)/(bch+3));ach=sp.factor(lower+(1-lower)*A);chart={a:ach,b:bch,c:cch};cv=(A,B,C);sc={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};sample={k:sp.factor(v.subs(sc)) for k,v in chart.items()};eng=base.SignEngine(cv,sc)
 H=sp.factor(a*b+3*a-b+1);assert sp.factor(H.subs(chart)-4*A)==0;invA=sp.factor((a-lower)/(1-lower));assert sp.factor(invA.subs(chart)-A)==0
 coeff={'one_plus_B':eng.positive_rational(B+1,'B+1'),'one_minus_lower':eng.positive_rational((1-lower),'1-lower')}
 pivot=X0.extract(rr,cc);V0=(pivot.inv()*X0.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F0=X0.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F0*V0-X0)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=factorized_positive(1-X0[i,j]**2,chart,eng,sample,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rs in itertools.combinations(inc,4):
   de=sp.factor(F0.extract(rs,range(4)).det());
   if de==0:continue
   sg=1 if de.subs(sample)>0 else -1
   try:ce=factorized_positive(sg*de,chart,eng,sample,f'ext {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rs),'determinant':str(de),'certificate':ce};break
  assert found is not None;ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V0.subs(sample),float);fn=np.array(F0.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP,rp=global_boundary(facP,ptsP);tetQ,rq=global_boundary(facQ,ptsQ);pb=base.check_closed_sphere(tetP);qb=base.check_closed_sphere(tetQ);pfc=base.check_facet_balls(tetP,facP);qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V0[:,i] if i<6 else -V0[:,i-6]
 def pointQ(i):return F0[i,:].T if i<11 else -F0[i-11,:].T
 def orient(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert de!=0,(label,k,ids);sg=1 if de.subs(sample)>0 else -1;ce=factorized_positive(sg*de,chart,eng,sample,f'{label} {k}');terms.append(sp.factor(sg*de));recs.append({'ids':list(ids),'determinant':str(de),'sign':sg,'certificate':ce})
  return terms,recs
 pt,pr=orient(tetP,pointP,'P');qt,qr=orient(tetQ,pointQ,'Q');volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel((volP*volQ-sp.Rational(32,3)).subs(chart)));mc=eng.positive_rational(margin,'margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2156','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relations':[str(z) for z in relations],'constant_elimination_steps':tr,'completion':{str(k):str(v) for k,v in sol.items()}},'parameter_domain':{'original':'-1<b,c<1 and (b-1)/(b+3)<a<1','chart':{str(k):str(v) for k,v in chart.items()},'inverse_A':str(invA)},'coefficient_certificates':coeff,'strict_defects':17,'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'polar_boundary':qb,'primal_ridge_sizes':dict(Counter(map(len,rp))),'polar_ridge_sizes':dict(Counter(map(len,rq))),'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P_original':str(volP),'volume_polar_original':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 2156 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':17,'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P_original':str(volP),'volume_polar_original':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
