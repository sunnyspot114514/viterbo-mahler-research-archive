#!/usr/bin/env python3
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import importlib.util
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_family2060_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_family2060_verifier_output.json')
spec=importlib.util.spec_from_file_location('base','/mnt/data/viterbo_22f_d17_family768_verifier.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
CID=2060

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,v in enumerate(row):
   if v==0:
    z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=v
 rr=(2,4,7,8);cc=(1,2,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 S=M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ)
 eq=[sp.factor(sp.cancel(e)) for e in S]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 relation=-(x['x2_0']+1)*(x['x5_5']-x['x6_4'])/2
 assert base.proportional_member(rem,relation)
 p,q,r=sp.symbols('p q r',real=True)
 st=dict(const);st.update({x['x6_4']:x['x5_5'],x['x2_0']:p,x['x5_5']:q,x['x8_3']:r})
 rem=[base.apply_all(e,st) for e in rem];rem=[sp.factor(e) for e in rem if e!=0]
 target=[x['x0_1'],x['x1_1'],x['x3_2'],x['x9_1'],x['x10_1']]
 sl=sp.solve(rem,target,dict=True,simplify=False);assert len(sl)==1
 st.update(sl[0]);allsol={z:base.apply_all(z,st) for z in vs}
 X=M.subs(allsol).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(sp.cancel(e.subs(allsol)))==0 for e in eq)
 return rec,rows,M,vs,X,(p,q,r),rr,cc,allsol,trace,relation

def affine_dim(points):return np.linalg.matrix_rank(points-points[0],tol=1e-8)
def polygon_tris(ids,coords):
 ids=sorted(ids);pts=coords[ids];delta=pts-pts[0];vh=np.linalg.svd(delta,full_matrices=False)[2];xy=delta@vh[:2].T;h=ConvexHull(xy);order=[ids[i] for i in h.vertices];root=min(order);k=order.index(root);order=order[k:]+order[:k]
 return [tuple(sorted((root,order[i],order[i+1]))) for i in range(1,len(order)-1)]
def global_boundary_triangulation(facets,coords):
 ridges={}
 for i,j in itertools.combinations(range(len(facets)),2):
  inter=tuple(sorted(set(facets[i])&set(facets[j])))
  if len(inter)>=3 and affine_dim(coords[list(inter)])==2:ridges[inter]=polygon_tris(inter,coords)
 out=[]
 for facet in facets:
  root=min(facet)
  for ridge,tris in ridges.items():
   if root not in ridge and set(ridge)<=set(facet):out += [tuple(sorted((root,)+tri)) for tri in tris]
 return sorted(set(out)),ridges


def factorized_positive(expression, chart, eng, sample_original, label):
 expression=sp.factor(sp.cancel(expression))
 assert sp.N(expression.subs(sample_original))>0,(label,expression.subs(sample_original))
 num,den=map(sp.factor,sp.together(expression).as_numer_denom())
 records=[]
 total_sign=sp.Rational(1)
 for side,poly,exp_sign in [('numerator',num,1),('denominator',den,-1)]:
  coef,factors=sp.factor_list(poly)
  if coef<0: total_sign*=-1
  for f,mult in factors:
   fs=sp.factor(sp.cancel(f.subs(chart)))
   val=sp.N(fs.subs(eng.sample))
   assert val!=0,(label,side,f)
   sg=1 if val>0 else -1
   cert=eng.positive_rational(sg*fs,label+' '+side+' factor')
   if mult%2: total_sign*=sg**exp_sign
   records.append({'side':side,'factor':str(f),'multiplicity':int(mult),'sign':int(sg),'certificate':cert})
 assert total_sign>0,(label,total_sign,expression)
 return {'factorized':True,'records':records}

def main():
 rec,rows,M,vs,X0,free,rr,cc,sol,trace,relation=build_branch();p,q,r=free
 A,B,C=sp.symbols('A B C',real=True)
 qchart=sp.factor((1-3*C+4*B*C)/(1+C));rchart=C
 H=sp.factor(qchart**2*rchart+qchart**2-4*qchart-5*rchart-1)
 c0=sp.factor(qchart**2*rchart+qchart**2+4*qchart*rchart+7*rchart-5)
 pmax=sp.factor(-c0/H);pchart=sp.factor(-1+(pmax+1)*A)
 chart={p:pchart,q:qchart,r:rchart};cv=(A,B,C);sample_cube={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};sample={k:sp.factor(v.subs(sample_cube)) for k,v in chart.items()}
 eng=base.SignEngine(cv,sample_cube)
 Fzero=sp.factor(q*r+q+3*r-1);G=sp.factor(p*q**2*r+p*q**2-4*p*q-5*p*r-p+q**2*r+q**2+4*q*r+7*r-5)
 coeff={'one_plus_C':eng.positive_rational(1+C,'1+C'),'minus_H':eng.positive_rational(-H,'minus H'),'pmax_plus_one':eng.positive_rational(pmax+1,'pmax+1'),'one_minus_pmax':eng.positive_rational(1-pmax,'1-pmax')}
 assert sp.factor(Fzero.subs(chart)-4*B*C)==0;assert sp.factor(G.subs(chart)-16*B*C*(1-A))==0
 invB=sp.factor(Fzero/(4*r));invA=sp.factor(-(p+1)*(q**2*r+q**2-4*q-5*r-1)/(4*Fzero));assert sp.factor(invB.subs(chart)-B)==0 and sp.factor(invA.subs(chart)-A)==0
 pivot0=X0.extract(rr,cc);V0=(pivot0.inv()*X0.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F0=X0.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F0*V0-X0)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=factorized_positive(1-X0[i,j]**2,chart,eng,sample,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F0.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=factorized_positive(sg*det,chart,eng,sample,f'extremality {j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found is not None,j
  ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V0.subs(sample),float);fn=np.array(F0.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP,ridP=global_boundary_triangulation(facP,ptsP);tetQ,ridQ=global_boundary_triangulation(facQ,ptsQ)
 pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP);qb=base.check_closed_sphere(tetQ);qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V0[:,i] if i<6 else -V0[:,i-6]
 def pointQ(i):return F0[i,:].T if i<11 else -F0[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0,(label,k,ids)
   sg=1 if det.subs(sample)>0 else -1;ce=factorized_positive(sg*det,chart,eng,sample,f'{label} tet {k}')
   terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(det),'sign':sg,'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'primal');qt,qr=oriented(tetQ,pointQ,'polar')
 volP0=sp.factor(sp.cancel(sum(pt)/24));volQ0=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel((volP0*volQ0-sp.Rational(32,3)).subs(chart)));mc=eng.positive_rational(margin,'Mahler margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2060','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,'rank_branch':{'pivot_rows':list(rr),'pivot_cols':list(cc),'pivot_determinant':8,'strict_relation':str(relation),'strict_consequence':'x6_4=x5_5 because x2_0+1>0','constant_elimination_steps':trace,'completion':{str(k):str(v) for k,v in sol.items()}},'parameter_domain':{'original':'-1<q,r<1, q*r+q+3*r-1>0, and -1<p<pmax(q,r)','unit_cube_chart':{str(k):str(v) for k,v in chart.items()},'inverse_B':str(invB),'inverse_A':str(invA),'pmax':str(pmax)},'coefficient_certificates':coeff,'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'polar_boundary':qb,'primal_ridge_sizes':dict(Counter(map(len,ridP))),'polar_ridge_sizes':dict(Counter(map(len,ridQ))),'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P_original':str(volP0),'volume_polar_original':str(volQ0),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 2060 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P_original':str(volP0),'volume_polar_original':str(volQ0),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
