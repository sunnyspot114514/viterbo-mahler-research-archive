# 四维中心对称 Mahler：`12V/20F, c=0, D=11` 整层完成报告

日期：2026-08-21

## 1. 组合枚举

`D=11` 对应九条 single-defect rows 与一条 double-defect row。把九对五顶点 facets 三角化后得到

\[
f=(12,50,76,38),\qquad g_2=12.
\]

固定一对 antipodal tetrahedra 后，精确回溯访问

\[
44{,}615{,}819
\]

个节点，得到

\[
673{,}512
\]

个闭合 pseudomanifold candidates。完整 vertex-link 球面检查留下

\[
\boxed{312{,}816}
\]

个真正的中心对称 simplicial 三维球。

在

\[
B_6/\{\pm I\}
\]

作用下，它们恰好形成

\[
\boxed{110\text{ 个球轨道}}.
\]

## 2. Ridge merges 与全局模板

选择九对相容的 antipodal ridges 合并，得到

\[
35{,}630\text{ 个 raw matchings}
\]

及

\[
\boxed{24{,}917\text{ 个局部 matching 代表}}.
\]

完整 signed-coordinate canonicalization 后只剩

\[
\boxed{11{,}978\text{ 个全局 pairing templates}}.
\]

## 3. Exact minor 分类

对每个 template 搜索多仿射 `5x5` minor，并在全部 defect-cube corners 上使用 Bareiss 整数行列式计算。结果为

\[
\boxed{
11{,}978
=
11{,}977\text{ 个 rank}\ge5
+
1\text{ 个 algebraic survivor}.
}
\]

这里没有重复 facet-row template。

## 4. 唯一 survivor 丢失一对 primal vertices

唯一 survivor 的十条 projective pairing rows 为

\[
\begin{pmatrix}
0&1&-1&-1&-1&1\\
0&1&-1&1&1&-1\\
0&1&1&-1&1&-1\\
1&-1&0&1&-1&-1\\
1&-1&1&0&-1&-1\\
1&0&-1&1&-1&-1\\
1&0&1&-1&-1&-1\\
1&0&1&0&-1&-1\\
1&1&-1&0&-1&-1\\
1&1&0&-1&-1&-1
\end{pmatrix}.
\]

取 rows `0,1,2,3` 与 columns `1,3,4,5` 为 pivot，行列式恒为

\[
\boxed{-8}.
\]

Schur-complement equations 在 strict defect branch 中完整化为

\[
x_{1,0}=x_{2,0}=-x_{0,0},
\]

\[
x_{3,2}=x_{4,3}=x_{5,1}=x_{6,1}=x_{8,3}=x_{9,2},
\]

\[
x_{7,1}+x_{7,3}=x_{9,2}-1.
\]

令 `a=x_{0,0}`。由前四条 basis rows 得到的六个 primal columns 恒满足

\[
\boxed{
v_0=rac{1+a}{2}(-v_4)+\frac{1-a}{2}(-v_5).
}
\]

由于 strict defect 给出

\[
-1<a<1,
\]

两个系数严格为正且和为一。因此 `v0` 位于边 `[-v4,-v5]` 的相对内部，不是极点；其 antipode 同理。该 family 实际至多只有十个 primal vertices。

## 5. 结论

\[
\boxed{12V/20F,\quad c=0,\quad D=11\quad\checkmark}.
\]

勾号表示 **computer-assisted analytic proof candidate**。
