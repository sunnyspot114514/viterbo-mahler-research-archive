#!/usr/bin/env python3
from __future__ import annotations
import json,itertools,sys
from pathlib import Path
import sympy as sp
CERT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('viterbo_20f_d11_preclassification_certificate.json')
d=json.loads(CERT.read_text())

def det_bareiss(mat):
    a=[list(map(int,r)) for r in mat];n=len(a);sgn=1;prev=1
    for k in range(n-1):
        p=next((i for i in range(k,n) if a[i][k]),None)
        if p is None:return 0
        if p!=k:a[k],a[p]=a[p],a[k];sgn=-sgn
        piv=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):a[i][j]=(a[i][j]*piv-a[i][k]*a[k][j])//prev
        prev=piv
        for i in range(k+1,n):a[i][k]=0
    return sgn*a[-1][-1]

def decode(k):return [[ord(k[6*i+j])-ord('1') for j in range(6)] for i in range(10)]
counts={'rank_ge_5':0,'duplicate_facet_rows':0,'algebraic_survivor':0}
for rec in d['records']:
    A=decode(rec['canonical_key'])
    zcounts=sorted(sum(x==0 for x in r) for r in A)
    assert zcounts==[1]*9+[2]
    counts[rec['status']]+=1
    if rec['status']=='duplicate_facet_rows':assert len({tuple(r) for r in A})<10
    elif rec['status']=='rank_ge_5':
        rs=rec['minor_rows'];cs=rec['minor_cols'];B0=[[A[i][j] for j in cs] for i in rs]
        loc=[(i,j) for i in range(5) for j in range(5) if B0[i][j]==0]
        assert len(loc)==rec['defect_entries_in_minor']
        vals=[]
        for mask in range(1<<len(loc)):
            B=[r[:] for r in B0]
            for k,(i,j) in enumerate(loc):B[i][j]=1 if (mask>>k)&1 else -1
            vals.append(det_bareiss(B))
        assert vals==rec['corner_dets']
        assert ((all(v>=0 for v in vals) and any(v>0 for v in vals)) or (all(v<=0 for v in vals) and any(v<0 for v in vals)))
assert counts==d['minor_classification']=={'rank_ge_5':11977,'duplicate_facet_rows':0,'algebraic_survivor':1}
# survivor exact branch
s=d['survivor_detail'];rows=s['rows'];M=[];xs={}
for i,row in enumerate(rows):
    rr=[]
    for j,v in enumerate(row):
        if v==0:xs[(i,j)]=sp.symbols(f'x{i}_{j}');rr.append(xs[(i,j)])
        else:rr.append(sp.Integer(v))
    M.append(rr)
X=sp.Matrix(M);R=[0,1,2,3];C=[1,3,4,5];RR=[i for i in range(10) if i not in R];CC=[0,2]
P=X.extract(R,C);assert P.det()==-8
S=sp.simplify(X.extract(RR,CC)-X.extract(RR,C)*P.inv()*X.extract(R,CC))
a,t,u=sp.symbols('a t u')
subs={xs[(0,0)]:a,xs[(1,0)]:-a,xs[(2,0)]:-a,xs[(3,2)]:t,xs[(4,3)]:t,xs[(5,1)]:t,xs[(6,1)]:t,xs[(7,1)]:u,xs[(7,3)]:t-1-u,xs[(8,3)]:t,xs[(9,2)]:t}
assert all(sp.simplify(e.subs(subs))==0 for e in S)
# Exhaustiveness inside strict cube follows directly from selected Schur equations.
eq=list(S)
assert sp.simplify(eq[10]+xs[(0,0)]+xs[(2,0)])==0
assert sp.simplify(eq[0]+(xs[(1,0)]-xs[(2,0)])*(xs[(4,3)]-1)/2)==0
for k,pos in [(1,(4,3)),(3,(5,1)),(5,(6,1)),(9,(8,3)),(11,(9,2))]:
    assert sp.simplify(eq[k]+xs[(3,2)]-xs[pos])==0
assert sp.simplify(eq[7]+xs[(3,2)]-xs[(7,1)]-xs[(7,3)]-1)==0
# primal vertex loss
B=sp.simplify(X.extract(R,range(6)).subs(subs));V=[B[:,j] for j in range(6)]
assert sp.simplify(V[0]-((1+a)/2)*(-V[4])-((1-a)/2)*(-V[5]))==sp.zeros(4,1)
out={'status':'PASS','global_templates':len(d['records']),'classification':counts,'sphere_orbits':d['sphere_orbit_count'],'local_matching_representatives':d['ridge_merge']['local_matching_representatives'],'survivor':'strict primal vertex loss'}
print(json.dumps(out,indent=2,sort_keys=True))
