#include <bits/stdc++.h>
#ifdef _OPENMP
#include <omp.h>
#endif
using namespace std;
using Row=array<int8_t,6>;

Row normrow(Row a){for(int i=0;i<6;i++)if(a[i]){if(a[i]<0)for(auto&x:a)x=-x;break;}return a;}

static inline int vidx(int signed_v){ // signed_v in +-1..+-6
    return signed_v>0 ? signed_v-1 : 6+(-signed_v-1);
}
static inline int edge_id(int a,int b){if(a>b)swap(a,b); return a*12 - a*(a+1)/2 + (b-a-1);}

struct TetPair { array<uint8_t,4> p, n; };

struct LinkScratch {
    uint8_t tris[12][40][3];
    uint8_t ntris[12];
    uint8_t edgeDeg[66];
    int8_t edgeT1[66], edgeT2[66];
};

bool valid_sphere(const array<uint8_t,19>& ids, const array<TetPair,120>& tp){
    LinkScratch sc{};
    uint16_t allverts=0;
    auto add_tet=[&](const array<uint8_t,4>& T){
        for(int z=0;z<4;z++) allverts |= uint16_t(1u<<T[z]);
        for(int z=0;z<4;z++){
            int v=T[z]; int k=sc.ntris[v]++;
            if(k>=40) return false;
            int q=0; for(int j=0;j<4;j++) if(j!=z) sc.tris[v][k][q++]=T[j];
            sort(sc.tris[v][k], sc.tris[v][k]+3);
        }
        return true;
    };
    for(uint8_t id:ids){ if(!add_tet(tp[id].p) || !add_tet(tp[id].n)) return false; }
    if(allverts != 0x0FFFu) return false;

    for(int v=0;v<12;v++){
        int F=sc.ntris[v]; if(F==0) return false;
        memset(sc.edgeDeg,0,sizeof(sc.edgeDeg));
        memset(sc.edgeT1,-1,sizeof(sc.edgeT1));
        memset(sc.edgeT2,-1,sizeof(sc.edgeT2));
        uint16_t verts=0;
        for(int i=0;i<F;i++){
            auto *tr=sc.tris[v][i];
            verts |= uint16_t(1u<<tr[0])|uint16_t(1u<<tr[1])|uint16_t(1u<<tr[2]);
            int e[3]={edge_id(tr[0],tr[1]),edge_id(tr[0],tr[2]),edge_id(tr[1],tr[2])};
            for(int z=0;z<3;z++){
                int ee=e[z]; int d=sc.edgeDeg[ee]++;
                if(d==0) sc.edgeT1[ee]=i;
                else if(d==1) sc.edgeT2[ee]=i;
                else return false;
            }
        }
        int E=0; for(int e=0;e<66;e++) if(sc.edgeDeg[e]){ if(sc.edgeDeg[e]!=2) return false; E++; }
        int V=__builtin_popcount((unsigned)verts);
        if(V-E+F != 2) return false;
        // triangle adjacency connected
        bool vis[40]={}; int q[40],qh=0,qt=0; q[qt++]=0;vis[0]=true;
        while(qh<qt){int x=q[qh++]; auto *tr=sc.tris[v][x]; int e[3]={edge_id(tr[0],tr[1]),edge_id(tr[0],tr[2]),edge_id(tr[1],tr[2])}; for(int z=0;z<3;z++){int ee=e[z];int y=(sc.edgeT1[ee]==x?sc.edgeT2[ee]:sc.edgeT1[ee]); if(y<0)return false; if(!vis[y])vis[y]=true,q[qt++]=y;}}
        if(qt!=F) return false;
        // each vertex-link inside 2D link is one connected cycle
        for(int w=0;w<12;w++) if(verts>>w&1){
            uint16_t neigh=0; uint16_t adj[12]{}; int deg[12]{};
            for(int i=0;i<F;i++){
                auto *tr=sc.tris[v][i]; int pos=-1; for(int z=0;z<3;z++)if(tr[z]==w)pos=z; if(pos<0)continue;
                int a=tr[(pos+1)%3], b=tr[(pos+2)%3];
                neigh|=uint16_t(1u<<a)|uint16_t(1u<<b); adj[a]|=uint16_t(1u<<b);adj[b]|=uint16_t(1u<<a);deg[a]++;deg[b]++;
            }
            if(!neigh) return false;
            for(int a=0;a<12;a++) if(neigh>>a&1) if(deg[a]!=2) return false;
            int st=__builtin_ctz((unsigned)neigh); uint16_t seen=0,front=uint16_t(1u<<st);
            while(front){seen|=front;uint16_t nxt=0;for(int a=0;a<12;a++)if(front>>a&1)nxt|=adj[a];front=nxt&~seen;}
            if(seen!=neigh) return false;
        }
    }
    return true;
}

int main(int argc,char**argv){
    if(argc<3){cerr<<"usage: input output [json]\n";return 2;}
    string inpath=argv[1],outpath=argv[2],jspath=argc>3?argv[3]:"filter_output.json";
    vector<Row> facets; set<Row> seen;
    for(int mask=0;mask<64;mask++)if(__builtin_popcount((unsigned)mask)==4){vector<int>ind;for(int j=0;j<6;j++)if(mask>>j&1)ind.push_back(j);for(int bits=0;bits<16;bits++){Row a{};for(int z=0;z<4;z++)a[ind[z]]=(bits>>z&1)?1:-1;a=normrow(a);if(seen.insert(a).second)facets.push_back(a);}}
    sort(facets.begin(),facets.end()); if(facets.size()!=120){cerr<<"facet count\n";return 3;}
    array<TetPair,120> tp{};
    for(int i=0;i<120;i++){int z=0;for(int j=0;j<6;j++)if(facets[i][j]){int sv=facets[i][j]*(j+1);tp[i].p[z]=vidx(sv);tp[i].n[z]=vidx(-sv);z++;}sort(tp[i].p.begin(),tp[i].p.end());sort(tp[i].n.begin(),tp[i].n.end());}
    ifstream in(inpath); vector<array<uint8_t,19>> sols; array<uint8_t,19>a; int x; while(true){for(int i=0;i<19;i++){if(!(in>>x))goto done;a[i]=uint8_t(x);}sols.push_back(a);} done:;
    vector<uint8_t> ok(sols.size());
    #pragma omp parallel for schedule(dynamic,256)
    for(long long i=0;i<(long long)sols.size();i++) ok[i]=valid_sphere(sols[i],tp);
    ofstream out(outpath); long long valid=0;
    for(size_t i=0;i<sols.size();i++)if(ok[i]){valid++;auto ids=sols[i];sort(ids.begin(),ids.end());for(auto id:ids)out<<int(id)<<' ';out<<'\n';}
    ofstream js(jspath);js<<"{\n  \"closed_pseudomanifolds\": "<<sols.size()<<",\n  \"valid_spheres_fixed_facet\": "<<valid<<",\n  \"f_vectors\": {\"(12, 50, 76, 38)\": "<<valid<<"}\n}\n";
    cerr<<"total="<<sols.size()<<" valid="<<valid;
    #ifdef _OPENMP
    cerr<<" threads="<<omp_get_max_threads();
    #endif
    cerr<<"\n";
}
