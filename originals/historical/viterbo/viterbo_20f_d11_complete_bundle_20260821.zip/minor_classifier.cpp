#include <bits/stdc++.h>
using namespace std;
using Mat=array<array<int,6>,10>;

long long det_bareiss5(array<array<long long,5>,5> a){
    long long prev=1,sgn=1;
    for(int k=0;k<4;k++){
        int p=-1; for(int i=k;i<5;i++) if(a[i][k]){p=i;break;}
        if(p<0) return 0;
        if(p!=k){swap(a[p],a[k]);sgn=-sgn;}
        long long piv=a[k][k];
        for(int i=k+1;i<5;i++)for(int j=k+1;j<5;j++) a[i][j]=(a[i][j]*piv-a[i][k]*a[k][j])/prev;
        prev=piv; for(int i=k+1;i<5;i++)a[i][k]=0;
    }
    return sgn*a[4][4];
}

struct Cert{bool ok=false;array<int,5> rs{},cs{};vector<long long>dets;int z=0;};

Cert find_cert(const Mat&A){
    vector<array<int,5>> rcombs,ccombs;
    for(int a=0;a<10;a++)for(int b=a+1;b<10;b++)for(int c=b+1;c<10;c++)for(int d=c+1;d<10;d++)for(int e=d+1;e<10;e++)rcombs.push_back({a,b,c,d,e});
    for(int omit=0;omit<6;omit++){array<int,5> c{};int z=0;for(int j=0;j<6;j++)if(j!=omit)c[z++]=j;ccombs.push_back(c);} // lex-ish by omitted col
    // search by defect count; old certificates never need >4, but allow up to 8
    for(int target=0;target<=8;target++){
        for(auto rs:rcombs)for(auto cs:ccombs){
            vector<pair<int,int>> loc;
            for(int i=0;i<5;i++)for(int j=0;j<5;j++)if(A[rs[i]][cs[j]]==0)loc.push_back({i,j});
            if((int)loc.size()!=target)continue;
            if(target>8)continue;
            vector<long long> vals; vals.reserve(1u<<target); bool nonneg=true,nonpos=true,anyp=false,anyn=false;
            for(int bits=0;bits<(1<<target);bits++){
                array<array<long long,5>,5>B{};
                for(int i=0;i<5;i++)for(int j=0;j<5;j++)B[i][j]=A[rs[i]][cs[j]];
                for(int k=0;k<target;k++)B[loc[k].first][loc[k].second]=(bits>>k&1)?1:-1;
                long long v=det_bareiss5(B);vals.push_back(v);if(v<0)nonneg=false,anyn=true;if(v>0)nonpos=false,anyp=true;
                if(!nonneg&&!nonpos)break;
            }
            if((nonneg&&anyp)||(nonpos&&anyn))return {true,rs,cs,vals,target};
        }
    }
    return {};
}

int main(int argc,char**argv){
    if(argc<3){cerr<<"usage input output\n";return 2;}
    ifstream in(argv[1]);ofstream out(argv[2]);int id;string key;long long n=0,nrank=0,ndup=0,nsurv=0;
    while(in>>id>>key){
        if(key.size()!=60){cerr<<"bad key\n";return 3;} Mat A{};int z=0;for(int i=0;i<10;i++)for(int j=0;j<6;j++)A[i][j]=int(key[z++]-'1');
        bool dup=false;for(int i=0;i<10;i++)for(int j=i+1;j<10;j++)if(A[i]==A[j])dup=true;
        if(dup){out<<id<<" DUP\n";ndup++;}
        else{
            Cert c=find_cert(A);
            if(c.ok){out<<id<<" RANK";for(int x:c.rs)out<<' '<<x;out<<" |";for(int x:c.cs)out<<' '<<x;out<<" |"<<c.z<<" |";for(auto v:c.dets)out<<' '<<v;out<<'\n';nrank++;}
            else{out<<id<<" SURV\n";nsurv++;}
        }
        n++;
    }
    cerr<<"templates="<<n<<" rank_ge_5="<<nrank<<" duplicate="<<ndup<<" survivors="<<nsurv<<"\n";
}
