#!/usr/bin/env python3
from __future__ import annotations
import sys,json,itertools
from pathlib import Path
from itertools import combinations
WORK=Path(sys.argv[1]); SI=int(sys.argv[2]); OUT=Path(sys.argv[3])
sys.path.insert(0,str(WORK))
import viterbo_20f_d16_preclassifier as d16

def normrow(a):
 a=tuple(a)
 for x in a:
  if x:return tuple(-y for y in a) if x<0 else a
 return a
facets=[];seen=set()
for mask in range(64):
 if mask.bit_count()!=4:continue
 inds=[i for i in range(6) if mask>>i&1]
 for signs in itertools.product((-1,1),repeat=4):
  a=[0]*6
  for i,s in zip(inds,signs):a[i]=s
  a=normrow(a)
  if a not in seen:seen.add(a);facets.append(a)
facets.sort()
def row_to_F(r):return frozenset((i+1 if x>0 else -(i+1)) for i,x in enumerate(r) if x)
def anti(F):return frozenset(-x for x in F)
def sphere_from_ids(ids):
 out=set()
 for i in ids:
  F=row_to_F(facets[i]);out.add(F);out.add(anti(F))
 return out
sphere_ids=[]
for line in open(WORK/'sphere_orbits.txt'):sphere_ids.append(tuple(map(int,line.split(':',1)[1].split())))
fs=sphere_from_ids(sphere_ids[SI])
def dual_data(fs):
 flist=sorted(fs,key=lambda f:tuple(sorted(f)));idx={f:i for i,f in enumerate(flist)};ant=[idx[anti(f)] for f in flist]
 ed=[(i,j) for i,j in combinations(range(len(flist)),2) if len(flist[i]&flist[j])==3]
 seen=set();eps=[]
 for e in ed:
  ae=tuple(sorted((ant[e[0]],ant[e[1]])));key=tuple(sorted((e,ae)))
  if key not in seen:seen.add(key);eps.append(key)
 eps=[pair for pair in eps if not any(i in (flist[pair[0][0]]|flist[pair[0][1]]) and -i in (flist[pair[0][0]]|flist[pair[0][1]]) for i in range(1,7))]
 return flist,idx,ant,eps,[frozenset(e1+e2) for e1,e2 in eps]
def enum_match(eps,supp,k=9):
 out=[]
 def rec(st,ch,used):
  if len(ch)==k:out.append(tuple(ch));return
  if len(eps)-st<k-len(ch):return
  for i in range(st,len(eps)):
   if supp[i].isdisjoint(used):rec(i+1,ch+[i],used|supp[i])
 rec(0,[],frozenset());return out
def matching_actions(autos,flist,idx,eps):
 epkey={p:i for i,p in enumerate(eps)};out=[]
 for mp in autos:
  fmap=[idx[frozenset(mp[v] for v in F)] for F in flist];arr=[]
  for e1,e2 in eps:
   ne1=tuple(sorted((fmap[e1[0]],fmap[e1[1]])));ne2=tuple(sorted((fmap[e2[0]],fmap[e2[1]])))
   arr.append(epkey[tuple(sorted((ne1,ne2)))])
  out.append(tuple(arr))
 return out
def orbit_reps(ms,acts):
 unseen=set(ms);reps=[];sizes=[]
 while unseen:
  m=min(unseen);orb={tuple(sorted(a[i] for i in m)) for a in acts};orb&=unseen;unseen-=orb;reps.append(m);sizes.append(len(orb))
 return reps,sizes
def row_from_face(F):return normrow([1 if i in F else -1 if -i in F else 0 for i in range(1,7)])
def sign_template(flist,ant,eps,m):
 cons=set();faces=[]
 for pi in m:
  e1,e2=eps[pi];faces.append(flist[e1[0]]|flist[e1[1]]);cons.update(e1);cons.update(e2)
 for i,F in enumerate(flist):
  if i not in cons and i<ant[i]:faces.append(F)
 rows=tuple(sorted(row_from_face(F) for F in faces));assert len(rows)==10 and sorted(sum(x==0 for x in r) for r in rows)==[1]*9+[2]*1
 return rows
flist,idx,ant,eps,supp=dual_data(fs);autos=d16.automorphisms(fs);ms=enum_match(eps,supp);acts=matching_actions(autos,flist,idx,eps);reps,sizes=orbit_reps(ms,acts)
rec=[{'sphere':SI,'matching':list(m),'orbit_size':sizes[z],'rows':[list(r) for r in sign_template(flist,ant,eps,m)]} for z,m in enumerate(reps)]
data={'summary':{'sphere':SI,'automorphisms_signed':len(autos),'good_ridge_pairs':len(eps),'raw_matchings':len(ms),'matching_orbits':len(reps)},'records':rec}
OUT.write_text(json.dumps(data,separators=(',',':')))
print(json.dumps(data['summary'],sort_keys=True))
