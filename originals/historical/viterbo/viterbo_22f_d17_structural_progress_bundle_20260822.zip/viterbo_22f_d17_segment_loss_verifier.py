#!/usr/bin/env python3
"""Exact verifier for line-segment vertex-loss certificates in 12V/22F,c=0,D=17."""
from __future__ import annotations
import itertools,json,hashlib
from pathlib import Path
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_segment_loss_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_segment_loss_verifier_output.json')

def det3(a):
 return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
        -a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
        +a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))

def check_minor(rows,c):
 rr,cc=c['rows'],c['cols'];m=[[rows[i][j] for j in cc] for i in rr]
 zp=[(i,j) for i in range(3) for j in range(3) if m[i][j]==0]
 assert len(zp)==c['zero_count']
 vals=[]
 for bits in itertools.product((-1,1),repeat=len(zp)):
  a=[r[:] for r in m]
  for v,(i,j) in zip(bits,zp):a[i][j]=v
  vals.append(det3(a))
 assert vals==c['corner_dets']
 nz=[v for v in vals if v]
 assert nz and (all(v>0 for v in nz) or all(v<0 for v in nz))
 # A multi-affine determinant is a strictly positive weighted average of
 # its cube-corner values on the open cube, hence nonzero there.

def check_primal(rows,c):
 i=c['target_col'];j,k=c['endpoint_cols'];sj,sk=c['endpoint_signs']
 common=c['common_rows'];assert len(common)>=3
 for r in common:
  z=rows[r][i]
  assert z and z==sj*rows[r][j]==sk*rows[r][k]
 check_minor(rows,c['independence_minor'])
 r=c['separator_row'];assert rows[r][i]==0
 vals=[sj*rows[r][j],sk*rows[r][k]]
 assert vals==c['separator_endpoint_values'] and set(vals)=={-1,1}
 # For every strict completion x in (-1,1), the target lies on the affine
 # line cut out by three independent hyperplanes and has separator value
 # strictly between the endpoint values -1 and +1. Hence it lies in the
 # relative interior of the endpoint segment and cannot be an extreme point.

def check_polar(rows,c):
 i=c['target_row'];j,k=c['endpoint_rows'];sj,sk=c['endpoint_signs']
 common=c['common_cols'];assert len(common)>=3
 for col in common:
  z=rows[i][col]
  assert z and z==sj*rows[j][col]==sk*rows[k][col]
 check_minor(rows,c['independence_minor'])
 col=c['separator_col'];assert rows[i][col]==0
 vals=[sj*rows[j][col],sk*rows[k][col]]
 assert vals==c['separator_endpoint_values'] and set(vals)=={-1,1}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 pre=json.loads(PRE.read_text());cert=json.loads(CERT.read_text())
 survivors=set(pre['remaining_survivor_ids']);closed=[];counts={'primal':0,'polar':0}
 for rec in cert['records']:
  idx=rec['canonical_id'];assert idx in survivors
  rows=pre['records'][idx]['rows'];typ=rec['loss_type'];c=rec['certificate']
  if typ=='primal':check_primal(rows,c)
  elif typ=='polar':check_polar(rows,c)
  else:raise AssertionError(typ)
  counts[typ]+=1;closed.append(idx)
 assert len(closed)==len(set(closed))==44
 assert counts=={'primal':42,'polar':2}
 expected=sorted(survivors-set(closed));assert expected==cert['remaining_ids'] and len(expected)==77
 result={
  'status':'PASS','scope':cert['scope'],'source_preclassification_sha256':sha(PRE),
  'certificate_sha256':sha(CERT),'closed_families':44,
  'primal_vertex_loss':42,'polar_vertex_loss':2,'remaining_survivors':77,
  'closed_ids':sorted(closed),
 }
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
