#!/usr/bin/env python3
"""Aggregate exact verifier for 12V/22F,c=0,D=17 structural progress."""
from __future__ import annotations
import json,hashlib,subprocess,sys
from pathlib import Path
R=Path('/mnt/data')
PRE=R/'viterbo_22f_d17_preclassification_certificate.json'
CONT=R/'viterbo_22f_d17_facet_antichain_certificate.json'
SEG=R/'viterbo_22f_d17_segment_loss_certificate.json'
DUP=R/'viterbo_22f_d17_duplicate_loss_certificate.json'
F606=R/'viterbo_22f_d17_family606_certificate.json'
F606OUT=R/'viterbo_22f_d17_family606_verifier_output.json'
CERT=R/'viterbo_22f_d17_structural_accounting_certificate.json'
OUT=R/'viterbo_22f_d17_structural_accounting_verifier_output.json'
CHILDREN=[
 R/'viterbo_22f_d17_preclassification_verifier.py',
 R/'viterbo_22f_d17_facet_antichain_verifier.py',
 R/'viterbo_22f_d17_segment_loss_verifier.py',
 R/'viterbo_22f_d17_duplicate_loss_verifier.py',
 R/'viterbo_22f_d17_family606_verifier.py',
]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 for child in CHILDREN:
  z=subprocess.run([sys.executable,str(child)],capture_output=True,text=True,check=False)
  assert z.returncode==0,(child,z.stdout,z.stderr)
 pre=json.loads(PRE.read_text());cont=json.loads(CONT.read_text());seg=json.loads(SEG.read_text());dup=json.loads(DUP.read_text());fout=json.loads(F606OUT.read_text());cert=json.loads(CERT.read_text())
 assert fout['status']=='PASS' and fout['canonical_family']==606
 assert cert['source_hashes']=={str(p):sha(p) for p in [PRE,CONT,SEG,DUP,F606,F606OUT]}
 allids=set(range(pre['global_templates']));surv=set(pre['remaining_survivor_ids']);rank={r['canonical_id'] for r in pre['records'] if r['status']=='rank_ge_5'}
 contain={r['canonical_id'] for r in cont['records']};segall=set(seg['closed_ids']);dupids=set(dup['closed_ids']);mahler={606}
 expected={
  'facet_containment':contain,
  'rank_ge_5_after_antichain':rank-contain,
  'segment_loss_after_antichain':segall-contain,
  'forced_duplicate_or_antipodal_primal_pair':dupids,
  'Mahler_positive_exact_family':mahler,
  'remaining_algebraic_survivors':surv-contain-segall-dupids-mahler,
 }
 got={k:set(v) for k,v in cert['categories'].items()};assert got==expected
 ss=list(got.values())
 for i in range(len(ss)):
  for j in range(i):assert not ss[i]&ss[j]
 assert set().union(*ss)==allids
 counts={k:len(v) for k,v in got.items()};assert counts==cert['disjoint_classification']
 assert counts=={'facet_containment':1230,'rank_ge_5_after_antichain':1070,'segment_loss_after_antichain':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':1,'remaining_algebraic_survivors':68}
 assert cert['survivor_level_accounting']=={'initial':121,'facet_containment':26,'additional_segment_loss':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':1,'remaining':68}
 result={'status':'PASS','scope':cert['scope'],'total_templates':2395,'initial_algebraic_survivors':121,'structurally_closed_survivors':52,'Mahler_positive_exact_families':1,'remaining_survivors':68,'disjoint_classification':counts,'remaining_ids':sorted(got['remaining_algebraic_survivors']),'certificate_sha256':sha(CERT)}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
