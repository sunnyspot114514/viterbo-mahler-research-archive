#!/usr/bin/env python3
"""Exact verifier for the facet-antichain obstruction in 12V/22F,c=0,D=17."""
from __future__ import annotations
import json,itertools,hashlib
from pathlib import Path
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_facet_antichain_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_facet_antichain_verifier_output.json')

def all_witnesses(rows):
 out=[]
 for i,j in itertools.permutations(range(len(rows)),2):
  si=sum(x!=0 for x in rows[i]);sj=sum(x!=0 for x in rows[j])
  if si>=sj:continue
  for eps in (1,-1):
   if all(rows[i][k]==0 or rows[j][k]==eps*rows[i][k] for k in range(6)):
    out.append((i,j,eps,si,sj));break
 return out

def check_record(rows,r):
 w=r['witness'];i=w['small_row'];j=w['large_row'];eps=w['sign']
 si=sum(x!=0 for x in rows[i]);sj=sum(x!=0 for x in rows[j])
 assert si==w['small_support']<w['large_support']==sj
 assert all(rows[i][k]==0 or rows[j][k]==eps*rows[i][k] for k in range(6))
 small=[x*(k+1) for k,x in enumerate(rows[i]) if x]
 large=[eps*x*(k+1) for k,x in enumerate(rows[j]) if x]
 assert small==w['small_signed_vertices'] and large==w['large_signed_vertices']
 assert set(small)<set(large)

def main():
 pre=json.loads(PRE.read_text());cert=json.loads(CERT.read_text())
 assert cert['source_preclassification_sha256']==hashlib.sha256(PRE.read_bytes()).hexdigest()
 recmap={r['canonical_id']:r for r in cert['records']};found={}
 for rec in pre['records']:
  ws=all_witnesses(rec['rows'])
  if ws:found[rec['canonical_id']]=ws
 assert set(found)==set(recmap)
 for idx,r in recmap.items():
  assert r['preclassification_status']==pre['records'][idx]['status']
  check_record(pre['records'][idx]['rows'],r)
 rank=sorted(i for i in found if pre['records'][i]['status']=='rank_ge_5')
 surv=sorted(i for i in found if pre['records'][i]['status']=='algebraic_survivor')
 assert rank==cert['rank_ge_5_ids'] and surv==cert['algebraic_survivor_ids']
 assert len(found)==1230 and len(rank)==1204 and len(surv)==26
 result={'status':'PASS','scope':cert['scope'],'templates_with_facet_containment':1230,
         'rank_ge_5_overlap':1204,'algebraic_survivor_overlap':26,
         'survivor_ids':surv,'certificate_sha256':hashlib.sha256(CERT.read_bytes()).hexdigest()}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
