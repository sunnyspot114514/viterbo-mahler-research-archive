# 四维中心对称 Mahler：12V/22F, D=17 结构推进

日期：2026-08-22

## 本轮结论

在此前的精确预分类中，

\[
2395=2274\text{ 个 rank}\ge5+121\text{ 个 algebraic survivors}.
\]

本轮在 121 个低秩候选上新增三类可重放结构证书，并完整关闭第一个 genuine 连续族 Family 606。最终得到一份不重叠 accounting：

\[
\boxed{
2395=
1230\text{ 个 facet containment}
+1070\text{ 个 antichain 内 rank}\ge5
+22\text{ 个额外 segment loss}
+4\text{ 个 forced duplicate}
+1\text{ 个 Mahler-positive family}
+68\text{ 个 remaining}.
}
\]

在 survivor 层面：

\[
\boxed{121=26+22+4+1+68.}
\]

因此，D=17 的代数候选已经由 121 个压缩到 68 个。

## 1. Facet-antichain 引理

多胞体的 facet 是极大真面，因此两个不同 facets 的顶点集不可能满足严格包含。

在 pairing-row 表述中，一行的非零带符号坐标就是该 facet 所含的带符号顶点。如果某行的非零带符号集合，在允许整体取反后，严格包含于另一行，则较小者不可能是 facet。

这一条件在全部 2395 个 templates 中命中 1230 个：

- 1204 个同时已有 rank≥5 证书；
- 26 个属于原来的 121 个 algebraic survivors。

其中 4 个新关闭 survivor 是 240、399、978、981；其典型形态是一条 tetrahedral facet 的四个顶点严格包含在一条五顶点 facet 中。

## 2. 三超平面线段证书

若目标点与两个端点同时落在三个线性独立的 facet 超平面中，它们位于同一条仿射直线上。再取一条 separator facet，使两个端点的取值为 -1 与 +1，而目标点取严格 defect 值 \(x\in(-1,1)\)，则

\[
p=\frac{1-x}{2}p_-+\frac{1+x}{2}p_+,
\]

所以目标点位于端点线段的相对内部，不能是极点。对偶版本同样排除 polar section row。

原 44 个 segment-loss families 中有 22 个已被 facet-antichain 覆盖；另外 22 个构成新的不重叠关闭项。

## 3. 四超平面重复点证书

若两个带符号 primal columns 在四个线性独立的 facet 超平面上取值完全相同，则四个超平面的交只有一个点，两个 columns 必须相等；相反号情形则强迫 antipodal duplication。

这排除了 4 个额外 families：

\[
1595,\ 1619,\ 1655,\ 2212.
\]

## 4. Family 606 完整关闭

Family 606 有恒非零 pivot，rank ideal 在自由参数域上是零维的，得到唯一三参数 strict branch。其完整严格域为

\[
-1<v,w<1,
\qquad
-1<u<\frac{v-w}{v+w+2}.
\]

单位开立方体参数化为

\[
v=2B-1,
\qquad
w=2C-1,
\qquad
u=-1+\frac{2AB}{B+C},
\qquad0<A,B,C<1.
\]

全域证书确认：

\[
\operatorname{rank}X=4,
\qquad f_0(P)=12,
\qquad f_0(P^\circ)=22.
\]

固定边界分解使用 34 个 primal tetrahedra 与 77 个 polar tetrahedra。

Mahler 余量分子的 tensor Bernstein degree 为

\[
(4,7,6),
\]

系数统计为

\[
148>0,\qquad132=0,\qquad0<0,
\]

最小正系数为 \(4/105\)。分母 degree 为 \((3,5,4)\)，有 59 个正系数、61 个零系数，最小正系数为 \(3/20\)。因此

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

贯穿完整 strict realization space。

## 5. 当前前沿

D=17 目前剩余 68 个 algebraic survivors。

探索性数值扫描（不作为证明）显示：

- 45 个 remaining families 找到了严格 rank-4 样本；
- 其中 43 个看起来是三参数 family；
- 2 个（IDs 131、1260）看起来是四参数 family；
- 23 个仍需 variable pivot、分块 Gröbner 或直接 determinantal-ideal 处理。

下一阶段优先处理 23 个困难分支，同时将 43 个三参数 families 按有理参数化和 template symmetry 聚类，避免逐族重复计算。

## 范围说明

所有关闭结论仍是 computer-assisted analytic proof candidates。当前结果属于四维 symmetric Mahler 的 bounded-12 有限核心；完整四维证明仍需完成剩余 bounded-12 层，并建立不依赖顶点或 facet 数的 finite-core / bi-shadow-rigid reduction theorem。
