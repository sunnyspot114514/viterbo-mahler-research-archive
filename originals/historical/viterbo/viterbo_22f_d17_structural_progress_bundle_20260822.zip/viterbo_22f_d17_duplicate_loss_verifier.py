#!/usr/bin/env python3
from __future__ import annotations
import itertools,json,hashlib
from pathlib import Path
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json')
SEG=Path('/mnt/data/viterbo_22f_d17_segment_loss_certificate.json')
CERT=Path('/mnt/data/viterbo_22f_d17_duplicate_loss_certificate.json')
OUT=Path('/mnt/data/viterbo_22f_d17_duplicate_loss_verifier_output.json')

def det4(m):
 a=[r[:] for r in m];sg=1;prev=1
 for k in range(3):
  if a[k][k]==0:
   q=next((i for i in range(k+1,4) if a[i][k]),None)
   if q is None:return 0
   a[k],a[q]=a[q],a[k];sg=-sg
  p=a[k][k]
  for i in range(k+1,4):
   for j in range(k+1,4):a[i][j]=(a[i][j]*p-a[i][k]*a[k][j])//prev
  prev=p
  for i in range(k+1,4):a[i][k]=0
 return sg*a[3][3]

def check_minor(rows,c):
 rr,cc=c['rows'],c['cols'];m=[[rows[i][j] for j in cc] for i in rr];zp=[(i,j) for i in range(4) for j in range(4) if m[i][j]==0]
 assert len(zp)==c['zero_count'];vals=[]
 for bits in itertools.product((-1,1),repeat=len(zp)):
  a=[r[:] for r in m]
  for v,(i,j) in zip(bits,zp):a[i][j]=v
  vals.append(det4(a))
 assert vals==c['corner_dets'];nz=[v for v in vals if v];assert nz and (all(v>0 for v in nz) or all(v<0 for v in nz))

def main():
 pre=json.loads(PRE.read_text());seg=json.loads(SEG.read_text());cert=json.loads(CERT.read_text());seen=[]
 for rec in cert['records']:
  idx=rec['canonical_id'];rows=pre['records'][idx]['rows'];typ=rec['loss_type'];c=rec['certificate']
  if typ=='primal':
   i,j=c['cols'];s=c['sign'];common=c['common_rows'];assert len(common)>=4
   for r in common:assert rows[r][i]!=0 and rows[r][i]==s*rows[r][j]
  else:
   i,j=c['rows'];s=c['sign'];common=c['common_cols'];assert len(common)>=4
   for col in common:assert rows[i][col]!=0 and rows[i][col]==s*rows[j][col]
  check_minor(rows,c['independence_minor']);seen.append(idx)
 assert len(set(seen))==4 and not set(seen)&set(seg['closed_ids'])
 remaining=set(pre['remaining_survivor_ids'])-set(seg['closed_ids'])-set(seen)
 assert sorted(remaining)==cert['remaining_ids'] and len(remaining)==73
 result={'status':'PASS','closed_families':4,'primal_point_loss':4,'polar_point_loss':0,'remaining_survivors':73,'closed_ids':sorted(seen),'certificate_sha256':hashlib.sha256(CERT.read_bytes()).hexdigest()}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
