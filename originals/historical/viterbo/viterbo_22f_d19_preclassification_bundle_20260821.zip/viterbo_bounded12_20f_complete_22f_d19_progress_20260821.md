# 四维中心对称 Mahler：bounded-12 最新推进

日期：2026-08-21

## 阶段里程碑：12V/20F 整层关闭

此前已完成 \(D=16,15,14,13,12\)。本轮又完成：

### D=11

\[
11978=11977\text{ 个 rank}\ge5+1\text{ 个 strict primal vertex-loss}.
\]

组合枚举数据：

- 搜索节点：44,615,819；
- 闭合 pseudomanifolds：673,512；
- 真正 cs 3-spheres：312,816；
- 球轨道：110；
- raw ridge matchings：35,630；
- 局部 matching 代表：24,917；
- 全局 templates：11,978。

唯一 survivor 满足

\[
v_0=\frac{1+a}2(-v_4)+\frac{1-a}2(-v_5),\qquad |a|<1,
\]

故至多 10 个 vertices。

### D=10

\[
2602=2602\text{ 个 rank}\ge5.
\]

组合枚举数据：

- 搜索节点：90,235,079；
- 闭合 pseudomanifolds：1,612,560；
- 真正 cs 3-spheres：612,800；
- 球轨道：198；
- perfect ridge matchings：7,780；
- 全局 templates：2,602。

因此

\[
\boxed{12V/20F,\ c=0\quad\checkmark}
\]

其中勾号表示 computer-assisted analytic proof candidate。

## 新前沿：12V/22F, D=19

最高 defect 层的直接预分类得到：

- 840 个 fixed-facet cs 3-spheres；
- 3 个球轨道；
- 849 个 raw ridge matchings；
- 103 个局部 matching 代表；
- 92 个全局 pairing templates。

Exact minor 分类与结构排除给出

\[
\boxed{
92=69\text{ rank}\ge5+8\text{ duplicate rows}+1\text{ primal vertex-loss}+14\text{ remaining}.
}
\]

唯一已结构关闭的 survivor 是 768；其三条 primal columns 被三个独立仿射方程强迫共线，故至少丢失一对极点。

## 范围说明

这意味着 bounded-12 主线已从 20F 完整推进到 22F 的最高 defect 层。它仍不是完整四维 symmetric Mahler 猜想的证明：

1. 22F 及更高 facet 层仍需处理；
2. 即便 bounded-12 全部关闭，仍需不依赖 \(f_0,f_3\) 的 finite-core / bi-shadow-rigid reduction theorem，才能覆盖任意复杂度的四维中心对称凸体。
