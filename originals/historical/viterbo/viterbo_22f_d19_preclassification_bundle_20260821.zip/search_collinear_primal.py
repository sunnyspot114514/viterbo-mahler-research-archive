import json,itertools,sympy as sp
meta=json.load(open('canonical_metadata.json'))['records'];ids={int(l.split()[0]) for l in open('survivors.txt')}

def sign_def(poly,vars):
 vals=[]
 for bits in itertools.product((-1,1),repeat=len(vars)):
  v=sp.simplify(poly.subs(dict(zip(vars,bits))))
  if not v.is_number:return None
  vals.append(sp.Rational(v))
 return (all(v>=0 for v in vals) and any(v>0 for v in vals)) or (all(v<=0 for v in vals) and any(v<0 for v in vals)), vals

for rec in meta:
 if rec['canonical_id'] not in ids:continue
 rows=rec['rows'];M=[];xs={}
 for i,row in enumerate(rows):
  rr=[]
  for j,v in enumerate(row):
   if v==0:xs[(i,j)]=sp.symbols(f'x{i}_{j}');rr.append(xs[(i,j)])
   else:rr.append(sp.Integer(v))
  M.append(rr)
 X=sp.Matrix(M);piv=None
 for R in itertools.combinations(range(11),4):
  for C in itertools.combinations(range(6),4):
   P=X.extract(R,C)
   if not any(e.free_symbols for e in P) and P.det()!=0:piv=(list(R),list(C),P);break
  if piv:break
 R,C,P=piv; found=[]
 for J in itertools.combinations(range(6),3):
  eqrows=[i for i in range(11) if rows[i][J[0]]==rows[i][J[1]]==rows[i][J[2]] and rows[i][J[0]]!=0]
  for I in itertools.combinations(eqrows,3):
   H=sp.simplify(X.extract(I,C)*P.inv())
   for K in itertools.combinations(range(4),3):
    det=sp.factor(H[:,K].det()); vs=sorted(det.free_symbols,key=str)
    sd=sign_def(det,vs)
    if sd and sd[0]:
     found.append((J,I,K,det,min(sd[1]),max(sd[1])));break
   if found:break
  if found:break
 print(rec['canonical_id'],'FOUND' if found else 'none',found[:1])
