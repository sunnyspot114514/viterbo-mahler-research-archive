import json,itertools,numpy as np
from scipy.optimize import least_squares, linprog
meta=json.load(open('canonical_metadata.json'))['records'];ids={int(l.split()[0]) for l in open('survivors.txt')}

def setup(rows):
 pos=[]; A0=np.array(rows,dtype=float)
 for i,j in itertools.product(range(len(rows)),range(6)):
  if rows[i][j]==0:pos.append((i,j))
 # constant pivot
 piv=None
 for R in itertools.combinations(range(len(rows)),4):
  for C in itertools.combinations(range(6),4):
   P=A0[np.ix_(R,C)]
   if np.all(P!=0) and abs(np.linalg.det(P))>.5:piv=(list(R),list(C));break
  if piv:break
 R,C=piv;RR=[i for i in range(len(rows)) if i not in R];CC=[j for j in range(6) if j not in C]
 def mat(x):
  A=A0.copy()
  for v,(i,j) in zip(x,pos):A[i,j]=v
  return A
 def fun(x):
  A=mat(x);P=A[np.ix_(R,C)]
  S=A[np.ix_(RR,CC)]-A[np.ix_(RR,C)]@np.linalg.inv(P)@A[np.ix_(R,CC)]
  return S.ravel()
 return pos,R,C,mat,fun

def section_vertices(B,tol=1e-7):
 vs=[]
 for C in itertools.combinations(range(6),4):
  M=B[:,C].T
  if abs(np.linalg.det(M))<1e-8:continue
  for signs in itertools.product((-1.,1.),repeat=4):
   lam=np.linalg.solve(M,np.array(signs));y=lam@B
   if np.max(np.abs(y))<=1+tol:
    if not any(np.max(np.abs(y-z))<1e-6 for z in vs):vs.append(y)
 return vs

def primal_extreme(B,j):
 # Is B[:,j] in convex hull of all other signed columns? LP weights >=0 sum 1.
 target=B[:,j]; pts=[]
 for k in range(6):
  if k==j:continue
  pts.append(B[:,k]);pts.append(-B[:,k])
 P=np.array(pts).T
 Aeq=np.vstack([P,np.ones(P.shape[1])]);beq=np.r_[target,1.]
 res=linprog(np.zeros(P.shape[1]),A_eq=Aeq,b_eq=beq,bounds=(0,None),method='highs')
 return not res.success

rng=np.random.default_rng(123)
for rec in meta:
 if rec['canonical_id'] not in ids:continue
 pos,R,C,mat,fun=setup(rec['rows']);best=None
 for z in range(30):
  x0=rng.uniform(-.7,.7,len(pos));res=least_squares(fun,x0,bounds=(-.999,.999),max_nfev=5000,ftol=1e-13,xtol=1e-13,gtol=1e-13)
  norm=np.max(np.abs(fun(res.x)))
  margin=1-np.max(np.abs(res.x))
  score=(norm,-margin)
  if best is None or score<best[0]:best=(score,res)
  if norm<1e-9 and margin>.02:break
 res=best[1];A=mat(res.x);B=A[R,:]
 sv=np.linalg.svd(A,compute_uv=False);sec=section_vertices(B)
 ext=[primal_extreme(B,j) for j in range(6)]
 print(rec['canonical_id'],'norm',np.max(np.abs(fun(res.x))),'margin',1-np.max(np.abs(res.x)),'rank_s',sv[:6],'section',len(sec),'primal_ext',ext,'x',np.round(res.x,4))
