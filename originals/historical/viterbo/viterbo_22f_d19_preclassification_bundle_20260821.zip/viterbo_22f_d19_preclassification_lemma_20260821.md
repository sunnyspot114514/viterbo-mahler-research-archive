# 12V/22F, c=0, D=19：预分类与 Survivor 768 结构排除

日期：2026-08-21

## 1. 层结构

这一层有 11 对 facets，defect profile 为

\[
3\text{ 条 single-defect rows}+8\text{ 条 double-defect rows}.
\]

将 5-vertex facets 三角化以后得到中心对称 simplicial 3-sphere

\[
f=(12,40,56,28),\qquad g_2=2.
\]

## 2. 无生成假设的直接枚举

固定一对 antipodal tetrahedra 后，精确回溯得到：

- 搜索节点：\(761,614\)；
- 闭合 pseudomanifolds：\(8,904\)；
- 通过完整 vertex-link sphere 检查：\(840\)；
- 模 \(B_6/\{\pm I\}\) 后：\(3\) 个球轨道，固定-facet 轨道大小 \(448,224,168\)。

选择三对相容 antipodal ridges 合并，得到：

- raw matchings：\(849\)；
- 球自同构群下的局部代表：\(103\)；
- 全局 signed-coordinate canonicalization 后：\(92\) 个 pairing templates。

## 3. Exact minor 分类

多仿射 \(5\times5\) minor 的 cube-corner 同号证书给出

\[
92=69\text{ 个 rank}\ge5+8\text{ 个重复 rows}+15\text{ 个 algebraic survivors}.
\]

## 4. Survivor 768 的严格 primal vertex loss

其 pairing sign template 为

```text
0 1 1 1 1 1
1 -1 -1 -1 0 0
1 -1 -1 1 0 0
1 -1 1 -1 0 0
1 -1 1 1 0 0
1 0 1 1 1 0
1 1 -1 -1 0 0
1 1 -1 1 0 0
1 1 0 1 1 1
1 1 1 -1 0 0
1 1 1 0 1 1
```

选择 rows \(R=(1,2,3,6)\)、columns \(C=(0,1,2,3)\)，恒有

\[
\det X_{R,C}=-8.
\]

rows \(0,8,10\) 在 primal columns \(1,4,5\) 上都取值 1。令

\[
H=X_{\{0,8,10\},C}X_{R,C}^{-1}.
\]

其 columns \(1,2,3\) 的 \(3\times3\) minor 为

\[
\det H_{[1,2,3]}
=-\frac{(x_{0,0}+1)(x_{10,3}-1)(x_{8,2}-1)}8.
\]

在 strict defect 域 \(-1<x_{0,0},x_{8,2},x_{10,3}<1\) 中，该式恒不为零，所以 \(\operatorname{rank}H=3\)。

对任何 rank \(\le4\) completion，三列 \(v_1,v_4,v_5\) 同时满足

\[
H_i v=1,\qquad i=1,2,3.
\]

三个独立仿射超平面在四维中的交是仿射直线，因此 \(v_1,v_4,v_5\) 共线。若三点不全相同，其中必有一点位于另外两点的线段上；若有点重合，则直接丢失 vertex-pair。因此 genuine primal 极点至多五对：

\[
\boxed{f_0(P)\le10}.
\]

所以 Survivor 768 不是 genuine 12V family。

## 5. 当前结论

\[
\boxed{
92=69\text{ rank}\ge5+8\text{ duplicate rows}+1\text{ primal vertex-loss}+14\text{ remaining}
}
\]

因此 \(D=19\) 尚未整层关闭，但已被压缩为 14 个 genuine 连续候选。数值严格样本显示它们均可保留 12 个 primal vertices 与 22 个 section vertices；正式关闭仍需 exact parameterization、section closure、volume formula 和 Mahler positivity certificates。
