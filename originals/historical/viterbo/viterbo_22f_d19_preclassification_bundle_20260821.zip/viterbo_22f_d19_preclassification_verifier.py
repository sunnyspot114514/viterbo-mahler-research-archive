#!/usr/bin/env python3
from __future__ import annotations
import json,itertools,sys
from pathlib import Path
import sympy as sp
CERT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('viterbo_22f_d19_preclassification_certificate.json')
d=json.loads(CERT.read_text())

def det_bareiss(mat):
    a=[list(map(int,r)) for r in mat];n=len(a);sgn=1;prev=1
    for k in range(n-1):
        p=next((i for i in range(k,n) if a[i][k]),None)
        if p is None:return 0
        if p!=k:a[k],a[p]=a[p],a[k];sgn=-sgn
        piv=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):a[i][j]=(a[i][j]*piv-a[i][k]*a[k][j])//prev
        prev=piv
        for i in range(k+1,n):a[i][k]=0
    return sgn*a[-1][-1]

def decode(k):return [[ord(k[6*i+j])-ord('1') for j in range(6)] for i in range(11)]
counts={'rank_ge_5':0,'duplicate_facet_rows':0,'algebraic_survivor':0}
for rec in d['records']:
    A=decode(rec['canonical_key'])
    zcounts=sorted(sum(x==0 for x in r) for r in A)
    assert zcounts==[1]*3+[2]*8
    counts[rec['status']]+=1
    if rec['status']=='duplicate_facet_rows':assert len({tuple(r) for r in A})<11
    elif rec['status']=='rank_ge_5':
        rs=rec['minor_rows'];cs=rec['minor_cols'];B0=[[A[i][j] for j in cs] for i in rs]
        loc=[(i,j) for i in range(5) for j in range(5) if B0[i][j]==0]
        assert len(loc)==rec['defect_entries_in_minor']
        vals=[]
        for mask in range(1<<len(loc)):
            B=[r[:] for r in B0]
            for k,(i,j) in enumerate(loc):B[i][j]=1 if (mask>>k)&1 else -1
            vals.append(det_bareiss(B))
        assert vals==rec['corner_dets']
        assert ((all(v>=0 for v in vals) and any(v>0 for v in vals)) or (all(v<=0 for v in vals) and any(v<0 for v in vals)))
assert counts==d['minor_classification']=={'rank_ge_5':69,'duplicate_facet_rows':8,'algebraic_survivor':15}
assert len(d['records'])==d['global_pairing_templates']==92
assert d['sphere_orbit_count']==3
assert sum(d['sphere_orbit_sizes_fixed_facet'])==d['fixed_facet_enumeration']['valid_spheres_fixed_facet']==840
assert sum(x['raw_matchings'] for x in d['ridge_merge']['per_sphere'])==d['ridge_merge']['raw_matchings']==849
assert sum(x['matching_orbits'] for x in d['ridge_merge']['per_sphere'])==d['ridge_merge']['local_matching_representatives']==103
# Exact structural exclusion of survivor 768.
s=d['survivor_768_detail'];rows=s['rows'];M=[];xs={}
for i,row in enumerate(rows):
    rr=[]
    for j,v in enumerate(row):
        if v==0:xs[(i,j)]=sp.symbols(f'x{i}_{j}');rr.append(xs[(i,j)])
        else:rr.append(sp.Integer(v))
    M.append(rr)
X=sp.Matrix(M);R=s['pivot_rows'];C=s['pivot_cols'];P=X.extract(R,C)
assert P.det()==s['pivot_determinant']==-8
I=s['equal_value_rows'];H=sp.simplify(X.extract(I,C)*P.inv())
minor=sp.factor(H[:,s['rank_minor_columns']].det())
expected=-(xs[(0,0)]+1)*(xs[(10,3)]-1)*(xs[(8,2)]-1)/8
assert sp.simplify(minor-expected)==0
for j in s['equal_value_columns']:
    assert [rows[i][j] for i in I]==[1,1,1]
# In the strict cube x00,x82,x103 are all in (-1,1), so the minor is nonzero.
# Hence H has rank 3. Rank<=4 then makes the three primal columns satisfy three
# independent affine equations H_i v=1, so they lie on a common affine line.
post=d['post_structural_classification']
assert post=={'rank_ge_5':69,'duplicate_facet_rows':8,'strict_primal_vertex_loss':1,'remaining_algebraic_survivors':14}
out={'status':'PASS','global_templates':92,'classification':counts,'sphere_orbits':3,'local_matching_representatives':103,'survivor_768':'strict primal vertex loss','remaining_survivors':14}
print(json.dumps(out,indent=2,sort_keys=True))
