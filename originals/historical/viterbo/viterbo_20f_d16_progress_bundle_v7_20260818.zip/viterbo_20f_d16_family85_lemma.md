# Family 85: exact closure and strict Mahler margin

**Scope.** Four-dimensional centrally symmetric Mahler problem, bounded-12 branch

\[
12V/20F,\qquad c=0,\qquad D=16.
\]

This note records a **computer-assisted analytic proof candidate** for survivor Family 85. It has not been externally peer reviewed.

## 1. Pairing family and strict domain

Let the four free defects be

\[
a=x_{3,0},\qquad b=x_{4,0},\qquad c=x_{5,0},\qquad t=x_{9,1}.
\]

Define

\[
A=\frac{1+a-b-c}{2},\qquad
B=\frac{1-a+b-c}{2},\qquad
C=\frac{1-a-b+c}{2},
\]

\[
D=\frac{1+a+b+c}{2}.
\]

On the strict component one has \(D<0\). Put

\[
E=-D>0.
\]

Then

\[
A-E>0,\qquad B-E>0,\qquad C-E>0,
\]

and

\[
(A-E)+(B-E)+(C-E)+2E=2.
\]

A rational bijection from the open unit four-cube is obtained by setting

\[
U=X,\qquad V=(1-X)Y,\qquad W=(1-X)(1-Y),
\]

\[
a=2(1-E)U-1,
\qquad b=2(1-E)V-1,
\qquad c=2(1-E)W-1,
\qquad t=2T-1,
\]

with

\[
0<E,T,X,Y<1.
\]

Equivalently,

\[
A=E+2(1-E)U,
\quad B=E+2(1-E)V,
\quad C=E+2(1-E)W.
\]

The exact verifier checks all sixteen defect inequalities \(|x_{ij}|<1\) on this domain. Thus the strict realization space is

\[
\boxed{\Delta_2^\circ\times(0,1)^2}.
\]

## 2. Rank-four normalization

The pivot rows are \(3,4,5,9\), the pivot columns are \(2,3,4,5\), and

\[
\det X[\{3,4,5,9\},\{2,3,4,5\}]=-16.
\]

After applying the induced \(GL(4)\) normalization, four primal columns become \(e_1,\dots,e_4\), while the other two are

\[
u=\left(\frac E2,\frac C2,\frac B2,-\frac A2\right),
\]

\[
v=\left(-\frac{1+T}{2},-\frac{1-T}{2},-\frac{1-T}{2},\frac{1-T}{2}\right).
\]

Hence

\[
P=\operatorname{conv}\{\pm e_1,\ldots,\pm e_4,\pm u,\pm v\}.
\]

Both additional vertex-pairs are genuine and all four coordinate facets of the polar remain nonredundant, so \(P\) has twelve vertices.

## 3. Exact cube-section closure

The polar has the normalized form

\[
P^\circ=[-1,1]^4\cap\{|u\cdot y|\le1\}\cap\{|v\cdot y|\le1\}.
\]

Both slab pairs truncate the same antipodal cube-vertex pair. Around

\[
s=(1,1,1,-1),
\]

use local corner coordinates

\[
z_i=\frac{1-s_i y_i}{2}.
\]

The two cap inequalities become

\[
z_0+\alpha_1z_1+\alpha_2z_2+\alpha_3z_3<1,
\]

\[
kz_0+z_1+z_2+z_3<1,
\]

where

\[
(\alpha_1,\alpha_2,\alpha_3)=\left(\frac CE,\frac BE,\frac AE\right),
\qquad
k=\frac{1+T}{1-T},
\]

and

\[
\alpha_i>1,\qquad k>1.
\]

Their boundary intersection has exactly three vertices. For \(i=1,2,3\),

\[
z_0=\frac{\alpha_i-1}{\alpha_i k-1},
\qquad
z_i=\frac{k-1}{\alpha_i k-1},
\qquad
z_j=0\ (j\ne0,i).
\]

These three points and their antipodes are exactly the six non-cube section vertices represented by pairing rows \(6,7,8\). Fourteen cube vertices survive. Therefore

\[
\boxed{f_0(P^\circ)=20}.
\]

No other active pattern can be a vertex: with one cap boundary active, the remaining axis intercepts violate the other kept inequality; with both boundaries active, two simultaneous nonzero coordinates among \(z_1,z_2,z_3\) are impossible because all \(\alpha_i>1\).

## 4. Exact primal volume

Using fixed-sign facet circuits for the ten positive facets gives

\[
\boxed{|P|=12-\frac43T(1-E)}.
\]

Every determinant sign is certified on the full open parameter cube.

## 5. Polar volume from overlapping simplex caps

After the change \(y_0=kz_0\), the overlap is a standard four-simplex sliced by an affine function whose vertex values are

\[
0,\quad \frac1k,\quad \alpha_1,\quad\alpha_2,\quad\alpha_3.
\]

The standard simplex-slice identity

\[
\operatorname{vol}\{x\in\Delta_4:\ell(x)\le t\}
=
\frac1{24}
\sum_i
\frac{(t-c_i)_+^4}{\prod_{j\ne i}(c_j-c_i)}
\]

leaves only the first two truncated-power terms.

Define

\[
L_A=A(1+T)-E(1-T),
\]

\[
L_B=B(1+T)-E(1-T),
\]

\[
L_C=C(1+T)-E(1-T).
\]

They satisfy

\[
L_A=2\bigl(ET+(1-E)U(1+T)\bigr)>0,
\]

and analogously for \(L_B,L_C\). After undoing the determinant-16 normalization,

\[
\boxed{
|P^\circ|
=
1-\frac{1-T}{12(1+T)}
-
\frac{4E^3T^4}{3(1+T)L_A L_B L_C}.
}
\]

This formula is global and does not rely on a fixed polar triangulation chamber.

## 6. Bernstein certificate for the Mahler margin

The exact margin is

\[
|P||P^\circ|-\frac{32}{3}
=
\frac{H(E,T,X,Y)}{\frac98 L_A L_B L_C}.
\]

The denominator is strictly positive. The numerator has tensor degree

\[
(4,4,3,2).
\]

Its 300 Bernstein coefficients satisfy

\[
\boxed{125>0,\qquad175=0,\qquad0<0},
\]

with minimum strictly positive coefficient

\[
\boxed{\frac1{24}}.
\]

Therefore

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

throughout the strict realization space.

## 7. Status

\[
\boxed{	ext{Family 85 closed as a computer-assisted analytic proof candidate.}}
\]

The accompanying verifier independently recomputes the rank completion, strict domain, section closure, primal and polar volumes, and all Bernstein coefficients.
