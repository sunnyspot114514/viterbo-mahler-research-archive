# 4D symmetric Mahler bounded-12 progress: Families 80 and 85

Date: 2026-08-18

## Executive status

In the layer

\[
12V/20F,\qquad c=0,\qquad D=16,
\]

two further algebraic survivors have been closed:

\[
\boxed{\text{Family 85}\ \checkmark},
\qquad
\boxed{\text{Family 80}\ \checkmark}.
\]

The running count is now

\[
\boxed{10/14\text{ continuous survivors closed}},
\]

with remaining indices

\[
\boxed{2,17,42,76}.
\]

Every checkmark denotes a **computer-assisted analytic proof candidate**, not an externally reviewed theorem.

---

## Family 85

### Domain

The complete strict realization space is

\[
\Delta_2^\circ\times(0,1)^2.
\]

A rational unit-cube parameterization uses \(0<E,T,X,Y<1\),

\[
U=X,\quad V=(1-X)Y,\quad W=(1-X)(1-Y),
\]

\[
a=2(1-E)U-1,\quad b=2(1-E)V-1,
\quad c=2(1-E)W-1,\quad t=2T-1.
\]

The rank pivot is \(-16\).

### Normalized geometry

After \(GL(4)\) normalization,

\[
u=\left(\frac E2,\frac C2,\frac B2,-\frac A2\right),
\]

\[
v=\left(-\frac{1+T}{2},-\frac{1-T}{2},-\frac{1-T}{2},\frac{1-T}{2}\right).
\]

Both slab pairs truncate the same antipodal cube-corner pair. Their boundary intersection has exactly three vertices per sign, giving

\[
14\text{ surviving cube vertices}+6\text{ intersection vertices}=20.
\]

Thus the family has exactly twenty facets and all twelve primal vertices remain extreme.

### Volumes and margin

\[
|P|=12-\frac43T(1-E).
\]

With

\[
L_A=A(1+T)-E(1-T),
\quad L_B=B(1+T)-E(1-T),
\quad L_C=C(1+T)-E(1-T),
\]

an exact simplex-slice computation gives

\[
|P^\circ|
=
1-\frac{1-T}{12(1+T)}
-
\frac{4E^3T^4}{3(1+T)L_A L_B L_C}.
\]

The Mahler-margin numerator has tensor degree \((4,4,3,2)\). Its 300 Bernstein coefficients satisfy

\[
125>0,\qquad175=0,\qquad0<0,
\]

with minimum positive coefficient \(1/24\). Therefore

\[
\boxed{|P||P^\circ|>32/3}.
\]

---

## Family 80

### Audit correction

A preliminary scratch formula suggested that one normalized column was a convex combination of cross-polytope vertices. Exact pivot reconstruction showed that this formula had been copied incorrectly. The corrected column is a genuine vertex. The earlier vertex-loss diagnosis is therefore withdrawn.

The corrected family can nevertheless be closed completely.

### Domain

Set

\[
p=2P-1,\quad q=2Q-1,\quad r=2R-1,\quad s=2S-1,
\qquad0<P,Q,R,S<1.
\]

The common denominator is

\[
8\Delta,
\qquad
\Delta=(1-R)(P+Q)+PQR>0.
\]

All sixteen defect inequalities have exact nonnegative Bernstein numerator certificates. Thus the full strict domain is the open unit four-cube.

The rank pivot is \(8\).

### Normalized geometry

\[
u=\frac1{R+S}(-S,-R,RS,RS),
\]

\[
v=\frac1\Delta
\bigl(-PQ,PQ(1-R),-P(1-R),-Q(1-R)\bigr).
\]

Their \(\ell_1\)-excesses are

\[
\|u\|_1-1=\frac{2RS}{R+S},
\qquad
\|v\|_1-1=\frac{2PQ(1-R)}\Delta.
\]

Both caps are at the limiting simplex condition. Same-sign caps have disjoint closures; opposite-sign caps meet only at one antipodal tangency pair. Exactly four cube vertices are removed and four non-cube antipodal pairs are created, so

\[
\boxed{f_0(P^\circ)=20}.
\]

All coordinate and slab facets are nonredundant, hence \(f_0(P)=12\).

### Volumes and margin

Let

\[
\begin{aligned}
N_P={}&PQ(R^2S+3R^2+3RS+R+S)\\
&+(P+Q)(1-R)(RS+4R+4S).
\end{aligned}
\]

Then

\[
|P|=\frac{4N_P}{3(R+S)\Delta}.
\]

The two antipodal cap-pair volumes add despite their zero-measure tangency, giving

\[
|P^\circ|=2-\frac{RS+PQ(1-R)}6.
\]

The exact Mahler margin is

\[
|P||P^\circ|-\frac{32}{3}
=
\frac{2H(P,Q,R,S)}{9(R+S)\Delta}.
\]

The polynomial \(H\) has tensor degree \((2,2,3,2)\). Its 108 Bernstein coefficients satisfy

\[
56>0,\qquad52=0,\qquad0<0,
\]

with minimum positive coefficient \(1/2\). Hence

\[
\boxed{|P||P^\circ|>32/3}.
\]

---

## Updated family table

\[
\begin{array}{c|c}
\text{Family}&\text{Status}\\
\hline
80,81,82,85,86,87,88,89,90,91&\checkmark\\
2,17,42,76&\text{remaining}
\end{array}
\]

Family 42 remains the only survivor without a completed rational parameterization. Families 2, 17, and 76 have exact rational rank-four descriptions.

## Next target

Family 76 is the next natural target. Its normalized form is again

\[
\operatorname{conv}\{\pm e_1,\ldots,\pm e_4,\pm u,\pm v\},
\]

and both additional columns define genuine cube-truncating slabs. The unfinished work is to obtain a complete rational description of its strict component and classify cap overlap/tangency before deriving a global polar-volume formula.

## Scope caveat

This closes two families inside the bounded-12, \(20F,D=16\) finite core. It does not by itself solve the full four-dimensional symmetric Mahler conjecture. A global complexity-independent reduction theorem is still required to bridge bounded-12 to arbitrary four-dimensional centrally symmetric convex bodies.
