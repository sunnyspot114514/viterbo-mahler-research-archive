# Family 80: exact closure and strict Mahler margin

**Scope.** Four-dimensional centrally symmetric Mahler problem, bounded-12 branch

\[
12V/20F,\qquad c=0,\qquad D=16.
\]

This note records a **computer-assisted analytic proof candidate** for survivor Family 80. It has not been externally peer reviewed.

## 1. Correction of the preliminary diagnosis

An early scratch calculation suggested that one normalized primal column was a strict convex combination of cross-polytope vertices. Reconstructing the exact pivot matrix showed that this formula had been transcribed incorrectly. The correct normalized column is outside the cross-polytope and is a genuine vertex.

The corrected family is nevertheless completely removable: it has an exact four-cube parameter domain, an exact twenty-vertex section, and a strictly positive Mahler margin.

## 2. Complete strict domain

Let the four free defects be

\[
p=x_{4,5},\qquad q=x_{5,4},\qquad r=x_{6,2},\qquad s=x_{9,3}.
\]

Set

\[
p=2P-1,\quad q=2Q-1,\quad r=2R-1,\quad s=2S-1,
\qquad0<P,Q,R,S<1.
\]

The common rank-completion denominator becomes

\[
8\Delta,
\qquad
\Delta=(1-R)(P+Q)+PQR>0.
\]

All sixteen quantities \(1-x_{ij}^2\) have nonnegative tensor-Bernstein numerator certificates with at least one positive coefficient. Their denominators are either \(1\), \((R+S)^2\), or \(\Delta^2\). Hence the strict realization space is exactly

\[
\boxed{(0,1)^4}.
\]

## 3. Rank-four normalization

Using pivot rows \(2,3,7,8\) and pivot columns \(2,3,4,5\),

\[
\det X[\{2,3,7,8\},\{2,3,4,5\}]=8.
\]

After normalization,

\[
P=\operatorname{conv}\{\pm e_1,\ldots,\pm e_4,\pm u,\pm v\},
\]

where

\[
u=rac1{R+S}(-S,-R,RS,RS),
\]

\[
v=rac1\Delta
\bigl(-PQ,\;PQ(1-R),\;-P(1-R),\;-Q(1-R)\bigr).
\]

Their \(\ell_1\)-excesses are

\[
\|u\|_1-1=\frac{2RS}{R+S}>0,
\]

\[
\|v\|_1-1=\frac{2PQ(1-R)}\Delta>0.
\]

Thus both extra slab inequalities of the polar are nonredundant. Every coordinate of \(u\) and \(v\) has absolute value below one, so the four coordinate facets remain nonredundant as well. Consequently all twelve primal vertices are genuine.

## 4. Exact section closure

The polar is

\[
P^\circ=[-1,1]^4\cap\{|u\cdot y|\le1\}\cap\{|v\cdot y|\le1\}.
\]

The \(u\)-cap pair is centered at

\[
s_u=(-1,-1,1,1),
\]

and, in local cube coordinates, has equation

\[
\frac{z_0}{R}+\frac{z_1}{S}+z_2+z_3<1.
\]

It creates the two non-cube vertices

\[
(r,-1,1,1),
\qquad
(-1,s,1,1)
\]

and their antipodes.

The \(v\)-cap pair is centered at

\[
s_v=(-1,1,-1,-1)
\]

and has equation

\[
\frac{z_0}{1-R}+z_1+\frac{z_2}{Q}+\frac{z_3}{P}<1.
\]

It creates

\[
(-r,1,-1,-1),
\quad
(-1,1,q,-1),
\quad
(-1,1,-1,p)
\]

and their antipodes. The first of these is the antipode of \((r,-1,1,1)\), so there are four non-cube antipodal pairs in total.

Exactly four cube vertices, \(\pm s_u,\pm s_v\), are removed. Hence

\[
16-4+8=20
\]

section vertices remain.

The cap interaction is global and exact:

- same-sign cap closures are disjoint; the \(u\)-cap forces \(y_2+y_3\ge0\), while the \(v\)-cap forces \(y_2+y_3<0\);
- opposite-sign cap closures meet only at \((r,-1,1,1)\) and its antipode. In common local coordinates, one cap forces \(z_0\le R\), the other \(z_0\ge R\), and equality forces \(z_1=z_2=z_3=0\).

Therefore

\[
\boxed{f_0(P^\circ)=20}.
\]

## 5. Exact primal volume

Define

\[
\Delta=(1-R)(P+Q)+PQR.
\]

Fixed-sign circuit determinants for the ten positive facets give

\[
\boxed{
|P|=
\frac{4N_P}{3(R+S)\Delta},
}
\]

where

\[
\begin{aligned}
N_P={}&PQ(R^2S+3R^2+3RS+R+S)\\
&+(P+Q)(1-R)(RS+4R+4S).
\end{aligned}
\]

For every circuit determinant, multiplication by the positive factor \((R+S)\Delta\) yields a polynomial with a nonnegative Bernstein certificate and at least one positive coefficient. Thus the displayed absolute-value choices are valid throughout the whole parameter cube.

## 6. Exact polar volume

For the \(u\)-slab,

\[
h_u=\|u\|_1-1=\frac{2RS}{R+S},
\]

and the minimum coordinate magnitude is \(RS/(R+S)\). Hence the pair is at the limiting simplex-cap condition \(h_u=2\min|u_i|\). Its total cap volume in the normalized cube is

\[
C_u=\frac{h_u^4}{12\prod_i|u_i|}=\frac{4RS}{3}.
\]

Likewise,

\[
h_v=\frac{2PQ(1-R)}\Delta,
\]

and

\[
C_v=\frac{4PQ(1-R)}3.
\]

The two cap pairs have disjoint interiors and only the tangency pair described above, so their four-dimensional volumes add. Undoing the determinant-8 normalization gives

\[
\boxed{
|P^\circ|
=2-\frac{RS+PQ(1-R)}6.
}
\]

## 7. Bernstein certificate for the Mahler margin

The exact margin takes the form

\[
|P||P^\circ|-\frac{32}{3}
=
\frac{2H(P,Q,R,S)}{9(R+S)\Delta}.
\]

The denominator is strictly positive. The polynomial \(H\) has tensor degree

\[
(2,2,3,2).
\]

Its 108 Bernstein coefficients satisfy

\[
\boxed{56>0,\qquad52=0,\qquad0<0},
\]

with minimum strictly positive coefficient

\[
\boxed{\frac12}.
\]

Therefore

\[
\boxed{|P||P^\circ|>\frac{32}{3}}
\]

on the entire strict realization space.

## 8. Status

\[
\boxed{\text{Family 80 closed as a computer-assisted analytic proof candidate.}}
\]

The accompanying verifier independently recomputes the rank completion, sixteen strict defect certificates, section closure, facet-circuit signs, both volumes, and the complete Bernstein table.
