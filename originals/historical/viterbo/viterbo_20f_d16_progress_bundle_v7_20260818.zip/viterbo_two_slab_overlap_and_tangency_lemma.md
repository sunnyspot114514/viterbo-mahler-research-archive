# Two-slab cube caps: disjointness, tangency, and overlap formulas in dimension four

This note records the geometric identities used to close Families 80 and 85 in the bounded-12 four-dimensional symmetric Mahler calculation.

## 1. Corner coordinates and simplex caps

Let

\[
Q=[-1,1]^4\cap\{|u\cdot y|\le1\}\cap\{|v\cdot y|\le1\}.
\]

Fix a cube vertex \(s\in\{\pm1\}^4\), and assume \(u_i s_i=|u_i|\). Put

\[
z_i=\frac{1-s_i y_i}{2}\in[0,1].
\]

Then

\[
u\cdot y=\|u\|_1-2\sum_i|u_i|z_i.
\]

If

\[
h_u=\|u\|_1-1>0,
\]

the deleted corner cap is

\[
\sum_i \frac{2|u_i|}{h_u}z_i<1.
\]

When

\[
h_u\le2\min_i|u_i|,
\]

this cap is a four-simplex, possibly with some intercepts exactly equal to one. The total volume of the antipodal cap pair is

\[
\boxed{
C_u=\frac{h_u^4}{12\prod_i|u_i|}.
}
\]

The formula remains valid at the limiting case \(h_u=2\min_i|u_i|\), where a cap boundary passes through one or more neighboring cube vertices.

## 2. Support-function test for cap intersections

The support function of the cube is

\[
h_{[-1,1]^4}(w)=\|w\|_1.
\]

Suppose two strict cap interiors satisfy

\[
u\cdot y>1,
\qquad
\varepsilon v\cdot y>1,
\qquad \varepsilon\in\{\pm1\}.
\]

For any \(\lambda,\mu>0\), this implies

\[
(\lambda u+\varepsilon\mu v)\cdot y>\lambda+\mu.
\]

Hence the two cap interiors are disjoint whenever

\[
\boxed{
\lambda+\mu\ge\|\lambda u+\varepsilon\mu v\|_1.
}
\]

- strict inequality gives disjoint closures;
- equality gives no interior overlap and confines any closure intersection to the exposed cube face of \(\lambda u+\varepsilon\\mu v\).

This is the mechanism behind the antipodal tangency pairs in Families 80 and 86.

## 3. Exact overlap of two simplex caps at the same corner

Assume two caps share the same corner and, after coordinate scaling, are

\[
z_0+\alpha_1z_1+\alpha_2z_2+\alpha_3z_3<1,
\]

\[
kz_0+z_1+z_2+z_3<1,
\]

with

\[
\alpha_i>1,
\qquad k>1.
\]

After setting \(y_0=kz_0\), the overlap becomes a standard four-simplex sliced by an affine function whose vertex values are

\[
0,\quad\frac1k,\quad\alpha_1,\quad\alpha_2,\quad\alpha_3.
\]

For an affine function \(\ell\) with pairwise distinct vertex values \(c_i\) on the standard \(d\)-simplex,

\[
\operatorname{vol}\{x\in\Delta_d:\ell(x)\le t\}
=
\frac1{d!}
\sum_i
\frac{(t-c_i)_+^d}{\prod_{j\ne i}(c_j-c_i)}.
\]

The identity extends continuously when values collide. In the four-dimensional cap configuration above, only the terms for \(0\) and \(1/k\) survive at threshold \(t=1\). This yields a global rational overlap formula and avoids any polar triangulation chamber analysis.

## 4. Section-vertex classification in the same-corner case

The two cap boundaries intersect in exactly three vertices. For \(i=1,2,3\),

\[
z_0=\frac{\alpha_i-1}{\alpha_i k-1},
\qquad
z_i=\frac{k-1}{\alpha_i k-1},
\qquad
z_j=0\quad(j\ne0,i).
\]

No boundary vertex can have two distinct nonzero coordinates among \(z_1,z_2,z_3\), since subtracting the two active equations would contradict \(\alpha_i,\alpha_j>1\). This gives an exact closure count without enumerating all 240 active charts.

## 5. Applications

- **Family 85:** two simplex-cap pairs overlap at the same antipodal corner pair. The simplex-slice formula gives a global polar-volume expression and exactly three new intersection vertices per sign.
- **Family 80:** the two limiting simplex-cap pairs have disjoint interiors and one antipodal tangency pair. Cap volumes add, and the tangency point is already one of the prescribed section vertices.

These mechanisms are candidates for reuse on the remaining rational survivors of the \(12V/20F, D=16\) layer.
