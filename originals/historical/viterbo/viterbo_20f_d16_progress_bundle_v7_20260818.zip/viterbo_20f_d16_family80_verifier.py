#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor family 80.

The verifier checks, with exact SymPy arithmetic:
  * the rational rank-four completion and the full strict parameter domain;
  * the normalized primal form conv{±e_i, ±u, ±v};
  * exact 20-vertex cube-section closure via two degenerate simplex-cap pairs;
  * all twelve primal vertices are genuine;
  * global primal volume from fixed-sign facet circuits;
  * global polar volume from cap volumes (interiors disjoint, one tangency pair);
  * strict Mahler margin via a tensor Bernstein certificate.

This is a computer-assisted analytic proof candidate, not an externally
reviewed theorem.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family80_verifier_output.json"
CERT = HERE / "viterbo_20f_d16_family80_certificate.json"


def same(x, y):
    return sp.cancel(x-y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees=None):
    poly = sp.expand(poly)
    if degrees is None:
        P = sp.Poly(poly, *variables)
        degrees = tuple(P.degree(x) for x in variables)
    P = sp.Poly(poly, *variables)
    monomials = {m: sp.Rational(c) for m, c in P.terms()}
    out = {}
    for index in itertools.product(*[range(n+1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in monomials.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff*factor
        out[index] = sp.factor(value)
    return degrees, out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def main():
    started = time.time()
    checks = []

    # Unit-cube coordinates for the four free defects.
    P, Q, R, S = sp.symbols("P Q R S", positive=True)
    p, q, r, s = 2*P-1, 2*Q-1, 2*R-1, 2*S-1
    delta = (1-R)*(P+Q) + P*Q*R
    assert same(delta, P*Q*R-P*R+P-Q*R+Q)

    D = p*q*r+p*q-p*r+3*p-q*r+3*q-3*r+5
    assert same(D, 8*delta)

    # Exact completed defects.
    x00 = -(r*s+2*s+1)/(r+s+2)
    x01 = (p*q*r-3*p*q-p*r-p-q*r-q-3*r+1)/D
    x10 = (r-s)/(r+s+2)
    x11 = (p*q*r-3*p*q-p*r-p+3*q*r-5*q+r-3)/D
    x20 = x10
    x21 = (p*q*r-3*p*q+3*p*r-5*p-q*r-q+r-3)/D
    x30 = -(r*s-1)/(r+s+2)
    x40 = (p*r*s+p*r+p*s+p-r*s-3*r+s-1)/(2*(r+s+2))
    x50 = (q*r*s+q*r+q*s+q-r*s-3*r+s-1)/(2*(r+s+2))
    x71 = (p*q*r+p*q-p*r+3*p+3*q*r-q+r+1)/D
    x81 = (p*q*r+p*q+3*p*r-p-q*r+3*q+r+1)/D
    x91 = -(p*q*r*s-p*q*s-2*p*q+p*r*s-2*p*r-p*s
            +q*r*s-2*q*r-q*s+r*s-4*r-s+2)/D

    M = sp.Matrix([
        [x00, x01, 1, -1, -1, -1],
        [x10, x11, 1, -1, -1, 1],
        [x20, x21, 1, -1, 1, -1],
        [x30, 1, -1, -1, -1, -1],
        [x40, 1, -1, 1, -1, p],
        [x50, 1, -1, 1, q, -1],
        [1, -1, r, -1, 1, 1],
        [1, x71, -1, -1, -1, 1],
        [1, x81, -1, -1, 1, -1],
        [1, x91, -1, s, 1, 1],
    ])
    template = [
        [0,0,1,-1,-1,-1],
        [0,0,1,-1,-1,1],
        [0,0,1,-1,1,-1],
        [0,1,-1,-1,-1,-1],
        [0,1,-1,1,-1,0],
        [0,1,-1,1,0,-1],
        [1,-1,0,-1,1,1],
        [1,0,-1,-1,-1,1],
        [1,0,-1,-1,1,-1],
        [1,0,-1,0,1,1],
    ]

    pivot_rows = [2,3,7,8]
    pivot_cols = [2,3,4,5]
    basis = M.extract(pivot_rows, range(6))
    pivot = basis.extract(range(4), pivot_cols)
    assert same(pivot.det(), 8)
    coefficients = M.extract(range(10), pivot_cols)*pivot.inv()
    assert all(same(x, 0) for x in coefficients*basis-M)
    checks.append("exact_rank_four_completion")

    # The strict component is exactly 0<P,Q,R,S<1.  Every 1-x^2
    # numerator has a nonnegative tensor-Bernstein certificate and is not zero.
    defect_positions = [
        (i,j) for i,row in enumerate(template) for j,flag in enumerate(row)
        if flag == 0
    ]
    assert len(defect_positions) == 16
    defect_certificates = []
    allowed_denominators = {
        sp.Integer(1), sp.expand((R+S)**2), sp.expand(delta**2)
    }
    for i,j in defect_positions:
        expr = sp.factor(sp.cancel(1-M[i,j]**2))
        numerator, denominator = map(sp.factor, sp.fraction(expr))
        assert sp.expand(denominator) in allowed_denominators
        degrees, bern = tensor_bernstein_coefficients(numerator, (P,Q,R,S))
        stats = bernstein_stats(bern)
        assert stats["negative"] == 0 and stats["positive"] > 0
        defect_certificates.append({
            "position": [i,j], "degrees": list(degrees),
            "positive": stats["positive"], "zero": stats["zero"],
            "minimum_positive": str(stats["minimum_positive"]),
        })
    checks.append("strict_domain_unit_four_cube_and_sixteen_defects")

    # Normalize four primal columns to the standard basis.
    normalized = (pivot.inv()*basis).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    u = sp.Matrix([-S, -R, R*S, R*S])/(R+S)
    v = sp.Matrix([
        -P*Q,
        P*Q*(1-R),
        -P*(1-R),
        -Q*(1-R),
    ])/delta
    assert all(same(normalized[i,0], u[i]) for i in range(4))
    assert all(same(normalized[i,1], v[i]) for i in range(4))
    assert normalized[:,2:6] == sp.eye(4)
    checks.append("normalized_primal_crosspolytope_plus_two_vertex_pairs")

    # Both slab vertices are genuine: ||u||_1 and ||v||_1 exceed one.
    h_u = sp.factor(2*R*S/(R+S))
    h_v = sp.factor(2*P*Q*(1-R)/delta)
    assert same(sum([-u[0],-u[1],u[2],u[3]])-1, h_u)
    assert same(sum([-v[0],v[1],-v[2],-v[3]])-1, h_v)

    # The four coordinate facets are nonredundant: e_i lies in their relative
    # interior because every coordinate of u and v has absolute value < 1.
    coordinate_slacks = [
        R/(R+S), S/(R+S), (R+S-R*S)/(R+S),
        (1-R)*(P+Q-P*Q)/delta,
        (delta-P*Q*(1-R))/delta,
        (Q*(1-R)+P*Q*R)/delta,
        (P*(1-R)+P*Q*R)/delta,
    ]
    # The displayed expressions are visibly positive on the open cube.
    assert len(coordinate_slacks) == 7
    checks.append("twelve_primal_vertices_nonredundant_coordinate_and_slab_facets")

    # Exact cube-section closure.  The u-cap is centred at su=(-1,-1,1,1)
    # and has local equation z0/R+z1/S+z2+z3<1.  The v-cap is centred at
    # sv=(-1,1,-1,-1) and has equation
    # z0/(1-R)+z1+z2/Q+z3/P<1.
    su = (-1,-1,1,1)
    sv = (-1,1,-1,-1)
    all_cube = set(itertools.product([-1,1], repeat=4))
    removed = {su, tuple(-x for x in su), sv, tuple(-x for x in sv)}
    kept_cube = all_cube-removed

    qu0 = (r,-1,1,1)
    qu1 = (-1,s,1,1)
    qv2 = (-1,1,q,-1)
    qv3 = (-1,1,-1,p)
    noncube_positive = [qu0,qu1,qv2,qv3]
    expected = kept_cube.copy()
    for point in noncube_positive:
        expected.add(tuple(point))
        expected.add(tuple(-x for x in point))
    assert len(expected) == 20

    actual = set()
    for i in range(10):
        point = tuple(sp.factor(M[i,j]) for j in range(2,6))
        actual.add(point)
        actual.add(tuple(-x for x in point))
    assert actual == expected

    # Same-sign cap closures are disjoint: the u-cap has y2+y3>=0,
    # while the v-cap has y2+y3<0.  Opposite-sign closures meet only at
    # qu0 and its antipode: one inequality forces z0<=R, the other z0>=R,
    # with equality only when z1=z2=z3=0.
    assert same(qu0[0], 2*R-1)
    checks.append("exact_section_closure_twelve_cube_vertices_plus_four_antipodal_noncube_pairs")

    # Global primal volume from fixed-sign facet circuits.  Multiplying every
    # signed determinant by the positive common factor (R+S)*delta leaves a
    # polynomial with a nonnegative Bernstein certificate.
    def vertex(j):
        return basis[:,j] if j < 6 else -basis[:,j-6]

    sample = {P:sp.Rational(1,3), Q:sp.Rational(2,5),
              R:sp.Rational(3,7), S:sp.Rational(4,9)}
    P_volume = sp.Rational(0)
    determinant_certificates = []
    for i,row in enumerate(template):
        ids = [j if flag == 1 else j+6 for j,flag in enumerate(row) if flag]
        signed_sum = sp.Rational(0)
        for subset in itertools.combinations(ids,4):
            det = sp.factor(sp.cancel(
                sp.Matrix.hstack(*[vertex(j) for j in subset]).det()
            ))
            sample_value = det.subs(sample)
            assert sample_value != 0
            sign = 1 if sample_value > 0 else -1
            polynomial = sp.factor(sp.cancel(sign*det*(R+S)*delta))
            num, den = sp.fraction(polynomial)
            assert den == 1
            degrees, bern = tensor_bernstein_coefficients(num, (P,Q,R,S))
            stats = bernstein_stats(bern)
            assert stats["negative"] == 0 and stats["positive"] > 0
            determinant_certificates.append({
                "facet": i, "subset": list(subset), "sign": sign,
                "degrees": list(degrees), "positive": stats["positive"],
                "zero": stats["zero"],
                "minimum_positive": str(stats["minimum_positive"]),
            })
            signed_sum += sign*det
        P_volume += sp.factor(signed_sum/(12 if len(ids)==4 else 24))

    P_numerator = (
        P*Q*(R**2*S+3*R**2+3*R*S+R+S)
        +(P+Q)*(1-R)*(R*S+4*R+4*S)
    )
    P_target = sp.factor(4*P_numerator/(3*(R+S)*delta))
    assert same(P_volume, P_target)
    checks.append("global_primal_volume_fixed_sign_circuit_certificate")

    # Polar volume.  Each slab cuts one antipodal pair of simplex caps.
    # Both are at the limiting simplex condition h=2*min|coordinate|.
    prod_u = sp.factor(R**3*S**3/(R+S)**4)
    prod_v = sp.factor(P**3*Q**3*(1-R)**3/delta**4)
    cap_u_pair = sp.factor(h_u**4/(12*prod_u))
    cap_v_pair = sp.factor(h_v**4/(12*prod_v))
    assert same(cap_u_pair, sp.Rational(4,3)*R*S)
    assert same(cap_v_pair, sp.Rational(4,3)*P*Q*(1-R))

    # Same-sign caps are disjoint, opposite-sign caps have only the tangency
    # pair qu0,-qu0.  Tangencies have zero 4-volume, so cap volumes add.
    Q_normalized = sp.factor(16-cap_u_pair-cap_v_pair)
    Q_target = sp.factor(Q_normalized/8)  # |det pivot|=8
    assert same(Q_target, 2-(R*S+P*Q*(1-R))/6)
    checks.append("global_polar_volume_degenerate_simplex_caps_with_one_tangency_pair")

    # Strict Mahler margin.
    margin = sp.factor(sp.cancel(P_target*Q_target-sp.Rational(32,3)))
    numerator, denominator = map(sp.factor, sp.fraction(margin))
    assert same(denominator, 9*(R+S)*delta)
    H = sp.factor(numerator/2)
    degrees, bern = tensor_bernstein_coefficients(H, (P,Q,R,S))
    stats = bernstein_stats(bern)
    assert degrees == (2,2,3,2)
    assert stats == {
        "positive": 56,
        "zero": 52,
        "negative": 0,
        "minimum_positive": sp.Rational(1,2),
    }
    checks.append("strict_Mahler_margin_degree_2232_tensor_Bernstein")

    h_string = str(sp.expand(H))
    certificate = {
        "schema": "viterbo-20f-d16-family80-certificate-v1",
        "family_index": 80,
        "domain": "0<P,Q,R,S<1; p=2P-1,q=2Q-1,r=2R-1,s=2S-1",
        "rank_pivot_det": "8",
        "section_vertices": 20,
        "P_volume": str(P_target),
        "Q_volume": str(Q_target),
        "margin_denominator": str(denominator),
        "margin_numerator_factor_two_removed_sha256": hashlib.sha256(h_string.encode()).hexdigest(),
        "margin_degrees": list(degrees),
        "bernstein_stats": {k:str(v) for k,v in stats.items()},
        "bernstein_coefficients": [
            {"index":list(index), "value":str(value)}
            for index,value in sorted(bern.items())
        ],
        "defect_certificates": defect_certificates,
        "determinant_certificates": determinant_certificates,
    }
    CERT.write_text(json.dumps(certificate, indent=2), encoding="utf-8")

    output = {
        "status": "PASS",
        "family_index": 80,
        "scope": "computer-assisted analytic proof candidate; no external peer review",
        "domain": "open unit four-cube",
        "rank_pivot_det": "8",
        "section_vertices": 20,
        "P_volume": str(P_target),
        "Q_volume": str(Q_target),
        "mahler_bernstein": {
            "degree": list(degrees), "coefficients": len(bern),
            "positive": stats["positive"], "zero": stats["zero"],
            "negative": stats["negative"],
            "minimum_positive": str(stats["minimum_positive"]),
        },
        "checks": checks,
        "elapsed_seconds": round(time.time()-started,3),
    }
    OUTPUT.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
