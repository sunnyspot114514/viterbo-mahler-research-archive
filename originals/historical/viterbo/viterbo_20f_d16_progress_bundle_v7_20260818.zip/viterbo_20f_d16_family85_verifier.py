#!/usr/bin/env python3
"""Exact verifier for bounded-12 4D symmetric Mahler survivor family 85.

Checks, using exact SymPy arithmetic:
  * rational rank-four completion;
  * exact strict-domain parametrization Delta_2^o x (0,1)^2;
  * exact 20-vertex cube-section closure for two overlapping slab caps;
  * all twelve primal vertices are genuine;
  * global primal volume by fixed-sign facet circuits;
  * global polar volume by an exact standard-simplex slice formula;
  * strict Mahler margin by a tensor Bernstein certificate.

This is a computer-assisted analytic proof candidate, not an externally
reviewed theorem.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import time
from pathlib import Path

import sympy as sp

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "viterbo_20f_d16_family85_verifier_output.json"
CERT = HERE / "viterbo_20f_d16_family85_certificate.json"


def same(x, y):
    return sp.cancel(x - y) == 0


def tensor_bernstein_coefficients(poly, variables, degrees):
    P = sp.Poly(sp.expand(poly), *variables)
    monomials = {m: sp.Rational(c) for m, c in P.terms()}
    out = {}
    for index in itertools.product(*[range(n + 1) for n in degrees]):
        value = sp.Rational(0)
        for powers, coeff in monomials.items():
            if all(k <= i for k, i in zip(powers, index)):
                factor = sp.Rational(1)
                for i, k, n in zip(index, powers, degrees):
                    factor *= sp.Rational(sp.binomial(i, k), sp.binomial(n, k))
                value += coeff * factor
        out[index] = sp.factor(value)
    return out


def bernstein_stats(coefficients):
    values = list(coefficients.values())
    positives = [x for x in values if bool(x > 0)]
    return {
        "positive": len(positives),
        "zero": sum(int(bool(x == 0)) for x in values),
        "negative": sum(int(bool(x < 0)) for x in values),
        "minimum_positive": min(positives) if positives else None,
    }


def main():
    started = time.time()
    checks = []

    # Original variables and the exact Delta_2 x square coordinates.
    a, b, c, t = sp.symbols("a b c t", real=True)
    E, T, X, Y = sp.symbols("E T X Y", positive=True)
    U = X
    V = (1 - X) * Y
    W = (1 - X) * (1 - Y)
    assert same(U + V + W, 1)

    A = E + 2 * (1 - E) * U
    B = E + 2 * (1 - E) * V
    C = E + 2 * (1 - E) * W
    domain_sub = {
        a: 2 * (1 - E) * U - 1,
        b: 2 * (1 - E) * V - 1,
        c: 2 * (1 - E) * W - 1,
        t: 2 * T - 1,
    }

    # Exact completed pairing matrix.
    x00 = (a - b - c - 1) / 2
    x01 = -(t + 1) / 2
    x10 = -(a - b + c + 1) / 2
    x11 = x01
    x20 = -(a + b - c + 1) / 2
    x21 = x01
    x62 = (a*t + a + b*t + b - 2*c*t - 2*t) / (a*t + a + b*t + b - 2*c - 2)
    x63 = -(a*t + a + b*t + b + 2*c*t + 4*c + 2*t + 4) / (a*t + a + b*t + b - 2*c - 2)
    x72 = (a*t + a - 2*b*t + c*t + c - 2*t) / (a*t + a - 2*b + c*t + c - 2)
    x74 = -(a*t + a + 2*b*t + 4*b + c*t + c + 2*t + 4) / (a*t + a - 2*b + c*t + c - 2)
    x82 = (2*a*t - b*t - b - c*t - c + 2*t) / (2*a - b*t - b - c*t - c + 2)
    x85 = -(2*a*t + 4*a + b*t + b + c*t + c + 2*t + 4) / (2*a - b*t - b - c*t - c + 2)

    M = sp.Matrix([
        [x00, x01, 1, -1, -1, -1],
        [x10, x11, 1, -1, 1, 1],
        [x20, x21, 1, 1, -1, 1],
        [a, 1, -1, -1, -1, -1],
        [b, 1, -1, -1, 1, 1],
        [c, 1, -1, 1, -1, 1],
        [1, -1, x62, x63, 1, -1],
        [1, -1, x72, 1, x74, -1],
        [1, -1, x82, 1, 1, x85],
        [1, t, -1, 1, 1, -1],
    ])
    template = [
        [0, 0, 1, -1, -1, -1],
        [0, 0, 1, -1, 1, 1],
        [0, 0, 1, 1, -1, 1],
        [0, 1, -1, -1, -1, -1],
        [0, 1, -1, -1, 1, 1],
        [0, 1, -1, 1, -1, 1],
        [1, -1, 0, 0, 1, -1],
        [1, -1, 0, 1, 0, -1],
        [1, -1, 0, 1, 1, 0],
        [1, 0, -1, 1, 1, -1],
    ]

    pivot_rows = [3, 4, 5, 9]
    pivot_cols = [2, 3, 4, 5]
    basis = M.extract(pivot_rows, range(6))
    pivot = basis.extract(range(4), pivot_cols)
    assert same(pivot.det(), -16)
    coefficients = M.extract(range(10), pivot_cols) * pivot.inv()
    assert all(same(x, 0) for x in coefficients * basis - M)
    checks.append("exact_rank_four_completion")

    # Inverse affine coordinates.  The strict component is exactly
    # E,T,X,Y in (0,1), equivalently alpha,beta,gamma,E>0 with
    # alpha+beta+gamma+2E=2.
    Ainv = (1 + a - b - c) / 2
    Binv = (1 - a + b - c) / 2
    Cinv = (1 - a - b + c) / 2
    Dinv = (1 + a + b + c) / 2
    assert same(Ainv.subs(domain_sub), A)
    assert same(Binv.subs(domain_sub), B)
    assert same(Cinv.subs(domain_sub), C)
    assert same(Dinv.subs(domain_sub), -E)
    assert same(A + B + C, 2 + E)

    Mc = M.subs(domain_sub).applyfunc(lambda x: sp.factor(sp.cancel(x)))
    defect_positions = [
        (i, j) for i, row in enumerate(template) for j, flag in enumerate(row)
        if flag == 0
    ]
    assert len(defect_positions) == 16

    d6 = E*T + W*(1-E)*(1+T)
    d7 = E*T*(1-V) + V*(1+T-E)
    d8 = E*T*(1-U) + U*(1+T-E)
    A1 = A
    B1 = B
    C1 = C

    # Simple defect forms.
    expected_simple = {
        (0, 0): (1-E)*(2*U-1),
        (0, 1): -T,
        (1, 0): (1-E)*(2*V-1),
        (1, 1): -T,
        (2, 0): -(1-E)*(1-2*W),
        (2, 1): -T,
        (3, 0): 2*(1-E)*U-1,
        (4, 0): 2*(1-E)*V-1,
        (5, 0): 2*(1-E)*W-1,
        (9, 1): 2*T-1,
    }
    for ij, value in expected_simple.items():
        assert same(Mc[ij], value)

    expected_one_minus_square = {
        (6, 2): 4*T*(1-E)*(1-T)*W*C1/d6**2,
        (6, 3): 4*E*T*(1-E)*(1+T)*W/d6**2,
        (7, 2): 4*T*V*(1-E)*(1-T)*B1/d7**2,
        (7, 4): 4*E*T*V*(1-E)*(1+T)/d7**2,
        (8, 2): 4*T*U*(1-E)*(1-T)*A1/d8**2,
        (8, 5): 4*E*T*U*(1-E)*(1+T)/d8**2,
    }
    for ij, expected in expected_one_minus_square.items():
        assert same(sp.factor(sp.cancel(1-Mc[ij]**2)), expected)
    assert same(d6, E*T + W*(1-E)*(1+T))
    assert same(d7, E*T*(1-V) + V*(1+T-E))
    assert same(d8, E*T*(1-U) + U*(1+T-E))
    checks.append("strict_domain_Delta2_times_square_and_sixteen_defects")

    # Normalize four primal columns to the standard basis.
    normalized = (pivot.inv() * basis).subs(domain_sub).applyfunc(
        lambda x: sp.factor(sp.cancel(x))
    )
    u = sp.Matrix([E/2, C/2, B/2, -A/2])
    v = sp.Matrix([-(T+1)/2, -(1-T)/2, -(1-T)/2, (1-T)/2])
    assert all(same(normalized[i, 0], u[i]) for i in range(4))
    assert all(same(normalized[i, 1], v[i]) for i in range(4))
    assert normalized[:, 2:6] == sp.eye(4)
    checks.append("normalized_primal_is_crosspolytope_plus_two_vertex_pairs")

    # The two caps are centred at the same antipodal cube-vertex pair.
    # Local coordinates around s=(1,1,1,-1) give two simplex inequalities
    # z0 + alpha_i zi < 1 and k z0 + z1+z2+z3 < 1.
    svec = sp.Matrix([1, 1, 1, -1])
    alphas = [C/E, B/E, A/E]
    k = (1+T)/(1-T)
    l1_u = E/2 + C/2 + B/2 + A/2
    l1_v = (T+1)/2 + 3*(1-T)/2
    assert same(l1_u, 1+E)
    assert same(l1_v, 2-T)

    q_points = []
    for idx, alpha in enumerate(alphas, start=1):
        z = sp.zeros(4, 1)
        z[0] = (alpha-1)/(alpha*k-1)
        z[idx] = (k-1)/(alpha*k-1)
        y = sp.Matrix([svec[i]*(1-2*z[i]) for i in range(4)])
        q_points.append(y.applyfunc(lambda x: sp.factor(sp.cancel(x))))

    for row_index, q in zip([6, 7, 8], q_points):
        actual = sp.Matrix([Mc[row_index, j] for j in range(2, 6)])
        assert all(same(actual[i], q[i]) for i in range(4))
        assert same(u.dot(q), 1)
        assert same(v.dot(q), -1)

    cube_rows = [0, 1, 2, 3, 4, 5, 9]
    positive_cube = {
        tuple(int(Mc[i, j]) for j in range(2, 6)) for i in cube_rows
    }
    all_kept_cube = positive_cube | {tuple(-x for x in p) for p in positive_cube}
    all_cube = set(itertools.product([-1, 1], repeat=4))
    s_tuple = (1, 1, 1, -1)
    assert all_kept_cube == all_cube - {s_tuple, tuple(-x for x in s_tuple)}
    assert 14 + 2*len(q_points) == 20
    checks.append("exact_section_closure_fourteen_cube_vertices_plus_three_antipodal_double_plane_pairs")

    # Both extra slab facets are nonredundant.  On the u-boundary, p0 has
    # the other affine form strictly outside its cap; on the v-boundary,
    # each pi has the u-form strictly outside its cap.  Only +/-s are removed,
    # so all coordinate cube facets remain 3-dimensional.
    assert all(sp.factor(alpha-1) != 0 for alpha in alphas)
    assert sp.factor(k-1) != 0
    checks.append("twelve_primal_vertices_from_nonredundant_cube_and_two_slab_facets")

    # Global primal volume from the ten positive facets.
    def vertex(j):
        return basis[:, j] if j < 6 else -basis[:, j-6]

    signs = {
        0: [1], 1: [1], 2: [1],
        3: [-1, -1, 1, -1, -1],
        4: [1, 1, 1, -1, -1],
        5: [1, -1, -1, -1, -1],
        6: [-1], 7: [1], 8: [-1],
        9: [1, -1, 1, 1, -1],
    }
    expected_signed = {
        0: [16], 1: [16], 2: [16],
        3: [8*(1-T), 8*(1-T), 8*(1-T), 8*(1+T), 16],
        4: [8*(1-T), 8*(1-T), 8*(1-T), 8*(1+T), 16],
        5: [8*(1-T), 8*(1-T), 8*(1-T), 8*(1+T), 16],
        6: [8*d6], 7: [8*d7], 8: [8*d8],
        9: [8*A, 8*B, 8*C, 8*E, 16],
    }
    P_volume = sp.Rational(0)
    for i, row in enumerate(template):
        ids = []
        for j, flag in enumerate(row):
            if flag == 1:
                ids.append(j)
            elif flag == -1:
                ids.append(j+6)
        dets = [
            sp.factor(sp.Matrix.hstack(*[vertex(j) for j in subset]).det())
            for subset in itertools.combinations(ids, 4)
        ]
        assert len(dets) == len(signs[i]) == len(expected_signed[i])
        signed_sum = sp.Rational(0)
        for det, sign, expected in zip(dets, signs[i], expected_signed[i]):
            signed = sp.factor((sign*det).subs(domain_sub))
            assert same(signed, expected)
            signed_sum += sign*det
        P_volume += sp.factor(signed_sum/(12 if len(ids) == 4 else 24))
    P_target = sp.Rational(4, 3)*(9-T+E*T)
    assert same(P_volume.subs(domain_sub), P_target)
    checks.append("global_primal_volume_by_fixed_sign_facet_circuits")

    # Exact polar volume.  In local cap coordinates, transform y0=k z0.
    # The overlap becomes a standard 4-simplex sliced by an affine form whose
    # vertex values are 0,1/k,alpha1,alpha2,alpha3.  The exact simplex-slice
    # formula leaves only the first two truncated-power terms.
    alpha_prod = sp.prod(alphas)
    overlap_z = (
        sp.Rational(1, 24)/alpha_prod
        - (1-1/k)**4 /
          (24*sp.prod(alpha-1/k for alpha in alphas))
    )
    cap_u_z = sp.Rational(1, 24)/alpha_prod
    cap_v_z = sp.Rational(1, 24)/k
    union_z = sp.factor(cap_u_z + cap_v_z - overlap_z)
    Q_normalized = sp.factor(16 - 32*union_z)
    Q_volume = sp.factor(Q_normalized/16)  # |det(pivot)|=16

    LA = A*(1+T)-E*(1-T)
    LB = B*(1+T)-E*(1-T)
    LC = C*(1+T)-E*(1-T)
    assert same(LA, 2*(E*T+(1-E)*U*(1+T)))
    assert same(LB, 2*(E*T+(1-E)*V*(1+T)))
    assert same(LC, 2*(E*T+(1-E)*W*(1+T)))
    Q_target = sp.factor(
        1 - (1-T)/(12*(1+T))
        - 4*E**3*T**4/(3*(1+T)*LA*LB*LC)
    )
    assert same(Q_volume, Q_target)
    checks.append("global_polar_volume_by_overlapping_simplex_caps_and_simplex_slice_formula")

    # Strict Mahler margin on the unit 4-cube.
    margin = sp.cancel(P_target*Q_target - sp.Rational(32, 3))
    H, denominator = map(sp.factor, sp.fraction(margin))
    assert same(denominator, sp.Rational(9, 8)*LA*LB*LC)
    degrees = tuple(sp.Poly(sp.expand(H), E, T, X, Y).degree(z) for z in (E, T, X, Y))
    assert degrees == (4, 4, 3, 2)
    bern = tensor_bernstein_coefficients(H, (E, T, X, Y), degrees)
    stats = bernstein_stats(bern)
    assert stats == {
        "positive": 125,
        "zero": 175,
        "negative": 0,
        "minimum_positive": sp.Rational(1, 24),
    }
    checks.append("strict_Mahler_margin_degree_4432_tensor_Bernstein")

    coeff_records = [
        {"index": list(index), "value": str(value)}
        for index, value in sorted(bern.items())
    ]
    h_string = str(sp.expand(H))
    certificate = {
        "schema": "viterbo-20f-d16-family85-certificate-v1",
        "family_index": 85,
        "domain": "0<E,T,X,Y<1 with U=X,V=(1-X)Y,W=(1-X)(1-Y)",
        "rank_pivot_det": "-16",
        "section_vertices": 20,
        "P_volume": str(P_target),
        "Q_volume": str(Q_target),
        "margin_denominator": str(denominator),
        "margin_numerator_sha256": hashlib.sha256(h_string.encode()).hexdigest(),
        "margin_degrees": list(degrees),
        "bernstein_stats": {k: str(v) for k, v in stats.items()},
        "bernstein_coefficients": coeff_records,
    }
    CERT.write_text(json.dumps(certificate, indent=2), encoding="utf-8")

    output = {
        "status": "PASS",
        "family_index": 85,
        "scope": "computer-assisted analytic proof candidate; no external peer review",
        "domain": "Delta_2^o x (0,1)^2, rationally parameterized by the unit 4-cube",
        "rank_pivot_det": "-16",
        "section_vertices": 20,
        "P_volume": str(P_target),
        "Q_volume": str(Q_target),
        "mahler_bernstein": {
            "degree": list(degrees),
            "coefficients": len(bern),
            "positive": stats["positive"],
            "zero": stats["zero"],
            "negative": stats["negative"],
            "minimum_positive": str(stats["minimum_positive"]),
        },
        "checks": checks,
        "elapsed_seconds": round(time.time()-started, 3),
    }
    OUTPUT.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
