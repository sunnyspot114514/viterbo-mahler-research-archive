# 四维中心对称 Mahler：`12V/20F, c=0, D=13` 整层完成报告

日期：2026-08-20

## 1. 组合层的无生成假设直接枚举

`D=13` 对应

\[
7\text{ 条 single-defect rows}+3\text{ 条 double-defect rows}.
\]

把七对五顶点 facets 三角化后得到中心对称 simplicial 三维球

\[
f=(12,46,68,34),\qquad g_2=8.
\]

固定一对 tetrahedra 后，直接精确搜索得到：

\[
9{,}692{,}172\text{ 个搜索节点},
\qquad
118{,}184\text{ 个闭合 pseudomanifold candidates}.
\]

完整 vertex-link 球面检查留下

\[
\boxed{50{,}320\text{ 个真正的 cs simplicial }3\text{-spheres}}.
\]

在

\[
B_6/\{\pm I\}
\]

作用下恰有

\[
\boxed{26\text{ 个组合轨道}}.
\]

## 2. Ridge merges 与全局 pairing templates

为恢复原始 `20F`，选择七对相容 antipodal ridges 合并。对 26 个球轨道逐一按自同构群约化，得到

\[
\boxed{20{,}406\text{ 个 local matching representatives}}.
\]

再按完整 signed-coordinate group 做全局 canonicalization：

\[
20{,}406\longrightarrow\boxed{11{,}190\text{ 个 pairing sign templates}}.
\]

canonicalization 使用单缺口 row 作 gauge：把其零坐标送到第一列，将其余五个符号 reorient 为正，只需遍历剩余五列置换和零列的一次符号自由度。该规范与完整 `B_6` 轨道等价。

## 3. Exact minor preclassification

多仿射 `5x5` minor 的全部 defect-cube 角点证书给出

\[
\boxed{
11{,}190
=
10{,}718\text{ 个 rank}\ge5
+467\text{ 个重复 facet rows}
+5\text{ 个 algebraic survivors}.
}
\]

## 4. 五个 survivors 全部结构退化

### 四个 primal vertex-loss

三个 survivors 具有同一关系：

\[
\boxed{
v_1=rac{1+t}{2}v_2+rac{1-t}{2}v_3,
\qquad |t|<1.
}
\]

两个系数严格为正且和为一，所以 `v1` 位于边 `[v2,v3]` 的相对内部。

另一个 survivor 满足

\[
\boxed{
v_0=rac{1-a}{2}(-v_1)+rac{1+a}{2}v_5,
\qquad |a|<1.
}
\]

同样丢失一对 primal vertices。四个对象实际至多只有 `10V`。

### 一个 polar vertex-loss

最后一族的 strict rank-four equations 先后强迫

\[
x_{2,0}=x_{3,0}=x_{9,1},
\qquad
x_{5,4}=x_{5,5}-x_{4,5}-1.
\]

令

\[
\lambda=\frac{1-x_{5,5}}{1-x_{4,5}}.
\]

由 strict inequalities 得 `0<lambda<1`，并且对应 section rows 满足

\[
\boxed{r_5=\lambda r_4+(1-\lambda)r_6}.
\]

所以该 row 不是 section vertex，实际至多只有 `18` 个 polar vertices，也就不可能对应 `20F`。

## 5. 结论

没有 genuine strict survivor，因此

\[
\boxed{12V/20F,\quad c=0,\quad D=13\quad\checkmark}.
\]

这里的勾号表示 **computer-assisted analytic proof candidate**。
