#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
W=Path('/mnt/data/viterbo_d13_work')
d=json.loads((W/'viterbo_20f_d13_preclassification_certificate.json').read_text())
assert d['fixed_facet_enumeration']=={'search_nodes':9692172,'closed_pseudomanifolds':118184,'valid_spheres_fixed_facet':50320}
assert d['sphere_orbit_count']==26
assert d['ridge_merge']['local_matching_representatives']==20406
assert d['global_pairing_templates']==11190
assert d['minor_classification']=={'rank_ge_5':10718,'duplicate_facet_rows':467,'algebraic_survivors':5}
assert d['survivor_classification']=={'primal_vertex_loss':4,'polar_vertex_loss':1,'strict_survivors_remaining':0}
assert len(d['records'])==11190
for f,h in d['hashes'].items():assert hashlib.sha256((W/f).read_bytes()).hexdigest()==h
s=json.loads((W/'viterbo_20f_d13_survivor_verifier_output.json').read_text());assert s['status']=='PASS'
print(json.dumps({'status':'PASS','scope':d['scope'],'accounting':{'rank_ge_5':10718,'duplicate_rows':467,'primal_vertex_loss':4,'polar_vertex_loss':1,'total':11190},'remaining':0},indent=2))
