#!/usr/bin/env python3
import json,sys
from pathlib import Path
WORK=Path(sys.argv[1]); files=[WORK/'local'/f'sphere_{i:02d}.json' for i in range(26)]
summary=[];records=[]
for f in files:
 d=json.loads(f.read_text());summary.append(d['summary']);records.extend(d['records'])
out={'sphere_summary':summary,'local_representatives':len(records),'records':records}
(WORK/'raw_templates_d13.json').write_text(json.dumps(out,separators=(',',':')))
with (WORK/'raw_templates_d13.txt').open('w') as g:
 for i,r in enumerate(records):g.write(str(i)+' '+''.join(str(x+1) for row in r['rows'] for x in row)+'\n')
print(json.dumps({'local_representatives':len(records),'sphere_summary':summary},indent=2))
