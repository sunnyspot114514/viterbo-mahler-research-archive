#!/usr/bin/env python3
from __future__ import annotations
import itertools,json
from pathlib import Path
import sympy as sp
WORK=Path(__file__).resolve().parent
KEYS={int(l.split()[0]):l.split()[1] for l in (WORK/'canonical_unique_with_id.txt').read_text().splitlines()}
OUT=WORK/'viterbo_20f_d13_survivor_verifier_output.json'

def matrix_for(idx):
 key=KEYS[idx];T=[];M=[];vars=[]
 for i in range(10):
  tr=[];mr=[]
  for j,c in enumerate(key[6*i:6*i+6]):
   z=int(c)-1;tr.append(z)
   if z==0:x=sp.Symbol(f'x{i}_{j}');vars.append(x);mr.append(x)
   else:mr.append(sp.Integer(z))
  T.append(tr);M.append(mr)
 return T,sp.Matrix(M),vars

def schur(M,rs,cs):
 rr=[i for i in range(10) if i not in rs];cc=[j for j in range(6) if j not in cs];P=M.extract(rs,cs)
 assert P.det()!=0
 S=(M.extract(rr,cc)-M.extract(rr,cs)*P.inv()*M.extract(rs,cc)).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 return P,S

def check_completed(idx,free_names,subs,rs,cs,col_relation):
 T,M,vars=matrix_for(idx);P,S=schur(M,rs,cs)
 assert all(sp.factor(sp.cancel(z.subs(subs)))==0 for z in S)
 Mc=M.subs(subs);V=(P.inv()*Mc.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)))
 assert all(sp.factor(sp.cancel(z))==0 for z in col_relation(V))
 return {'origin_id':idx,'status':'primal_vertex_loss','pivot_det':int(P.det()),'pivot_rows':list(rs),'pivot_cols':list(cs),'free_variables':free_names,'relation_verified':True}

def main():
 rec=[]
 # IDs 117 and 2184: v1=(1+t)/2 v2 +(1-t)/2 v3
 for idx,csign in [(117,1),(2184,1)]:
  T,M,v=matrix_for(idx);d={str(x):x for x in v};a=d['x2_0'];b=d['x5_0'];t=d['x9_1'];u=d['x3_5']
  sub={d['x0_0']:(a-b)/2,d['x0_1']:t,d['x1_0']:-(a-b)/2,d['x1_1']:t,
       d['x3_0']:-(a*u-3*a-u*b+(-2 if idx==117 else 2)*u-b+(-2 if idx==117 else 2))/4,
       d['x4_0']:(a+b+2)/2,d['x8_1']:-t}
  if idx==117:
   sub[d['x6_5']]=-(a+3*b+2)/(a-b-2);sub[d['x7_4']]=-(3*a+b+2)/(a-b+2)
  else:
   sub[d['x6_4']]=-(a+3*b+2)/(a-b-2);sub[d['x7_5']]=-(3*a+b+2)/(a-b+2)
  rs=(2,5,8,9);cs=(2,3,4,5)
  rec.append(check_completed(idx,[str(a),str(b),str(t),str(u)],sub,rs,cs,
   lambda V:[V[k,1]-(1+t)*V[k,2]/2-(1-t)*V[k,3]/2 for k in range(4)]))
  rec[-1]['convex_coefficients']=['(1+x9_1)/2','(1-x9_1)/2'];rec[-1]['strict_reason']='|x9_1|<1'
 # ID 3948, same column relation
 idx=3948;T,M,v=matrix_for(idx);d={str(x):x for x in v};a=d['x2_0'];b=d['x4_0'];t=d['x9_1'];u=d['x6_4']
 sub={d['x0_0']:(a-b)/2,d['x0_1']:t,d['x1_0']:-(a-b)/2,d['x1_1']:t,d['x3_0']:(a+b+2)/2,
      d['x5_5']:-(a+3*b+2)/(a-b-2),d['x6_5']:-(a*u+2*a-b*u+2*b+2*u+4)/(a-b-2),
      d['x7_4']:-(3*a+b+2)/(a-b+2),d['x8_1']:-t}
 rec.append(check_completed(idx,[str(a),str(b),str(t),str(u)],sub,(2,4,8,9),(2,3,4,5),
  lambda V:[V[k,1]-(1+t)*V[k,2]/2-(1-t)*V[k,3]/2 for k in range(4)]))
 rec[-1]['convex_coefficients']=['(1+x9_1)/2','(1-x9_1)/2'];rec[-1]['strict_reason']='|x9_1|<1'
 # ID 2992: v0=(1-a)/2(-v1)+(1+a)/2 v5
 idx=2992;T,M,v=matrix_for(idx);d={str(x):x for x in v};a=d['x4_0'];p=d['x0_1'];r=d['x9_4']
 sub={d['x0_0']:(p*a-p-a-1)/2,
      d['x1_0']:(p*a*r-p*a-p*r+p+3*a*r+a-r-3)/(2*(r-1)),
      d['x1_1']:(p*r-p+2*r+2)/(r-1),d['x2_0']:a,d['x3_0']:a,
      d['x3_4']:(p*r-p+r+1)/2,d['x5_4']:r,d['x6_4']:-(p*r-p-r-1)/2,
      d['x7_2']:-(p*r-p+5*r+3)/((p+1)*(r-1)),d['x8_3']:(p*r-p+5*r+3)/((p+1)*(r-1))}
 rec.append(check_completed(idx,[str(a),str(p),str(r)],sub,(3,4,6,9),(1,2,3,5),
  lambda V:[V[k,0]+(1-a)*V[k,1]/2-(1+a)*V[k,5]/2 for k in range(4)]))
 rec[-1]['convex_coefficients']=['(1-x4_0)/2','(1+x4_0)/2'];rec[-1]['strict_reason']='|x4_0|<1'
 # ID 4127: strict rank branch forces a=b=t and row 5 lies inside [row4,row6]
 idx=4127;T,M,v=matrix_for(idx);d={str(x):x for x in v};a=d['x2_0'];b=d['x3_0'];t=d['x9_1'];y=d['x4_5'];m=d['x5_4'];n=d['x5_5']
 P,S=schur(M,(1,2,3,9),(2,3,4,5))
 # Eliminate x1_0,x1_1 and the three auxiliary row defects using equations whose
 # denominators a-1,b-1 are nonzero on the strict branch.
 x10=-(a*y+a-y+1)/2
 x11=(t*y+t-y+1)/2
 z6=-(a*y-a+b-y)/(b-1)
 z7=-(a*y+2*b-y+2)/(a-1)
 z8=(a*y+a+b-y+2)/(b-1)
 c6=sp.factor(2*x11+z6*t-z6-t-1)
 c7=sp.factor(-2*x11-z7*t+z7-t-1)
 c8=sp.factor(-2*x11+z8*t-z8-t-1)
 assert sp.factor(c6 + (a-b)*(t-1)*(y-1)/(b-1))==0
 assert sp.factor(c7 + 2*(a*t+a-b*t+b-2*t)/(a-1))==0
 # Strict t!=1,y!=1 gives a=b from c6; c7 then gives a=t.
 assert sp.factor(c8.subs({b:a,t:a}))==0
 e5=sp.factor((2*x10+a*n+a-b*m-b+m-n+2).subs({b:t,a:t}))
 e6=sp.factor((2*x11+m*t-m-n*t+n-2).subs({a:t}))
 assert sp.factor(e5 + (t-1)*(m-n+y+1))==0
 assert sp.factor(e6 - (t-1)*(m-n+y+1))==0
 F=M.extract(range(10),(2,3,4,5)).subs({a:t,b:t,m:n-y-1,d['x6_4']:-y})
 lam=(1-n)/(1-y)
 relation=[sp.factor(F[5,k]-lam*F[4,k]-(1-lam)*F[6,k]) for k in range(4)]
 assert relation==[0,0,0,0]
 rec.append({'origin_id':idx,'status':'polar_vertex_loss','pivot_det':int(P.det()),'pivot_rows':[1,2,3,9],'pivot_cols':[2,3,4,5],
             'exact_chain':['strict implies x2_0=x3_0','then x2_0=x9_1','then x5_4=x5_5-x4_5-1'],
             'relation':'row5=lambda row4+(1-lambda) row6','lambda':'(1-x5_5)/(1-x4_5)',
             'strict_reason':'x5_4>-1 implies x5_5>x4_5; x5_5<1 and x4_5<1 imply 0<lambda<1'})
 out={'status':'PASS','scope':'12V/20F,c=0,D=13','survivors':rec,'classification':{'primal_vertex_loss':4,'polar_vertex_loss':1,'strict_survivors_remaining':0},
      'conclusion':'all five algebraic survivors lose a prescribed primal or polar vertex pair'}
 OUT.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
