#include <bits/stdc++.h>
using namespace std;
struct Row{array<int8_t,6>a;};
vector<Row> facets,tris;vector<array<int,4>>ftris;vector<vector<int>>tfac;
long long nodes=0,sols=0;vector<vector<int>>solutions;
string keyrow(array<int8_t,6>a){int first=0;while(first<6&&!a[first])first++;if(first<6&&a[first]<0)for(auto &x:a)x=-x;string s;for(auto x:a)s+=char('1'+x);return s;}
void gen(){
 map<string,int>tid;
 for(int mask=0;mask<64;mask++)if(__builtin_popcount((unsigned)mask)==3){
  vector<int> inds;for(int j=0;j<6;j++)if(mask>>j&1)inds.push_back(j);
  for(int bits=0;bits<8;bits++){array<int8_t,6>a{};for(int z=0;z<3;z++)a[inds[z]]=(bits>>z&1)?1:-1;string k=keyrow(a);if(!tid.count(k)){Row r;for(int j=0;j<6;j++)r.a[j]=k[j]-'1';tid[k]=tris.size();tris.push_back(r);}}
 }
 sort(tris.begin(),tris.end(),[](auto&x,auto&y){return x.a<y.a;});tid.clear();for(int i=0;i<(int)tris.size();i++)tid[keyrow(tris[i].a)]=i;
 set<string>seen;
 for(int mask=0;mask<64;mask++)if(__builtin_popcount((unsigned)mask)==4){
  vector<int> inds;for(int j=0;j<6;j++)if(mask>>j&1)inds.push_back(j);
  for(int bits=0;bits<16;bits++){array<int8_t,6>a{};for(int z=0;z<4;z++)a[inds[z]]=(bits>>z&1)?1:-1;string k=keyrow(a);if(seen.insert(k).second){Row r;for(int j=0;j<6;j++)r.a[j]=k[j]-'1';facets.push_back(r);}}
 }
 sort(facets.begin(),facets.end(),[](auto&x,auto&y){return x.a<y.a;});ftris.resize(facets.size());tfac.assign(tris.size(),{});
 for(int i=0;i<(int)facets.size();i++){int z=0;for(int j=0;j<6;j++)if(facets[i].a[j]){auto b=facets[i].a;b[j]=0;int t=tid[keyrow(b)];ftris[i][z++]=t;tfac[t].push_back(i);}}
}
array<uint8_t,80>deg{};bitset<120>selected;vector<int>sel;
bool compatible(int f){if(selected[f])return false;for(int t:ftris[f])if(deg[t]>=2)return false;return true;}
void dfs(){
 nodes++;int n=sel.size(),boundary=0;for(int t=0;t<80;t++)boundary+=deg[t]==1;
 if(boundary==0){if(n==17){sols++;solutions.push_back(sel);}return;}if(n>=17)return;int rem=17-n;if((boundary+3)/4>rem)return;
 int bt=-1,bavail=99;for(int t=0;t<80;t++)if(deg[t]==1){int c=0;for(int f:tfac[t])if(compatible(f))c++;if(c<bavail){bavail=c;bt=t;if(c<=1)break;}}
 if(bavail==0)return;
 for(int f:tfac[bt])if(compatible(f)){selected.set(f);sel.push_back(f);for(int t:ftris[f])deg[t]++;dfs();for(int t:ftris[f])deg[t]--;sel.pop_back();selected.reset(f);}
}
int main(int argc,char**argv){gen();array<int8_t,6>a={0,0,1,1,1,1};int f0=-1;for(int i=0;i<120;i++)if(facets[i].a==a)f0=i;selected.set(f0);sel.push_back(f0);for(int t:ftris[f0])deg[t]++;dfs();
 string path=argc>1?argv[1]:"sphere_solutions.txt";ofstream out(path);for(auto&s:solutions){for(int f:s)out<<f<<' ';out<<'\n';}
 cerr<<"nodes="<<nodes<<" solutions="<<sols<<" facets="<<facets.size()<<" triangles="<<tris.size()<<" fixed_facet="<<f0<<"\n";
}
