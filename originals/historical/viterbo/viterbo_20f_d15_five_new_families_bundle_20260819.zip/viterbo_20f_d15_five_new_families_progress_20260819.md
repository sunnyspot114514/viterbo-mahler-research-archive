# 四维中心对称 Mahler：`12V/20F, c=0, D=15` 新进展

日期：2026-08-19

## 结论

本轮完整关闭五个 canonical algebraic survivors：

\[
\boxed{50,\ 272,\ 281,\ 286,\ 497\quad\checkmark}
\]

每个勾号表示 **computer-assisted analytic proof candidate**。五族均完成：

\[
\text{exact rank completion}
+\text{strict-domain equivalence}
+12V/20F\text{ extremality}
+\text{global triangulation}
+\text{exact volumes}
+\text{Bernstein positivity}.
\]

此外，针对每一族，以三个自由 defects 为系数域计算 Schur-complement ideal，其 Gröbner 基均含 12 个线性主元，且为零维：

\[
\boxed{\text{basis length}=12,\qquad \text{zero-dimensional}=\mathrm{True}.}
\]

这给出当前恒非零 pivot 分支上的唯一有理 rank-4 completion。

---

## Family 50

取

\[
p=x_{6,2},\qquad q=x_{7,4},\qquad r=x_{9,2}.
\]

所有 strict inequalities 在 \(-1<p,q,r<1\) 中只剩一个非自动条件：

\[
pq-p-q+2r-1<0.
\]

所以完整严格域为

\[
-1<p,q<1,
\qquad
-1<r<\frac{1+p+q-pq}{2}.
\]

令

\[
p=2A-1,\quad q=2B-1,\quad
r=-1+2(A+B-AB)C,
\qquad0<A,B,C<1,
\]

即可双射到单位开立方体。

固定 boundary triangulations 使用

\[
33\text{ 个 primal tetrahedra},\qquad
67\text{ 个 polar-facet tetrahedra}.
\]

Mahler 余量分子在 tensor Bernstein basis 中：

\[
\deg=(3,6,2),\qquad69>0,\quad15=0,\quad0<0,
\]

最小正系数为 \(8/9\)。因此

\[
\boxed{|P||P^\circ|>32/3}.
\]

---

## Family 272

取

\[
a=x_{1,1},\qquad b=x_{4,5},\qquad c=x_{5,3}.
\]

在 \(-1<a,b,c<1\) 内，所有额外条件归约成

\[
a>\ell(b,c),
\qquad
\ell(b,c)=
-\frac{(b+1)(c-3)}{bc+b+c-7}.
\]

并且

\[
-1<\ell(b,c)<1.
\]

因此取

\[
b=2B-1,\quad c=2C-1,\quad
 a=\ell(b,c)+(1-\ell(b,c))A,
\qquad0<A,B,C<1.
\]

固定 triangulations 使用

\[
35\text{ 个 primal tetrahedra},\qquad69\text{ 个 polar tetrahedra}.
\]

余量分子的 Bernstein 统计：

\[
\deg=(4,6,7),\qquad265>0,\quad15=0,\quad0<0,
\]

最小正系数为 \(20/21\)。所以整族严格高于 \(32/3\)。

---

## Family 281

取

\[
a=x_{1,1},\qquad b=x_{4,3},\qquad c=x_{9,5}.
\]

严格域归约成

\[
-1<b,c<1,
\qquad
-1<a<u(b,c),
\]

其中

\[
u(b,c)=
-\frac{(b-3)(c-1)}{bc-b+c+7}.
\]

关键比较恒等式包括

\[
u-c=-\frac{(c+1)(bc-b+c+3)}{bc-b+c+7}<0,
\]

\[
u-u_{G_2}=
-\frac{8(c+1)^2}
{(bc-b-c+5)(bc-b+c+7)}<0,
\]

以及对其他候选上界的同类严格比较。因此 \(u\) 是唯一主导上界。

令

\[
b=2B-1,\quad c=2C-1,\quad
 a=-1+A\frac{4(c+1)}{bc-b+c+7},
\]

即可覆盖完整开域。

固定 triangulations 使用 \(35\) 与 \(67\) 个 tetrahedra。余量分子：

\[
\deg=(2,4,6),\qquad91>0,\quad14=0,\quad0<0,
\]

最小正系数 \(28/15\)。

---

## Families 286 与 497

这两族的三个自由 defects 本身可独立遍历 \((-1,1)^3\)。精确检查表明，对任意

\[
(f_1,f_2,f_3)=(2A-1,2B-1,2C-1),
\]

其余 12 个 dependent defects 自动满足 \(|x|<1\)。因此完整严格域就是单位开立方体。

| Family | primal tets | polar tets | margin degree | positive | zero | min positive |
|---:|---:|---:|---:|---:|---:|---:|
| 286 | 34 | 68 | \((6,2,3)\) | 49 | 35 | \(8/9\) |
| 497 | 35 | 68 | \((4,7,3)\) | 130 | 30 | \(4/7\) |

两族分母也均具有无负系数且至少一个严格正系数的 Bernstein 证书。

---

## 更新后的 D=15 计数

完整预分类保持为

\[
748
=669\text{ rank}\ge5
+51\text{ repeated rows}
+28\text{ algebraic survivors}.
\]

当前分类为

\[
\boxed{
748=669+51+2\text{ vertex-loss}
+17\text{ Mahler-positive}
+9\text{ remaining}.
}
\]

新关闭：

\[
\boxed{50,272,281,286,497}.
\]

剩余 canonical survivors：

\[
\boxed{244,396,509,514,541,675,683,728,747}.
\]

下一阶段优先处理 \(244\) 与 \(514\)：两者已经具有严格内部 rank-4 样本和恒非零 pivot；需要完成有理参数域分解。Families \(396\) 与 \(728\) 的 Schur Jacobian generic rank 为 11，可能代表四参数分支，需单独做 component decomposition。
