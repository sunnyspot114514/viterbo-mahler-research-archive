#!/usr/bin/env python3
import sympy as sp, itertools, math, json, time
import numpy as np
from scipy.spatial import ConvexHull
from collections import Counter,defaultdict,deque
from pathlib import Path

A,B,C=sp.symbols('A B C', real=True); VARS=(A,B,C)
p=2*A-1;q=2*B-1;H=sp.factor(A+B-A*B);r=sp.factor(-1+2*H*C)
# solution free p=x6_2 q=x7_4 r=x9_2
D0=sp.factor(p*q-p+q*r+3*r-4)
D1=sp.factor(p*q+p-q-5)
sol={
'x0_0': (p*q-p-q*r+2*q-3*r+2)/D0,
'x0_1': (p*q+5*p-q-1)/D1,
'x1_0': (q-1)*(p-r+2)/D0,
'x1_1': (p*q+p-q+3)/D1,
'x2_0': (q-1)*(p-r+2)/D0,
'x2_1': (p*q+p-q+3)/D1,
'x3_0': -(p*q-p-q*r-2*q+5*r-2)/D0,
'x3_1': -(p*q-3*p-q-1)/D1,
'x4_0': (q-1)*(p-r-2)/D0,
'x5_0': (q-1)*(p-r-2)/D0,
'x6_2':p,'x7_4':q,'x8_5':q,
'x9_1':(p*q-3*p-q+4*r+3)/D1,'x9_2':r}
BASE=Path('/mnt/data/d15_exact/viterbo_d15_work');idx=50;key=BASE.joinpath('unique_templates.txt').read_text().splitlines()[idx]
M=[];templ=[];defs=[]
for i in range(10):
 row=[];tr=[]
 for j,ch in enumerate(key[6*i:6*i+6]):
  z=int(ch)-1;tr.append(z)
  if z==0:
   nm=f'x{i}_{j}';row.append(sp.factor(sp.cancel(sol[nm])));defs.append((i,j,nm))
  else:row.append(sp.Integer(z))
 M.append(row);templ.append(tr)
M=sp.Matrix(M);rs=(2,3,4,5);cs=(2,3,4,5);P=M.extract(rs,cs);print('pivot',P.det())
ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs]
S=(M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj)).applyfunc(sp.factor)
assert all(x==0 for x in S)
VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs)
assert all(sp.factor(x)==0 for x in FM*VM-M)
SAMPLE={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)}

def bern(poly):
 P0=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,P0.degree_list()));co=dict(P0.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr
cache={}
def pospoly(poly,label=''):
 poly=sp.factor(poly);k=sp.srepr(poly)
 if k not in cache:
  deg,arr=bern(poly);cache[k]=(deg,arr)
 deg,arr=cache[k];neg=[x for x in arr if x<0];pos=[x for x in arr if x>0]
 if neg or not pos:
  print('FAIL poly',label,poly,'deg',deg,'neg',neg[:5],'pos',len(pos),'zero',sum(x==0 for x in arr));return None
 return {'degree':deg,'positive':len(pos),'zero':sum(x==0 for x in arr),'min':min(pos)}
def posrat(expr,label=''):
 expr=sp.cancel(expr);assert expr.subs(SAMPLE)>0,(label,expr.subs(SAMPLE))
 n,d=map(sp.factor,sp.together(expr).as_numer_denom())
 if d.subs(SAMPLE)<0:n,d=-n,-d
 sn=pospoly(n,label+' num');sd=pospoly(d,label+' den')
 if sn is None or sd is None:return None
 return sn,sd
print('defects')
for i,j,nm in defs:
 st=posrat(1-M[i,j]**2,nm);assert st is not None
print('defects pass cache',len(cache))
# extremality
ext=[]
for j in range(6):
 inc=[i for i in range(10) if templ[i][j]!=0];found=None
 for rr in itertools.combinations(inc,4):
  de=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
  if de==0:continue
  sg=1 if de.subs(SAMPLE)>0 else -1
  if posrat(sg*de,f'ext{j}{rr}'):
   found=(j,rr,de);break
 assert found,j;ext.append(found)
print('ext pass',[(j,rr) for j,rr,d in ext])
# sample hull and triangulations
Vnum=np.array(VM.subs(SAMPLE),float);Fnum=np.array(FM.subs(SAMPLE),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);print('hulls',len(ConvexHull(ptsP).vertices),len(ConvexHull(ptsQ).vertices))
Acode=np.array(templ,int)
def project3(x):
 d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,eqn in zip(h.simplices,h.equations):
  if abs(float(eqn[:-1]@pr[0]+eqn[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
facP=[]
for i in range(10):facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)]
print('tets',len(tP),len(tQ),'facet lens P',Counter(map(len,facP)),'Q',Counter(map(len,facQ)))
def ppoint(i):return VM[:,i] if i<6 else -VM[:,i-6]
def qpoint(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
def oriented(tets,point,name):
 terms=[]
 for z,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')))
  if de==0: raise RuntimeError(('zero',name,z,ids))
  sg=1 if de.subs(SAMPLE)>0 else -1
  if not posrat(sg*de,f'{name}{z}'):
   print('orientation wall',name,z,ids,de);return None
  terms.append(sp.factor(sg*de))
  if z%20==0:print(name,z,'/',len(tets),flush=True)
 return terms
pt=oriented(tP,ppoint,'P');qt=oriented(tQ,qpoint,'Q')
if pt is None or qt is None:
 print('TRIANGULATION NOT GLOBAL');raise SystemExit(2)
volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)))
print('volP=',volP);print('volQ=',volQ);print('margin factor=',margin)
st=posrat(margin,'margin');print('margin stat',st,'cache',len(cache))
out={'status':'PASS','scope':'12V/20F,c=0,D=15','index':50,'template':key,'parameterization':{'p':str(p),'q':str(q),'r':str(r)},'domain':'0<A,B,C<1','pivot_det':str(P.det()),'volP':str(volP),'volQ':str(volQ),'margin':str(margin),'margin_stats':st,'tetsP':len(tP),'tetsQ':len(tQ),'fixed_sign_polynomials':len(cache)}
Path('/mnt/data/viterbo_20f_d15_family50_verifier_output.json').write_text(json.dumps(out,indent=2,default=str))
print(json.dumps(out,indent=2,default=str))
