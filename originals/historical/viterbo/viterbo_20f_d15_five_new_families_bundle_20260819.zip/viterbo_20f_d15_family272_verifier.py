#!/usr/bin/env python3
import sympy as sp,itertools,math,json
import numpy as np
from scipy.spatial import ConvexHull
from collections import Counter
from pathlib import Path
A,B,C=sp.symbols('A B C');VARS=(A,B,C)
b=2*B-1;c=2*C-1;t=sp.factor(-(b+1)*(c-3)/(b*c+b+c-7));a=sp.factor(t+(1-t)*A)
loc={'x1_1':a,'x4_5':b,'x5_3':c};data=json.load(open('/mnt/data/family272_symbolic_solution.json'));sol={n:sp.factor(sp.sympify(e,locals=loc)) for n,e in data['solutions'][0].items()};sol.update(loc)
BASE=Path('/mnt/data/d15_exact/viterbo_d15_work');idx=272;key=BASE.joinpath('unique_templates.txt').read_text().splitlines()[idx]
M=[];templ=[];defs=[]
for i in range(10):
 row=[];tr=[]
 for j,ch in enumerate(key[6*i:6*i+6]):
  z=int(ch)-1;tr.append(z)
  if z==0:nm=f'x{i}_{j}';row.append(sp.factor(sp.cancel(sol[nm])));defs.append((i,j,nm))
  else:row.append(sp.Integer(z))
 M.append(row);templ.append(tr)
M=sp.Matrix(M);rs=(2,3,8,9);cs=(2,3,4,5);P=M.extract(rs,cs);assert P.det()==8
ri=[i for i in range(10) if i not in rs];cj=[j for j in range(6) if j not in cs];assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));FM=M.extract(range(10),cs);assert all(sp.factor(x)==0 for x in FM*VM-M)
SAMPLE={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)}
def bern(poly):
 P0=sp.Poly(sp.expand(poly),*VARS,domain='QQ');deg=tuple(map(int,P0.degree_list()));co=dict(P0.terms());arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg):f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr
cache={}
def pospoly(poly,label=''):
 poly=sp.factor(poly);k=sp.srepr(poly)
 if k not in cache:cache[k]=bern(poly)
 deg,arr=cache[k];pos=[x for x in arr if x>0];neg=[x for x in arr if x<0]
 if neg or not pos:print('FAIL',label,poly,deg,neg[:3]);return None
 return {'degree':deg,'positive':len(pos),'zero':sum(x==0 for x in arr),'min':min(pos)}
def posrat(e,label=''):
 e=sp.cancel(e);assert e.subs(SAMPLE)>0,(label,e.subs(SAMPLE))
 n,d=map(sp.factor,sp.together(e).as_numer_denom());
 if d.subs(SAMPLE)<0:n,d=-n,-d
 sn=pospoly(n,label+'n');sd=pospoly(d,label+'d');return (sn,sd) if sn and sd else None
for i,j,n in defs:assert posrat(1-M[i,j]**2,n)
print('defects',len(cache))
for j in range(6):
 inc=[i for i in range(10) if templ[i][j]!=0];ok=False
 for rr in itertools.combinations(inc,4):
  de=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
  if de==0:continue
  sg=1 if de.subs(SAMPLE)>0 else -1
  if posrat(sg*de,f'e{j}'):ok=True;break
 assert ok,j
Vnum=np.array(VM.subs(SAMPLE),float);Fnum=np.array(FM.subs(SAMPLE),float);ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum]);print('hulls',len(ConvexHull(ptsP).vertices),len(ConvexHull(ptsQ).vertices))
Acode=np.array(templ,int)
def project3(x):d=x-x[0];return d@np.linalg.svd(d,full_matrices=False)[2][:3].T
def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]);h=ConvexHull(pr);out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)
facP=[]
for i in range(10):facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
facQ=[]
for j in range(6):facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
tP=[t0 for f in facP for t0 in pull(f,ptsP)];tQ=[t0 for f in facQ for t0 in pull(f,ptsQ)];print('tets',len(tP),len(tQ),Counter(map(len,facP)),Counter(map(len,facQ)))
def pp(i):return VM[:,i] if i<6 else -VM[:,i-6]
def qq(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
def orient(tets,fn,name):
 out=[]
 for z,ids in enumerate(tets):
  de=sp.factor(sp.cancel(sp.Matrix.hstack(*[fn(i) for i in ids]).det(method='domain-ge')));assert de!=0
  sg=1 if de.subs(SAMPLE)>0 else -1
  if not posrat(sg*de,f'{name}{z}'):print('WALL',name,z,ids,de);return None
  out.append(sp.factor(sg*de))
  if z%20==0:print(name,z,'/',len(tets),flush=True)
 return out
pt=orient(tP,pp,'P');qt=orient(tQ,qq,'Q')
if pt is None or qt is None:raise SystemExit(2)
volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));st=posrat(margin,'margin')
print('volP',volP);print('volQ',volQ);print('margin',st,'cache',len(cache))
out={'status':'PASS','scope':'12V/20F,c=0,D=15','index':272,'parameterization':{'a':str(a),'b':str(b),'c':str(c),'lower':str(t)},'domain':'0<A,B,C<1','volP':str(volP),'volQ':str(volQ),'margin':str(margin),'margin_stats':st,'tetsP':len(tP),'tetsQ':len(tQ),'fixed_sign_polynomials':len(cache)};Path('/mnt/data/viterbo_20f_d15_family272_verifier_output.json').write_text(json.dumps(out,indent=2,default=str));print(json.dumps(out,indent=2,default=str))
