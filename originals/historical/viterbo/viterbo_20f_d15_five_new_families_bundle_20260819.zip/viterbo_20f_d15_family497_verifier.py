from viterbo_d15_cube_family_common_extended import verify
verify('/mnt/data/family497_certificate.json','/mnt/data/viterbo_20f_d15_family497_verifier_output.json')
