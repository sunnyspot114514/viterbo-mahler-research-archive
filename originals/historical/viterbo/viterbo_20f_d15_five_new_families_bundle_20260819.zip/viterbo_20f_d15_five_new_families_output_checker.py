#!/usr/bin/env python3
import json
from pathlib import Path
expected={
50:((3,6,2),69,15,'8/9'),
272:((4,6,7),265,15,'20/21'),
281:((2,4,6),91,14,'28/15'),
286:((6,2,3),49,35,'8/9'),
497:((4,7,3),130,30,'4/7'),
}
summary={}
for idx,(deg,pos,zero,mn) in expected.items():
 p=Path(f'/mnt/data/viterbo_20f_d15_family{idx}_verifier_output.json')
 c=json.loads(p.read_text())
 assert c['status']=='PASS'
 if idx in (50,272,281): s=c['margin_stats'][0]; got=(tuple(s['degree']),s['positive'],s['zero'],s['min'])
 else: s=c['margin_numerator_bernstein']; got=(tuple(s['degree']),s['positive'],s['zero'],s['min_positive'])
 assert got==(deg,pos,zero,mn),(idx,got)
 g=Path(f'/mnt/data/viterbo_20f_d15_family{idx}_groebner_output.txt').read_text()
 assert 'basis len 12 zero dim? True' in g
 summary[idx]={'status':'PASS','margin_degree':list(deg),'positive':pos,'zero':zero,'min_positive':mn,'groebner_basis_length':12}
out={'status':'PASS','scope':'12V/20F,c=0,D=15','newly_closed':[50,272,281,286,497],'remaining_survivors':[244,396,509,514,541,675,683,728,747],'families':summary}
Path('/mnt/data/viterbo_20f_d15_five_new_families_output_checker_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
