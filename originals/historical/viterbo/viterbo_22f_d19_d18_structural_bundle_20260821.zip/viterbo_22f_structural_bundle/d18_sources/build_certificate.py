import json,itertools,re,hashlib
from pathlib import Path
W=Path(__file__).resolve().parent

def decode(key,n=11):
 vals=[ord(c)-49 for c in key.strip()]
 return [vals[6*i:6*i+6] for i in range(n)]
def facets_from_rows(rows):
 out=[]
 for r in rows:
  F=frozenset((j+1 if x>0 else -(j+1)) for j,x in enumerate(r) if x)
  out.extend([F,frozenset(-x for x in F)])
 return list(dict.fromkeys(out))
def edge_data(rows):
 fs=facets_from_rows(rows); V=sorted(set().union(*fs));E=[]
 for a,b in itertools.combinations(V,2):
  if a==-b:continue
  contain=[F for F in fs if a in F and b in F]
  if not contain:continue
  I=set(contain[0])
  for F in contain[1:]:I.intersection_update(F)
  if I=={a,b}:E.append((a,b))
 deg={v:0 for v in V}
 for a,b in E:deg[a]+=1;deg[b]+=1
 H={v for v,d in deg.items() if d>=5};NS=[F for F in fs if len(F)>4]
 nsc={v:sum(v in F for F in NS) for v in V};fh=[sum(v in H for v in F) for F in fs]
 return {'degrees':{str(k):v for k,v in deg.items()},'nonsimplex_incidence':{str(k):v for k,v in nsc.items()},'facet_high_counts':fh,
         'guberman_vertex_ok':all(v>=3 for v in nsc.values()),'guberman_facet_ok':all(v>=3 for v in fh)}
def parse_minor(line):
 p=line.split('|'); left=p[0].split(); cid=int(left[0]); assert left[1]=='RANK'
 rows=list(map(int,left[2:7]));cols=list(map(int,p[1].split()));z=int(p[2]);dets=list(map(int,p[3].split()))
 return cid,{'rows':rows,'cols':cols,'zero_count':z,'corner_dets':dets}
keys={int(i):k for i,k in (line.split() for line in open(W/'unique_d18.txt'))}
minor_lines=[line.strip() for line in open(W/'minor_d18.txt') if line.strip()]
minor_status={};minor_cert={}
for line in minor_lines:
 t=line.split();cid=int(t[0]);minor_status[cid]=t[1]
 if t[1]=='RANK':_,c=parse_minor(line);minor_cert[cid]=c
records=[];counts={}
for cid,key in sorted(keys.items()):
 rows=decode(key);ed=edge_data(rows);gp=ed['guberman_vertex_ok'] and ed['guberman_facet_ok']
 rec={'canonical_id':cid,'key':key,'rows':rows,'combinatorics':ed}
 if not gp:
  status='fails_guberman_facet_condition' if ed['guberman_vertex_ok'] else 'fails_guberman_vertex_condition'
 elif minor_status[cid]=='RANK':
  status='rank_ge_5';rec['minor_certificate']=minor_cert[cid]
 elif cid==19:
  assert all(rows[i][1]==-rows[i][0] for i in range(11));status='antipodal_duplicate_columns';rec['column_relation']='column_1=-column_0'
 elif cid==22:
  incidence=sum(x!=0 for x in [r[0] for r in rows]);assert incidence==3;status='insufficient_vertex_facets';rec['column']=0;rec['incident_facets']=incidence
 else:
  status='algebraic_survivor'
 rec['status']=status;counts[status]=counts.get(status,0)+1;records.append(rec)
cert={
 'scope':'4D symmetric Mahler bounded-12, 12V/22F, c=0, D=18 local-minimizer preclassification',
 'literature_dependency':'Guberman arXiv:2608.10994v1, Theorem 1.3',
 'sphere_source':'the five cs simplicial 3-sphere orbits with f=(12,42,60,30), independently enumerated in the 20F,D=15 certificate',
 'sphere_summary':json.load(open(W/'raw_templates_d18.json'))['sphere_summary'],
 'local_representatives_after_first_guberman_filter':73,
 'global_templates':len(records),
 'classification':counts,
 'remaining_survivor_ids':[r['canonical_id'] for r in records if r['status']=='algebraic_survivor'],
 'records':records
}
(W/'viterbo_22f_d18_preclassification_certificate.json').write_text(json.dumps(cert,indent=2,sort_keys=True))
print(json.dumps({'global_templates':len(records),'classification':counts,'survivors':cert['remaining_survivor_ids']},indent=2))
