#!/usr/bin/env python3
import hashlib, json
from pathlib import Path

FILES = {
    'd19_output': Path('/mnt/data/viterbo_22f_d19_guberman_closure_verifier_output.json'),
    'd19_certificate': Path('/mnt/data/viterbo_22f_d19_guberman_closure_certificate.json'),
    'd18_output': Path('/mnt/data/viterbo_22f_d18_preclassification_verifier_output.json'),
    'd18_certificate': Path('/mnt/data/viterbo_d18_work/viterbo_22f_d18_preclassification_certificate.json'),
    'family20_output': Path('/mnt/data/viterbo_22f_d18_family20_rank_domain_verifier_output.json'),
    'family20_certificate': Path('/mnt/data/viterbo_22f_d18_family20_rank_domain_certificate.json'),
    'report': Path('/mnt/data/viterbo_22f_d19_d18_progress_20260821.md'),
    'status': Path('/mnt/data/viterbo_bounded12_status_20260821_v14.json'),
}

def sha(p):
    h=hashlib.sha256();h.update(p.read_bytes());return h.hexdigest()

def main():
    for p in FILES.values(): assert p.exists() and p.stat().st_size>0
    d19=json.load(open(FILES['d19_output']));assert d19['status']=='PASS' and d19['canonical_templates_checked']==92
    d18=json.load(open(FILES['d18_output']));assert d18['status']=='PASS' and d18['templates_checked']==62
    assert d18['classification']['algebraic_survivor']==13
    f20=json.load(open(FILES['family20_output']));assert f20['status']=='PASS' and f20['canonical_survivor']==20
    status=json.load(open(FILES['status']));assert status['current_frontier']['classification']['remaining_algebraic_survivors']==13
    out={'status':'PASS','hashes':{k:sha(p) for k,p in FILES.items()},'checks':[
      'D19 92/92 structural exclusions','D18 exact accounting 62=13+34+1+1+13','Family20 unique rank branch and full strict domain','status accounting consistency']}
    Path('/mnt/data/viterbo_22f_d19_d18_output_checker_output.json').write_text(json.dumps(out,indent=2,sort_keys=True))
    Path('/mnt/data/viterbo_22f_d19_d18_manifest.json').write_text(json.dumps({'files':{k:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for k,p in FILES.items()}},indent=2,sort_keys=True))
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
