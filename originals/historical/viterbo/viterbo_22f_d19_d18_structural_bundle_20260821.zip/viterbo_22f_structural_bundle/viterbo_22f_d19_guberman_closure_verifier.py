#!/usr/bin/env python3
"""Exact structural verifier for 12V/22F, c=0, D=19.

The external mathematical input is Guberman, arXiv:2608.10994v1,
Theorem 3.2.  In dimension four, a bounded-vertex-class local minimizer
which is neither the cube nor the cross-polytope must have every vertex in
at least three nonsimplicial facets.

This script verifies the finite/combinatorial application to all 92 canonical
pairing templates produced by the independent D=19 preclassifier.
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path('/mnt/data/viterbo_22f_d19_work_full')
OLD_CERT = ROOT / 'viterbo_22f_d19_preclassification_certificate.json'
UNIQUE = ROOT / 'canonical_unique_with_id.txt'
OUT = Path('/mnt/data/viterbo_22f_d19_guberman_closure_verifier_output.json')
NEW_CERT = Path('/mnt/data/viterbo_22f_d19_guberman_closure_certificate.json')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def decode_key(key: str, nrows: int = 11) -> list[list[int]]:
    vals = [ord(c) - ord('1') for c in key.strip()]
    assert len(vals) == 6 * nrows
    rows = [vals[6*i:6*i+6] for i in range(nrows)]
    assert all(x in (-1, 0, 1) for row in rows for x in row)
    return rows


def row_zero_count(row: list[int]) -> int:
    return sum(x == 0 for x in row)


def analyze(rows: list[list[int]]) -> dict:
    zero_profile = sorted(row_zero_count(r) for r in rows)
    assert zero_profile == [1] * 3 + [2] * 8
    single_zero_cols = [r.index(0) for r in rows if row_zero_count(r) == 1]
    multiplicity = Counter(single_zero_cols)
    s = len(single_zero_cols)
    assert s == 3

    # A single-defect row-pair represents two antipodal nonsimplicial
    # 5-vertex facets.  A fixed individual vertex in pair j lies in exactly
    # s-d_j of those actual facets.
    per_pair_incidence = [s - multiplicity.get(j, 0) for j in range(6)]
    total_actual_incidence = 2 * sum(per_pair_incidence)
    # Equivalent double count: 2s facets * 5 vertices.
    assert total_actual_incidence == 10 * s == 30
    assert min(per_pair_incidence) <= 2
    return {
        'single_zero_columns': single_zero_cols,
        'single_direction_partition': sorted(multiplicity.values(), reverse=True),
        'nonsimplicial_facets_per_individual_vertex_pair': per_pair_incidence,
        'minimum_nonsimplicial_facets_at_a_vertex': min(per_pair_incidence),
        'total_vertex_nonsimplicial_facet_incidences': total_actual_incidence,
        'guberman_required_total_incidences': 12 * 3,
        'passes_guberman_vertex_condition': all(x >= 3 for x in per_pair_incidence),
    }


def main() -> None:
    old = json.loads(OLD_CERT.read_text())
    assert old['global_pairing_templates'] == 92
    records = old['records']
    assert len(records) == 92

    # Cross-check the canonical-key file independently.
    keys_from_file = [line.split()[1] for line in UNIQUE.read_text().splitlines() if line.strip()]
    assert len(keys_from_file) == 92
    assert len(set(keys_from_file)) == 92
    keys_from_cert = [r['canonical_key'] for r in records]
    assert set(keys_from_file) == set(keys_from_cert)

    partition_counts: Counter[tuple[int, ...]] = Counter()
    out_records = []
    for rec in records:
        rows = decode_key(rec['canonical_key'])
        a = analyze(rows)
        assert not a['passes_guberman_vertex_condition']
        partition_counts[tuple(a['single_direction_partition'])] += 1
        out_records.append({
            'canonical_index': rec['canonical_index'],
            'canonical_key': rec['canonical_key'],
            **a,
            'status': 'excluded_as_bounded_class_local_minimizer',
        })

    assert partition_counts == Counter({(2, 1): 66, (1, 1, 1): 20, (3,): 6})

    cert = {
        'scope': '4D symmetric Mahler bounded-12 minimizer analysis; 12V/22F, c=0, D=19',
        'external_theorem': {
            'citation': 'Agam Guberman, arXiv:2608.10994v1, Theorem 3.2',
            'dimension_4_consequence': (
                'A local minimizer among symmetric polytopes with at most l vertices, '
                'unless cube/cross-polytope, has every vertex in at least 3 nonsimplicial facets.'
            ),
        },
        'logic': {
            'single_defect_row_pairs': 3,
            'actual_nonsimplicial_facets': 6,
            'incidences_available': 30,
            'incidences_required': 36,
            'conclusion': 'No D=19 template can be a bounded-vertex-class local minimizer.',
            'note': (
                'This closes the layer in the minimizer-based proof architecture; '
                'it does not assert that every D=19 polytope individually has Mahler product >=32/3.'
            ),
        },
        'canonical_templates': 92,
        'single_direction_partition_counts': {
            ','.join(map(str, k)): v for k, v in sorted(partition_counts.items())
        },
        'classification': {'excluded_by_guberman_vertex_condition': 92},
        'records': out_records,
        'source_hashes': {
            str(OLD_CERT): sha256(OLD_CERT),
            str(UNIQUE): sha256(UNIQUE),
        },
    }
    NEW_CERT.write_text(json.dumps(cert, indent=2, sort_keys=True))
    result = {
        'status': 'PASS',
        'canonical_templates_checked': 92,
        'partition_counts': cert['single_direction_partition_counts'],
        'all_fail_guberman_vertex_condition': True,
        'certificate': str(NEW_CERT),
        'certificate_sha256': sha256(NEW_CERT),
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
