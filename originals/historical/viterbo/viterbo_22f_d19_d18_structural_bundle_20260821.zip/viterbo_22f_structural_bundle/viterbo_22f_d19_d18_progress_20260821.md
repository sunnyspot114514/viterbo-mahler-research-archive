# 四维中心对称 Mahler：22F 的结构性推进

日期：2026-08-21

## 结论摘要

本轮首次让“无限复杂度归约”理论线直接替代了一整个连续族计算层。

对四维 bounded-vertex class 的局部 Mahler 极小多胞体，Guberman 的最新必要条件给出：除四维 cube / cross-polytope 外，

1. 每个顶点至少属于 3 个非单纯 facets；
2. 每个 facet 至少包含 3 个图度数不小于 5 的顶点。

在我们的 12-vertex、`c=0` pairing-matrix 语言中，一条 single-defect row-pair 对应一对 5-vertex、因而非单纯的 antipodal facets。若 single row-pairs 数为 `s`，第 `j` 个顶点方向被漏掉 `d_j` 次，则每个该方向中的单个顶点恰属于

\[
s-d_j
\]

个非单纯 facets。因此任何非 Hanner 例外的 bounded-class 局部极小体必须满足

\[
\boxed{s\ge4,\qquad d_j\le s-3\quad(j=1,\dots,6).}
\]

等价地，若有 `m` 个 facet-pairs 且每行只有一或两个 defects，

\[
D=2m-s\le 2m-4.
\]

这是一个不依赖 facet 数的结构筛选器。

---

## 一、`12V/22F, c=0, D=19` 整层结构排除

这里 `m=11` 且

\[
s=2m-D=22-19=3.
\]

实际非单纯 facets 数为 `2s=6`，它们产生的顶点—非单纯-facet incidence 总数只有

\[
6\cdot5=30.
\]

但 Guberman 条件至少要求

\[
12\cdot3=36.
\]

所以任何 `D=19` 对象都不可能是 bounded-vertex class 的局部 Mahler 极小体。

原来的 92 个 canonical templates 已全部复核：其三条 single defects 的方向 multiplicity 分布为

\[
(2,1):66,\qquad(1,1,1):20,\qquad(3):6.
\]

92/92 全部违反顶点—非单纯-facet 必要条件。因此此前留下的 14 个五参数连续 family 不再需要逐一计算体积。

应准确理解这个结论：

\[
\boxed{D=19\text{ 已在“极小者排除”证明架构中关闭。}}
\]

它没有单独声称每一个 `D=19` 多胞体都已被逐点证明 Mahler product 大于 `32/3`；bounded-12 定理只需证明全局极小者不可能落在这里。

---

## 二、`12V/22F, c=0, D=18` 的结构压缩

`D=18` 有

\[
4\text{ 条 single rows}+7\text{ 条 double rows}.
\]

此时 `s=4`，上面的精细条件 `d_j\le1` 强迫四条 single defects 位于四个互不相同的坐标方向。

三角化后的中心对称三维球具有

\[
f=(12,42,60,30),\qquad g_2=4.
\]

复用此前由直接枚举得到的 5 个 `g_2=4` cs sphere orbits，并重新枚举四对相容 ridge merges：

| sphere orbit | raw matchings | local orbits | 通过第一 Guberman 条件 |
|---:|---:|---:|---:|
| 0 | 185 | 33 | 20 |
| 1 | 560 | 303 | 22 |
| 2 | 744 | 79 | 25 |
| 3 | 1113 | 582 | 0 |
| 4 | 1059 | 297 | 6 |

共得到

\[
73\text{ 个 local representatives}.
\]

经完整 `B_6` canonicalization：

\[
73\longrightarrow\boxed{62\text{ 个全局 pairing templates}}.
\]

精确分类为

\[
\boxed{
62=
13\text{ 个违反 facet-high-degree 条件}
+34\text{ 个 rank}\ge5
+1\text{ 个 primal column loss}
+1\text{ 个 vertex 仅邻接 3 facets}
+13\text{ 个连续 survivors}.
}
\]

### 34 个 rank obstruction

每一个都有一个 `5x5` minor。该 determinant 对 minor 中的 defect variables 是多仿射的；全部 cube-corner determinants 同号或为零，并至少一个严格非零，所以该 minor 在整个 open defect cube 中不为零。

### Canonical ID 19：精确 column loss

选定恒定 pivot

\[
R=(0,1,2,4),\qquad C=(2,3,4,5),\qquad\det=-8.
\]

令前七个 double rows 的两列 defect 和为 `s_i`。rank-four Schur equations 给出关于

\[
(s_0,s_1,s_2,s_4)
\]

的齐次 `4x4` 线性系统。其 determinant 为

\[
-2F(t_{10},t_7,t_8,t_9),
\]

而多仿射多项式 `F` 的 16 个 cube-corner values 为

\[
0,0,0,0,0,0,0,-8,0,0,0,-8,0,-8,-8,-16.
\]

因此 `F<0` 遍历 open cube，系统 determinant 严格非零，所有 `s_i=0`。其余 Schur equations 继续给出所有行上

\[
X_{i1}=-X_{i0}.
\]

所以两个 primal columns 互为相反数，两个所谓不同的 vertex-pairs 实际重复。

### Canonical ID 22：顶点只有三个 incident facets

第一 primal column 只在三条 facet-pair rows 上取 `\pm1`；其余位置都是 strict defects。因此该候选顶点只属于三个实际 facets，不可能是四维满维多胞体的顶点。

最终留下 13 个 canonical survivors：

\[
\boxed{20,27,28,29,32,33,34,43,49,51,67,69,71.}
\]

它们 generic realization dimension 均预期为 4。

---

## 三、Family 20 已得到完整 rank/domain 证书

Family 20 的四条 single defects 可取为

\[
a=x_{4,0},\qquad b=x_{7,2},\qquad c=x_{8,3},\qquad d=x_{10,1}.
\]

存在恒定 pivot

\[
R=(0,1,4,10),\qquad C=(2,3,4,5),\qquad\det=8.
\]

在有理函数域 `Q(a,b,c,d)` 上，14 条 Schur equations 的 Gröbner basis：

\[
\boxed{\text{长度}=14,\qquad\text{zero-dimensional}=\mathrm{True}.}
\]

每个 dependent defect 都被唯一解成 `a,b,c,d` 的有理函数，所以 strict rank-four branch 是唯一的四参数分支。

定义

\[
K=3-b-c-bc,
\]

\[
U_b=1-\frac{4(1-b)}{K},\qquad
U_c=1-\frac{4(1-c)}{K}.
\]

完整 strict realization domain 精确为

\[
\boxed{
-1<a,b,c<1,\qquad -1<d<\min\{U_b,U_c\}.
}
\]

其中 `K>0`，且 `U_b,U_c\in(-1,1)`。

在 chamber `b<c` 中，整个域可由单位开四立方体参数化：

\[
a=2A-1,
\]

\[
b=2B-1,
\]

\[
c=2B-1+2(1-B)C,
\]

\[
d=-1+\frac{2B(1-C)}{1+B-BC}T,
\qquad0<A,B,C,T<1.
\]

模板存在交换 `b\leftrightarrow c` 的 exact `B_6` symmetry，因此另一 chamber 完全等价；公共墙 `b=c` 也已单独获得 strict Bernstein certificate。

全部 18 个 defect inequalities 以及所有 completion denominators 都在该 chart 上得到 exact tensor-Bernstein 定号证书。

Family 20 目前尚未关闭的部分是：

1. 全域 section closure / extremality；
2. 精确 primal 与 polar volume；
3. Mahler 余量正性。

---

## 四、当前 bounded-12 状态

\[
\boxed{
\begin{array}{c|c}
\text{层}&\text{状态}\\
\hline
c=1&\checkmark\\
c=0,\ 12V/12F&\checkmark\\
c=0,\ 12V/14F&\checkmark\\
c=0,\ 12V/16F&\checkmark\\
c=0,\ 12V/18F&\checkmark\\
c=0,\ 12V/20F&\checkmark\\
c=0,\ 12V/22F,\ D=19&\checkmark\ \text{（极小者结构排除）}\\
c=0,\ 12V/22F,\ D=18&13\text{ 个 family 剩余}
\end{array}}
\]

### 证明标准说明

- Guberman 结果目前是 2026-08-11 提交的 arXiv v1，属于非常新的外部理论依赖。
- 这里的所有计算关闭仍是 computer-assisted analytic proof candidates。
- 完整四维 symmetric Mahler 仍需要：完成 bounded-12 有限核心，并建立不依赖 `f_0,f_3` 的 finite-core / bi-shadow-rigid reduction theorem。

本轮的意义在于：理论线首次真正删掉了一个原本包含 14 个连续 family 的完整层，并将下一层在进入体积计算前从 92 类压缩到 13 类。
