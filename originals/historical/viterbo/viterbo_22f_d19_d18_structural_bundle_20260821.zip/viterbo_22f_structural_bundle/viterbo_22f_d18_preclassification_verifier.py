#!/usr/bin/env python3
"""Exact verifier for the local-minimizer preclassification of
12V/22F, c=0, D=18.

External input: Guberman, arXiv:2608.10994v1, Theorem 3.2.
Everything after the theorem's two combinatorial conditions is checked here
with exact integer/rational/symbolic arithmetic.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path

import sympy as sp

W = Path('/mnt/data/viterbo_d18_work')
CERT_PATH = W / 'viterbo_22f_d18_preclassification_certificate.json'
UNIQUE = W / 'unique_d18.txt'
MINOR_FILE = W / 'minor_d18.txt'
OUT = Path('/mnt/data/viterbo_22f_d18_preclassification_verifier_output.json')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def decode_key(key: str, nrows: int = 11) -> list[list[int]]:
    vals = [ord(c) - ord('1') for c in key.strip()]
    assert len(vals) == 6 * nrows
    rows = [vals[6*i:6*i+6] for i in range(nrows)]
    assert all(x in (-1, 0, 1) for row in rows for x in row)
    return rows


def bareiss_det(a: list[list[int]]) -> int:
    n = len(a)
    assert all(len(r) == n for r in a)
    m = [list(map(int, r)) for r in a]
    sign = 1
    prev = 1
    if n == 0:
        return 1
    for k in range(n - 1):
        if m[k][k] == 0:
            p = next((i for i in range(k + 1, n) if m[i][k] != 0), None)
            if p is None:
                return 0
            m[k], m[p] = m[p], m[k]
            sign *= -1
        pivot = m[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                num = m[i][j] * pivot - m[i][k] * m[k][j]
                assert num % prev == 0
                m[i][j] = num // prev
        prev = pivot
        for i in range(k + 1, n):
            m[i][k] = 0
        for j in range(k + 1, n):
            m[k][j] = 0
    return sign * m[n - 1][n - 1]


def facets_from_rows(rows: list[list[int]]) -> list[frozenset[int]]:
    facets = []
    for row in rows:
        f = frozenset((j + 1 if x > 0 else -(j + 1)) for j, x in enumerate(row) if x != 0)
        facets.extend([f, frozenset(-v for v in f)])
    return list(dict.fromkeys(facets))


def exact_combinatorics(rows: list[list[int]]) -> dict:
    facets = facets_from_rows(rows)
    assert len(facets) == 22
    vertices = sorted(set().union(*facets))
    assert vertices == list(range(-6, 0)) + list(range(1, 7))

    edges: list[frozenset[int]] = []
    for a, b in itertools.combinations(vertices, 2):
        if a == -b:
            continue
        containing = [f for f in facets if a in f and b in f]
        if not containing:
            continue
        intersection = set(containing[0])
        for f in containing[1:]:
            intersection.intersection_update(f)
        if intersection == {a, b}:
            edges.append(frozenset((a, b)))

    degrees = {v: 0 for v in vertices}
    for edge in edges:
        for v in edge:
            degrees[v] += 1
    high = {v for v, d in degrees.items() if d >= 5}
    nonsimp = [f for f in facets if len(f) == 5]
    ns_inc = {v: sum(v in f for f in nonsimp) for v in vertices}
    facet_high = [sum(v in high for v in f) for f in facets]
    return {
        'degrees': {str(k): v for k, v in degrees.items()},
        'nonsimplex_incidence': {str(k): v for k, v in ns_inc.items()},
        'facet_high_counts': facet_high,
        'guberman_vertex_ok': all(v >= 3 for v in ns_inc.values()),
        'guberman_facet_ok': all(v >= 3 for v in facet_high),
    }


def verify_minor(rows: list[list[int]], cert: dict) -> None:
    rr = cert['rows']
    cc = cert['cols']
    base = [[rows[i][j] for j in cc] for i in rr]
    zero_pos = [(i, j) for i in range(5) for j in range(5) if base[i][j] == 0]
    assert len(zero_pos) == cert['zero_count']
    dets = []
    for corner in itertools.product((-1, 1), repeat=len(zero_pos)):
        mat = [r[:] for r in base]
        for value, (i, j) in zip(corner, zero_pos):
            mat[i][j] = value
        dets.append(bareiss_det(mat))
    # The C++ classifier uses a different bit ordering for cube corners;
    # compare the exact multiset rather than an incidental enumeration order.
    assert sorted(dets) == sorted(cert['corner_dets']), (dets, cert['corner_dets'])
    nz = [d for d in dets if d != 0]
    assert nz and (all(d > 0 for d in nz) or all(d < 0 for d in nz))


def verify_id19_antipodal_columns(rows: list[list[int]]) -> dict:
    # Fill all defects symbolically.
    m = sp.zeros(11, 6)
    for i, row in enumerate(rows):
        for j, z in enumerate(row):
            m[i, j] = sp.symbols(f'x{i}_{j}') if z == 0 else z

    pivot_rows = [0, 1, 2, 4]
    pivot_cols = [2, 3, 4, 5]
    p = m.extract(pivot_rows, pivot_cols)
    assert p.det() == -8
    other_rows = [i for i in range(11) if i not in pivot_rows]
    schur = sp.simplify(
        m.extract(other_rows, [0, 1])
        - m.extract(other_rows, pivot_cols) * p.inv() * m.extract(pivot_rows, [0, 1])
    )
    eq = {(other_rows[i], j): sp.factor(schur[i, j]) for i in range(7) for j in range(2)}

    # Let s_i be the sum of the two defect entries in row i for rows 0..6.
    s0, s1, s2, s4 = sp.symbols('s0 s1 s2 s4')
    t7, t8, t9, t10 = m[7, 5], m[8, 4], m[9, 3], m[10, 2]

    # Check that adding the col-0 and col-1 Schur equations yields the stated
    # homogeneous 4x4 system in s0,s1,s2,s4.
    substitutions = {
        m[0, 0] + m[0, 1]: s0,
        m[1, 0] + m[1, 1]: s1,
        m[2, 0] + m[2, 1]: s2,
        m[4, 0] + m[4, 1]: s4,
    }
    expected = [
        (s0 - s1) * t7 - 3*s0 + s1 + 2*s2 + 2*s4,
        (s0 - s2) * t8 - 3*s0 + 2*s1 + s2 + 2*s4,
        (s0 - s4) * t9 - 3*s0 + 2*s1 + 2*s2 + s4,
        t10 * (s0 - s1 - s2 - s4) - 3*s0 + s1 + s2 + s4,
    ]
    for r, target in zip([7, 8, 9, 10], expected):
        summed = sp.expand(eq[(r, 0)] + eq[(r, 1)])
        # Replace explicit sums in a controlled way.
        summed = summed.subs(m[0, 0], s0 - m[0, 1])
        summed = summed.subs(m[1, 0], s1 - m[1, 1])
        summed = summed.subs(m[2, 0], s2 - m[2, 1])
        summed = summed.subs(m[4, 0], s4 - m[4, 1])
        assert sp.factor(2*summed - target) == 0

    coeff = sp.Matrix([[sp.expand(e).coeff(x) for x in (s0, s1, s2, s4)] for e in expected])
    determinant = sp.factor(coeff.det())
    f = sp.factor(-determinant / 2)
    expected_f = (
        t10*t7*t8*t9 - t10*t7 - t10*t8 - t10*t9 - 2*t10
        - t7*t8 - t7*t9 - 2*t7 - t8*t9 - 2*t8 - 2*t9 - 3
    )
    assert sp.expand(f - expected_f) == 0
    corner_values = [
        int(f.subs(dict(zip((t10, t7, t8, t9), corner))))
        for corner in itertools.product((-1, 1), repeat=4)
    ]
    assert all(v <= 0 for v in corner_values) and any(v < 0 for v in corner_values)
    # Multi-affine interpolation makes f strictly negative in the open cube,
    # hence det(coeff)>0 and all four sums vanish.

    # The three remaining double rows are then forced by linear Schur sums:
    # s3=s1+s2-s0, s5=s1+s4-s0, s6=s2+s4-s0.
    for r, rhs in [(3, s1+s2-s0), (5, s1+s4-s0), (6, s2+s4-s0)]:
        summed = sp.expand(eq[(r, 0)] + eq[(r, 1)])
        summed = summed.subs(m[0, 0], s0 - m[0, 1])
        summed = summed.subs(m[1, 0], s1 - m[1, 1])
        summed = summed.subs(m[2, 0], s2 - m[2, 1])
        summed = summed.subs(m[4, 0], s4 - m[4, 1])
        sr = m[r, 0] + m[r, 1]
        assert sp.factor(summed - (sr - rhs)) == 0

    return {
        'pivot_rows': pivot_rows,
        'pivot_cols': pivot_cols,
        'pivot_determinant': -8,
        'homogeneous_system_determinant': str(determinant),
        'multiaffine_factor_corner_values': corner_values,
        'conclusion': 'rank<=4 and strict defects force column_1=-column_0; a primal vertex-pair is duplicated',
    }


def main() -> None:
    cert = json.loads(CERT_PATH.read_text())
    assert cert['global_templates'] == 62
    assert len(cert['records']) == 62
    expected_counts = {
        'fails_guberman_facet_condition': 13,
        'rank_ge_5': 34,
        'antipodal_duplicate_columns': 1,
        'insufficient_vertex_facets': 1,
        'algebraic_survivor': 13,
    }
    assert cert['classification'] == expected_counts

    keys = {int(i): k for i, k in (line.split() for line in UNIQUE.read_text().splitlines() if line.strip())}
    assert len(keys) == 62
    by_id = {r['canonical_id']: r for r in cert['records']}
    assert set(keys) == set(by_id)

    status_counts = Counter()
    id19_certificate = None
    for cid in sorted(keys):
        rec = by_id[cid]
        rows = decode_key(keys[cid])
        assert rows == rec['rows']
        assert sorted(sum(x == 0 for x in row) for row in rows) == [1]*4 + [2]*7
        single_cols = [row.index(0) for row in rows if sum(x == 0 for x in row) == 1]
        assert len(single_cols) == 4 and len(set(single_cols)) == 4

        comb = exact_combinatorics(rows)
        assert comb == rec['combinatorics']
        assert comb['guberman_vertex_ok']
        status = rec['status']
        status_counts[status] += 1

        if status == 'fails_guberman_facet_condition':
            assert not comb['guberman_facet_ok']
        elif status == 'rank_ge_5':
            assert comb['guberman_facet_ok']
            verify_minor(rows, rec['minor_certificate'])
        elif status == 'antipodal_duplicate_columns':
            assert cid == 19 and comb['guberman_facet_ok']
            id19_certificate = verify_id19_antipodal_columns(rows)
        elif status == 'insufficient_vertex_facets':
            assert cid == 22 and comb['guberman_facet_ok']
            incidence = sum(row[0] != 0 for row in rows)
            assert incidence == 3
        elif status == 'algebraic_survivor':
            assert comb['guberman_facet_ok']
        else:
            raise AssertionError(status)

    assert dict(status_counts) == expected_counts
    assert id19_certificate is not None
    survivors = [r['canonical_id'] for r in cert['records'] if r['status'] == 'algebraic_survivor']
    assert survivors == [20, 27, 28, 29, 32, 33, 34, 43, 49, 51, 67, 69, 71]

    result = {
        'status': 'PASS',
        'scope': '12V/22F, c=0, D=18 local-minimizer preclassification',
        'templates_checked': 62,
        'classification': expected_counts,
        'remaining_survivor_ids': survivors,
        'id19_exact_column_loss_certificate': id19_certificate,
        'source_hashes': {
            str(CERT_PATH): sha256(CERT_PATH),
            str(UNIQUE): sha256(UNIQUE),
            str(MINOR_FILE): sha256(MINOR_FILE),
        },
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
