#!/usr/bin/env python3
"""Exact rank-completion and strict-domain verifier for D=18 survivor 20.

This does NOT close the Mahler family.  It proves that the strict rank-four
branch is a unique rational four-parameter family and gives its complete
strict realization domain (two symmetric open charts plus their common wall).
"""
from __future__ import annotations

import itertools
import json
import math
from pathlib import Path

import sympy as sp

UNIQUE = Path('/mnt/data/viterbo_d18_work/unique_d18.txt')
OUT = Path('/mnt/data/viterbo_22f_d18_family20_rank_domain_verifier_output.json')
CERT = Path('/mnt/data/viterbo_22f_d18_family20_rank_domain_certificate.json')


def tensor_bernstein(poly: sp.Expr, variables: tuple[sp.Symbol, ...]):
    p = sp.Poly(sp.expand(poly), *variables)
    degrees = p.degree_list()
    powers = {mon: sp.Rational(co) for mon, co in p.terms()}
    coeffs = []
    for beta in itertools.product(*[range(d + 1) for d in degrees]):
        value = sp.Rational(0)
        for alpha, co in powers.items():
            if all(alpha[j] <= beta[j] for j in range(len(variables))):
                weight = sp.Rational(1)
                for j in range(len(variables)):
                    weight *= sp.Rational(
                        math.comb(beta[j], alpha[j]),
                        math.comb(degrees[j], alpha[j]),
                    )
                value += co * weight
        coeffs.append(value)
    return degrees, coeffs


def sign_certificate(poly: sp.Expr, variables: tuple[sp.Symbol, ...]):
    poly = sp.factor(poly)
    if poly == 0:
        return {'sign': 'zero', 'degree': [], 'positive': 0, 'zero': 1}
    for sign, label in ((1, 'positive'), (-1, 'negative')):
        degree, coeffs = tensor_bernstein(sign * poly, variables)
        if all(c >= 0 for c in coeffs) and any(c > 0 for c in coeffs):
            positives = [c for c in coeffs if c > 0]
            return {
                'sign': label,
                'degree': list(map(int, degree)),
                'positive': sum(bool(c > 0) for c in coeffs),
                'zero': sum(bool(c == 0) for c in coeffs),
                'min_positive': str(min(positives)),
            }
    raise AssertionError(f'No Bernstein sign certificate for {sp.factor(poly)}')


def decode_template(cid: int = 20):
    keys = {int(i): key for i, key in (line.split() for line in UNIQUE.read_text().splitlines() if line.strip())}
    vals = [ord(c) - ord('1') for c in keys[cid]]
    return [vals[6*i:6*i+6] for i in range(11)]


def main():
    rows = decode_template(20)
    matrix = sp.zeros(11, 6)
    variables = []
    for i, row in enumerate(rows):
        for j, z in enumerate(row):
            if z == 0:
                x = sp.symbols(f'x{i}_{j}')
                variables.append(x)
                matrix[i, j] = x
            else:
                matrix[i, j] = z

    pivot_rows = [0, 1, 4, 10]
    pivot_cols = [2, 3, 4, 5]
    pivot = matrix.extract(pivot_rows, pivot_cols)
    assert pivot.det() == 8
    other_rows = [i for i in range(11) if i not in pivot_rows]
    other_cols = [j for j in range(6) if j not in pivot_cols]
    schur_matrix = sp.simplify(
        matrix.extract(other_rows, other_cols)
        - matrix.extract(other_rows, pivot_cols) * pivot.inv() * matrix.extract(pivot_rows, other_cols)
    )
    equations = [sp.factor(e) for e in list(schur_matrix)]

    a = matrix[4, 0]
    b = matrix[7, 2]
    c = matrix[8, 3]
    d = matrix[10, 1]
    free = (a, b, c, d)
    dependent = [x for x in variables if x not in free]

    field = sp.QQ.frac_field(*free)
    groebner = sp.groebner(
        [sp.Poly(e, *dependent, domain=field).as_expr() for e in equations],
        *dependent,
        order='lex',
        domain=field,
    )
    assert groebner.is_zero_dimensional and len(groebner.polys) == 14
    solutions = sp.solve(equations, dependent, dict=True, simplify=False)
    assert len(solutions) == 1
    solution = {x: sp.factor(v) for x, v in solutions[0].items()}
    assert all(sp.factor(e.subs(solution)) == 0 for e in equations)

    # Full-domain converse inequalities.
    K = 3 - b - c - b*c
    assert sp.factor(K - (3 - b - c - b*c)) == 0
    ub = sp.factor(1 - 4*(1-b)/K)
    uc = sp.factor(1 - 4*(1-c)/K)
    assert sp.factor(solution[matrix[1, 1]] - (d + 4*(1-b)/K)) == 0
    assert sp.factor(solution[matrix[2, 1]] - (-d - 4*(1-c)/K)) == 0
    assert sp.factor(ub + 1 - 2*(1-c)*(1+b)/K) == 0
    assert sp.factor(uc + 1 - 2*(1-b)*(1+c)/K) == 0

    # Exact template symmetry interchanging b and c, fixing a and d.
    perm = (0, 1, 3, 2, 4, 5)
    flips = (-1, -1, -1, -1, -1, -1)
    normalized_rows = tuple(sorted(tuple(r) for r in rows))
    transformed = []
    for row in rows:
        t = [0] * 6
        for k in range(6):
            t[perm[k]] = flips[k] * row[k]
        first = next(x for x in t if x)
        if first < 0:
            t = [-x for x in t]
        transformed.append(tuple(t))
    assert tuple(sorted(transformed)) == normalized_rows

    # Chart b<c.  The opposite chamber is obtained by the exact symmetry.
    A, B, C, T = sp.symbols('A B C T')
    chart_vars = (A, B, C, T)
    chart = {
        a: 2*A - 1,
        b: 2*B - 1,
        c: 2*B - 1 + 2*(1-B)*C,
    }
    chart_K = sp.factor(K.subs(chart))
    assert sp.factor(chart_K - 4*(1-B)*(1+B-B*C)) == 0
    chart_ub_plus_1 = sp.factor((ub + 1).subs(chart))
    assert sp.factor(chart_ub_plus_1 - 2*B*(1-C)/(1+B-B*C)) == 0
    chart[d] = -1 + chart_ub_plus_1*T

    strict_stats = {}
    denominator_stats = {}
    for x in variables:
        expression = sp.cancel(solution.get(x, x).subs(chart))
        num, den = sp.fraction(sp.cancel(1 - expression**2))
        num_cert = sign_certificate(num, chart_vars)
        den_cert = sign_certificate(den, chart_vars)
        assert num_cert['sign'] == 'positive' and den_cert['sign'] == 'positive'
        strict_stats[str(x)] = {'numerator': num_cert, 'denominator': den_cert}
        _, expression_den = sp.fraction(expression)
        denominator_stats[str(x)] = sign_certificate(expression_den, chart_vars)

    # Common wall b=c is C=0 and remains strict for 0<A,B,T<1.
    wall_vars = (A, B, T)
    wall_stats = {}
    for x in variables:
        expression = sp.cancel(solution.get(x, x).subs(chart).subs(C, 0))
        num, den = sp.fraction(sp.cancel(1 - expression**2))
        nc = sign_certificate(num, wall_vars)
        dc = sign_certificate(den, wall_vars)
        assert nc['sign'] == 'positive' and dc['sign'] == 'positive'
        wall_stats[str(x)] = {'numerator': nc, 'denominator': dc}

    cert = {
        'scope': '12V/22F, c=0, D=18, canonical survivor 20',
        'status': 'exact_rank_completion_and_strict_domain_only',
        'not_yet_certified': [
            'global section closure/extremality over the whole domain',
            'exact primal and polar volume formulas',
            'Mahler-margin positivity',
        ],
        'pivot': {'rows': pivot_rows, 'cols': pivot_cols, 'determinant': 8},
        'rank_ideal': {
            'defect_variables': 18,
            'free_variables': [str(x) for x in free],
            'dependent_variables': [str(x) for x in dependent],
            'groebner_basis_length': len(groebner.polys),
            'zero_dimensional_over_free_parameter_field': True,
            'unique_solution': {str(x): str(v) for x, v in solution.items()},
        },
        'full_strict_domain': {
            'formula': '-1<a,b,c<1 and -1<d<min(U_b,U_c)',
            'K': str(K),
            'U_b': str(ub),
            'U_c': str(uc),
            'chart_b_less_c': {
                'a': str(chart[a]),
                'b': str(chart[b]),
                'c': str(chart[c]),
                'd': str(chart[d]),
                'parameters': '0<A,B,C,T<1',
            },
            'other_chamber': 'obtained by the exact b<->c template symmetry',
            'common_wall': 'b=c, certified separately by C=0',
        },
        'strict_defect_bernstein_certificates_chart': strict_stats,
        'solution_denominator_sign_certificates_chart': denominator_stats,
        'strict_defect_bernstein_certificates_wall': wall_stats,
        'template_symmetry': {'perm': perm, 'flips': flips, 'action_on_free_parameters': 'a,d fixed; b,c exchanged'},
    }
    CERT.write_text(json.dumps(cert, indent=2, sort_keys=True))
    result = {
        'status': 'PASS',
        'canonical_survivor': 20,
        'rank_completion': 'unique rational four-parameter branch',
        'strict_domain': cert['full_strict_domain']['formula'],
        'chart_certified_defects': len(strict_stats),
        'wall_certified_defects': len(wall_stats),
        'certificate': str(CERT),
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
