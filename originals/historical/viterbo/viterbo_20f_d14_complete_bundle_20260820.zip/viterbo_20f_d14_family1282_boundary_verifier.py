#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
import numpy as np
import sympy as sp

OUT=Path('/mnt/data/viterbo_20f_d14_family1282_boundary_verifier_output.json')
SOURCE=Path('/mnt/data/viterbo_20f_d15_complete_and_d14_preclassification_bundle_20260820.zip')
SHA='8cb0e7c09e3121dab8e6675d54bebfc2fd654183a1f1da06735bb960c4806c46'
IDX=1282;RS=(2,4,6,7);CS=(1,2,4,5)

def main():
 with zipfile.ZipFile(SOURCE) as z:raw=z.read('viterbo_d14_work/unique_templates.txt')
 assert hashlib.sha256(raw).hexdigest()==SHA;key=raw.decode().splitlines()[IDX]
 T=np.array([[int(ch)-1 for ch in key[6*i:6*i+6]] for i in range(10)],int);rows=[]
 for i in range(10):
  row=[]
  for j in range(6):
   row.append(sp.Symbol(f'x{i}_{j}') if T[i,j]==0 else sp.Integer(T[i,j]))
  rows.append(row)
 M=sp.Matrix(rows);P=M.extract(RS,CS);assert P.det()==8
 rr=[i for i in range(10) if i not in RS];cc=[j for j in range(6) if j not in CS]
 S=(M.extract(rr,cc)-M.extract(rr,CS)*P.inv()*M.extract(RS,cc)).applyfunc(sp.factor)
 # Relevant Schur entries, in row-major order.
 e5=sp.factor(2*S[2,1])   # (x3_4*x7_3-x3_4+2*x6_3-x7_3-1)
 e6=sp.factor(-2*S[3,0])  # (x2_0+1)*(x4_4-x5_4)
 e7=sp.factor(-2*S[3,1])
 x20,x34,x44,x54,x63,x73=sp.symbols('x2_0 x3_4 x4_4 x5_4 x6_3 x7_3')
 assert sp.factor(e6-(x20+1)*(x44-x54))==0
 # In a strict defect branch x20 != -1, hence x44=x54.
 e7eq=sp.factor(e7.subs(x54,x44))
 assert sp.factor(e7eq-2*(x73-x63))==0
 # Hence x63=x73. Substitution in e5 forces (x34+1)(x73-1)=0.
 e5eq=sp.factor(e5.subs(x63,x73))
 assert sp.factor(e5eq-(x34+1)*(x73-1))==0
 out={
  'status':'PASS','scope':'12V/20F,c=0,D=14','template_index':IDX,'pivot':{'rows':list(RS),'cols':list(CS),'det':8},
  'exact_chain':[
   '(x2_0+1)(x4_4-x5_4)=0',
   'strict x2_0>-1 implies x4_4=x5_4',
   'then Schur equation implies x6_3=x7_3',
   'then (x3_4+1)(x7_3-1)=0',
   'strict x3_4>-1 implies x7_3=1, contradicting |x7_3|<1'
  ],
  'conclusion':'no strict rank-four realization; every algebraic branch meets the defect boundary'
 }
 OUT.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
