#!/usr/bin/env python3
from __future__ import annotations
import hashlib,itertools,json,math,zipfile
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull

OUT=Path('/mnt/data/viterbo_20f_d14_four_families_verifier_output.json')
SOURCE=Path('/mnt/data/viterbo_20f_d15_complete_and_d14_preclassification_bundle_20260820.zip')
SHA='8cb0e7c09e3121dab8e6675d54bebfc2fd654183a1f1da06735bb960c4806c46'
A,B,C=sp.symbols('A B C',real=True); VARS=(A,B,C)

CFG={
1102:{'free':['x0_1','x2_0','x5_3'],'map':{'x0_1':2*A-1,'x2_0':2*B-1,'x5_3':2*C-1},'sample':{A:sp.Rational(1,3),B:sp.Rational(2,5),C:sp.Rational(1,4)},'domain':'(-1,1)^3','pivot':((2,3,4,6),(1,2,3,5))},
2503:{'free':['x5_5','x7_5','x9_1'],'map':{'x5_5':2*A-1,'x7_5':2*B-1,'x9_1':2*C-1},'sample':{A:sp.Rational(1,3),B:sp.Rational(2,5),C:sp.Rational(1,4)},'domain':'(-1,1)^3'},
3775:{'free':['x0_1','x4_0','x8_3'],'map':{'x0_1':2*(A+C-A*C)-1,'x4_0':2*B-1,'x8_3':2*C-1},'sample':{A:sp.Rational(1,3),B:sp.Rational(2,5),C:sp.Rational(1,4)},'domain':'-1<x8_3<x0_1<1, -1<x4_0<1'},
4300:{'free':['x4_5','x8_1','x9_4'],'map':{'x4_5':2*A-1,'x8_1':2*B-1,'x9_4':2*C-1},'sample':{A:sp.Rational(1,3),B:sp.Rational(2,5),C:sp.Rational(1,4)},'domain':'(-1,1)^3'},
4304:{'free':['x1_0','x4_5','x7_1'],'map':{'x1_0':2*A-1,'x4_5':2*B-1,'x7_1':2*C-1},'sample':{A:sp.Rational(1,3),B:sp.Rational(2,5),C:sp.Rational(1,4)},'domain':'(-1,1)^3'},
}

def lines():
 with zipfile.ZipFile(SOURCE) as z: raw=z.read('viterbo_d14_work/unique_templates.txt')
 assert hashlib.sha256(raw).hexdigest()==SHA
 return raw.decode().splitlines()

def bern(poly):
 P=sp.Poly(sp.expand(poly),*VARS,domain='QQ'); deg=tuple(map(int,P.degree_list())); co=dict(P.terms()); arr=[]
 for ii in itertools.product(*[range(d+1) for d in deg]):
  z=sp.Rational(0)
  for kk,cc in co.items():
   if all(kk[j]<=ii[j] for j in range(3)):
    f=sp.Rational(1)
    for j,d in enumerate(deg): f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
    z+=cc*f
  arr.append(sp.factor(z))
 return deg,arr

def project3(x):
 d=x-x[0]; return d@np.linalg.svd(d,full_matrices=False)[2][:3].T

def pull(ids,coords):
 ids=sorted(ids)
 if len(ids)==4:return [tuple(ids)]
 pr=project3(coords[ids]); h=ConvexHull(pr); out=set()
 for tri,e in zip(h.simplices,h.equations):
  if abs(float(e[:-1]@pr[0]+e[-1]))<1e-8:continue
  out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
 return sorted(out)

def sphere(tets):
 tri=Counter(tuple(sorted(z)) for t in tets for z in itertools.combinations(t,3)); assert set(tri.values())=={2}
 return {'tetrahedra':len(tets),'triangles':len(tri),'vertices':12}

def balls(tets,facets):
 out=[]
 for f in facets:
  g=[t for t in tets if set(t)<=set(f)]; assert g and set(x for t in g for x in t)==set(f)
  tri=Counter(tuple(sorted(z)) for t in g for z in itertools.combinations(t,3)); assert max(tri.values())<=2
  bt=[z for z,n in tri.items() if n==1]; vs=set(x for z in bt for x in z); es=set(tuple(sorted(e)) for z in bt for e in itertools.combinations(z,2)); assert len(vs)-len(es)+len(bt)==2
  out.append(len(g))
 return out

def derive(idx,key,free_names,pivot=None):
 T=np.array([[int(ch)-1 for ch in key[6*i:6*i+6]] for i in range(10)],int)
 vars=[]; rows=[]
 for i in range(10):
  row=[]
  for j in range(6):
   if T[i,j]==0:
    x=sp.Symbol(f'x{i}_{j}'); vars.append(x); row.append(x)
   else: row.append(sp.Integer(T[i,j]))
  rows.append(row)
 M=sp.Matrix(rows)
 if pivot is not None:
  rs,cs=pivot; pd=int(M.extract(rs,cs).det()); assert pd != 0
 else:
  piv=[]
  for rs in itertools.combinations(range(10),4):
   for cs in itertools.combinations(range(6),4):
    if any(T[i,j]==0 for i in rs for j in cs): continue
    d=int(M.extract(rs,cs).det())
    if d:piv.append((abs(d),d,rs,cs))
  piv.sort(reverse=True); _,pd,rs,cs=piv[0]
 rr=[i for i in range(10) if i not in rs]; cc=[j for j in range(6) if j not in cs]
 P=M.extract(rs,cs); S=M.extract(rr,cc)-M.extract(rr,cs)*P.inv()*M.extract(rs,cc)
 polys=[]
 for e in S:
  n=sp.factor(sp.together(e).as_numer_denom()[0])
  if n!=0 and n not in polys:polys.append(n)
 free=[sp.Symbol(n) for n in free_names]; dep=[x for x in vars if x not in free]
 G=sp.groebner(polys,*dep,order='lex',domain=sp.QQ.frac_field(*free)); assert G.is_zero_dimensional and len(G.polys)==len(dep)
 sol={}
 for gp in G.polys:
  e=sp.factor(gp.as_expr())
  found=[x for x in dep if e.has(x) and sp.degree(e,x)==1 and all(not e.has(y) for y in dep if y!=x)]
  assert len(found)==1,(idx,e,found)
  sol[found[0]]=sp.factor(sp.solve(e,found[0])[0])
 assert set(sol)==set(dep)
 return T,M,vars,free,sol,pd,rs,cs

def verify(idx,cfg,key):
 T,M0,orig,free,sol,pd,rs,cs=derive(idx,key,cfg['free'],cfg.get('pivot'))
 mp={sp.Symbol(k):v for k,v in cfg['map'].items()}
 cache={}
 def pp(poly,label):
  poly=sp.factor(sp.cancel(poly).subs(mp)); k=sp.srepr(poly)
  if k not in cache:cache[k]=bern(poly)
  deg,arr=cache[k]; pos=[x for x in arr if x.is_positive]; zero=[x for x in arr if x.is_zero]; neg=[x for x in arr if x.is_negative]; unk=[x for x in arr if not(x.is_positive or x.is_zero or x.is_negative)]
  assert pos and not neg and not unk,(idx,label,poly,deg,neg[:3],unk[:3])
  return {'degree':list(deg),'positive':len(pos),'zero':len(zero),'negative':0,'unknown':0,'min_positive':str(min(pos))}
 def pr(expr,label):
  expr=sp.factor(sp.cancel(expr)); exprm=sp.factor(sp.cancel(expr.subs(mp))); val=sp.N(exprm.subs(cfg['sample']))
  assert val>0,(idx,label,val,expr)
  n,d=map(sp.factor,sp.together(exprm).as_numer_denom())
  if sp.N(d.subs(cfg['sample']))<0:n,d=-n,-d
  return {'numerator':pp(n,label+'N'),'denominator':pp(d,label+'D')}
 # completed M
 M=M0.subs(sol)
 assert len(orig)==14
 # rank branch exact
 rr=[i for i in range(10) if i not in rs];cc=[j for j in range(6) if j not in cs];P=M.extract(rs,cs)
 assert int(P.det())==pd or abs(int(P.det()))==abs(pd)
 S=M.extract(rr,cc)-M.extract(rr,cs)*P.inv()*M.extract(rs,cc); assert all(sp.factor(sp.cancel(e))==0 for e in S)
 # defects strict
 strict=[]
 for x in orig:
  e=x if x in free else sol[x]
  strict.append(pr(1-e**2,str(x)))
 # primal/polar factorization
 VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda x:sp.factor(sp.cancel(x)))
 FM=M.extract(range(10),cs)
 assert all(sp.factor(e)==0 for e in FM*VM-M)
 # extremality supporting determinants
 ext=[]
 for j in range(6):
  inc=[i for i in range(10) if T[i,j]!=0]; ok=False
  for z in itertools.combinations(inc,4):
   de=sp.factor(FM.extract(z,range(4)).det(method='domain-ge'))
   if de==0:continue
   sg=1 if sp.N(de.subs(mp).subs(cfg['sample']))>0 else -1
   try: ext.append(pr(sg*de,f'e{j}_{z}'));ok=True;break
   except AssertionError:pass
  assert ok,(idx,j)
 # sample geometry and facets
 sample_sub={k:sp.N(v.subs(cfg['sample'])) for k,v in mp.items()}
 Vnum=np.array(VM.subs(sample_sub),float);Fnum=np.array(FM.subs(sample_sub),float)
 ptsP=np.vstack([Vnum.T,-Vnum.T]);ptsQ=np.vstack([Fnum,-Fnum])
 assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
 facP=[];facQ=[]
 for i in range(10):facP += [sorted(j if T[i,j]==1 else j+6 for j in range(6) if T[i,j]),sorted(j+6 if T[i,j]==1 else j for j in range(6) if T[i,j])]
 for j in range(6):facQ += [sorted(i if T[i,j]==1 else i+10 for i in range(10) if T[i,j]),sorted(i+10 if T[i,j]==1 else i for i in range(10) if T[i,j])]
 tP=[t for f in facP for t in pull(f,ptsP)];tQ=[t for f in facQ for t in pull(f,ptsQ)]
 bp=balls(tP,facP);bq=balls(tQ,facQ); sph={'tetrahedra':len(tP),'vertices':12,'source_combinatorial_sphere':'preclassification-certificate'}
 def pv(i):return VM[:,i] if i<6 else -VM[:,i-6]
 def qv(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
 def ori(ts,point,name):
  out=[]
  for k,z in enumerate(ts):
   de=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in z]).det(method='domain-ge')))
   sg=1 if sp.N(de.subs(mp).subs(cfg['sample']))>0 else -1
   pr(sg*de,f'{name}{k}');out.append(sp.factor(sg*de))
  return out
 volP=sp.factor(sp.cancel(sum(ori(tP,pv,'P'))/24));volQ=sp.factor(sp.cancel(sum(ori(tQ,qv,'Q'))/24))
 margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=pr(margin,'margin')
 return {'template_index':idx,'status':'PASS','domain':cfg['domain'],'rank':4,'strict_defects':14,'primal_vertices':12,'polar_vertices':20,'pivot':{'det':int(P.det()),'rows':list(rs),'cols':list(cs)},'free_variables':cfg['free'],'solution':{str(x):str(sol[x]) for x in sol},'primal_tetrahedra':len(tP),'polar_tetrahedra':len(tQ),'primal_boundary':sph,'primal_facet_tetrahedra':bp,'polar_facet_tetrahedra':bq,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_numerator_bernstein':mc['numerator'],'margin_denominator_bernstein':mc['denominator'],'fixed_sign_polynomials_checked':len(cache)}

def main():
 ls=lines(); rec=[]
 for idx,cfg in CFG.items():
  rec.append(verify(idx,cfg,ls[idx])); print('PASS',idx,flush=True)
 out={'status':'PASS','scope':'12V/20F,c=0,D=14','closed_template_indices':list(CFG),'count':len(rec),'records':rec,'conclusion':'four additional rank-four families have Mahler product > 32/3'}
 OUT.write_text(json.dumps(out,indent=2)); print(json.dumps({'status':'PASS','closed':list(CFG),'output':str(OUT)},indent=2))
if __name__=='__main__':main()
