# 四维中心对称 Mahler：`12V/20F, c=0, D=14` 整层完成报告

日期：2026-08-20

## 结论

此前的直接组合预分类为

\[
4319
=
4024\text{ 个 rank}\ge5
+268\text{ 个重复 facet rows}
+27\text{ 个 algebraic survivors}.
\]

最后八个 survivors 已全部处理：

- `1102, 2503, 2742, 3775, 4300, 4304, 4318`：完整严格 realization space 上均有
  \[
  |P||P^\circ|>\frac{32}{3};
  \]
- `1282`：任何 rank-four 分支都被迫落到 defect endpoint，严格 interior 为空。

所以最终 accounting 是

\[
\boxed{
4319
=4024+268+8+3+15+1
}
\]

分别对应：

\[
\begin{array}{c|r}
\text{类型}&\text{数量}\\\hline
\operatorname{rank}\ge5&4024\\
\text{重复 facet rows}&268\\
\text{primal vertex loss}&8\\
\text{polar vertex loss}&3\\
\text{Mahler-positive families}&15\\
\text{strict rank-four boundary only}&1
\end{array}
\]

因此

\[
\boxed{12V/20F,\quad c=0,\quad D=14\quad\checkmark}
\]

其中勾号表示 **computer-assisted analytic proof candidate**。

## 新关闭的七个 Mahler-positive families

| Family | 参数域 | Margin Bernstein degree | 正系数 | 零系数 | 最小正系数 |
|---:|---|---:|---:|---:|---:|
| 1102 | `(-1,1)^3` | `(2,2,4)` | 23 | 22 | `2` |
| 2503 | `(-1,1)^3` | `(3,3,3)` | 39 | 25 | `16/9` |
| 3775 | `-1<x8_3<x0_1<1`, one free interval | `(5,2,4)` | 60 | 30 | `8/5` |
| 4300 | `(-1,1)^3` | `(3,2,3)` | 32 | 16 | `8/3` |
| 4304 | `(-1,1)^3` | `(2,3,3)` | 31 | 17 | `8/3` |
| 4318 | rational four-cube | `(2,5,2,5)` | 89 | 235 | `6/25` |
| 2742 | `0<A,B,C<1, C<A+B` | two charts + wall | no negative coefficients | — | `16/9`, `6`, wall `20/3` |

### Family 1282 的严格边界矛盾

选定恒非零 pivot 后，Schur equations 给出

\[
(x_{2,0}+1)(x_{4,4}-x_{5,4})=0.
\]

严格性给 `x_{2,0}>-1`，所以 `x_{4,4}=x_{5,4}`。随后依次得到

\[
x_{6,3}=x_{7,3},
\qquad
(x_{3,4}+1)(x_{7,3}-1)=0.
\]

又因 `x_{3,4}>-1`，只能有 `x_{7,3}=1`，与 strict defect 矛盾。

## 证明标准说明

对新增 Mahler-positive families，证书包含：

\[
\text{exact rank completion}
+\text{strict-domain parametrization}
+\text{primal/polar extremality}
+\text{facet-wise exact triangulations}
+\text{exact volumes}
+\text{Bernstein positivity}.
\]

个别五顶点 facets 的局部三角剖分在共享二维面上不必选同一条对角线；这不影响体积，因为共享边界为零测度。组合 sphere 和 facet incidences来自已哈希的直接预分类工件。
