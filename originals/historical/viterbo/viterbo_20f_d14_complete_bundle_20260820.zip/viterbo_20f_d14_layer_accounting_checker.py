#!/usr/bin/env python3
import json
from pathlib import Path
R=Path('/mnt/data')
s=json.loads((R/'viterbo_20f_d14_progress_v6_20260820.json').read_text())
a=s['accounting'];assert sum(v for k,v in a.items() if k!='total')==a['total']==4319
assert len(s['closed']['primal_vertex_loss'])==8
assert len(s['closed']['polar_vertex_loss'])==3
assert len(s['closed']['Mahler_positive'])==15
assert s['closed']['strict_rank4_empty_or_defect_boundary']==[1282]
for f in ['viterbo_20f_d14_four_families_verifier_output.json','viterbo_20f_d14_family4318_verifier_output.json','viterbo_20f_d14_family2742_verifier_output.json','viterbo_20f_d14_family1282_boundary_verifier_output.json']:
 d=json.loads((R/f).read_text());assert d['status']=='PASS'
print(json.dumps({'status':'PASS','scope':s['scope'],'accounting':a,'remaining':0},indent=2))
