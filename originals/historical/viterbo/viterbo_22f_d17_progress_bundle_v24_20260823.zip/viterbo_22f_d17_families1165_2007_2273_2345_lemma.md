# Four exact positive families in the 12V/22F, c=0, D=17 layer

Date: 2026-08-23

## Scope

This note records the exact closure of canonical Families 1165, 2007, 2273, and 2345 in the four-dimensional centrally symmetric Mahler bounded-12 program. Every checkmark below means **computer-assisted analytic proof candidate**. It does not assert external peer review or completion of the full four-dimensional conjecture.

All four families start from the original 11-by-6 pairing sign template. The verifier:

1. selects a constant nonzero 4-by-4 pivot;
2. reconstructs the strict rank-four branch from the Schur-complement equations, retaining coefficient-zero branches until strictness excludes them;
3. proves the stated strict realization domain by exact rational inequalities;
4. recovers the original simplicial 3-sphere from the preclassification local matching and transports it to canonical signed-coordinate labels;
5. certifies 12 primal vertices and exactly 22 polar-section vertices;
6. computes exact primal and polar volumes from globally fixed-sign tetrahedral decompositions;
7. proves the Mahler margin by tensor-Bernstein positivity.

## Family 1165

The strict branch contains

\[
x_{4,3}=-x_{7,3}.
\]

With

\[
p=x_{2,1},\qquad t=x_{7,3},\qquad s=x_{8,4},
\]

the complete strict domain is

\[
-1<t,s<1,
\qquad
\frac{1-t}{t+3}<p<1.
\]

It is rationally equivalent to the open unit cube via

\[
t=2T-1,\qquad s=2S-1,
\qquad
p=\frac{1-T+2AT}{1+T},
\qquad0<A,T,S<1.
\]

The original simplicial sphere comes from local matching 1270, sphere orbit 5. Its exact signed-coordinate transport uses permutation

\[
(0,1,2,3,5,4)
\]

and signs

\[
(1,1,1,1,-1,1).
\]

The verifier obtains 32 primal tetrahedra and 76 polar-facet tetrahedra. The Mahler-margin numerator has Bernstein degree \((4,8,2)\), with

\[
111>0,\qquad24=0,\qquad0<0,
\]

and minimum positive coefficient \(2\). Hence

\[
\mathcal P(P)>\frac{32}{3}
\]

throughout the full strict domain.

## Family 2007

The strict rank-four branch forces

\[
x_{0,1}=x_{1,1}.
\]

Let

\[
a=x_{0,1},\qquad b=x_{5,3},\qquad c=x_{8,5}.
\]

The complete strict domain is

\[
-1<a,c<1,
\qquad
\frac{a-1}{a+3}<b<1.
\]

A unit-cube chart is

\[
a=2A-1,\qquad c=2C-1,
\qquad
b=\frac{A-1+2B}{A+1},
\qquad0<A,B,C<1.
\]

The transported source triangulation comes from local matching 1322, sphere orbit 5, with signed-coordinate permutation

\[
(0,3,4,1,2,5),
\qquad
(1,1,1,1,-1,1).
\]

The verifier obtains 32 primal tetrahedra and 79 polar tetrahedra. The margin numerator has Bernstein degree \((6,4,2)\):

\[
92>0,\qquad13=0,\qquad0<0,
\]

with minimum positive coefficient \(4\). Thus the entire family is strictly above \(32/3\).

## Family 2273

The strict rank-four branch forces

\[
x_{4,5}=-x_{5,4}.
\]

Using

\[
a=x_{5,4},\qquad b=x_{6,3},\qquad c=x_{9,5},
\]

the full domain is simply

\[
-1<a<c<1,
\qquad
-1<b<1.
\]

A unit-cube chart is

\[
a=2A-1,\qquad b=2B-1,
\qquad c=a+2(1-A)C,
\qquad0<A,B,C<1.
\]

The exact source is local matching 1772, sphere orbit 7, transported by

\[
(1,0,5,4,2,3),
\qquad
(1,1,1,1,1,-1).
\]

The verifier uses 32 primal and 77 polar tetrahedra. The margin numerator has Bernstein degree \((4,3,4)\):

\[
67>0,\qquad33=0,\qquad0<0,
\]

with minimum positive coefficient \(1\). Therefore the Mahler product is strictly larger than \(32/3\) throughout the full domain.

## Family 2345

This family has two useful strict-branch relations:

\[
x_{4,2}=-x_{5,2},
\]

and

\[
2x_{10,3}=x_{6,3}x_{8,5}+x_{6,3}-x_{8,5}+1.
\]

Set

\[
a=x_{5,2},\qquad b=x_{6,3},\qquad c=x_{8,5}.
\]

After exact triangular Schur elimination, every remaining defect is a rational function of \((a,b,c)\). All strict inequalities hold precisely on the full open cube

\[
\boxed{-1<a,b,c<1}.
\]

Thus one may use

\[
a=2A-1,\qquad b=2B-1,\qquad c=2C-1,
\qquad0<A,B,C<1.
\]

The source is local matching 2203, sphere orbit 8, transported by

\[
(0,2,3,1,5,4),
\qquad
(1,-1,-1,-1,-1,1).
\]

The verifier obtains 32 primal and 77 polar tetrahedra. The margin numerator has Bernstein degree \((3,3,5)\):

\[
65>0,\qquad31=0,\qquad0<0,
\]

with minimum positive coefficient

\[
\frac{16}{15}.
\]

The denominator has degree \((2,2,2)\), with 23 positive and 4 zero coefficients, and minimum positive coefficient \(9/2\). Consequently

\[
\mathcal P(P)>\frac{32}{3}
\]

on the whole strict realization space.

## Updated accounting

The D=17 layer now has ten exact Mahler-positive families:

\[
606,757,768,952,1165,1440,1446,2007,2273,2345.
\]

The disjoint accounting is

\[
\begin{aligned}
2395={}&1230\text{ facet-containment templates}\\
&+1070\text{ antichain rank-}\ge5\text{ templates}\\
&+22\text{ segment vertex-loss templates}\\
&+4\text{ duplicate/antipodal primal-pair templates}\\
&+10\text{ exact Mahler-positive families}\\
&+13\text{ strict boundary/interval-impossible families}\\
&+46\text{ remaining algebraic survivors}.
\end{aligned}
\]

At the original survivor level,

\[
121=26+22+4+10+13+46.
\]
