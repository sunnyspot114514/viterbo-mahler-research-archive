#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 2273."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import viterbo_22f_d17_family768_verifier as base
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json');CERT=Path('/mnt/data/viterbo_22f_d17_family2273_certificate.json');OUT=Path('/mnt/data/viterbo_22f_d17_family2273_verifier_output.json');CID=2273
PRIMAL_TETRAHEDRA=[
(0,2,5,7),(0,2,5,9),(0,2,7,10),(0,2,9,10),(0,3,5,7),(0,3,5,8),
(0,3,7,10),(0,3,8,10),(0,5,8,9),(0,8,9,10),(1,4,6,8),(1,4,6,9),
(1,4,8,9),(1,6,8,11),(1,6,9,11),(1,8,9,11),(2,3,4,5),(2,3,4,6),
(2,3,5,7),(2,3,6,11),(2,3,7,10),(2,3,10,11),(2,4,5,9),(2,4,6,9),
(2,6,9,11),(2,9,10,11),(3,4,5,8),(3,4,6,8),(3,6,8,11),(3,8,10,11),
(4,5,8,9),(8,9,10,11)]
def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,val in enumerate(row):
   if val==0:z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=val
 rr=(0,1,3,8);cc=(2,3,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 eq=[sp.factor(sp.cancel(z)) for z in M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ)]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 rel1=-(x['x4_5']+x['x5_4'])*(x['x8_1']-1)/2;ratio1=base.proportional_member(rem,rel1)
 a,b,c=sp.symbols('a b c',real=True)
 x20=sp.factor((a-c+2)/(a-c-2));x81=sp.factor((a-b-c+1)/(a+b-c-1));x74=sp.factor((a*b+a+b-2*c+1)/2);x65=-x74
 stage=dict(const);stage.update({x['x5_4']:a,x['x4_5']:-a,x['x6_3']:b,x['x7_3']:b,x['x9_5']:c,x['x10_4']:-c,x['x6_5']:x65,x['x7_4']:x74,x['x2_0']:x20,x['x8_1']:x81})
 sol={z:base.apply_all(z,stage) for z in vs};X=M.subs(sol).applyfunc(lambda z:sp.factor(sp.cancel(z)));assert all(base.apply_all(e,stage)==0 for e in eq)
 return rec,rows,M,vs,X,(a,b,c),rr,cc,sol,trace,ratio1

def main():
 rec,rows,M,vs,X,free,rr,cc,sol,trace,ratio1=build_branch();a,b,c=free
 A,B,C=sp.symbols('A B C',real=True);chart={a:2*A-1,b:2*B-1,c:2*A-1+2*(1-A)*C};cv=(A,B,C);sample={A:sp.Rational(1,3),B:sp.Rational(1,2),C:sp.Rational(1,2)};eng=base.SignEngine(cv,sample)
 coeff={
  'c_minus_a':eng.positive_rational((c-a).subs(chart),'c-a'),
  'minus_a_minus_c_minus_2':eng.positive_rational((-(a-c-2)).subs(chart),'-(a-c-2)'),
  'minus_a_plus_b_minus_c_minus_1':eng.positive_rational((-(a+b-c-1)).subs(chart),'-(a+b-c-1)'),
  'minus_F':eng.positive_rational((-(a*b+a+b-2*c-1)).subs(chart),'-F')}
 X=X.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)));pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'ext{j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found;ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),float);fn=np.array(F.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP=list(PRIMAL_TETRAHEDRA);assert len(tetP)==len(set(tetP))==32;pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([k for k,f in enumerate(facP) if set(tet)<=set(f)])==1
 tetQ=[z for f in facQ for z in base.pulling_triangulation(f,ptsQ)];assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0;sg=1 if det.subs(sample)>0 else -1;ce=eng.positive_rational(sg*det,f'{label}{k}');terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'P');qt,qr=oriented(tetQ,pointQ,'Q');volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=eng.positive_rational(margin,'margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2273','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,'rank_trace':{'constant_elimination_steps':trace,'strict_relation':'x4_5=-x5_4','relation_ratio':ratio1},'coefficient_certificates':coeff,'parameters':['A','B','C'],'parameter_domain':'0<A,B,C<1; a=2A-1, b=2B-1, c=a+2(1-A)C, equivalently -1<a<c<1 and -1<b<1','completion':{str(k):str(v) for k,v in sol.items()},'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'primal_triangulation_source':{'source_local_id':1772,'source_sphere_orbit':7,'signed_coordinate_permutation':{'permutation':[1,0,5,4,2,3],'signs':[1,1,1,1,1,-1]}},'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 2273 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
