#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json
from pathlib import Path
ROOT=Path('/mnt/data')
OLD=ROOT/'viterbo_22f_d17_progress_accounting_certificate_v6.json'
OLD_OUT=ROOT/'viterbo_22f_d17_progress_accounting_verifier_output_v6.json'
CERT=ROOT/'viterbo_22f_d17_progress_accounting_certificate_v7.json'
OUT=ROOT/'viterbo_22f_d17_progress_accounting_verifier_output_v7.json'
FAMILIES=[1165,2007,2273,2345]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 old=json.loads(OLD.read_text());oldout=json.loads(OLD_OUT.read_text())
 assert old['status']=='PASS' and oldout['status']=='PASS' and oldout['remaining_algebraic_survivors']==50
 oldrem=set(old['remaining_ids']);assert set(FAMILIES)<=oldrem
 reruns={}
 for cid in FAMILIES:
  script=ROOT/f'viterbo_22f_d17_family{cid}_verifier.py';outpath=ROOT/f'viterbo_22f_d17_family{cid}_verifier_output.json'
  out=json.loads(outpath.read_text());assert out['status']=='PASS' and out['canonical_id']==cid
  assert out['rank']==4 and out['strict_defects']==17 and out['primal_vertices']==12 and out['polar_vertices']==22
  assert out['tetrahedra_primal']==32 and out['tetrahedra_polar']>0
  assert sha(out['certificate'])==out['certificate_sha256']
  reruns[str(cid)]={'script_sha256':sha(script),'output_sha256':sha(outpath),'certificate_sha256':out['certificate_sha256'],'status':'PASS','tetrahedra_primal':out['tetrahedra_primal'],'tetrahedra_polar':out['tetrahedra_polar'],'margin_certificate':out['margin_certificate']}
 rem=sorted(oldrem-set(FAMILIES));mahler=sorted(set(old['Mahler_positive_exact_families'])|set(FAMILIES))
 dis={'facet_containment':1230,'rank_ge_5_after_antichain':1070,'segment_loss_after_antichain':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':len(mahler),'strict_rank4_boundary_or_interval_impossible':13,'remaining_algebraic_survivors':len(rem)}
 assert sum(dis.values())==2395
 surv={'initial':121,'facet_containment':26,'additional_segment_loss':22,'forced_duplicate_or_antipodal_primal_pair':4,'Mahler_positive_exact_family':len(mahler),'strict_rank4_boundary_or_interval_impossible':13,'remaining':len(rem)}
 assert sum(v for k,v in surv.items() if k!='initial')==surv['initial']
 cert={'status':'PASS','scope':old['scope'],'scope_warning':old['scope_warning'],'total_pairing_templates':2395,'disjoint_classification':dis,'survivor_level_accounting':surv,'Mahler_positive_exact_families':mahler,'strict_rank4_boundary_or_interval_impossible':old['strict_rank4_boundary_or_interval_impossible'],'remaining_ids':rem,'newly_closed':{'Mahler_positive_exact':FAMILIES},'verified_outputs':reruns,'source_hashes':{str(OLD):sha(OLD),str(OLD_OUT):sha(OLD_OUT),str(ROOT/'viterbo_22f_d17_preclassification_certificate.json'):sha(ROOT/'viterbo_22f_d17_preclassification_certificate.json')}}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True))
 result={'status':'PASS','total_pairing_templates':2395,'initial_algebraic_survivors':121,'Mahler_positive_exact_families':mahler,'newly_closed':FAMILIES,'remaining_algebraic_survivors':len(rem),'accounting_certificate':str(CERT),'accounting_certificate_sha256':sha(CERT),'verified_outputs':reruns}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
