#!/usr/bin/env python3
"""Exact verifier for 12V/22F,c=0,D=17 canonical Family 2007."""
from __future__ import annotations
import hashlib,itertools,json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
import viterbo_22f_d17_family768_verifier as base
PRE=Path('/mnt/data/viterbo_22f_d17_preclassification_certificate.json');CERT=Path('/mnt/data/viterbo_22f_d17_family2007_certificate.json');OUT=Path('/mnt/data/viterbo_22f_d17_family2007_verifier_output.json');CID=2007
PRIMAL_TETRAHEDRA=[
(0,1,5,8),(0,1,5,9),(0,1,8,10),(0,1,9,10),(0,5,8,10),(0,5,9,10),
(1,2,4,5),(1,2,4,11),(1,2,5,9),(1,2,9,11),(1,4,5,8),(1,4,8,11),
(1,8,10,11),(1,9,10,11),(2,4,5,7),(2,4,6,7),(2,4,6,11),(2,5,7,10),
(2,5,9,10),(2,6,7,11),(2,7,10,11),(2,9,10,11),(3,4,5,7),(3,4,5,8),
(3,4,6,7),(3,4,6,11),(3,4,8,11),(3,5,7,8),(3,6,7,11),(3,7,8,11),
(5,7,8,10),(7,8,10,11)]
def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def build_branch():
 rec=json.loads(PRE.read_text())['records'][CID];rows=rec['rows'];M=sp.zeros(11,6);vs=[];x={}
 for i,row in enumerate(rows):
  for j,val in enumerate(row):
   if val==0:z=sp.Symbol(f'x{i}_{j}',real=True);M[i,j]=z;vs.append(z);x[str(z)]=z
   else:M[i,j]=val
 rr=(2,3,6,9);cc=(1,2,4,5);P=M.extract(rr,cc);assert P.det(method='domain-ge')==8
 orr=[i for i in range(11) if i not in rr];occ=[j for j in range(6) if j not in cc]
 eq=[sp.factor(sp.cancel(z)) for z in M.extract(orr,occ)-M.extract(orr,cc)*P.inv()*M.extract(rr,occ)]
 const,uns,rem,trace=base.constant_eliminate(eq,vs)
 rel=-(x['x0_1']-x['x1_1'])*(x['x5_3']-1)*(x['x8_5']+1)/4;relratio=base.proportional_member(rem,rel)
 a,b,c=sp.symbols('a b c',real=True)
 L=sp.factor(a*b-a+b+3);coef=sp.factor(a**2*b-a**2+4*a-5*b-7);D=sp.factor(a*b-a-b*c+2*b-c+4)
 x44=sp.factor((a*b-a-3*b-1)/L)
 x72=sp.factor(-(a**2*b-a**2+4*a*b-b+5)/coef)
 x71=sp.factor((a*x72+a-x72+1)/2)
 x50=sp.factor((a*b-a+b*c+c+2)/D)
 stage=dict(const);stage.update({x['x0_1']:a,x['x1_1']:a,x['x5_3']:b,x['x8_5']:c,x['x4_4']:x44,x['x10_4']:x44,x['x7_2']:x72,x['x7_1']:x71,x['x5_0']:x50})
 sol={z:base.apply_all(z,stage) for z in vs};X=M.subs(sol).applyfunc(lambda z:sp.factor(sp.cancel(z)));assert all(base.apply_all(e,stage)==0 for e in eq)
 return rec,rows,M,vs,X,(a,b,c),rr,cc,sol,trace,relratio,L,coef,D

def main():
 rec,rows,M,vs,X,free,rr,cc,sol,trace,relratio,L,coef,D=build_branch();a,b,c=free
 A,B,C=sp.symbols('A B C',real=True);chart={a:2*A-1,c:2*C-1,b:(A-1+2*B)/(A+1)};cv=(A,B,C);sample={A:sp.Rational(1,2),B:sp.Rational(1,2),C:sp.Rational(1,2)};eng=base.SignEngine(cv,sample)
 coeff={'L':eng.positive_rational(L.subs(chart),'L'),'-coef':eng.positive_rational((-coef).subs(chart),'-coef'),'D':eng.positive_rational(D.subs(chart),'D'),'A_plus_1':eng.positive_rational((A+1),'A+1')}
 X=X.subs(chart).applyfunc(lambda z:sp.factor(sp.cancel(z)));pivot=X.extract(rr,cc);assert pivot.det(method='domain-ge')==8
 V=(pivot.inv()*X.extract(rr,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z)));F=X.extract(range(11),cc);assert all(sp.factor(z)==0 for z in F*V-X)
 defects={}
 for z in vs:
  i,j=map(int,str(z)[1:].split('_'));defects[str(z)]=eng.positive_rational(1-X[i,j]**2,'defect '+str(z))
 ext=[]
 for j in range(6):
  inc=[i for i in range(11) if rows[i][j]!=0];found=None
  for rrr in itertools.combinations(inc,4):
   det=sp.factor(F.extract(rrr,range(4)).det(method='domain-ge'))
   if det==0:continue
   sg=1 if det.subs(sample)>0 else -1
   try:ce=eng.positive_rational(sg*det,f'ext{j}')
   except AssertionError:continue
   found={'vertex_pair':j,'facet_rows':list(rrr),'determinant':str(det),'certificate':ce};break
  assert found;ext.append(found)
 code=np.array(rows,int);facP=[]
 for i in range(11):facP += [sorted(j if code[i,j]==1 else j+6 for j in range(6) if code[i,j]),sorted(j+6 if code[i,j]==1 else j for j in range(6) if code[i,j])]
 facQ=[]
 for j in range(6):facQ += [sorted(i if code[i,j]==1 else i+11 for i in range(11) if code[i,j]),sorted(i+11 if code[i,j]==1 else i for i in range(11) if code[i,j])]
 vn=np.array(V.subs(sample),float);fn=np.array(F.subs(sample),float);ptsP=np.vstack([vn.T,-vn.T]);ptsQ=np.vstack([fn,-fn]);assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==22
 tetP=list(PRIMAL_TETRAHEDRA);assert len(tetP)==len(set(tetP))==32;pb=base.check_closed_sphere(tetP);pfc=base.check_facet_balls(tetP,facP)
 for tet in tetP:assert len([k for k,f in enumerate(facP) if set(tet)<=set(f)])==1
 tetQ=[z for f in facQ for z in base.pulling_triangulation(f,ptsQ)];assert len(tetQ)==len(set(tetQ));qfc=base.check_facet_balls(tetQ,facQ)
 def pointP(i):return V[:,i] if i<6 else -V[:,i-6]
 def pointQ(i):return F[i,:].T if i<11 else -F[i-11,:].T
 def oriented(tets,point,label):
  terms=[];recs=[]
  for k,ids in enumerate(tets):
   det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge')));assert det!=0;sg=1 if det.subs(sample)>0 else -1;ce=eng.positive_rational(sg*det,f'{label}{k}');terms.append(sp.factor(sg*det));recs.append({'ids':list(ids),'signed_determinant':str(sp.factor(sg*det)),'certificate':ce})
  return terms,recs
 pt,pr=oriented(tetP,pointP,'P');qt,qr=oriented(tetQ,pointQ,'Q');volP=sp.factor(sp.cancel(sum(pt)/24));volQ=sp.factor(sp.cancel(sum(qt)/24));margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3)));mc=eng.positive_rational(margin,'margin')
 cert={'status':'PASS','scope':'4D symmetric Mahler bounded-12; 12V/22F,c=0,D=17 Family 2007','canonical_id':CID,'canonical_key':rec['canonical_key'],'rank':4,'rank_trace':{'constant_elimination_steps':trace,'strict_relation':'x0_1=x1_1','relation_ratio':relratio},'coefficient_certificates':coeff,'parameters':['A','B','C'],'parameter_domain':'0<A,B,C<1; a=2A-1, c=2C-1, b=(A-1+2B)/(A+1), equivalently -1<a,c<1 and (a-1)/(a+3)<b<1','completion':{str(k):str(v) for k,v in sol.items()},'strict_defects':len(defects),'defect_certificates':defects,'primal_vertices':12,'polar_vertices':22,'extremality':ext,'facet_size_counts_primal':dict(Counter(map(len,facP))),'facet_size_counts_polar':dict(Counter(map(len,facQ))),'primal_boundary':pb,'primal_triangulation_source':{'source_local_id':1322,'source_sphere_orbit':5,'signed_coordinate_permutation':{'permutation':[0,3,4,1,2,5],'signs':[1,1,1,1,-1,1]}},'primal_facet_tetrahedra':pfc,'polar_facet_tetrahedra':qfc,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'orientation_records_primal':pr,'orientation_records_polar':qr,'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'fixed_sign_polynomials':len(eng.cache),'source_hashes':{str(PRE):sha256(PRE)},'conclusion':'Family 2007 has Mahler product >32/3 throughout its full strict realization space.'}
 CERT.write_text(json.dumps(cert,indent=2,sort_keys=True));out={'status':'PASS','canonical_id':CID,'rank':4,'strict_defects':len(defects),'primal_vertices':12,'polar_vertices':22,'tetrahedra_primal':len(tetP),'tetrahedra_polar':len(tetQ),'volume_P':str(volP),'volume_polar':str(volQ),'Mahler_margin':str(margin),'margin_certificate':mc,'certificate':str(CERT),'certificate_sha256':sha256(CERT),'conclusion':cert['conclusion']};OUT.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
