# Four-dimensional symmetric Mahler, bounded-12: first exact `20F, D=14` preclassification

Date: 20 August 2026

## Combinatorial setup

For

\[
12V/20F,\qquad c=0,\qquad D=14,
\]

there are

\[
6\text{ single-defect facet pairs}
+4\text{ double-defect facet pairs}.
\]

Triangulating each five-vertex facet without adding vertices produces a centrally symmetric simplicial three-sphere with

\[
\boxed{f=(12,44,64,32)},
\qquad
\boxed{g_2=6}.
\]

Equivalently, it contains sixteen antipodal tetrahedron pairs.

## Direct sphere enumeration

The enumeration fixes one tetrahedron pair and does not assume any bistellar-generation theorem.

The exact backtracking search found

\[
32,016
\]

closed centrally symmetric pseudomanifolds in the fixed-facet slice.  Full vertex-link checks retained

\[
\boxed{16,944}
\]

centrally symmetric simplicial three-spheres, all with the expected f-vector.

Under the projective signed-permutation group

\[
B_6/\{\pm I\},
\]

they form exactly

\[
\boxed{15\text{ combinatorial orbits}}.
\]

The fixed-facet orbit sizes are

\[
1536,768,1536,1536,3072,1536,768,768,768,384,384,48,1536,768,1536.
\]

## Ridge-merge enumeration

Six compatible antipodal ridge pairs must be merged to recover

\[
6\text{ pairs of five-vertex facets}
+4\text{ pairs of tetrahedral facets}.
\]

Across the fifteen sphere types, exact automorphism reduction leaves

\[
\boxed{7,071\text{ local matching representatives}}.
\]

Global signed-coordinate canonicalization reduces these to

\[
\boxed{4,319\text{ pairing sign templates}}.
\]

The exact multi-affine `5 x 5` minor corner certificates classify them as

\[
\boxed{
4,319
=4,024\text{ rank-}\ge5
+268\text{ repeated-row}
+27\text{ algebraic survivors}.
}
\]

The twenty-seven surviving template indices are

\[
\begin{aligned}
&8,154,447,461,959,1065,1102,1106,1282,1770,1838,2391,2411,\\
&2503,2651,2653,2723,2742,2744,2815,2871,3775,4086,4211,4300,4304,4318.
\end{aligned}
\]

## Current status

This is an exact combinatorial and low-rank preclassification, not a closure of the `D=14` layer.  The next task is to decompose the twenty-seven survivors into rational rank-four components, then apply vertex-loss, extra-section-vertex, and Mahler-margin certificates.

The standalone artifact verifier checks all stored file hashes and the counts above and returns `PASS`.
