# Final three algebraic families in the `12V/20F, c=0, D=15` layer

Date: 20 August 2026

All conclusions below are **computer-assisted analytic proof candidates**.  Each family is checked by exact rational rank completion, an exact realization-domain parametrization, global fixed-sign boundary triangulations, and tensor-Bernstein positivity of the Mahler margin.

## Family 396

Use the free defects

\[
a=x_{2,0},\qquad b=x_{3,0},\qquad c=x_{4,0},\qquad t=x_{7,3}.
\]

The constant pivot on rows `(2,3,4,7)` and columns `(1,2,4,5)` has determinant `-8`.  The Schur equations have a unique rational completion in these four variables.

Define

\[
P=\frac{b+1}{2},\qquad
Q=\frac{1-a+b+c}{2},\qquad
R=a-b,\qquad
S=-\frac{a+c}{2}.
\]

Then `P+Q+R+S=1`.  Factoring all fifteen expressions `1-x_{ij}^2` shows that the full strict branch is exactly

\[
P,Q,R,S>0,\qquad -1<t<1,
\qquad (1-t)R<2(1+t)S.
\]

It is rationally equivalent to the open unit four-cube.  Put

\[
P=A,\quad Q=(1-A)B,\quad R=(1-A)(1-B)C,
\quad S=(1-A)(1-B)(1-C),
\]

and

\[
t=\frac{R-2S+4SD}{R+2S},\qquad 0<A,B,C,D<1.
\]

The inverse is

\[
A=P,\qquad B=\frac{Q}{1-P},\qquad C=\frac{R}{R+S},
\]

\[
D=\frac{(t-1)R+2(t+1)S}{4S}.
\]

The verifier certifies twelve primal vertices and twenty polar vertices.  A globally valid boundary decomposition uses `31` primal and `68` polar tetrahedra.  The Mahler-margin numerator has tensor degree

\[
(2,3,5,2)
\]

with

\[
118>0,\qquad 98=0,\qquad 0<0,
\]

and smallest positive Bernstein coefficient `32/15`.  The denominator has degree `(1,2,4,0)`, with `21` positive and `9` zero coefficients and smallest positive coefficient `6`.  Hence

\[
|P|\,|P^\circ|>\frac{32}{3}
\]

on the complete strict realization space.

## Family 728

Use

\[
a=x_{1,0},\qquad b=x_{2,0},\qquad c=x_{5,0},\qquad t=x_{9,1}.
\]

The pivot on rows `(1,2,5,9)` and columns `(2,3,4,5)` has determinant `-8`, and the rank-four completion is uniquely rational.

Define

\[
P=\frac{a+1}{2},\qquad
Q=\frac{1+a-b+c}{2},\qquad
R=\frac{b-a}{2},\qquad
S=-\frac{a+c}{2}.
\]

The exact strict domain is

\[
P,Q,R,S>0,\qquad P+Q+R+S=1,
\]

\[
-1<t<1,\qquad 2R>(1+t)S.
\]

Let `T=(1+t)/2`, `W=R-TS`, and `Z=(1+T)S`.  Then

\[
P,Q,W,Z>0,\qquad P+Q+W+Z=1.
\]

Use the cube map

\[
P=A,\quad Q=(1-A)B,\quad W=(1-A)(1-B)C,
\quad Z=(1-A)(1-B)(1-C),\quad T=D.
\]

Recover

\[
S=\frac{Z}{1+D},\qquad R=W+\frac{DZ}{1+D},
\]

\[
a=2P-1,\qquad b=a+2R,\qquad c=-a-2S,
\qquad t=2D-1.
\]

The exact verifier certifies twelve primal and twenty polar vertices, using `32` primal and `66` polar tetrahedra.  The Mahler-margin numerator has degree

\[
(2,3,4,6)
\]

with `228` positive and `192` zero Bernstein coefficients, no negative coefficient, and smallest positive coefficient `4/45`.  Its denominator has degree `(1,2,3,4)`, with `65` positive and `55` zero coefficients and smallest positive coefficient `3/8`.  Therefore the Mahler margin is strictly positive throughout the family.

## Family 509

Use

\[
a=x_{0,0},\qquad b=x_{2,0},\qquad t=x_{8,1}.
\]

The pivot on rows `(0,2,4,8)` and columns `(2,3,4,5)` has determinant `8`.  Before solving for these three free quantities, four apparent variables satisfy the bilinear relation

\[
a d-a+bc-b+c-d=0.
\]

Solving it and the remaining Schur equations yields the unique three-parameter rational component recorded in the verifier.

Define

\[
P=\frac{b+1}{2},\qquad Q=\frac{a-b}{2},\qquad R=\frac{1-a}{2}.
\]

Then `P+Q+R=1`.  The full strict domain is exactly

\[
P,Q,R>0,\qquad -1<t<0,
\]

\[
(1+t)Q<2(-t)R.
\]

Writing `T=-t`, introduce

\[
P=A,\qquad Q=(1-A)B,\qquad R=(1-A)(1-B),
\]

\[
T=\frac{Q+2RC}{Q+2R},\qquad 0<A,B,C<1.
\]

Thus

\[
a=2(P+Q)-1,\qquad b=2P-1,\qquad t=-T.
\]

The inverse coordinate is

\[
C=\frac{T(Q+2R)-Q}{2R}.
\]

The verifier obtains twelve primal and twenty polar vertices, with `36` primal and `69` polar tetrahedra.  The margin numerator has degree `(3,8,4)` and Bernstein statistics

\[
100>0,\qquad80=0,\qquad0<0,
\]

with smallest positive coefficient `1/21`.  The denominator has degree `(2,6,3)`, with `45` positive and `39` zero coefficients and smallest positive coefficient `1/5`.  Hence the Mahler product is strictly greater than `32/3` on the entire family.

## Consequence for the layer

The exact preclassification of the layer is

\[
748
=669\text{ rank-}\ge5
+51\text{ repeated-row}
+28\text{ algebraic survivors}.
\]

Two survivors (`44,342`) lose a primal vertex pair.  The remaining twenty-six, including `396,509,728`, have strictly positive Mahler margin.  Consequently

\[
\boxed{12V/20F,\quad c=0,\quad D=15\quad\checkmark}
\]

as a computer-assisted analytic proof candidate.
