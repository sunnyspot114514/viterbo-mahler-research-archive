#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
BASE=Path('/mnt/data'); W=BASE/'viterbo_d14_work'
cert=json.loads((BASE/'viterbo_20f_d14_preclassification_certificate.json').read_text())
def sha(p):return hashlib.sha256((W/p).read_bytes()).hexdigest()
for f,h in cert['hashes'].items():assert sha(f)==h,(f,sha(f),h)
assert sum(1 for _ in open(W/'sphere_solutions.txt'))==32016
assert sum(1 for _ in open(W/'valid_spheres.txt'))==16944
assert sum(1 for _ in open(W/'sphere_orbits.txt'))==15
raw=json.loads((W/'raw_templates_d14.json').read_text());assert raw['local_representatives']==7071
keys=(W/'unique_templates.txt').read_text().splitlines();assert len(keys)==4319 and len(set(keys))==4319
counts={};surv=[]
for line in (W/'minor_classification.txt').read_text().splitlines():
 p=line.split();counts[p[1]]=counts.get(p[1],0)+1
 if p[1]=='SURV':surv.append(int(p[0]))
assert counts=={'DUP':268,'RANK':4024,'SURV':27}
assert surv==cert['algebraic_survivor_indices']
out={'status':'PASS','scope':cert['scope'],'closed_pseudomanifolds':32016,'valid_cs_3_spheres':16944,'sphere_orbits':15,'local_matching_representatives':7071,'global_pairing_templates':4319,'rank_ge_5':4024,'duplicate_rows':268,'algebraic_survivors':27,'survivor_indices':surv}
(BASE/'viterbo_20f_d14_preclassification_verifier_output.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
