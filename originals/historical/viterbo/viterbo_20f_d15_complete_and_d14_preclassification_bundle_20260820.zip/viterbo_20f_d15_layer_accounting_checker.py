#!/usr/bin/env python3
import json
from pathlib import Path
BASE=Path('/mnt/data')
pre=json.loads((BASE/'viterbo_20f_d15_preclassification_certificate.json').read_text())
preout=json.loads((BASE/'viterbo_d15_work/preclassification_verifier_output.json').read_text())
vl=json.loads((BASE/'viterbo_d15_work/vertex_loss_verifier_output.json').read_text())
old=json.loads((BASE/'viterbo_20f_d15_progress_v8_20260820.json').read_text())
new={i:json.loads((BASE/f'viterbo_20f_d15_family{i}_verifier_output.json').read_text()) for i in (396,509,728)}
assert preout['status']=='PASS'
assert preout['pairing_templates']==748 and preout['rank_ge_5']==669 and preout['duplicate_rows']==51 and preout['algebraic_survivors']==28
assert vl['status']=='PASS'
assert set(old['remaining'])=={396,509,728}
assert len(old['mahler_positive'])==23
assert all(x['status']=='PASS' and x['conclusion']=='Mahler product > 32/3 on the full strict realization space' for x in new.values())
assert {x['template_index'] for x in new.values()}=={396,509,728}
surv=set(pre['survivor_indices']); vertex_loss={44,342}; positive=set(old['mahler_positive'])|set(new)
assert vertex_loss.isdisjoint(positive)
assert vertex_loss|positive==surv
assert len(positive)==26 and len(surv)==28
out={
 'status':'PASS',
 'scope':'4D symmetric Mahler, bounded-12, 12V/20F,c=0,D=15',
 'preclassification':{'templates':748,'rank_ge_5':669,'duplicate_rows':51,'algebraic_survivors':28},
 'vertex_loss':sorted(vertex_loss),
 'mahler_positive':sorted(positive),
 'remaining':[],
 'accounting':{'rank_ge_5':669,'duplicate_rows':51,'vertex_loss':2,'mahler_positive':26,'remaining':0,'total':748},
 'newly_closed':[396,509,728],
 'conclusion':'12V/20F,c=0,D=15 is closed as a computer-assisted analytic proof candidate'
}
(BASE/'viterbo_20f_d15_layer_accounting_checker_output.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
