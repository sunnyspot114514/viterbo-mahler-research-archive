#!/usr/bin/env python3
from __future__ import annotations
import itertools, json, math
from collections import Counter, defaultdict, deque
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull


def cube_bernstein(poly, vars_):
    P=sp.Poly(sp.expand(poly),*vars_,domain='QQ')
    deg=tuple(map(int,P.degree_list())); co=dict(P.terms()); out=[]
    for ii in itertools.product(*[range(d+1) for d in deg]):
        z=sp.Rational(0)
        for kk,cc in co.items():
            if all(kk[j]<=ii[j] for j in range(len(vars_))):
                f=sp.Rational(1)
                for j,d in enumerate(deg):
                    f*=sp.Rational(math.comb(ii[j],kk[j]),math.comb(d,kk[j]))
                z+=cc*f
        out.append(sp.factor(z))
    return deg,out

def bstat(poly, vars_):
    deg,arr=cube_bernstein(poly,vars_)
    pos=[x for x in arr if x.is_positive]; zero=[x for x in arr if x.is_zero]
    neg=[x for x in arr if x.is_negative]; unk=[x for x in arr if not(x.is_positive or x.is_zero or x.is_negative)]
    return {'degree':list(deg),'positive':len(pos),'zero':len(zero),'negative':len(neg),'unknown':len(unk),'min_positive':str(min(pos)) if pos else None}

def project3(x):
    d=x-x[0]
    return d@np.linalg.svd(d,full_matrices=False)[2][:3].T

def pull(ids,coords):
    ids=sorted(ids)
    if len(ids)==4:return [tuple(ids)]
    pr=project3(coords[ids]); h=ConvexHull(pr); out=set()
    for tri,eqn in zip(h.simplices,h.equations):
        if abs(float(eqn[:-1]@pr[0]+eqn[-1]))<1e-8:continue
        out.add(tuple(sorted([ids[0]]+[ids[i] for i in tri])))
    return sorted(out)

def check_closed_sphere(tets,nverts):
    tets=[tuple(sorted(t)) for t in tets]; assert len(set(tets))==len(tets)
    tris=Counter(tuple(sorted(q)) for t in tets for q in itertools.combinations(t,3)); assert set(tris.values())=={2}
    by=defaultdict(list)
    for k,t in enumerate(tets):
        for q in itertools.combinations(t,3):by[tuple(sorted(q))].append(k)
    adj=[set() for _ in tets]
    for ids in by.values():
        assert len(ids)==2; adj[ids[0]].add(ids[1]); adj[ids[1]].add(ids[0])
    seen={0}; dq=deque([0])
    while dq:
        k=dq.popleft()
        for l in adj[k]:
            if l not in seen:seen.add(l);dq.append(l)
    assert len(seen)==len(tets)
    return {'tetrahedra':len(tets),'triangles':len(tris),'vertices':nverts}

def check_facet_balls(tets,facets):
    counts=[]
    for f in facets:
        group=[tuple(t) for t in tets if set(t)<=set(f)]; assert group and set(x for t in group for x in t)==set(f)
        tri=Counter(tuple(sorted(q)) for t in group for q in itertools.combinations(t,3)); assert max(tri.values())<=2
        btri=[q for q,n in tri.items() if n==1]; bvs=set(x for q in btri for x in q); bes=set(tuple(sorted(e)) for q in btri for e in itertools.combinations(q,2))
        assert len(bvs)-len(bes)+len(btri)==2
        counts.append(len(group))
    return {'facets':len(facets),'tetrahedra':len(tets),'per_facet':counts}

def verify(config_path, output_path):
    cfg=json.loads(Path(config_path).read_text()); idx=cfg['index']; key=cfg['template_key']; rs=tuple(cfg['pivot_rows']); cs=tuple(cfg['pivot_cols'])
    cube_names=cfg['cube_vars']; cube=sp.symbols(' '.join(cube_names)); cube=(cube,) if len(cube_names)==1 else tuple(cube)
    locals_={n:v for n,v in zip(cube_names,cube)}
    sample={v:sp.Rational(s) for v,s in zip(cube,cfg['sample'])}
    names=set(cfg['free'])|set(cfg['solution']); loc={n:sp.symbols(n) for n in names}; locals_.update(loc)
    free=[loc[n] for n in cfg['free']]
    sol={loc[n]:sp.sympify(s,locals=locals_) for n,s in cfg['solution'].items()}
    pmap={loc[n]:sp.sympify(s,locals=locals_) for n,s in cfg['parameter_map'].items()}
    M=[]; templ=[]; defects=[]
    for i in range(10):
        row=[]; tr=[]
        for j,ch in enumerate(key[6*i:6*i+6]):
            z=int(ch)-1; tr.append(z)
            if z==0:
                v=sp.symbols(f'x{i}_{j}'); expr=sp.factor(sp.cancel(sol.get(v,v).subs(pmap))); row.append(expr); defects.append((i,j,str(v)))
            else:row.append(sp.Integer(z))
        M.append(row);templ.append(tr)
    M=sp.Matrix(M); assert len(defects)==15
    P=M.extract(rs,cs); assert str(P.det())==cfg['pivot_det']
    ri=[i for i in range(10) if i not in rs]; cj=[j for j in range(6) if j not in cs]
    assert all(sp.factor(x)==0 for x in M.extract(ri,cj)-M.extract(ri,cs)*P.inv()*M.extract(rs,cj))
    cache={}
    def positive_poly(poly):
        poly=sp.factor(poly); k=sp.srepr(poly)
        if k not in cache:cache[k]=bstat(poly,cube)
        st=cache[k]; assert st['negative']==0 and st['unknown']==0 and st['positive']>0,(poly,st)
        return st
    def positive_rat(expr):
        expr=sp.factor(sp.cancel(expr)); assert expr.subs(sample)>0,expr
        n,d=map(sp.factor,sp.together(expr).as_numer_denom())
        if d.subs(sample)<0:n,d=-n,-d
        return {'numerator':positive_poly(n),'denominator':positive_poly(d)}
    for i,j,nm in defects:positive_rat(1-M[i,j]**2)
    VM=(P.inv()*M.extract(rs,range(6))).applyfunc(lambda z:sp.factor(sp.cancel(z))); FM=M.extract(range(10),cs)
    assert all(sp.factor(x)==0 for x in FM*VM-M)
    extremality=[]
    for j in range(6):
        inc=[i for i in range(10) if templ[i][j]!=0]; found=None
        for rr in itertools.combinations(inc,4):
            det=sp.factor(FM.extract(rr,range(4)).det(method='domain-ge'))
            if det==0:continue
            sg=1 if det.subs(sample)>0 else -1
            try:positive_rat(sg*det)
            except AssertionError:continue
            found=(j,rr,str(det));break
        assert found is not None,j; extremality.append(found)
    Vnum=np.array(VM.subs(sample),float); Fnum=np.array(FM.subs(sample),float)
    ptsP=np.vstack([Vnum.T,-Vnum.T]); ptsQ=np.vstack([Fnum,-Fnum]); Acode=np.array(templ,int)
    assert len(ConvexHull(ptsP).vertices)==12 and len(ConvexHull(ptsQ).vertices)==20
    facP=[]
    for i in range(10):
        facP += [sorted(j if Acode[i,j]==1 else j+6 for j in range(6) if Acode[i,j]),sorted(j+6 if Acode[i,j]==1 else j for j in range(6) if Acode[i,j])]
    facQ=[]
    for j in range(6):
        facQ += [sorted(i if Acode[i,j]==1 else i+10 for i in range(10) if Acode[i,j]),sorted(i+10 if Acode[i,j]==1 else i for i in range(10) if Acode[i,j])]
    tP=[t for f in facP for t in pull(f,ptsP)]; tQ=[t for f in facQ for t in pull(f,ptsQ)]
    assert len(tP)==cfg['expected_primal_tetrahedra'] and len(tQ)==cfg['expected_polar_tetrahedra']
    sphP=check_closed_sphere(tP,12); ballsP=check_facet_balls(tP,facP); ballsQ=check_facet_balls(tQ,facQ)
    def ppoint(i):return VM[:,i] if i<6 else -VM[:,i-6]
    def qpoint(i):return FM[i,:].T if i<10 else -FM[i-10,:].T
    def oriented(tets,point):
        terms=[]
        for ids in tets:
            det=sp.factor(sp.cancel(sp.Matrix.hstack(*[point(i) for i in ids]).det(method='domain-ge'))); assert det!=0
            sg=1 if det.subs(sample)>0 else -1; positive_rat(sg*det); terms.append(sp.factor(sg*det))
        return terms
    pterms=oriented(tP,ppoint); qterms=oriented(tQ,qpoint)
    volP=sp.factor(sp.cancel(sum(pterms)/24)); volQ=sp.factor(sp.cancel(sum(qterms)/24))
    margin=sp.factor(sp.cancel(volP*volQ-sp.Rational(32,3))); assert margin.subs(sample)>0
    n,d=map(sp.factor,sp.together(margin).as_numer_denom())
    if d.subs(sample)<0:n,d=-n,-d
    ns=positive_poly(n); ds=positive_poly(d)
    for expected,actual in [(cfg['margin_n'],ns),(cfg['margin_d'],ds)]:
        for k in ['degree','positive','zero','negative','min_positive']:
            assert expected[k]==actual[k],(k,expected[k],actual[k])
    out={'status':'PASS','scope':'12V/20F,c=0,D=15','template_index':idx,'domain':cfg['domain'],'rank':4,'strict_defects':15,'primal_vertices':12,'polar_vertices':20,'primal_boundary':sphP,'primal_facet_balls':ballsP,'polar_facet_balls':ballsQ,'primal_tetrahedra':len(tP),'polar_tetrahedra':len(tQ),'volume_P':str(volP),'volume_polar':str(volQ),'margin_numerator_bernstein':ns,'margin_denominator_bernstein':ds,'fixed_sign_polynomials_checked':len(cache),'conclusion':'Mahler product > 32/3 on the full strict realization space'}
    Path(output_path).write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2)); return out

if __name__=='__main__':
    import sys
    verify(sys.argv[1],sys.argv[2])
