from itertools import combinations,product
from collections import Counter,defaultdict
from pathlib import Path
import json,sys
WORK=Path(sys.argv[1] if len(sys.argv)>1 else '.')
def norm(a):
 a=tuple(a)
 for x in a:
  if x:return tuple(-y for y in a) if x<0 else a
 return a
facets=[];seen=set()
for mask in range(64):
 if mask.bit_count()!=4:continue
 inds=[j for j in range(6) if mask>>j&1]
 for signs in product((-1,1),repeat=4):
  a=[0]*6
  for j,s in zip(inds,signs):a[j]=s
  k=norm(a)
  if k not in seen:seen.add(k);facets.append(k)
facets.sort()
def tet(row,neg=False):
 s=-1 if neg else 1
 return tuple(sorted(s*row[i]*(i+1) for i in range(6) if row[i]))
def link_sphere(tets,v):
 tris=list({tuple(sorted(x for x in T if x!=v)) for T in tets if v in T})
 if not tris:return False
 ec=Counter();verts=set()
 for tr in tris:
  verts.update(tr)
  for e in combinations(tr,2):ec[tuple(sorted(e))]+=1
 if any(c!=2 for c in ec.values()):return False
 # triangle adjacency connected
 et=defaultdict(list)
 for i,tr in enumerate(tris):
  for e in combinations(tr,2):et[tuple(sorted(e))].append(i)
 adj=[set() for _ in tris]
 for ids in et.values():
  if len(ids)!=2:return False
  a,b=ids;adj[a].add(b);adj[b].add(a)
 vis={0};stack=[0]
 while stack:
  i=stack.pop()
  for j in adj[i]:
   if j not in vis:vis.add(j);stack.append(j)
 if len(vis)!=len(tris):return False
 # vertex links inside link are connected cycles
 for w in verts:
  g=defaultdict(set)
  for tr in tris:
   if w in tr:
    a,b=[x for x in tr if x!=w];g[a].add(b);g[b].add(a)
  if not g or any(len(ns)!=2 for ns in g.values()):return False
  st=next(iter(g));vv={st};q=[st]
  while q:
   x=q.pop()
   for y in g[x]:
    if y not in vv:vv.add(y);q.append(y)
  if len(vv)!=len(g):return False
 return len(verts)-len(ec)+len(tris)==2
def valid(ids):
 t=[]
 for i in ids:t.extend((tet(facets[i]),tet(facets[i],True)))
 verts={x for T in t for x in T}
 if verts != set(range(1,7))|set(range(-6,0)):return False,None
 edges=set();tc=Counter()
 for T in t:
  for e in combinations(T,2):edges.add(tuple(sorted(e)))
  for tr in combinations(T,3):tc[tuple(sorted(tr))]+=1
 if any(c!=2 for c in tc.values()):return False,None
 if not all(link_sphere(t,v) for v in verts):return False,None
 return True,(12,len(edges),len(tc),len(t))
valids=[];fvec=Counter()
for line in open(WORK/'sphere_solutions.txt'):
 ids=tuple(map(int,line.split()));ok,f=valid(ids)
 if ok:valids.append(tuple(sorted(ids)));fvec[f]+=1
with open(WORK/'valid_spheres.txt','w') as out:
 for s in valids:out.write(' '.join(map(str,s))+'\n')
json.dump({'closed_pseudomanifolds':sum(1 for _ in open(WORK/'sphere_solutions.txt')),'valid_spheres_fixed_facet':len(valids),'f_vectors':{str(k):v for k,v in fvec.items()}},open(WORK/'filter_output.json','w'),indent=2)
print(json.dumps(json.load(open(WORK/'filter_output.json')),indent=2))
