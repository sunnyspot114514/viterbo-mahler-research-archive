#!/usr/bin/env python3
from viterbo_d15_final_family_common import verify
verify('/mnt/data/viterbo_20f_d15_family509_config.json','/mnt/data/viterbo_20f_d15_family509_verifier_output.json')
