# Four-dimensional symmetric Mahler, bounded-12: `20F, D=15` complete

Date: 20 August 2026

## Milestone

The final three algebraic survivors in

\[
12V/20F,\qquad c=0,\qquad D=15
\]

have been closed:

\[
\boxed{396,\ 509,\ 728\quad\checkmark}.
\]

Consequently the exact layer accounting is

\[
\boxed{
748
=669\text{ rank-}\ge5
+51\text{ repeated-row}
+2\text{ primal-vertex-loss}
+26\text{ Mahler-positive}
}.
\]

There are no remaining algebraic survivors.  Thus

\[
\boxed{12V/20F,\ c=0,\ D=15\quad\checkmark}
\]

as a **computer-assisted analytic proof candidate**.

This does not yet prove the complete four-dimensional conjecture.  External review, a unified third-party replay, the remaining bounded-12 layers, and a complexity-independent reduction theorem are still required.

## Family 396

The Schur system has a unique four-parameter rational completion.  Its strict realization domain is an open tetrahedron times an interval, rationally equivalent to the unit four-cube.

A globally fixed boundary triangulation contains

\[
31\text{ primal tetrahedra},\qquad68\text{ polar tetrahedra}.
\]

The Mahler-margin numerator has tensor-Bernstein degree

\[
(2,3,5,2)
\]

with

\[
118>0,\qquad98=0,\qquad0<0,
\]

and smallest positive coefficient

\[
\frac{32}{15}.
\]

The denominator has degree `(1,2,4,0)`, with `21` positive and `9` zero coefficients and minimum positive coefficient `6`.

## Family 509

The apparent four-variable Schur coordinates satisfy the exact bilinear relation

\[
ad-a+bc-b+c-d=0,
\]

and the strict rank-four component reduces to a three-parameter rational family.  Its domain is an open triangle times an interval, rationally equivalent to the unit three-cube.

The verifier uses

\[
36\text{ primal tetrahedra},\qquad69\text{ polar tetrahedra}.
\]

The margin numerator has degree `(3,8,4)` and statistics

\[
100>0,\\ 80=0,
\qquad \min_+=\frac1{21}.
\]

The denominator has degree `(2,6,3)`, with `45` positive and `39` zero coefficients and minimum positive coefficient `1/5`.

## Family 728

This is another genuine four-parameter family.  Its exact domain is obtained from an open tetrahedron by the inequality

\[
2R>(1+t)S,
\]

and becomes the open unit four-cube after a rational change of variables.

The fixed boundary triangulations contain

\[
32\text{ primal tetrahedra},\qquad66\text{ polar tetrahedra}.
\]

The margin numerator has degree `(2,3,4,6)` with

\[
228>0,
\qquad192=0,
\qquad \min_+=\frac4{45}.
\]

The denominator has degree `(1,2,3,4)`, with `65` positive and `55` zero coefficients and minimum positive coefficient `3/8`.

## Verification status

The three standalone verifiers each check:

1. the exact rank-four Schur completion;
2. all fifteen strict defect inequalities on the full parameter domain;
3. all twelve primal vertices remain extreme;
4. the prescribed twenty polar vertices and the closed boundary complexes;
5. globally fixed signs of every simplex determinant used in the volume formulas;
6. exact volumes and Bernstein positivity of
   \(|P||P^\circ|-32/3\).

Each returned `PASS`.  The layer-accounting checker also returned `PASS` and confirms that the twenty-eight preclassified survivors are exactly the two vertex-loss branches and twenty-six positive-margin branches.
